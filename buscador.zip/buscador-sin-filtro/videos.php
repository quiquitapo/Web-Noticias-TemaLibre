<?php
/** Explorar: galería de videos, noticias y fotos con búsqueda, categorías y filtros. */
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$f = filtros_desde_url($_GET);
$catActual = $f['cat'] !== '' ? categoria_por_slug($f['cat']) : null;
// Ventas ahora se llama Productos: las direcciones antiguas siguen funcionando
if (!$catActual && preg_match('/^ventas(-.+)?$/', $f['cat'], $m) && ($nueva = categoria_por_slug('productos' . ($m[1] ?? '')))) {
    redirigir(url('videos.php', filtros_a_url($f, ['cat' => $nueva['slug']])), 301);
}
if (!$catActual) {
    $f['cat'] = '';
}
$res = explorar($f);
$fac = facetas($f);
if ($f['q'] !== '' && $res['pagina'] === 1) {
    registrar_busqueda($f['q'], $res['total']);
}
$raiz = $catActual ? ($catActual['padre_slug'] ?: $catActual['slug']) : '';
$titulo = $f['q'] !== '' ? 'Resultados para “' . $f['q'] . '”'
    : ($catActual ? ($catActual['padre_nombre'] ? $catActual['padre_nombre'] . ': ' : '') . $catActual['nombre'] : 'Todos los videos');

vista('cabecera', [
    'titulo' => $titulo,
    'seccion' => $f['q'] !== '' ? 'buscar' : 'videos',
    'nav_activo' => nav_de_seccion($raiz),
    'descripcion' => $catActual['descripcion'] ?? config('app.descripcion'),
    'sin_indexar' => $f['q'] !== '' || count(filtros_a_url($f, ['q' => '', 'cat' => ''])) > 0,
]);
vista('explorar', ['f' => $f, 'res' => $res, 'fac' => $fac, 'catActual' => $catActual, 'raiz' => $raiz, 'titulo' => $titulo]);
vista('pie', ['seccion' => $f['q'] !== '' ? 'buscar' : 'videos']);
