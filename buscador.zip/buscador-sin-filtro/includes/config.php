<?php
/**
 * Configuración de Sin Filtro.
 * Cada valor se puede sobrescribir con una variable de entorno (útil en producción).
 */
declare(strict_types=1);

$env = static fn(string $k, $def) => ($v = getenv($k)) !== false && $v !== '' ? $v : $def;

return [
    'app' => [
        'nombre'      => 'Sin Filtro',
        'lema'        => 'Contra la corrupción y los videos falsos: el algoritmo lo controlas tú.',
        'descripcion' => 'Buscador privado de noticias y videos con filtros de orientación y verificación.',
        // Déjalo vacío para detectarlo solo. Ejemplo si va en subcarpeta: '/buscador-sin-filtro'
        'url_base'    => $env('SF_URL_BASE', ''),
        // 'desarrollo' muestra errores en pantalla; 'produccion' los guarda en logs/
        'entorno'     => $env('SF_ENTORNO', 'desarrollo'),
        'zona_horaria' => 'America/Santiago',
        // Muestra las cuentas de prueba en el formulario de acceso. Desactívalo en producción.
        'mostrar_cuenta_demo' => $env('SF_CUENTA_DEMO', '1') === '1',
        'por_pagina'  => 24,
    ],

    'db' => [
        // 'sqlite' funciona sin instalar nada. Para MySQL/MariaDB usa 'mysql'.
        'driver'      => $env('SF_DB_DRIVER', 'sqlite'),
        'sqlite_ruta' => $env('SF_DB_SQLITE', __DIR__ . '/../sql/buscador.sqlite'),
        'host'        => $env('SF_DB_HOST', '127.0.0.1'),
        'puerto'      => $env('SF_DB_PUERTO', '3306'),
        'nombre'      => $env('SF_DB_NOMBRE', 'buscador_sin_filtro'),
        'usuario'     => $env('SF_DB_USUARIO', 'root'),
        'clave'       => $env('SF_DB_CLAVE', ''),
    ],

    'privacidad' => [
        // Guarda los términos buscados (sin IP ni usuario) solo para mostrar "Lo más buscado".
        'registrar_busquedas' => $env('SF_REGISTRAR_BUSQUEDAS', '1') === '1',
        // Las IP de los registros se guardan recortadas (última parte en cero).
        'anonimizar_ip' => true,
    ],

    'subidas' => [
        'video_max_mb'  => (int) $env('SF_VIDEO_MAX_MB', '512'),
        'imagen_max_mb' => 8,
        'imagen_max_px' => 6000,   // lado máximo aceptado; además se revisa que quepa en memory_limit
        'max_fotos'     => 12,
    ],

    // Videos de YouTube: miniaturas y datos del canal que el servidor descarga una vez (ver includes/youtube.php)
    'youtube' => [
        'miniaturas' => $env('SF_YT_MINIATURAS', 'https://i.ytimg.com/vi/'),
        'oembed'     => $env('SF_YT_OEMBED', 'https://www.youtube.com/oembed'),
        'hosts'      => $env('SF_YT_HOSTS', 'i.ytimg.com,www.youtube.com'),
    ],

    'seguridad' => [
        'max_intentos'  => 5,   // intentos fallidos de acceso permitidos…
        'ventana_min'   => 15,  // …dentro de esta ventana de minutos
        'clave_min'     => 8,   // largo mínimo de contraseña
    ],

    // Cuentas que se crean al instalar. Cambia las contraseñas antes de publicar el sitio.
    'cuenta_demo' => [
        'nombre' => 'Cuenta de prueba',
        'email'  => 'demo@sinfiltro.test',
        'clave'  => 'demo1234',
    ],
    'cuenta_admin' => [
        'nombre'       => 'Administración',
        'nombre_admin' => 'Equipo Sin Filtro',
        'email'        => 'admin@sinfiltro.test',
        'clave'        => 'admin1234',
    ],
];
