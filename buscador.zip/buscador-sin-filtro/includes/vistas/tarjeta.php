<?php
/**
 * Tarjeta estilo galería de video. Sirve para videos, fotos y noticias.
 * Variables: $p (fila de SQL_TARJETA), $variante ('rejilla'|'fila'), $terminos, $prioridad, $h
 */
$variante = $variante ?? 'rejilla';
$terminos = $terminos ?? [];
$h = $h ?? 'h3';
$enganoso = $p['verificacion'] === 'enganoso';
$conSesion = sesion_iniciada();
$sizes = $variante === 'fila' ? '168px' : '(min-width: 1500px) 320px, (min-width: 1100px) 25vw, (min-width: 640px) 45vw, 100vw';
?>
<article class="tarjeta tarjeta--<?= e($variante) ?> tarjeta--<?= e($p['tipo']) ?><?= $enganoso ? ' tarjeta--enganoso' : '' ?>">
  <div class="tarjeta__media">
    <?= img($p['miniatura'], $variante === 'fila' ? [480] : [480, 960], $sizes, '', 1600, 900, $p['miniatura_color'], ['prioridad' => !empty($prioridad), 'vt' => 'pub-' . $p['id']]) ?>
    <?php if ($enganoso): ?>
      <span class="tarjeta__engano"><?= icono('alerta') ?>Engañoso</span>
    <?php endif; ?>
    <?php if ($p['tipo'] === 'video'): ?>
      <?php if ((int) $p['duracion_seg'] > 0): ?>
        <span class="insignia insignia--dur"><span class="sr">Duración: </span><?= e(duracion((int) $p['duracion_seg'])) ?></span>
      <?php elseif (!empty($p['es_youtube'])): ?>
        <span class="insignia"><?= icono('youtube') ?>YouTube</span>
      <?php else: ?>
        <span class="insignia"><?= icono('video') ?>Video</span>
      <?php endif; ?>
      <?php if (!$conSesion && $variante !== 'fila' && !empty($p['con_video'])): ?><span class="insignia insignia--candado" title="Se reproduce con una cuenta gratis"><?= icono('candado') ?><span class="sr">Requiere cuenta para reproducir</span></span><?php endif; ?>
    <?php elseif ($p['tipo'] === 'imagen'): ?>
      <span class="insignia"><?= icono('fotos') ?><?= (int) $p['n_imagenes'] ?> <?= (int) $p['n_imagenes'] === 1 ? 'foto' : 'fotos' ?></span>
    <?php else: ?>
      <span class="insignia"><?= icono('noticia') ?>Noticia</span>
    <?php endif; ?>
    <?php if ($p['precio'] !== null && $variante !== 'fila'): ?>
      <span class="insignia insignia--precio"><?= e(precio((int) $p['precio'])) ?></span>
    <?php endif; ?>
  </div>
  <div class="tarjeta__cuerpo">
    <?php if ($variante !== 'fila'): ?>
      <span class="avatar-creador" style="--av: <?= e(color_avatar($p['creador'])) ?>" aria-hidden="true"><?= e(iniciales($p['creador'])) ?></span>
    <?php endif; ?>
    <div class="tarjeta__txt">
      <<?= $h ?> class="tarjeta__titulo"><a class="enlace-tarjeta" href="<?= e(url_publicacion($p)) ?>"><?= resaltar($p['titulo'], $terminos) ?></a></<?= $h ?>>
      <p class="tarjeta__creador"><span><?= e($p['creador']) ?></span><?php if ($p['verificacion'] !== 'enganoso'): vista('sello', ['verificacion' => $p['verificacion'], 'compacto' => true]); endif; ?></p>
      <p class="meta"><span><?= e(numero_corto((int) $p['vistas'])) ?> vistas</span><time datetime="<?= e(fecha_iso($p['publicado_en'])) ?>"><?= e(fecha_relativa($p['publicado_en'])) ?></time></p>
      <?php if ($p['orientacion'] !== 'no-aplica'): ?>
        <p class="tarjeta__orientacion"><?php vista('escala', ['orientacion' => $p['orientacion'], 'compacta' => true]); ?></p>
      <?php endif; ?>
    </div>
  </div>
</article>
