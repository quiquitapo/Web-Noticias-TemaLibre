<?php
/**
 * Formulario de preferencias de lectura. Se usa en el diálogo (con JavaScript los cambios se ven al instante)
 * y en preferencias.php (sin JavaScript se guardan con el botón).
 * Variables: $prefijo ('dlg' | 'pag'), $volver
 */
$pref = preferencias();
$px = $prefijo ?? 'pag';
$muestras = ['azul' => '#2340f5', 'violeta' => '#6d28d9', 'verde' => '#047857', 'terracota' => '#b03e12', 'grafito' => '#27272a'];
$iconosTema = ['sistema' => 'memoria', 'claro' => 'sol', 'oscuro' => 'luna'];
$tamTexto = ['normal' => '1.05rem', 'chico' => '.9rem', 'grande' => '1.25rem', 'muy-grande' => '1.45rem'];
$grupo = static function (string $clave, string $leyenda, callable $contenido, string $clase = '') use ($pref, $px): void { ?>
  <fieldset class="prefs__grupo<?= $clase ? ' ' . $clase : '' ?>">
    <legend class="prefs__leyenda"><?= e($leyenda) ?></legend>
    <div class="prefs__opciones prefs__opciones--<?= count(PREFERENCIAS[$clave]) ?>">
      <?php foreach (PREFERENCIAS[$clave] as $v => $t): ?>
        <label class="pref-op">
          <input type="radio" name="<?= e($clave) ?>" value="<?= e((string) $v) ?>"<?= $pref[$clave] === (string) $v ? ' checked' : '' ?> data-pref="<?= e($clave) ?>">
          <span class="pref-op__caja"><?php $contenido((string) $v, $t); ?></span>
        </label>
      <?php endforeach; ?>
    </div>
  </fieldset>
<?php };
?>
<form class="prefs" method="post" action="<?= e(url('preferencias.php')) ?>" data-preferencias>
  <?= csrf_campo() ?><input type="hidden" name="volver" value="<?= e($volver ?? url()) ?>">
  <?php $grupo('tema', 'Tema', static function (string $v, string $t) use ($iconosTema): void { echo icono($iconosTema[$v]) . '<span>' . e($t) . '</span>'; }); ?>
  <?php $grupo('acento', 'Color de acento', static function (string $v, string $t) use ($muestras): void { echo '<span class="pref-op__muestra" style="--m: ' . $muestras[$v] . '"></span><span>' . e($t) . '</span>'; }, 'prefs__grupo--acento'); ?>
  <?php $grupo('texto', 'Tamaño del texto', static function (string $v, string $t) use ($tamTexto): void { echo '<span class="pref-op__aa" style="font-size: ' . $tamTexto[$v] . '" aria-hidden="true">Aa</span><span>' . e($t) . '</span>'; }); ?>
  <div class="prefs__fila">
    <?php $grupo('linea', 'Espacio entre líneas', static function (string $v, string $t): void { echo '<span>' . e($t) . '</span>'; }); ?>
    <?php $grupo('contraste', 'Contraste', static function (string $v, string $t): void { echo '<span>' . e($t) . '</span>'; }); ?>
  </div>
  <?php $grupo('movimiento', 'Animaciones', static function (string $v, string $t): void { echo '<span>' . e($t) . '</span>'; }); ?>

  <fieldset class="prefs__grupo prefs__voz" data-prefs-voz hidden>
    <legend class="prefs__leyenda">Lectura en voz alta</legend>
    <p class="prefs__ayuda">Usa el botón <?= icono('altavoz') ?> <strong>Escuchar</strong> en títulos, descripciones, noticias y comentarios.</p>
    <div class="prefs__opciones prefs__opciones--4">
      <?php foreach (PREFERENCIAS['velocidad'] as $v => $t): ?>
        <label class="pref-op"><input type="radio" name="velocidad" value="<?= e((string) $v) ?>"<?= $pref['velocidad'] === (string) $v ? ' checked' : '' ?> data-pref="velocidad"><span class="pref-op__caja"><span><?= e($t) ?></span><span class="pref-op__det"><?= e(str_replace('.', ',', (string) $v)) ?>×</span></span></label>
      <?php endforeach; ?>
    </div>
    <div class="prefs__voz-fila">
      <div class="campo">
        <label for="<?= $px ?>-voz">Voz</label>
        <select id="<?= $px ?>-voz" data-voces aria-describedby="<?= $px ?>-voz-ayuda"><option value="">Automática (voz del dispositivo en español)</option></select>
      </div>
      <button class="boton boton--suave" type="button" data-probar-voz><?= icono('altavoz') ?>Probar</button>
    </div>
    <p class="prefs__ayuda" id="<?= $px ?>-voz-ayuda">Preferimos las voces de tu dispositivo: el texto no sale de tu equipo. Las marcadas «en línea» las procesa un servicio externo.</p>
  </fieldset>

  <p class="prefs__nota"><?= icono('candado-privado') ?><span>Se guardan solo en este navegador, en una cookie de preferencias sin datos personales. No se usan para medir nada.</span></p>
  <div class="prefs__botones">
    <button class="boton boton--suave" type="submit" name="restablecer" value="1" data-restablecer>Restablecer</button>
    <button class="boton boton--primario" type="submit" data-listo>Guardar</button>
  </div>
</form>
