<?php
/** Pie común: footer, barra inferior móvil, diálogo de búsqueda, diálogo de acceso y avisos. */
$usuario = usuario_actual();
$seccion = $seccion ?? '';
$demo = config('app.mostrar_cuenta_demo') ? config('cuenta_demo') : null;
$flash = flash_obtener();
?>
</main>

<footer class="pie">
  <div class="contenedor pie__in">
    <div class="pie__marca">
      <a class="marca" href="<?= e(url()) ?>">
        <svg class="marca__logo" aria-hidden="true" focusable="false"><use href="#i-logo"/></svg>
        <span class="marca__nombre">sin filtro</span>
      </a>
      <p class="pie__lema"><?= e(config('app.lema')) ?></p>
      <ul class="pie__garantias">
        <li><?= icono('candado-privado') ?>Sin rastreadores ni publicidad</li>
        <li><?= icono('balanza') ?>Orientación visible en cada publicación</li>
        <li><?= icono('memoria') ?><span data-memoria>Esta página usó <?= e(tamano_legible(memory_get_peak_usage())) ?> de memoria del servidor</span></li>
      </ul>
    </div>
    <nav class="pie__nav" aria-label="Pie de página">
      <div>
        <h2>Explorar</h2>
        <ul>
          <li><a href="<?= e(url('videos.php')) ?>">Todos los videos</a></li>
          <li><a href="<?= e(url('videos.php', ['orden' => 'equilibrado'])) ?>">Vista equilibrada</a></li>
          <?php foreach (array_slice(categorias_arbol(), 0, 4) as $r): ?><li><a href="<?= e(url('videos.php', ['cat' => $r['slug']])) ?>"><?= e($r['nombre']) ?></a></li><?php endforeach; ?>
        </ul>
      </div>
      <div>
        <h2>Más secciones</h2>
        <ul>
          <?php foreach (array_slice(categorias_arbol(), 4) as $r): ?><li><a href="<?= e(url('videos.php', ['cat' => $r['slug']])) ?>"><?= e($r['nombre']) ?></a></li><?php endforeach; ?>
        </ul>
      </div>
      <div>
        <h2>Sin Filtro</h2>
        <ul>
          <li><a href="<?= e(url('transparencia.php')) ?>">Cómo funciona</a></li>
          <li><a href="<?= e(url('preferencias.php')) ?>" data-abrir-preferencias>Preferencias de lectura</a></li>
          <?php if ($usuario): ?>
            <li><a href="<?= e(url('cuenta.php')) ?>">Mi cuenta y privacidad</a></li>
            <?php if ($usuario['rol'] === 'admin'): ?><li><a href="<?= e(url('admin/')) ?>">Panel de administración</a></li><?php endif; ?>
          <?php else: ?>
            <li><a href="<?= e(url_acceso()) ?>" data-acceso>Iniciar sesión</a></li>
            <li><a href="<?= e(url('registro.php')) ?>" data-acceso data-pestana="registro">Crear cuenta</a></li>
          <?php endif; ?>
        </ul>
      </div>
    </nav>
  </div>
  <div class="contenedor pie__legal">
    <p>© <?= date('Y') ?> Sin Filtro. Canales, marcas y tiendas de ejemplo.</p>
    <p>Atajos: <kbd>/</kbd> abre el buscador, <kbd>Esc</kbd> lo cierra.</p>
  </div>
</footer>

<nav class="tabbar" aria-label="Navegación rápida">
  <a href="<?= e(url()) ?>"<?= $seccion === 'inicio' ? ' aria-current="page"' : '' ?>><?= icono('inicio') ?><span>Inicio</span></a>
  <a href="<?= e(url('videos.php')) ?>"<?= $seccion === 'videos' ? ' aria-current="page"' : '' ?>><?= icono('video') ?><span>Videos</span></a>
  <a href="<?= e(url('buscar.php')) ?>" data-abrir-buscador<?= $seccion === 'buscar' ? ' aria-current="page"' : '' ?>><?= icono('buscar') ?><span>Buscar</span></a>
  <a href="<?= e(url('videos.php', ['orden' => 'equilibrado'])) ?>"><?= icono('balanza') ?><span>Equilibrio</span></a>
  <?php if ($usuario && $usuario['rol'] === 'admin'): ?>
    <a href="<?= e(url('admin/')) ?>"<?= $seccion === 'admin' ? ' aria-current="page"' : '' ?>><?= icono('panel') ?><span>Panel</span></a>
  <?php elseif ($usuario): ?>
    <a href="<?= e(url('cuenta.php')) ?>"<?= $seccion === 'cuenta' ? ' aria-current="page"' : '' ?>><?= icono('usuario') ?><span>Cuenta</span></a>
  <?php else: ?>
    <a href="<?= e(url_acceso()) ?>" data-acceso><?= icono('usuario') ?><span>Entrar</span></a>
  <?php endif; ?>
</nav>

<dialog class="dlg dlg-buscador" id="dlg-buscador" aria-label="Buscar en Sin Filtro">
  <?php vista('buscador', ['id' => 'q-dlg', 'variante' => 'dialogo']); ?>
  <p class="dlg-buscador__ayuda" aria-hidden="true"><kbd>↑</kbd><kbd>↓</kbd> para moverte <kbd>Enter</kbd> para abrir <kbd>Esc</kbd> para cerrar</p>
</dialog>

<?php if (!$usuario): ?>
<dialog class="dlg dlg-acceso" id="dlg-acceso" aria-labelledby="acceso-titulo">
  <div class="acceso">
    <button class="icono-btn dlg__cerrar" type="button" data-cerrar><?= icono('cerrar') ?><span class="sr">Cerrar</span></button>
    <aside class="acceso__lado">
      <svg class="acceso__logo" aria-hidden="true" focusable="false"><use href="#i-logo"/></svg>
      <h2 id="acceso-titulo" class="acceso__titulo">Entra para ver el contenido completo</h2>
      <p class="acceso__motivo" data-motivo-texto>Puedes explorar noticias, videos y productos sin cuenta. Con una cuenta gratis también ves:</p>
      <?php vista('desbloquea'); ?>
    </aside>
    <div class="acceso__formularios">
      <?php vista('formularios-acceso', ['prefijo' => 'dlg', 'volver' => url_actual(), 'demo' => $demo]); ?>
    </div>
  </div>
</dialog>
<?php endif; ?>

<dialog class="dlg dlg-prefs" id="dlg-preferencias" aria-labelledby="prefs-titulo">
  <div class="prefs-panel">
    <div class="prefs-panel__cabeza">
      <h2 class="prefs-panel__titulo" id="prefs-titulo"><?= icono('texto') ?>Preferencias de lectura</h2>
      <button class="icono-btn" type="button" data-cerrar><?= icono('cerrar') ?><span class="sr">Cerrar</span></button>
    </div>
    <?php if ($seccion !== 'preferencias') { vista('preferencias', ['prefijo' => 'dlg', 'volver' => url_actual()]); } ?>
  </div>
</dialog>

<div class="lector" data-lector role="region" aria-label="Lectura en voz alta" hidden>
  <span class="lector__onda" aria-hidden="true"><i></i><i></i><i></i><i></i></span>
  <p class="lector__txt"><span class="lector__estado" data-lector-estado>Leyendo</span><span class="lector__titulo" data-lector-titulo></span></p>
  <button class="icono-btn lector__btn" type="button" data-lector-pausa><?= icono('pausa') ?><span class="sr" data-lector-pausa-txt>Pausar</span></button>
  <button class="icono-btn lector__btn" type="button" data-lector-detener><?= icono('detener') ?><span class="sr">Detener la lectura</span></button>
</div>
<p class="sr" data-lector-anuncio aria-live="polite"></p>

<div class="avisos" data-avisos role="status" aria-live="polite">
  <?php foreach ($flash as $f): ?>
    <div class="aviso aviso--<?= e($f['tipo']) ?>"><?= icono($f['tipo'] === 'error' ? 'alerta' : 'check') ?><p><?= e($f['mensaje']) ?></p></div>
  <?php endforeach; ?>
</div>
</body>
</html>
