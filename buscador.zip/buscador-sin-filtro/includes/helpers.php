<?php
/**
 * Funciones auxiliares: URLs, escape, formato, CSRF, mensajes flash y vistas.
 */
declare(strict_types=1);

// --- URLs ---------------------------------------------------------------------

/** Ruta base de la app (sin barra final). Funciona en raíz o en subcarpeta. */
function url_base(): string
{
    static $base = null;
    if ($base !== null) {
        return $base;
    }
    $conf = (string) config('app.url_base', '');
    if ($conf !== '') {
        return $base = rtrim($conf, '/');
    }
    if (PHP_SAPI === 'cli') {
        return $base = '';
    }
    $scriptDir = str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_FILENAME'] ?? '')));
    $appDir = str_replace('\\', '/', APP_DIR);
    $sufijo = $scriptDir !== '' && str_starts_with($scriptDir, $appDir) ? substr($scriptDir, strlen($appDir)) : '';
    $urlDir = str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/')));
    if ($sufijo !== '' && str_ends_with($urlDir, $sufijo)) {
        $urlDir = substr($urlDir, 0, -strlen($sufijo));
    }
    return $base = rtrim($urlDir, '/');
}

function url(string $ruta = '', array $params = []): string
{
    $u = url_base() . '/' . ltrim($ruta, '/');
    $params = array_filter($params, static fn($v) => $v !== null && $v !== '' && $v !== false);
    return $params ? $u . '?' . http_build_query($params) : $u;
}

/** Recurso estático con versión según fecha de modificación (cache busting). */
function asset(string $ruta): string
{
    $archivo = APP_DIR . '/assets/' . $ruta;
    $v = is_file($archivo) ? (string) filemtime($archivo) : '1';
    return url('assets/' . $ruta) . '?v=' . $v;
}

/** Imagen WebP generada en varios anchos: media/portadas/{base}-{ancho}.webp */
function imagen(string $base, int $ancho): string
{
    return url('media/portadas/' . $base . '-' . $ancho . '.webp');
}

function srcset(string $base, array $anchos): string
{
    return implode(', ', array_map(static fn($w) => imagen($base, $w) . ' ' . $w . 'w', $anchos));
}

function es_https(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
}

function url_actual(): string
{
    return (string) ($_SERVER['REQUEST_URI'] ?? url());
}

function url_absoluta(string $ruta): string
{
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return (es_https() ? 'https://' : 'http://') . $host . $ruta;
}

/** Solo permite volver a rutas internas (evita redirecciones abiertas). */
function volver_seguro(?string $destino, string $defecto = ''): string
{
    $defecto = $defecto ?: url();
    if (!$destino) {
        return $defecto;
    }
    $destino = trim($destino);
    if ($destino === '' || $destino[0] !== '/' || str_starts_with($destino, '//') || str_contains($destino, '\\')
        || preg_match('#[\r\n]#', $destino) || parse_url($destino, PHP_URL_SCHEME) !== null) {
        return $defecto;
    }
    return $destino;
}

function redirigir(string $destino, int $codigo = 303): never
{
    header('Location: ' . $destino, true, $codigo);
    exit;
}

function dominio(string $url): string
{
    $host = (string) parse_url($url, PHP_URL_HOST);
    return preg_replace('/^www\./', '', $host);
}

// --- Escape y texto ------------------------------------------------------------

function e(?string $s): string
{
    return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Minúsculas, sin tildes y con espacios simples. Se usa para buscar sin importar acentos. */
function normalizar(string $texto): string
{
    $texto = mb_strtolower($texto, 'UTF-8');
    $texto = strtr($texto, [
        'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ü' => 'u', 'ñ' => 'n',
        'à' => 'a', 'è' => 'e', 'ì' => 'i', 'ò' => 'o', 'ù' => 'u', 'â' => 'a', 'ê' => 'e', 'ô' => 'o', 'ç' => 'c',
    ]);
    $texto = preg_replace('/[^a-z0-9%$.,\- ]+/u', ' ', $texto) ?? '';
    return trim(preg_replace('/\s+/', ' ', $texto) ?? '');
}

/** Términos útiles de una búsqueda (sin palabras vacías). */
function terminos_busqueda(string $q): array
{
    static $vacias = ['de', 'la', 'el', 'en', 'y', 'con', 'para', 'los', 'las', 'un', 'una', 'del', 'al', 'que', 'por', 'a', 'o', 'mas', 'como', 'se', 'su', 'es', 'lo'];
    $limpio = (string) preg_replace('/[^a-z0-9]+/', ' ', normalizar($q));
    $t = array_filter(explode(' ', $limpio), static fn($w) => mb_strlen($w) >= 2 && !in_array($w, $vacias, true));
    return array_values(array_unique(array_slice($t, 0, 8)));
}

/** Resalta los términos buscados dentro de un texto ya escapado. */
function resaltar(string $texto, array $terminos): string
{
    $html = e($texto);
    if (!$terminos) {
        return $html;
    }
    // Mapa posición a posición para comparar sin tildes y resaltar el texto original.
    $chars = mb_str_split($texto);
    $norm = '';
    $map = [];
    foreach ($chars as $i => $c) {
        $n = normalizar($c);
        $n = $n === '' ? ' ' : mb_substr($n, 0, 1);
        $norm .= $n;
        $map[] = $i;
    }
    $marcas = array_fill(0, count($chars), false);
    foreach ($terminos as $t) {
        $offset = 0;
        while (($pos = mb_strpos($norm, $t, $offset)) !== false) {
            for ($k = $pos; $k < $pos + mb_strlen($t); $k++) {
                $marcas[$k] = true;
            }
            $offset = $pos + 1;
        }
    }
    $out = '';
    $abierto = false;
    foreach ($chars as $i => $c) {
        if ($marcas[$i] && !$abierto) {
            $out .= '<mark>';
            $abierto = true;
        } elseif (!$marcas[$i] && $abierto) {
            $out .= '</mark>';
            $abierto = false;
        }
        $out .= e($c);
    }
    return $abierto ? $out . '</mark>' : $out;
}

function recortar(string $texto, int $max = 140): string
{
    if (mb_strlen($texto) <= $max) {
        return $texto;
    }
    $corte = mb_substr($texto, 0, $max);
    $esp = mb_strrpos($corte, ' ');
    return rtrim(mb_substr($corte, 0, $esp ?: $max), ',.;: ') . '…';
}

function plural(int $n, string $singular, string $plural): string
{
    return number_format($n, 0, ',', '.') . ' ' . ($n === 1 ? $singular : $plural);
}

// --- Formato -------------------------------------------------------------------

function precio(int|float $monto): string
{
    return '$' . number_format((float) $monto, 0, ',', '.');
}

function descuento(int $precio, ?int $antes): int
{
    if (!$antes || $antes <= $precio) {
        return 0;
    }
    return (int) round((1 - $precio / $antes) * 100);
}

function numero_corto(int $n): string
{
    if ($n >= 1_000_000) {
        return str_replace('.', ',', (string) round($n / 1_000_000, 1)) . ' M';
    }
    if ($n >= 1000) {
        return str_replace('.', ',', (string) round($n / 1000, 1)) . ' mil';
    }
    return (string) $n;
}

function duracion(int $segundos): string
{
    $h = intdiv($segundos, 3600);
    $m = intdiv($segundos % 3600, 60);
    $s = $segundos % 60;
    return $h > 0 ? sprintf('%d:%02d:%02d', $h, $m, $s) : sprintf('%d:%02d', $m, $s);
}

function duracion_texto(int $segundos): string
{
    $m = intdiv($segundos, 60);
    $s = $segundos % 60;
    $partes = [];
    if ($m) {
        $partes[] = plural($m, 'minuto', 'minutos');
    }
    if ($s || !$m) {
        $partes[] = plural($s, 'segundo', 'segundos');
    }
    return implode(' y ', $partes);
}

const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

function fecha_larga(string $fecha, bool $hora = false): string
{
    $t = strtotime($fecha);
    $txt = date('j', $t) . ' de ' . MESES[(int) date('n', $t) - 1] . ' de ' . date('Y', $t);
    return $hora ? $txt . ', ' . date('H:i', $t) : $txt;
}

function fecha_relativa(string $fecha): string
{
    $t = strtotime($fecha);
    $dif = time() - $t;
    if ($dif < 0) {
        return fecha_larga($fecha);
    }
    if ($dif < 60) {
        return 'hace un momento';
    }
    if ($dif < 3600) {
        $m = intdiv($dif, 60);
        return 'hace ' . $m . ' min';
    }
    if ($dif < 86400) {
        $h = intdiv($dif, 3600);
        return 'hace ' . $h . ' h';
    }
    if ($dif < 172800) {
        return 'ayer';
    }
    if ($dif < 604800) {
        return 'hace ' . intdiv($dif, 86400) . ' días';
    }
    $txt = date('j', $t) . ' de ' . MESES[(int) date('n', $t) - 1];
    return date('Y', $t) === date('Y') ? $txt : $txt . ' de ' . date('Y', $t);
}

function fecha_iso(string $fecha): string
{
    return date('c', strtotime($fecha));
}

// --- Redes sociales ------------------------------------------------------------

function red_info(string $red): array
{
    return [
        'instagram' => ['Instagram', 'instagram'],
        'tiktok'    => ['TikTok', 'tiktok'],
        'facebook'  => ['Facebook', 'facebook'],
        'x'         => ['X', 'x'],
        'youtube'   => ['YouTube', 'youtube'],
        'whatsapp'  => ['WhatsApp', 'whatsapp'],
        'linkedin'  => ['LinkedIn', 'linkedin'],
    ][$red] ?? [ucfirst($red), 'enlace'];
}

// --- Iconos (sprite en includes/vistas/iconos.php) -------------------------------

function icono(string $nombre, string $clase = '', ?string $etiqueta = null): string
{
    $aria = $etiqueta ? 'role="img" aria-label="' . e($etiqueta) . '"' : 'aria-hidden="true"';
    return '<svg class="ico ' . e($clase) . '" ' . $aria . ' focusable="false"><use href="#i-' . e($nombre) . '"/></svg>';
}

// --- Seguridad -------------------------------------------------------------------

function csp_nonce(): string
{
    static $nonce = null;
    return $nonce ??= base64_encode(random_bytes(16));
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_campo(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_valido(): bool
{
    $enviado = $_POST['csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    return is_string($enviado) && $enviado !== '' && hash_equals(csrf_token(), $enviado);
}

function es_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

function entrada(string $clave, string $defecto = ''): string
{
    $v = $_POST[$clave] ?? $_GET[$clave] ?? $defecto;
    return is_string($v) ? trim($v) : $defecto;
}

function ip_cliente(): string
{
    return (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

/** IP recortada para los registros: 203.0.113.0 o 2001:db8:85a3:: (no identifica a la persona). */
function ip_anonima(): string
{
    $ip = ip_cliente();
    if (!config('privacidad.anonimizar_ip', true)) {
        return $ip;
    }
    if (str_contains($ip, ':')) {
        $bin = @inet_pton($ip);
        return $bin === false ? '::' : (string) inet_ntop(substr($bin, 0, 6) . str_repeat("\0", 10));
    }
    return preg_replace('/\.\d+$/', '.0', $ip) ?? '0.0.0.0';
}

// --- Respuestas ----------------------------------------------------------------

function es_peticion_json(): bool
{
    return str_contains((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json')
        || ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';
}

function json_respuesta(array $datos, int $codigo = 200): never
{
    http_response_code($codigo);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function no_encontrado(): never
{
    http_response_code(404);
    require APP_DIR . '/404.php';
    exit;
}

// --- Mensajes flash ------------------------------------------------------------

function flash(string $tipo, string $mensaje): void
{
    $_SESSION['flash'][] = ['tipo' => $tipo, 'mensaje' => $mensaje];
}

function flash_obtener(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

// --- Vistas y registros --------------------------------------------------------

function vista(string $nombre, array $vars = []): void
{
    extract($vars, EXTR_SKIP);
    require INC_DIR . '/vistas/' . $nombre . '.php';
}

function registrar_log(string $archivo, string $mensaje): void
{
    $linea = '[' . date('Y-m-d H:i:s') . '] ' . ip_anonima() . ' ' . str_replace(["\r", "\n"], ' ', $mensaje) . PHP_EOL;
    @file_put_contents(APP_DIR . '/logs/' . preg_replace('/[^a-z0-9_-]/i', '', $archivo) . '.log', $linea, FILE_APPEND | LOCK_EX);
}

// --- Imágenes responsivas --------------------------------------------------------

/**
 * <img> responsiva con color de fondo mientras carga y nombre opcional para View Transitions.
 * $opc: lazy (bool), prioridad (bool), vt (string), clase (string)
 */
function img(string $base, array $anchos, string $sizes, string $alt, int $w, int $h, string $color = '#e5e7ef', array $opc = []): string
{
    $prioridad = !empty($opc['prioridad']);
    $lazy = $opc['lazy'] ?? !$prioridad;
    // Un nombre de transición solo puede aparecer una vez por página (la misma publicación puede estar en dos filas)
    static $vtUsados = [];
    $vt = (string) ($opc['vt'] ?? '');
    if ($vt !== '' && isset($vtUsados[$vt])) {
        $vt = '';
    }
    if ($vt !== '') {
        $vtUsados[$vt] = true;
    }
    $estilo = '--ph:' . e($color) . ($vt !== '' ? ';view-transition-name:' . e($vt) : '');
    $medio = $anchos[(int) floor((count($anchos) - 1) / 2)];
    return '<img class="img ' . e($opc['clase'] ?? '') . '" src="' . e(imagen($base, $medio)) . '" srcset="' . e(srcset($base, $anchos)) . '"'
        . ' sizes="' . e($sizes) . '" alt="' . e($alt) . '" width="' . $w . '" height="' . $h . '"'
        . ($lazy ? ' loading="lazy"' : '') . ($prioridad ? ' fetchpriority="high"' : '')
        . ' decoding="async" style="' . $estilo . '">';
}

function iniciales(string $nombre): string
{
    $partes = preg_split('/\s+/', trim($nombre)) ?: [''];
    $i = mb_substr($partes[0], 0, 1) . (isset($partes[1]) ? mb_substr($partes[1], 0, 1) : '');
    return mb_strtoupper($i);
}

/** Mensajes que explican por qué se pide iniciar sesión (la URL solo lleva la clave). */
const MOTIVOS_ACCESO = [
    'venta'  => 'Inicia sesión para ver el enlace de venta.',
    'fuente' => 'Inicia sesión para leer la fuente original de la noticia.',
    'red'    => 'Inicia sesión para ver las redes sociales.',
    'video'  => 'Inicia sesión para ver el video completo.',
    'cuenta' => 'Inicia sesión para ver tu cuenta.',
    'admin'  => 'Inicia sesión con una cuenta de administración.',
    'comentar' => 'Inicia sesión para comentar. Leer los comentarios es libre.',
];

/** URL de la página de acceso que vuelve a la página actual (o a un ancla dentro de ella). $motivo es una clave de MOTIVOS_ACCESO. */
function url_acceso(string $motivo = '', string $ancla = ''): string
{
    $volver = strtok(url_actual(), '#') . ($ancla ? '#' . $ancla : '');
    return url('entrar.php', ['volver' => $volver, 'motivo' => $motivo]);
}

// --- Preferencias de lectura ------------------------------------------------------------
// Se guardan en una cookie del propio sitio (sin datos personales) para aplicarlas antes de pintar
// la página y para que funcionen también sin JavaScript.

const PREFERENCIAS = [
    'tema'       => ['sistema' => 'Según el sistema', 'claro' => 'Claro', 'oscuro' => 'Oscuro'],
    'acento'     => ['azul' => 'Azul', 'violeta' => 'Violeta', 'verde' => 'Verde', 'terracota' => 'Terracota', 'grafito' => 'Grafito'],
    'texto'      => ['normal' => 'Normal', 'chico' => 'Pequeño', 'grande' => 'Grande', 'muy-grande' => 'Muy grande'],
    'linea'      => ['normal' => 'Normal', 'amplio' => 'Amplio'],
    'contraste'  => ['normal' => 'Normal', 'alto' => 'Alto'],
    'movimiento' => ['sistema' => 'Según el sistema', 'reducido' => 'Reducidas'],
    'velocidad'  => ['1' => 'Normal', '0.8' => 'Lenta', '1.25' => 'Rápida', '1.5' => 'Muy rápida'],
];

/** Preferencias actuales (validadas). El primer valor de cada lista es el predeterminado. */
function preferencias(): array
{
    static $p = null;
    if ($p !== null) {
        return $p;
    }
    parse_str((string) ($_COOKIE['sf_pref'] ?? ''), $c);
    $p = [];
    foreach (PREFERENCIAS as $k => $opciones) {
        $v = is_string($c[$k] ?? null) ? $c[$k] : '';
        $p[$k] = isset($opciones[$v]) ? $v : (string) array_key_first($opciones);
    }
    return $p;
}

function guardar_preferencias(array $valores): void
{
    $p = [];
    foreach (PREFERENCIAS as $k => $opciones) {
        $v = (string) ($valores[$k] ?? '');
        if (isset($opciones[$v]) && $v !== (string) array_key_first($opciones)) {
            $p[$k] = $v;
        }
    }
    setcookie('sf_pref', http_build_query($p), ['expires' => $p ? time() + 31536000 : time() - 3600, 'path' => url_base() . '/', 'secure' => es_https(), 'httponly' => false, 'samesite' => 'Lax']);
}

/** Atributos para <html> según las preferencias. */
function atributos_preferencias(): string
{
    $p = preferencias();
    $a = '';
    if ($p['tema'] !== 'sistema') {
        $a .= ' data-theme="' . ($p['tema'] === 'oscuro' ? 'dark' : 'light') . '"';
    }
    foreach (['acento', 'texto', 'linea', 'contraste', 'movimiento'] as $k) {
        if ($p[$k] !== array_key_first(PREFERENCIAS[$k])) {
            $a .= ' data-' . $k . '="' . e($p[$k]) . '"';
        }
    }
    return $a;
}

// --- Secciones -----------------------------------------------------------------------

/** Secciones con enlace en la cabecera (además de Videos), en orden. Prioridad 1 se ve siempre en escritorio. */
const SECCIONES_NAV = [
    'noticias'     => ['Noticias', 1],
    'deportes'     => ['Deportes', 1],
    'tecnologia'   => ['Tecnología', 1],
    'productos'    => ['Productos', 2],
    'curiosidades' => ['Curiosidades', 3],
];

function icono_seccion(string $slug): string
{
    return [
        'noticias' => 'noticia', 'deportes' => 'balon', 'tecnologia' => 'chip', 'productos' => 'etiqueta',
        'analisis-debate' => 'balanza', 'verificacion' => 'escudo', 'conflictos-seguridad' => 'globo',
        'aciertos-errores' => 'aciertos', 'curiosidades' => 'chispa',
    ][$slug] ?? 'carpeta';
}

/** Clave de la cabecera que se marca como activa para una sección raíz. */
function nav_de_seccion(?string $raiz): string
{
    return $raiz && isset(SECCIONES_NAV[$raiz]) ? $raiz : 'videos';
}

// --- Publicaciones -------------------------------------------------------------------

/** Color estable para el avatar de un creador (paleta neutra, sin connotación política). */
function color_avatar(string $nombre): string
{
    $paleta = ['#2340f5', '#0e6b6a', '#8f5a17', '#5a2a5d', '#4a5a1c', '#334155', '#8a3b2e', '#1f5f8b'];
    return $paleta[abs(crc32(mb_strtolower($nombre))) % count($paleta)];
}

function url_publicacion(array $p): string
{
    return url('video.php', ['v' => $p['slug']]);
}

/** Texto plano a párrafos HTML escapados. */
function parrafos(string $texto): string
{
    $out = '';
    foreach (preg_split('/\n\s*\n/', trim($texto)) ?: [] as $par) {
        if (trim($par) !== '') {
            $out .= '<p>' . nl2br(e(trim($par)), false) . '</p>';
        }
    }
    return $out;
}

/** Bytes legibles: 1,4 MB */
function tamano_legible(int $bytes): string
{
    if ($bytes >= 1048576) {
        return str_replace('.', ',', (string) round($bytes / 1048576, 1)) . ' MB';
    }
    return max(1, (int) round($bytes / 1024)) . ' KB';
}
