<?php
/**
 * Funciones del panel de administración: publicar, editar, eliminar, categorías y usuarios.
 * Se cargan solo en las páginas de admin/ (el sitio público no paga su costo).
 */
declare(strict_types=1);

require_once INC_DIR . '/medios.php';

const REDES_PERMITIDAS = ['youtube', 'instagram', 'tiktok', 'x', 'facebook', 'whatsapp', 'linkedin'];

function slug(string $texto): string
{
    $s = trim((string) preg_replace('/[^a-z0-9]+/', '-', normalizar($texto)), '-');
    return mb_substr($s !== '' ? $s : 'publicacion', 0, 80);
}

function slug_unico(string $tabla, string $base, ?int $excluirId = null): string
{
    $slug = $base;
    for ($i = 2; valor("SELECT 1 FROM {$tabla} WHERE slug = ?" . ($excluirId ? ' AND id <> ' . (int) $excluirId : ''), [$slug]); $i++) {
        $slug = mb_substr($base, 0, 74) . '-' . $i;
    }
    return $slug;
}

function url_valida(string $u): bool
{
    return $u !== '' && filter_var($u, FILTER_VALIDATE_URL) !== false && preg_match('#^https?://#i', $u) === 1 && mb_strlen($u) <= 255;
}

/** "Clave: valor" por línea → arreglo (ficha técnica). */
function ficha_desde_texto(string $txt): array
{
    $out = [];
    foreach (preg_split('/\R/', $txt) ?: [] as $linea) {
        if (str_contains($linea, ':')) {
            [$k, $v] = array_map('trim', explode(':', $linea, 2));
            if ($k !== '' && $v !== '') {
                $out[mb_substr($k, 0, 60)] = mb_substr($v, 0, 160);
            }
        }
    }
    return array_slice($out, 0, 20, true);
}

function ficha_a_texto(?string $json): string
{
    $a = $json ? (json_decode($json, true) ?: []) : [];
    return implode("\n", array_map(static fn($k, $v) => $k . ': ' . $v, array_keys($a), $a));
}

/** "a, b ,  a" → "a, b" (máximo 15, sin repetir, 40 caracteres cada una) */
function etiquetas_limpias(string $txt): string
{
    $lista = array_map(static fn($t) => mb_substr(trim($t), 0, 40), explode(',', $txt));
    $lista = array_values(array_unique(array_filter($lista, static fn($t) => $t !== '')));
    return implode(', ', array_slice($lista, 0, 15));
}

function categorias_planas(): array
{
    $out = [];
    foreach (categorias_arbol() as $r) {
        $out[] = $r + ['nivel' => 0, 'padre_slug' => null];
        foreach ($r['subs'] as $s) {
            $out[] = $s + ['nivel' => 1, 'padre_slug' => $r['slug'], 'padre_nombre' => $r['nombre']];
        }
    }
    return $out;
}

/**
 * Valida el formulario de publicación. No toca archivos.
 * @return array{0: array, 1: array<string,string>} datos limpios y errores por campo
 */
function validar_publicacion(array $in, ?array $actual): array
{
    $err = [];
    $txt = static fn(string $k, int $max) => mb_substr(trim((string) ($in[$k] ?? '')), 0, $max);
    $d = [
        'tipo' => in_array($in['tipo'] ?? '', array_keys(TIPOS), true) ? $in['tipo'] : '',
        'titulo' => $txt('titulo', 200),
        'descripcion' => $txt('descripcion', 5000),
        'cuerpo' => $txt('cuerpo', 30000),
        'categoria_id' => (int) ($in['categoria_id'] ?? 0),
        'orientacion' => isset(ORIENTACIONES[$in['orientacion'] ?? '']) ? $in['orientacion'] : '',
        'orientacion_nota' => $txt('orientacion_nota', 255),
        'verificacion' => isset(VERIFICACIONES[$in['verificacion'] ?? '']) ? $in['verificacion'] : '',
        'verificacion_nota' => $txt('verificacion_nota', 600),
        'creador' => $txt('creador', 120),
        'creador_url' => $txt('creador_url', 255),
        'autor' => $txt('autor', 120),
        'fuente_url' => $txt('fuente_url', 255),
        'venta_url' => $txt('venta_url', 255),
        'tienda' => $txt('tienda', 120),
        'precio' => trim((string) ($in['precio'] ?? '')),
        'precio_antes' => trim((string) ($in['precio_antes'] ?? '')),
        'ficha' => ficha_desde_texto((string) ($in['ficha'] ?? '')),
        'etiquetas' => etiquetas_limpias((string) ($in['etiquetas'] ?? '')),
        'subido_por' => $txt('subido_por', 80),
        'destacado' => !empty($in['destacado']) ? 1 : 0,
        'publicado_en' => trim((string) ($in['publicado_en'] ?? '')),
        'duracion_seg' => max(0, min(86400, (int) ($in['duracion_seg'] ?? 0))),
        'youtube_url' => $txt('youtube_url', 255),
        'youtube_id' => null,
    ];
    if ($d['youtube_url'] !== '') {
        $d['youtube_id'] = youtube_id_de($d['youtube_url']);
        if (!$d['youtube_id']) {
            $err['youtube_url'] = 'No reconocemos ese enlace de YouTube. Pega la dirección del video (youtube.com/watch?v=… o youtu.be/…).';
        } elseif ($d['fuente_url'] === '') {
            $d['fuente_url'] = youtube_url($d['youtube_id']);
        }
    }
    if (!$d['tipo']) {
        $err['tipo'] = 'Elige si es un video, fotos o una noticia.';
    }
    if (mb_strlen($d['titulo']) < 3) {
        $err['titulo'] = 'Escribe un título de al menos 3 caracteres.';
    }
    if (mb_strlen($d['descripcion']) < 10) {
        $err['descripcion'] = 'Escribe una descripción de al menos 10 caracteres.';
    }
    if (!categoria_por_id($d['categoria_id'])) {
        $err['categoria_id'] = 'Elige una categoría.';
    }
    if (!$d['orientacion']) {
        $err['orientacion'] = 'Elige una orientación (o “Sin orientación política”).';
    }
    if (!$d['verificacion']) {
        $err['verificacion'] = 'Elige un estado de verificación.';
    } elseif ($d['verificacion'] === 'enganoso' && mb_strlen($d['verificacion_nota']) < 10) {
        $err['verificacion_nota'] = 'Explica por qué es engañoso: la gente verá esta nota.';
    }
    if (mb_strlen($d['creador']) < 2) {
        $err['creador'] = 'Escribe quién creó el contenido (canal, medio o persona).';
    }
    foreach (['creador_url' => 'del creador', 'fuente_url' => 'de la noticia', 'venta_url' => 'de venta'] as $k => $que) {
        if ($d[$k] !== '' && !url_valida($d[$k])) {
            $err[$k] = "La URL {$que} debe empezar con https:// y ser válida.";
        }
    }
    foreach (['precio', 'precio_antes'] as $k) {
        if ($d[$k] !== '') {
            $n = (int) preg_replace('/[^\d]/', '', $d[$k]);
            $d[$k] = $n;
        } else {
            $d[$k] = null;
        }
    }
    if ($d['precio_antes'] !== null && $d['precio'] !== null && $d['precio_antes'] <= $d['precio']) {
        $err['precio_antes'] = 'El precio anterior debe ser mayor que el actual (o déjalo vacío).';
    }
    if ($d['publicado_en'] !== '') {
        $t = strtotime($d['publicado_en']);
        if ($t === false) {
            $err['publicado_en'] = 'La fecha no es válida.';
        } else {
            $d['publicado_en'] = date('Y-m-d H:i:s', $t);
        }
    } else {
        $d['publicado_en'] = $actual['publicado_en'] ?? ahora();
    }
    if ($d['subido_por'] === '') {
        $d['subido_por'] = usuario_actual()['nombre_admin'] ?: usuario_actual()['nombre'];
    }
    // Redes adjuntas: filas red + URL
    $redes = [];
    foreach ((array) ($in['red'] ?? []) as $i => $red) {
        $u = trim((string) (($in['red_url'] ?? [])[$i] ?? ''));
        if ($u === '') {
            continue;
        }
        if (!in_array($red, REDES_PERMITIDAS, true) || !url_valida($u)) {
            $err['redes'] = 'Revisa las redes: cada una necesita una plataforma y una URL que empiece con https://.';
            continue;
        }
        $usuario = trim((string) basename((string) parse_url($u, PHP_URL_PATH)), '@/');
        $redes[] = ['red' => $red, 'url' => $u, 'usuario' => mb_substr($usuario !== '' ? $usuario : (string) parse_url($u, PHP_URL_HOST), 0, 80)];
    }
    $d['redes'] = array_slice($redes, 0, 10);
    return [$d, $err];
}

/**
 * Crea o actualiza una publicación con sus archivos.
 * @return array{ok: bool, id?: int, slug?: string, errores?: array}
 */
function guardar_publicacion(array $post, array $files, ?array $actual): array
{
    [$d, $err] = validar_publicacion($post, $actual);
    $esNueva = $actual === null;
    $fotosNuevas = lista_archivos($files['fotos'] ?? null);
    // En publicaciones de fotos, la miniatura es opcional: se usa la primera foto recortada a 16:9
    $miniDesdeFoto = $esNueva && !archivo_presente($files['miniatura'] ?? null) && $d['tipo'] === 'imagen' && $fotosNuevas;
    // Con un enlace de YouTube la miniatura es opcional: se usa la del video
    $miniDeYoutube = !archivo_presente($files['miniatura'] ?? null) && $d['tipo'] === 'video' && $d['youtube_id']
        && ($esNueva || (string) ($actual['youtube_id'] ?? '') !== $d['youtube_id'] || str_starts_with((string) ($actual['miniatura'] ?? ''), 'youtube/'));
    if ($esNueva && !archivo_presente($files['miniatura'] ?? null) && !$miniDesdeFoto && !$miniDeYoutube) {
        $err['miniatura'] = 'Sube una miniatura (PNG recomendado, 16:9).';
    }
    // Un video nuevo necesita su archivo; al editar uno existente (o uno de ejemplo sin archivo) no es obligatorio
    if ($d['tipo'] === 'video' && $esNueva && !archivo_presente($files['video'] ?? null) && !$d['youtube_id'] && !isset($err['youtube_url'])) {
        $err['video'] = 'Sube el archivo de video (MP4 o WebM) o pega un enlace de YouTube.';
    }
    $quitar = array_map('intval', (array) ($post['quitar_fotos'] ?? []));
    $fotosActuales = $actual ? imagenes_de((int) $actual['id']) : [];
    $quedan = count(array_filter($fotosActuales, static fn($i) => !in_array((int) $i['id'], $quitar, true)));
    if ($d['tipo'] === 'imagen' && $quedan + count($fotosNuevas) === 0) {
        $err['fotos'] = 'Sube al menos una foto.';
    }
    if ($quedan + count($fotosNuevas) > (int) config('subidas.max_fotos', 12)) {
        $err['fotos'] = 'Puedes tener hasta ' . (int) config('subidas.max_fotos', 12) . ' fotos por publicación.';
    }
    if ($err) {
        return ['ok' => false, 'errores' => $err];
    }

    $slug = $esNueva ? slug_unico('publicaciones', slug($d['titulo'])) : $actual['slug'];
    $creados = ['img' => [], 'vid' => []];
    $reemplazados = ['img' => [], 'vid' => []];
    try {
        // Miniatura (16:9)
        $mini = null;
        if (archivo_presente($files['miniatura'] ?? null) || $miniDesdeFoto) {
            $mini = subir_imagen($miniDesdeFoto ? $fotosNuevas[0] : $files['miniatura'], 'subidas', $slug, ANCHOS_MINIATURA, 16 / 9, 'miniatura');
            $creados['img'][] = $mini['base'];
        }
        // Video y subtítulos
        $video = null;
        if ($d['tipo'] === 'video' && archivo_presente($files['video'] ?? null)) {
            $video = subir_video($files['video'], $slug);
            $creados['vid'][] = $video['archivo'];
            if (!$d['duracion_seg']) {
                $d['duracion_seg'] = duracion_video($video['archivo']);
            }
        }
        $vtt = null;
        if ($d['tipo'] === 'video' && archivo_presente($files['subtitulos'] ?? null)) {
            $vtt = subir_subtitulos($files['subtitulos'], $slug);
            $creados['vid'][] = $vtt;
        }
        // Fotos de la galería (se conserva su proporción)
        $fotos = [];
        foreach ($fotosNuevas as $i => $foto) {
            $r = subir_imagen($foto, 'subidas', $slug . '-f' . ($i + 1), ANCHOS_FOTO, null, 'foto ' . ($i + 1));
            $creados['img'][] = $r['base'];
            $fotos[] = $r + ['alt' => mb_substr(trim((string) (($post['fotos_alt'] ?? [])[$i] ?? '')), 0, 255)];
        }
    } catch (ErrorSubida $e) {
        foreach ($creados['img'] as $b) {
            borrar_imagen_si_huerfana($b);
        }
        foreach ($creados['vid'] as $v) {
            borrar_video_si_huerfano($v);
        }
        return ['ok' => false, 'errores' => ['archivos' => $e->getMessage()]];
    }

    $cat = categoria_por_id($d['categoria_id']);
    $fila = [
        'tipo' => $d['tipo'], 'titulo' => $d['titulo'], 'descripcion' => $d['descripcion'],
        'cuerpo' => $d['tipo'] === 'noticia' && $d['cuerpo'] !== '' ? $d['cuerpo'] : null,
        'categoria_id' => $d['categoria_id'], 'orientacion' => $d['orientacion'], 'orientacion_nota' => $d['orientacion_nota'] ?: null,
        'verificacion' => $d['verificacion'], 'verificacion_nota' => $d['verificacion_nota'] ?: null,
        'creador' => $d['creador'], 'creador_url' => $d['creador_url'] ?: null, 'autor' => $d['autor'] ?: null,
        'fuente_url' => $d['fuente_url'] ?: null, 'venta_url' => $d['venta_url'] ?: null, 'tienda' => $d['tienda'] ?: null,
        'precio' => $d['precio'], 'precio_antes' => $d['precio_antes'],
        'ficha' => $d['ficha'] ? json_encode($d['ficha'], JSON_UNESCAPED_UNICODE) : null,
        'etiquetas' => $d['etiquetas'], 'destacado' => $d['destacado'], 'subido_por' => $d['subido_por'],
        'publicado_en' => $d['publicado_en'],
        'youtube_id' => $d['tipo'] === 'video' ? $d['youtube_id'] : null,
    ];
    $miniYoutubeNueva = false;
    if (!$mini && $miniDeYoutube) {
        // La miniatura del video la descarga el servidor (ver includes/youtube.php)
        $fila['miniatura'] = 'youtube/' . $slug;
        $miniYoutubeNueva = $esNueva || (string) $actual['youtube_id'] !== (string) $d['youtube_id'] || $actual['miniatura'] !== $fila['miniatura'];
        if ($miniYoutubeNueva) {
            $fila['miniatura_color'] = '#1f2937';
            if (!$esNueva && $actual['miniatura'] !== $fila['miniatura']) {
                $reemplazados['img'][] = $actual['miniatura'];
            }
        }
    }
    if ($mini) {
        $fila['miniatura'] = $mini['base'];
        $fila['miniatura_color'] = $mini['color'];
        if (!$esNueva) {
            $reemplazados['img'][] = $actual['miniatura'];
        }
    }
    if ($video) {
        // Un video nuevo reemplaza ambos formatos anteriores
        if (!$esNueva) {
            $reemplazados['vid'][] = $actual['video_archivo'];
            $reemplazados['vid'][] = $actual['video_webm'];
        }
        // El archivo subido (MP4 o WebM) es la fuente principal; la versión alternativa se descarta.
        $fila['video_archivo'] = $video['archivo'];
        $fila['video_webm'] = null;
        $fila['duracion_seg'] = $d['duracion_seg'];
    } elseif ($d['duracion_seg'] && $d['tipo'] === 'video') {
        $fila['duracion_seg'] = $d['duracion_seg'];
    }
    if ($vtt) {
        if (!$esNueva) {
            $reemplazados['vid'][] = $actual['subtitulos'];
        }
        $fila['subtitulos'] = $vtt;
    }
    if ($d['tipo'] !== 'video' && !$esNueva) {
        // Si dejó de ser video, se liberan los archivos
        $reemplazados['vid'] = array_merge($reemplazados['vid'], [$actual['video_archivo'], $actual['video_webm'], $actual['subtitulos']]);
        $fila += ['video_archivo' => null, 'video_webm' => null, 'subtitulos' => null, 'duracion_seg' => 0];
    }
    $fila += campos_busqueda($fila + ['tipo' => $d['tipo']], $cat['nombre'], $cat['padre_nombre'] ?? '');

    $pdo = db();
    $pdo->beginTransaction();
    try {
        if ($esNueva) {
            $fila += ['slug' => $slug, 'vistas' => 0, 'subido_por_id' => (int) usuario_actual()['id'], 'actualizado_en' => null];
            $cols = array_keys($fila);
            consulta('INSERT INTO publicaciones (' . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')', array_values($fila));
            $id = (int) $pdo->lastInsertId();
        } else {
            $id = (int) $actual['id'];
            $fila['actualizado_en'] = ahora();
            $sets = implode(', ', array_map(static fn($c) => "{$c} = ?", array_keys($fila)));
            consulta("UPDATE publicaciones SET {$sets} WHERE id = ?", array_merge(array_values($fila), [$id]));
        }
        // Fotos
        foreach ($fotosActuales as $f) {
            if (in_array((int) $f['id'], $quitar, true)) {
                consulta('DELETE FROM imagenes WHERE id = ? AND publicacion_id = ?', [(int) $f['id'], $id]);
                $reemplazados['img'][] = $f['base'];
            }
        }
        $orden = (int) valor('SELECT COALESCE(MAX(orden), -1) FROM imagenes WHERE publicacion_id = ?', [$id]);
        foreach ($fotos as $f) {
            consulta('INSERT INTO imagenes (publicacion_id, base, color, alt, orden) VALUES (?, ?, ?, ?, ?)', [$id, $f['base'], $f['color'], $f['alt'] ?: $d['titulo'], ++$orden]);
        }
        // Redes adjuntas: se reemplazan completas
        consulta('DELETE FROM redes_sociales WHERE publicacion_id = ?', [$id]);
        foreach ($d['redes'] as $r) {
            consulta('INSERT INTO redes_sociales (publicacion_id, red, usuario, url) VALUES (?, ?, ?, ?)', [$id, $r['red'], $r['usuario'], $r['url']]);
        }
        $pdo->commit();
        if ($miniYoutubeNueva) {
            foreach (ANCHOS_MINIATURA as $w) {
                @unlink(APP_DIR . '/media/portadas/youtube/' . $slug . '-' . $w . '.webp');
            }
            @unlink(APP_DIR . '/media/portadas/youtube/.sin-conexion-' . $slug);
            try {
                youtube_completar(publicacion_por_id($id)); // si no hay conexión, se reintenta al mostrarla
            } catch (Throwable) {
                // la publicación ya quedó guardada
            }
        }
    } catch (Throwable $e) {
        $pdo->rollBack();
        foreach ($creados['img'] as $b) {
            borrar_imagen_si_huerfana($b);
        }
        foreach ($creados['vid'] as $v) {
            borrar_video_si_huerfano($v);
        }
        throw $e;
    }
    foreach ($reemplazados['img'] as $b) {
        borrar_imagen_si_huerfana((string) $b);
    }
    foreach (array_filter($reemplazados['vid']) as $v) {
        borrar_video_si_huerfano((string) $v);
    }
    // "Recordar mi nombre de admin"
    if (!empty($post['recordar_nombre'])) {
        consulta('UPDATE usuarios SET nombre_admin = ? WHERE id = ?', [$d['subido_por'], (int) usuario_actual()['id']]);
    }
    registrar_log('admin', ($esNueva ? 'publicó' : 'editó') . " #{$id} {$slug} por usuario #" . usuario_actual()['id']);
    return ['ok' => true, 'id' => $id, 'slug' => $slug];
}

function eliminar_publicacion(int $id): bool
{
    $p = publicacion_por_id($id);
    if (!$p) {
        return false;
    }
    $imgs = imagenes_de($id);
    consulta('DELETE FROM publicaciones WHERE id = ?', [$id]);
    borrar_imagen_si_huerfana($p['miniatura']);
    foreach ($imgs as $im) {
        borrar_imagen_si_huerfana($im['base']);
    }
    foreach ([$p['video_archivo'], $p['video_webm'], $p['subtitulos']] as $v) {
        borrar_video_si_huerfano($v);
    }
    registrar_log('admin', "eliminó #{$id} {$p['slug']} por usuario #" . (usuario_actual()['id'] ?? 0));
    return true;
}

// --- Categorías ------------------------------------------------------------------

function guardar_categoria(array $in, ?array $actual): array
{
    $nombre = mb_substr(trim((string) ($in['nombre'] ?? '')), 0, 80);
    $desc = mb_substr(trim((string) ($in['descripcion'] ?? '')), 0, 255);
    $nota = mb_substr(trim(str_replace("\r\n", "\n", (string) ($in['nota'] ?? ''))), 0, 1500);
    $padre = (int) ($in['padre_id'] ?? 0) ?: null;
    $orden = (int) ($in['orden'] ?? 0);
    if (mb_strlen($nombre) < 2) {
        return ['ok' => false, 'error' => 'Escribe un nombre de al menos 2 caracteres.'];
    }
    if ($padre !== null) {
        $p = categoria_por_id($padre);
        if (!$p || $p['padre_id'] !== null) {
            return ['ok' => false, 'error' => 'La categoría madre debe ser una categoría principal.'];
        }
        if ($actual && (int) $actual['id'] === $padre) {
            return ['ok' => false, 'error' => 'Una categoría no puede ser madre de sí misma.'];
        }
        if ($actual && (int) valor('SELECT COUNT(*) FROM categorias WHERE padre_id = ?', [(int) $actual['id']]) > 0) {
            return ['ok' => false, 'error' => 'Esta categoría tiene subcategorías: no puede pasar a ser subcategoría.'];
        }
    }
    if ($actual) {
        consulta('UPDATE categorias SET nombre = ?, descripcion = ?, nota = ?, padre_id = ?, orden = ? WHERE id = ?', [$nombre, $desc, $nota !== '' ? $nota : null, $padre, $orden, (int) $actual['id']]);
        reindexar_categoria((int) $actual['id']);
        return ['ok' => true, 'mensaje' => "Categoría “{$nombre}” actualizada."];
    }
    $slug = slug_unico('categorias', slug($nombre));
    consulta('INSERT INTO categorias (slug, nombre, descripcion, nota, padre_id, orden) VALUES (?, ?, ?, ?, ?, ?)', [$slug, $nombre, $desc, $nota !== '' ? $nota : null, $padre, $orden]);
    return ['ok' => true, 'mensaje' => ($padre ? 'Subcategoría' : 'Categoría') . " “{$nombre}” creada."];
}

/** Al renombrar o mover una categoría, actualiza el texto de búsqueda de sus publicaciones. */
function reindexar_categoria(int $catId): void
{
    $ids = array_column(filas('SELECT p.id FROM publicaciones p JOIN categorias c ON c.id = p.categoria_id WHERE c.id = ? OR c.padre_id = ?', [$catId, $catId]), 'id');
    foreach ($ids as $id) {
        $p = publicacion_por_id((int) $id);
        $campos = campos_busqueda($p, $p['categoria_nombre'], (string) $p['padre_nombre']);
        consulta('UPDATE publicaciones SET titulo_norm = ?, busqueda = ? WHERE id = ?', [$campos['titulo_norm'], $campos['busqueda'], (int) $id]);
    }
}

function eliminar_categoria(int $id, int $moverA): array
{
    $c = categoria_por_id($id);
    if (!$c) {
        return ['ok' => false, 'error' => 'La categoría no existe.'];
    }
    if ((int) valor('SELECT COUNT(*) FROM categorias WHERE padre_id = ?', [$id]) > 0) {
        return ['ok' => false, 'error' => "“{$c['nombre']}” tiene subcategorías. Muévelas o elimínalas primero."];
    }
    $n = (int) valor('SELECT COUNT(*) FROM publicaciones WHERE categoria_id = ?', [$id]);
    if ($n > 0) {
        if ($moverA === $id || !categoria_por_id($moverA)) {
            return ['ok' => false, 'error' => "“{$c['nombre']}” tiene " . plural($n, 'publicación', 'publicaciones') . '. Elige a qué categoría moverlas.'];
        }
        consulta('UPDATE publicaciones SET categoria_id = ? WHERE categoria_id = ?', [$moverA, $id]);
        reindexar_categoria($moverA);
    }
    consulta('DELETE FROM categorias WHERE id = ?', [$id]);
    registrar_log('admin', "eliminó categoría #{$id} {$c['slug']}");
    return ['ok' => true, 'mensaje' => "“{$c['nombre']}” eliminada" . ($n ? ' y sus publicaciones movidas.' : '.')];
}

// --- Usuarios ----------------------------------------------------------------------

function cambiar_rol(int $id, string $rol): array
{
    if (!in_array($rol, ['usuario', 'admin'], true)) {
        return ['ok' => false, 'error' => 'Rol no válido.'];
    }
    $u = fila('SELECT id, nombre, rol FROM usuarios WHERE id = ?', [$id]);
    if (!$u) {
        return ['ok' => false, 'error' => 'La cuenta no existe.'];
    }
    if ($rol === 'usuario' && $u['rol'] === 'admin' && (int) valor("SELECT COUNT(*) FROM usuarios WHERE rol = 'admin'") <= 1) {
        return ['ok' => false, 'error' => 'Debe quedar al menos un administrador.'];
    }
    consulta('UPDATE usuarios SET rol = ? WHERE id = ?', [$rol, $id]);
    registrar_log('admin', "rol de #{$id} cambiado a {$rol} por usuario #" . usuario_actual()['id']);
    return ['ok' => true, 'mensaje' => $rol === 'admin' ? "{$u['nombre']} ahora es admin." : "{$u['nombre']} ya no es admin."];
}
