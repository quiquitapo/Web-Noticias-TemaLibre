<?php
/**
 * Esquema de base de datos (versión 3) y datos de ejemplo.
 *
 * Uso por consola (desde la carpeta del proyecto):
 *   php includes/instalar.php              Crea las tablas y carga los datos de ejemplo si están vacías
 *   php includes/instalar.php --reiniciar  Borra todo y vuelve a instalar
 *   php includes/instalar.php --exportar   Regenera sql/buscador_mysql.sql (para importar en phpMyAdmin)
 *
 * Con SQLite no necesitas ejecutar nada: la base se crea (o se actualiza) sola.
 * Una base v2 (Sin Filtro v4) se migra sola a v3 sin perder lo que subiste.
 */
declare(strict_types=1);

const TABLAS = ['comentarios', 'busquedas', 'clics', 'intentos_acceso', 'redes_sociales', 'imagenes', 'publicaciones', 'usuarios', 'categorias', 'meta'];
// Tablas de la versión 1, se eliminan al actualizar.
const TABLAS_V1 = ['videos', 'noticias', 'productos', 'perfiles'];

function esquema(string $driver): array
{
    $mysql = $driver === 'mysql';
    $pk = $mysql ? 'INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
    $fk = $mysql ? 'INT UNSIGNED' : 'INTEGER';
    $fin = $mysql ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';
    $ix = static fn(string $n, string $t, string $c) => "CREATE INDEX {$n} ON {$t} ({$c})";

    return [
        "CREATE TABLE IF NOT EXISTS meta (
  clave VARCHAR(40) NOT NULL PRIMARY KEY,
  valor VARCHAR(255) NOT NULL
){$fin}",
        "CREATE TABLE IF NOT EXISTS categorias (
  id {$pk},
  slug VARCHAR(80) NOT NULL UNIQUE,
  nombre VARCHAR(80) NOT NULL,
  descripcion VARCHAR(255) NOT NULL DEFAULT '',
  nota TEXT NULL,
  padre_id {$fk} NULL,
  orden INT NOT NULL DEFAULT 0,
  FOREIGN KEY (padre_id) REFERENCES categorias(id)
){$fin}",
        "CREATE TABLE IF NOT EXISTS usuarios (
  id {$pk},
  nombre VARCHAR(80) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  clave_hash VARCHAR(255) NOT NULL,
  rol VARCHAR(10) NOT NULL DEFAULT 'usuario',
  nombre_admin VARCHAR(80) NULL,
  guardar_historial SMALLINT NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL,
  ultimo_acceso DATETIME NULL
){$fin}",
        "CREATE TABLE IF NOT EXISTS publicaciones (
  id {$pk},
  slug VARCHAR(160) NOT NULL UNIQUE,
  tipo VARCHAR(10) NOT NULL,
  titulo VARCHAR(200) NOT NULL,
  descripcion TEXT NOT NULL,
  cuerpo TEXT NULL,
  categoria_id {$fk} NOT NULL,
  orientacion VARCHAR(20) NOT NULL DEFAULT 'no-aplica',
  orientacion_nota VARCHAR(255) NULL,
  verificacion VARCHAR(20) NOT NULL DEFAULT 'sin-verificar',
  verificacion_nota VARCHAR(600) NULL,
  creador VARCHAR(120) NOT NULL DEFAULT '',
  creador_url VARCHAR(255) NULL,
  autor VARCHAR(120) NULL,
  fuente_url VARCHAR(255) NULL,
  venta_url VARCHAR(255) NULL,
  tienda VARCHAR(120) NULL,
  precio INT NULL,
  precio_antes INT NULL,
  ficha TEXT NULL,
  miniatura VARCHAR(200) NOT NULL,
  miniatura_color CHAR(7) NOT NULL DEFAULT '#e5e7ef',
  video_archivo VARCHAR(200) NULL,
  video_webm VARCHAR(200) NULL,
  subtitulos VARCHAR(200) NULL,
  duracion_seg INT NOT NULL DEFAULT 0,
  etiquetas VARCHAR(500) NOT NULL DEFAULT '',
  vistas INT NOT NULL DEFAULT 0,
  destacado SMALLINT NOT NULL DEFAULT 0,
  subido_por_id {$fk} NULL,
  subido_por VARCHAR(80) NOT NULL DEFAULT '',
  titulo_norm VARCHAR(400) NOT NULL DEFAULT '',
  busqueda TEXT NOT NULL,
  publicado_en DATETIME NOT NULL,
  actualizado_en DATETIME NULL,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id),
  FOREIGN KEY (subido_por_id) REFERENCES usuarios(id) ON DELETE SET NULL
){$fin}",
        "CREATE TABLE IF NOT EXISTS imagenes (
  id {$pk},
  publicacion_id {$fk} NOT NULL,
  base VARCHAR(200) NOT NULL,
  color CHAR(7) NOT NULL DEFAULT '#e5e7ef',
  alt VARCHAR(255) NOT NULL DEFAULT '',
  orden INT NOT NULL DEFAULT 0,
  FOREIGN KEY (publicacion_id) REFERENCES publicaciones(id) ON DELETE CASCADE
){$fin}",
        "CREATE TABLE IF NOT EXISTS redes_sociales (
  id {$pk},
  publicacion_id {$fk} NOT NULL,
  red VARCHAR(20) NOT NULL,
  usuario VARCHAR(80) NOT NULL,
  url VARCHAR(255) NOT NULL,
  FOREIGN KEY (publicacion_id) REFERENCES publicaciones(id) ON DELETE CASCADE
){$fin}",
        "CREATE TABLE IF NOT EXISTS intentos_acceso (
  id {$pk},
  clave CHAR(64) NOT NULL,
  creado_en DATETIME NOT NULL
){$fin}",
        "CREATE TABLE IF NOT EXISTS clics (
  id {$pk},
  usuario_id {$fk} NOT NULL,
  publicacion_id {$fk} NOT NULL,
  tipo VARCHAR(12) NOT NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (publicacion_id) REFERENCES publicaciones(id) ON DELETE CASCADE
){$fin}",
        tabla_comentarios($driver),
        "CREATE TABLE IF NOT EXISTS busquedas (
  id {$pk},
  termino VARCHAR(120) NOT NULL,
  resultados INT NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL
){$fin}",
        $ix('idx_pub_categoria', 'publicaciones', 'categoria_id'),
        $ix('idx_pub_fecha', 'publicaciones', 'publicado_en'),
        $ix('idx_pub_orientacion', 'publicaciones', 'orientacion'),
        $ix('idx_pub_verificacion', 'publicaciones', 'verificacion'),
        $ix('idx_pub_tipo', 'publicaciones', 'tipo'),
        $ix('idx_cat_padre', 'categorias', 'padre_id'),
        $ix('idx_img_pub', 'imagenes', 'publicacion_id'),
        $ix('idx_redes_pub', 'redes_sociales', 'publicacion_id'),
        $ix('idx_intentos_clave', 'intentos_acceso', 'clave, creado_en'),
        $ix('idx_clics_usuario', 'clics', 'usuario_id, creado_en'),
        $ix('idx_busquedas_fecha', 'busquedas', 'creado_en'),
        $ix('idx_comentarios_pub', 'comentarios', 'publicacion_id, creado_en'),
        $ix('idx_comentarios_usuario', 'comentarios', 'usuario_id, creado_en'),
    ];
}

function tabla_comentarios(string $driver): string
{
    $mysql = $driver === 'mysql';
    $pk = $mysql ? 'INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
    $fk = $mysql ? 'INT UNSIGNED' : 'INTEGER';
    $fin = $mysql ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';
    return "CREATE TABLE IF NOT EXISTS comentarios (
  id {$pk},
  publicacion_id {$fk} NOT NULL,
  usuario_id {$fk} NOT NULL,
  texto TEXT NOT NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (publicacion_id) REFERENCES publicaciones(id) ON DELETE CASCADE,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
){$fin}";
}

function borrar_tablas(PDO $pdo, string $driver): void
{
    if ($driver === 'mysql') {
        $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
    } else {
        $pdo->exec('PRAGMA foreign_keys = OFF');
    }
    foreach (array_merge(TABLAS, TABLAS_V1) as $t) {
        $pdo->exec("DROP TABLE IF EXISTS {$t}");
    }
    if ($driver === 'mysql') {
        $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
    } else {
        $pdo->exec('PRAGMA foreign_keys = ON');
    }
}

function version_esquema(PDO $pdo): ?string
{
    try {
        $v = $pdo->query("SELECT valor FROM meta WHERE clave = 'esquema'")->fetchColumn();
        return $v === false ? null : (string) $v;
    } catch (Throwable) {
        return null;
    }
}

function instalar(PDO $pdo, string $driver): void
{
    $version = version_esquema($pdo);
    if ($version === '2') {
        migrar_v2_a_v3($pdo, $driver);
        return;
    }
    if ($version !== null && $version !== ESQUEMA_VERSION) {
        throw new RuntimeException("La base usa el esquema v{$version}. Usa --reiniciar para reemplazarla (se borran los datos).");
    }
    if ($version === null) {
        borrar_tablas($pdo, $driver); // elimina tablas de la versión 1 si existen
        foreach (esquema($driver) as $sql) {
            $pdo->exec($sql);
        }
        $pdo->prepare('INSERT INTO meta (clave, valor) VALUES (?, ?)')->execute(['esquema', ESQUEMA_VERSION]);
    }
    if ((int) $pdo->query('SELECT COUNT(*) FROM categorias')->fetchColumn() === 0) {
        $pdo->beginTransaction();
        foreach (filas_semilla() as [$tabla, $datos]) {
            $cols = array_keys($datos);
            $st = $pdo->prepare("INSERT INTO {$tabla} (" . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')');
            $st->execute(array_values($datos));
        }
        $pdo->commit();
    }
}

/** Lee sql/datos_demo.json. */
function datos_demo(): array
{
    return json_decode((string) file_get_contents(APP_DIR . '/sql/datos_demo.json'), true, 512, JSON_THROW_ON_ERROR);
}

/** Fila de publicación de ejemplo (sin id) a partir del JSON. */
function fila_publicacion_demo(array $p, int $categoriaId, string $categoria, string $padre, string $firma): array
{
    $fila = [
        'slug' => $p['slug'], 'tipo' => $p['tipo'], 'titulo' => $p['titulo'], 'descripcion' => $p['descripcion'],
        'cuerpo' => $p['cuerpo'] ?? null, 'categoria_id' => $categoriaId,
        'orientacion' => $p['orientacion'], 'orientacion_nota' => $p['orientacion_nota'] ?? null,
        'verificacion' => $p['verificacion'], 'verificacion_nota' => $p['verificacion_nota'] ?? null,
        'creador' => $p['creador'] ?? '', 'creador_url' => $p['creador_url'] ?? null, 'autor' => $p['autor'] ?? null,
        'fuente_url' => $p['fuente_url'] ?? null,
        'venta_url' => $p['venta']['url'] ?? null, 'tienda' => $p['venta']['tienda'] ?? null,
        'precio' => $p['venta']['precio'] ?? null, 'precio_antes' => $p['venta']['antes'] ?? null,
        'ficha' => !empty($p['ficha']) ? json_encode($p['ficha'], JSON_UNESCAPED_UNICODE) : null,
        'miniatura' => $p['miniatura'], 'miniatura_color' => $p['miniatura_color'],
        'video_archivo' => $p['video']['archivo'] ?? null, 'video_webm' => $p['video']['webm'] ?? null,
        'subtitulos' => $p['video']['vtt'] ?? null, 'duracion_seg' => $p['video']['duracion'] ?? 0,
        'etiquetas' => implode(', ', $p['etiquetas'] ?? []), 'vistas' => $p['vistas'] ?? 0, 'destacado' => $p['destacado'] ?? 0,
        'subido_por_id' => 1, 'subido_por' => $p['subido_por'] ?? $firma,
        'publicado_en' => $p['publicado_en'], 'actualizado_en' => null,
    ];
    return $fila + campos_busqueda($fila, $categoria, $padre);
}

/** Cuenta de la comunidad de ejemplo: no se puede usar para entrar (contraseña aleatoria). */
function fila_comunidad(array $u): array
{
    return ['nombre' => $u['nombre'], 'email' => $u['email'], 'clave_hash' => password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT),
        'rol' => 'usuario', 'nombre_admin' => null, 'guardar_historial' => 0, 'creado_en' => '2026-09-10 12:00:00', 'ultimo_acceso' => null];
}

/** Convierte sql/datos_demo.json en filas listas para insertar, con IDs explícitos. */
function filas_semilla(): array
{
    $d = datos_demo();
    $out = [];
    $demo = config('cuenta_demo');
    $admin = config('cuenta_admin');
    $out[] = ['usuarios', ['id' => 1, 'nombre' => $admin['nombre'], 'email' => $admin['email'], 'clave_hash' => password_hash($admin['clave'], PASSWORD_DEFAULT),
        'rol' => 'admin', 'nombre_admin' => $admin['nombre_admin'], 'guardar_historial' => 0, 'creado_en' => '2026-09-01 09:00:00', 'ultimo_acceso' => null]];
    $out[] = ['usuarios', ['id' => 2, 'nombre' => $demo['nombre'], 'email' => $demo['email'], 'clave_hash' => password_hash($demo['clave'], PASSWORD_DEFAULT),
        'rol' => 'usuario', 'nombre_admin' => null, 'guardar_historial' => 0, 'creado_en' => '2026-09-01 10:00:00', 'ultimo_acceso' => null]];
    $usuarioId = [];
    foreach ($d['comunidad'] ?? [] as $i => $u) {
        $usuarioId[$u['email']] = 3 + $i;
        $out[] = ['usuarios', ['id' => 3 + $i] + fila_comunidad($u)];
    }

    $catId = [];
    $catNombre = [];
    $padreDe = [];
    $id = 0;
    foreach ($d['categorias'] as $i => $c) {
        $pid = ++$id;
        $catId[$c['slug']] = $pid;
        $catNombre[$c['slug']] = $c['nombre'];
        $out[] = ['categorias', ['id' => $pid, 'slug' => $c['slug'], 'nombre' => $c['nombre'], 'descripcion' => $c['descripcion'], 'nota' => $c['nota'] ?? null, 'padre_id' => null, 'orden' => $i]];
        foreach ($c['subcategorias'] as $k => $sc) {
            $sid = ++$id;
            $catId[$sc['slug']] = $sid;
            $catNombre[$sc['slug']] = $sc['nombre'];
            $padreDe[$sc['slug']] = $c['nombre'];
            $out[] = ['categorias', ['id' => $sid, 'slug' => $sc['slug'], 'nombre' => $sc['nombre'], 'descripcion' => '', 'nota' => null, 'padre_id' => $pid, 'orden' => $k]];
        }
    }

    $img = 0;
    $red = 0;
    $pubId = [];
    // Orden cronológico: los IDs crecen con la fecha, igual que si se hubieran subido de a uno.
    usort($d['publicaciones'], static fn($a, $b) => strcmp($a['publicado_en'], $b['publicado_en']));
    foreach ($d['publicaciones'] as $i => $p) {
        $pid = $i + 1;
        $pubId[$p['slug']] = $pid;
        $out[] = ['publicaciones', ['id' => $pid] + fila_publicacion_demo($p, $catId[$p['categoria']], $catNombre[$p['categoria']], $padreDe[$p['categoria']] ?? '', $admin['nombre_admin'])];
        foreach ($p['imagenes'] ?? [] as $k => $im) {
            $out[] = ['imagenes', ['id' => ++$img, 'publicacion_id' => $pid, 'base' => $im['base'], 'color' => $im['color'], 'alt' => $im['alt'], 'orden' => $k]];
        }
        foreach ($p['redes'] ?? [] as $r) {
            $out[] = ['redes_sociales', ['id' => ++$red, 'publicacion_id' => $pid, 'red' => $r['red'], 'usuario' => $r['usuario'], 'url' => $r['url']]];
        }
    }
    foreach ($d['comentarios'] ?? [] as $k => $c) {
        if (isset($pubId[$c['publicacion']], $usuarioId[$c['email']])) {
            $out[] = ['comentarios', ['id' => $k + 1, 'publicacion_id' => $pubId[$c['publicacion']], 'usuario_id' => $usuarioId[$c['email']], 'texto' => $c['texto'], 'creado_en' => $c['fecha']]];
        }
    }
    return $out;
}

/**
 * Migra una base v2 (Sin Filtro v4) a v3 sin borrar nada:
 * agrega comentarios y notas de sección, renombra Ventas a Productos, convierte Tecnología en sección,
 * crea las categorías nuevas y suma las publicaciones de ejemplo que falten.
 */
function migrar_v2_a_v3(PDO $pdo, string $driver): void
{
    $d = datos_demo();
    $ins = static function (string $tabla, array $datos) use ($pdo): int {
        $cols = array_keys($datos);
        $pdo->prepare("INSERT INTO {$tabla} (" . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')')->execute(array_values($datos));
        return (int) $pdo->lastInsertId();
    };
    $uno = static function (string $sql, array $p = []) use ($pdo) {
        $st = $pdo->prepare($sql);
        $st->execute($p);
        $v = $st->fetchColumn();
        return $v === false ? null : $v;
    };
    $ejec = static fn(string $sql, array $p = []) => $pdo->prepare($sql)->execute($p);

    // 1. Esquema (fuera de la transacción: MySQL confirma solo los cambios de estructura)
    $columnas = $driver === 'mysql'
        ? array_column($pdo->query('SHOW COLUMNS FROM categorias')->fetchAll(), 'Field')
        : array_column($pdo->query('PRAGMA table_info(categorias)')->fetchAll(), 'name');
    if (!in_array('nota', $columnas, true)) {
        $pdo->exec('ALTER TABLE categorias ADD COLUMN nota TEXT NULL');
    }
    $pdo->exec(tabla_comentarios($driver));
    foreach (['idx_comentarios_pub' => 'publicacion_id, creado_en', 'idx_comentarios_usuario' => 'usuario_id, creado_en'] as $n => $c) {
        try {
            $pdo->exec("CREATE INDEX {$n} ON comentarios ({$c})");
        } catch (Throwable) {
            // ya existe
        }
    }

    $pdo->beginTransaction();
    try {
        // 2. Ventas pasa a llamarse Productos (y sus subcategorías cambian de dirección)
        if ($uno("SELECT id FROM categorias WHERE slug = 'ventas'") && !$uno("SELECT id FROM categorias WHERE slug = 'productos'")) {
            $ejec("UPDATE categorias SET slug = 'productos', nombre = 'Productos' WHERE slug = 'ventas'");
            foreach (['tecnologia', 'hogar', 'deportes', 'fotografia'] as $s) {
                if (!$uno('SELECT id FROM categorias WHERE slug = ?', ["productos-{$s}"])) {
                    $ejec('UPDATE categorias SET slug = ? WHERE slug = ?', ["productos-{$s}", "ventas-{$s}"]);
                }
            }
        }
        // 3. Tecnología deja de ser subcategoría de Noticias y pasa a ser una sección
        $ejec("UPDATE categorias SET padre_id = NULL WHERE slug = 'tecnologia'");

        // 4. Categorías que falten, notas y orden de las secciones según la semilla
        $catId = [];
        foreach ($d['categorias'] as $i => $c) {
            $id = (int) $uno('SELECT id FROM categorias WHERE slug = ?', [$c['slug']]);
            if (!$id) {
                $id = $ins('categorias', ['slug' => $c['slug'], 'nombre' => $c['nombre'], 'descripcion' => $c['descripcion'], 'nota' => $c['nota'] ?? null, 'padre_id' => null, 'orden' => $i]);
            } else {
                $ejec('UPDATE categorias SET orden = ?, descripcion = ?, nota = COALESCE(nota, ?) WHERE id = ?', [$i, $c['descripcion'], $c['nota'] ?? null, $id]);
            }
            $catId[$c['slug']] = $id;
            foreach ($c['subcategorias'] as $k => $sc) {
                $sid = (int) $uno('SELECT id FROM categorias WHERE slug = ?', [$sc['slug']]);
                if (!$sid) {
                    $sid = $ins('categorias', ['slug' => $sc['slug'], 'nombre' => $sc['nombre'], 'descripcion' => '', 'nota' => null, 'padre_id' => $id, 'orden' => $k]);
                }
                $catId[$sc['slug']] = $sid;
            }
        }

        // 5. Publicaciones de ejemplo que estaban en Tecnología pasan a su subcategoría
        $tec = $catId['tecnologia'] ?? 0;
        foreach ($d['publicaciones'] as $p) {
            if ($tec && ($catId[$p['categoria']] ?? 0) !== $tec) {
                $ejec('UPDATE publicaciones SET categoria_id = ? WHERE slug = ? AND categoria_id = ?', [$catId[$p['categoria']] ?? $tec, $p['slug'], $tec]);
            }
        }

        // 6. Comunidad, publicaciones y comentarios de ejemplo que falten
        $usuarioId = [];
        foreach ($d['comunidad'] ?? [] as $u) {
            $usuarioId[$u['email']] = (int) ($uno('SELECT id FROM usuarios WHERE email = ?', [$u['email']]) ?: $ins('usuarios', fila_comunidad($u)));
        }
        $nombres = [];
        foreach ($pdo->query('SELECT c.id, c.nombre, pc.nombre AS padre FROM categorias c LEFT JOIN categorias pc ON pc.id = c.padre_id')->fetchAll() as $c) {
            $nombres[(int) $c['id']] = [$c['nombre'], (string) $c['padre']];
        }
        $nuevas = [];
        usort($d['publicaciones'], static fn($a, $b) => strcmp($a['publicado_en'], $b['publicado_en']));
        foreach ($d['publicaciones'] as $p) {
            if ($uno('SELECT id FROM publicaciones WHERE slug = ?', [$p['slug']]) || !isset($catId[$p['categoria']])) {
                continue;
            }
            $cid = $catId[$p['categoria']];
            $pid = $ins('publicaciones', fila_publicacion_demo($p, $cid, $nombres[$cid][0], $nombres[$cid][1], (string) config('cuenta_admin.nombre_admin')));
            $nuevas[$p['slug']] = $pid;
            foreach ($p['imagenes'] ?? [] as $k => $im) {
                $ins('imagenes', ['publicacion_id' => $pid, 'base' => $im['base'], 'color' => $im['color'], 'alt' => $im['alt'], 'orden' => $k]);
            }
            foreach ($p['redes'] ?? [] as $r) {
                $ins('redes_sociales', ['publicacion_id' => $pid, 'red' => $r['red'], 'usuario' => $r['usuario'], 'url' => $r['url']]);
            }
        }
        foreach ($d['comentarios'] ?? [] as $c) {
            $pid = $nuevas[$c['publicacion']] ?? (int) $uno('SELECT id FROM publicaciones WHERE slug = ?', [$c['publicacion']]);
            if ($pid && isset($usuarioId[$c['email']]) && !$uno('SELECT id FROM comentarios WHERE publicacion_id = ? AND usuario_id = ? AND texto = ?', [$pid, $usuarioId[$c['email']], $c['texto']])) {
                $ins('comentarios', ['publicacion_id' => $pid, 'usuario_id' => $usuarioId[$c['email']], 'texto' => $c['texto'], 'creado_en' => $c['fecha']]);
            }
        }

        // 7. Texto de búsqueda al día con los nombres nuevos de las categorías
        $st = $pdo->prepare('UPDATE publicaciones SET titulo_norm = ?, busqueda = ? WHERE id = ?');
        foreach ($pdo->query('SELECT * FROM publicaciones')->fetchAll() as $p) {
            [$cat, $padre] = $nombres[(int) $p['categoria_id']] ?? ['', ''];
            $b = campos_busqueda($p, $cat, $padre);
            $st->execute([$b['titulo_norm'], $b['busqueda'], $p['id']]);
        }
        $ejec('UPDATE meta SET valor = ? WHERE clave = ?', [ESQUEMA_VERSION, 'esquema']);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function exportar_sql_mysql(): string
{
    $q = static function ($v): string {
        if ($v === null) {
            return 'NULL';
        }
        if (is_int($v) || is_float($v)) {
            return (string) $v;
        }
        return "'" . str_replace(['\\', "'", "\0"], ['\\\\', "''", ''], (string) $v) . "'";
    };
    $sql = "-- Sin Filtro: esquema v" . ESQUEMA_VERSION . " y datos de ejemplo para MySQL 8+ / MariaDB 10.3+\n"
        . "-- Generado con: php includes/instalar.php --exportar\n"
        . '-- Admin: ' . config('cuenta_admin.email') . ' / ' . config('cuenta_admin.clave') . "\n"
        . '-- Usuario: ' . config('cuenta_demo.email') . ' / ' . config('cuenta_demo.clave') . "\n\n"
        . "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n";
    foreach (array_merge(TABLAS, TABLAS_V1) as $t) {
        $sql .= "DROP TABLE IF EXISTS {$t};\n";
    }
    $sql .= "SET FOREIGN_KEY_CHECKS = 1;\n\n" . implode(";\n\n", esquema('mysql')) . ";\n\n";
    $sql .= "INSERT INTO meta (clave, valor) VALUES ('esquema', '" . ESQUEMA_VERSION . "');\n";
    foreach (filas_semilla() as [$tabla, $datos]) {
        $sql .= "INSERT INTO {$tabla} (" . implode(', ', array_keys($datos)) . ') VALUES (' . implode(', ', array_map($q, $datos)) . ");\n";
    }
    return $sql;
}

// --- Ejecución por consola ------------------------------------------------------
if (PHP_SAPI === 'cli' && realpath($argv[0] ?? '') === realpath(__FILE__)) {
    require __DIR__ . '/bootstrap.php';
    $args = array_slice($argv, 1);
    if (in_array('--exportar', $args, true)) {
        file_put_contents(APP_DIR . '/sql/buscador_mysql.sql', exportar_sql_mysql());
        file_put_contents(APP_DIR . '/sql/esquema_sqlite.sql', implode(";\n\n", esquema('sqlite')) . ";\n");
        echo "Listo: sql/buscador_mysql.sql y sql/esquema_sqlite.sql\n";
        exit(0);
    }
    $pdo = db();
    if (in_array('--reiniciar', $args, true)) {
        borrar_tablas($pdo, db_driver());
    }
    instalar($pdo, db_driver());
    echo 'Base de datos lista (' . db_driver() . ', esquema v' . ESQUEMA_VERSION . ').' . PHP_EOL;
    echo 'Admin: ' . config('cuenta_admin.email') . ' / ' . config('cuenta_admin.clave') . PHP_EOL;
    echo 'Usuario: ' . config('cuenta_demo.email') . ' / ' . config('cuenta_demo.clave') . PHP_EOL;
    exit(0);
}
