<?php
/**
 * Videos de YouTube.
 * - El reproductor se carga desde youtube-nocookie.com solo cuando la persona pulsa «Reproducir».
 * - Las miniaturas las descarga el servidor una vez y se guardan aquí como WebP: el navegador
 *   nunca pide imágenes a YouTube y el identificador del video no aparece en la página sin sesión.
 * - Las descargas solo van a direcciones fijas de YouTube con un identificador validado (sin SSRF).
 */
declare(strict_types=1);

require_once __DIR__ . '/medios.php';

const YOUTUBE_CANAL_PENDIENTE = 'Canal de YouTube';

/** Extrae el identificador de 11 caracteres de cualquier enlace habitual de YouTube (o del id suelto). */
function youtube_id_de(string $texto): ?string
{
    $texto = trim($texto);
    if (preg_match('/^[A-Za-z0-9_-]{11}$/', $texto)) {
        return $texto;
    }
    $u = parse_url($texto);
    if (!$u || !in_array(strtolower($u['scheme'] ?? ''), ['http', 'https'], true)) {
        return null;
    }
    $host = strtolower(preg_replace('/^(www\.|m\.|music\.)/', '', (string) ($u['host'] ?? '')));
    $ruta = (string) ($u['path'] ?? '');
    $id = null;
    if ($host === 'youtu.be') {
        $id = trim($ruta, '/');
    } elseif (in_array($host, ['youtube.com', 'youtube-nocookie.com'], true)) {
        parse_str((string) ($u['query'] ?? ''), $q);
        if ($ruta === '/watch' && is_string($q['v'] ?? null)) {
            $id = $q['v'];
        } elseif (preg_match('#^/(embed|shorts|live|v)/([^/?]+)#', $ruta, $m)) {
            $id = $m[2];
        }
    }
    return is_string($id) && preg_match('/^[A-Za-z0-9_-]{11}$/', $id) ? $id : null;
}

function youtube_url(string $id): string
{
    return 'https://www.youtube.com/watch?v=' . rawurlencode($id);
}

function youtube_embed(string $id): string
{
    return 'https://www.youtube-nocookie.com/embed/' . rawurlencode($id) . '?autoplay=1&rel=0&hl=es&cc_lang_pref=es';
}

/**
 * GET acotado: solo a los hosts de YouTube, con tiempo y tamaño máximos. Devuelve null si falla.
 * $sinRed queda en true si no se pudo conectar (sin internet, DNS o tiempo agotado), para no insistir.
 */
function youtube_http(string $url, int $maxBytes = 3145728, int $segundos = 6, ?bool &$sinRed = null): ?string
{
    $sinRed = false;
    $host = (string) parse_url($url, PHP_URL_HOST);
    $permitidos = array_filter(array_map('trim', explode(',', (string) config('youtube.hosts', 'i.ytimg.com,www.youtube.com'))));
    if (!in_array($host, $permitidos, true)) {
        return null;
    }
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $datos = '';
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => $segundos,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTPS | CURLPROTO_HTTP,
            CURLOPT_USERAGENT => 'SinFiltro/1.0',
            CURLOPT_WRITEFUNCTION => static function ($ch, string $trozo) use (&$datos, $maxBytes): int {
                $datos .= $trozo;
                return strlen($datos) > $maxBytes ? 0 : strlen($trozo); // aborta si es demasiado grande
            },
        ]);
        $ok = curl_exec($ch);
        $codigo = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $errno = curl_errno($ch);
        $sinRed = $errno !== 0 && $errno !== CURLE_WRITE_ERROR; // 23: cortamos nosotros por tamaño
        return $ok && $codigo === 200 && $datos !== '' ? $datos : null;
    }
    if (!filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) {
        return null;
    }
    $ctx = stream_context_create(['http' => ['timeout' => $segundos, 'follow_location' => 0, 'ignore_errors' => true, 'user_agent' => 'SinFiltro/1.0']]);
    $f = @fopen($url, 'rb', false, $ctx);
    if (!$f) {
        $sinRed = true;
        return null;
    }
    $estado = (string) (stream_get_meta_data($f)['wrapper_data'][0] ?? '');
    $datos = (string) stream_get_contents($f, $maxBytes + 1);
    fclose($f);
    return str_contains($estado, ' 200') && $datos !== '' && strlen($datos) <= $maxBytes ? $datos : null;
}

/** Título y canal del video (oEmbed público de YouTube, sin clave de API). */
function youtube_oembed(string $id): ?array
{
    if (!preg_match('/^[A-Za-z0-9_-]{11}$/', $id)) {
        return null;
    }
    $base = rtrim((string) config('youtube.oembed', 'https://www.youtube.com/oembed'), '?');
    $json = youtube_http($base . '?format=json&url=' . rawurlencode(youtube_url($id)), 65536, 5);
    $d = $json ? json_decode($json, true) : null;
    if (!is_array($d) || !is_string($d['title'] ?? null)) {
        return null;
    }
    $canalUrl = is_string($d['author_url'] ?? null) && str_starts_with($d['author_url'], 'https://www.youtube.com/') ? $d['author_url'] : null;
    return [
        'titulo' => mb_substr(trim($d['title']), 0, 200),
        'canal' => mb_substr(trim((string) ($d['author_name'] ?? '')), 0, 120),
        'canal_url' => $canalUrl,
    ];
}

/**
 * Descarga la miniatura del video y la guarda como WebP en media/portadas/youtube/{slug}-{ancho}.webp.
 * Prueba la de máxima resolución y, si no existe, las de menor tamaño. Devuelve el color promedio o null.
 */
function youtube_guardar_miniatura(string $id, string $slug): ?string
{
    if (!preg_match('/^[A-Za-z0-9_-]{11}$/', $id) || !preg_match('/^[a-z0-9-]{1,160}$/', $slug) || !function_exists('imagewebp')) {
        return null;
    }
    $base = rtrim((string) config('youtube.miniaturas', 'https://i.ytimg.com/vi/'), '/') . '/';
    $img = null;
    foreach (['maxresdefault', 'sddefault', 'hqdefault'] as $variante) {
        $datos = youtube_http($base . $id . '/' . $variante . '.jpg', 3145728, 6, $sinRed);
        if ($sinRed) {
            break; // sin conexión: no tiene sentido probar las otras variantes
        }
        $info = $datos ? @getimagesizefromstring($datos) : false;
        // YouTube responde con una imagen gris de 120×90 cuando la variante no existe
        if ($info && in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_WEBP, IMAGETYPE_PNG], true) && $info[0] >= 320 && $info[0] <= 4000 && $info[1] <= 4000) {
            $img = @imagecreatefromstring($datos);
            if ($img) {
                break;
            }
        }
    }
    if (!$img) {
        return null;
    }
    [$w, $h] = [imagesx($img), imagesy($img)];
    // Recorte 16:9 centrado (las variantes 4:3 traen franjas negras arriba y abajo)
    $ch = (int) round($w * 9 / 16);
    $cy = max(0, (int) (($h - $ch) / 2));
    $dir = APP_DIR . '/media/portadas/youtube';
    if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
        imagedestroy($img);
        return null;
    }
    $listo = true;
    foreach (ANCHOS_MINIATURA as $aw) {
        $ah = (int) round($aw * 9 / 16);
        $dst = imagecreatetruecolor($aw, $ah);
        imagecopyresampled($dst, $img, 0, 0, 0, $cy, $aw, $ah, $w, min($ch, $h));
        $tmp = $dir . '/.' . $slug . '-' . $aw . '-' . bin2hex(random_bytes(3)) . '.tmp';
        $listo = $listo && imagewebp($dst, $tmp, $aw <= 480 ? 72 : ($aw <= 960 ? 66 : 60)) && rename($tmp, $dir . '/' . $slug . '-' . $aw . '.webp');
        imagedestroy($dst);
        if (is_file($tmp)) {
            @unlink($tmp);
        }
    }
    $px = imagecreatetruecolor(1, 1);
    imagecopyresampled($px, $img, 0, 0, 0, $cy, 1, 1, $w, min($ch, $h));
    $rgb = imagecolorat($px, 0, 0);
    imagedestroy($px);
    imagedestroy($img);
    return $listo ? sprintf('#%02x%02x%02x', ($rgb >> 16) & 255, ($rgb >> 8) & 255, $rgb & 255) : null;
}

/**
 * Completa una publicación de YouTube la primera vez: miniatura local y, si el canal aún no se conoce,
 * nombre y enlace del canal según YouTube. Devuelve true si la miniatura quedó guardada.
 */
function youtube_completar(array $p): bool
{
    $color = youtube_guardar_miniatura((string) $p['youtube_id'], (string) $p['slug']);
    if (!$color) {
        return false;
    }
    $cambios = ['miniatura_color' => $color];
    if (($p['creador'] ?? '') === YOUTUBE_CANAL_PENDIENTE && ($o = youtube_oembed((string) $p['youtube_id'])) && $o['canal'] !== '') {
        $cambios['creador'] = $o['canal'];
        $cambios['creador_url'] = $o['canal_url'];
    }
    $sets = implode(', ', array_map(static fn($k) => "{$k} = ?", array_keys($cambios)));
    consulta("UPDATE publicaciones SET {$sets} WHERE id = ?", [...array_values($cambios), (int) $p['id']]);
    if (isset($cambios['creador'])) {
        $pub = publicacion_por_id((int) $p['id']);
        $b = campos_busqueda($pub, (string) $pub['categoria_nombre'], (string) $pub['padre_nombre']);
        consulta('UPDATE publicaciones SET titulo_norm = ?, busqueda = ? WHERE id = ?', [$b['titulo_norm'], $b['busqueda'], (int) $p['id']]);
    }
    return true;
}
