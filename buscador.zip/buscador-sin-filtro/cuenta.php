<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

requerir_sesion('cuenta');
$u = usuario_actual();
$id = (int) $u['id'];
$errorEliminar = '';
$erroresClave = [];

if (es_post()) {
    if (!csrf_valido()) {
        flash('error', 'El formulario expiró por seguridad. Vuelve a intentarlo.');
        redirigir(url('cuenta.php'));
    }
    switch (entrada('accion')) {
        case 'historial':
            $activar = entrada('guardar') === '1';
            consulta('UPDATE usuarios SET guardar_historial = ? WHERE id = ?', [$activar ? 1 : 0, $id]);
            if (!$activar) {
                consulta('DELETE FROM clics WHERE usuario_id = ?', [$id]);
            }
            flash('exito', $activar ? 'Historial activado. Solo tú puedes verlo.' : 'Historial desactivado y borrado.');
            redirigir(url('cuenta.php') . '#privacidad');
        case 'borrar_historial':
            consulta('DELETE FROM clics WHERE usuario_id = ?', [$id]);
            flash('exito', 'Historial borrado.');
            redirigir(url('cuenta.php') . '#privacidad');
        case 'nombre_admin':
            if ($u['rol'] === 'admin') {
                $n = mb_substr(trim(entrada('nombre_admin')), 0, 80);
                consulta('UPDATE usuarios SET nombre_admin = ? WHERE id = ?', [$n !== '' ? $n : null, $id]);
                flash('exito', 'Nombre de admin guardado.');
            }
            redirigir(url('cuenta.php'));
        case 'clave':
            $r = cambiar_clave($id, (string) ($_POST['clave_actual'] ?? ''), (string) ($_POST['clave_nueva'] ?? ''));
            if ($r['ok']) {
                flash('exito', 'Contraseña actualizada.');
                redirigir(url('cuenta.php') . '#seguridad');
            }
            $erroresClave = $r['errores'];
            http_response_code(422);
            break;
        case 'eliminar':
            $r = eliminar_cuenta($id, (string) ($_POST['clave'] ?? ''));
            if ($r['ok']) {
                session_start();
                flash('info', 'Tu cuenta y tu historial fueron eliminados.');
                redirigir(url());
            }
            $errorEliminar = $r['error'];
            break;
    }
}
$clics = $u['guardar_historial'] ? clics_recientes($id) : [];
$etiquetaClic = ['video' => 'Video', 'youtube' => 'YouTube', 'fuente' => 'Fuente', 'venta' => 'Enlace de venta', 'red' => 'Red social', 'creador' => 'Sitio del creador'];

vista('cabecera', ['titulo' => 'Tu cuenta', 'seccion' => 'cuenta', 'sin_indexar' => true]);
?>
<div class="contenedor contenedor--texto cuenta">
  <header class="cuenta__cabeza">
    <span class="avatar avatar--grande" aria-hidden="true"><span><?= e(iniciales($u['nombre'])) ?></span></span>
    <div>
      <h1 class="cuenta__nombre"><?= e($u['nombre']) ?></h1>
      <p class="cuenta__email"><?= e($u['email']) ?><?php if ($u['rol'] === 'admin'): ?> <span class="rol-chip"><?= icono('escudo') ?>Administración</span><?php endif; ?></p>
    </div>
  </header>

  <dl class="specs specs--cuenta">
    <div class="specs__fila"><dt>Miembro desde</dt><dd><?= e(fecha_larga($u['creado_en'])) ?></dd></div>
    <div class="specs__fila"><dt>Último acceso</dt><dd><?= e($u['ultimo_acceso'] ? fecha_larga($u['ultimo_acceso'], true) : 'Ahora') ?></dd></div>
  </dl>

  <?php if ($u['rol'] === 'admin'): ?>
    <section class="caja" aria-labelledby="admin-titulo">
      <h2 class="caja__titulo" id="admin-titulo">Tu nombre de admin</h2>
      <p class="caja__txt">Aparece como “Subido por” en lo que publiques. Puedes cambiarlo en cada subida.</p>
      <form class="form form--linea" method="post">
        <?= csrf_campo() ?><input type="hidden" name="accion" value="nombre_admin">
        <div class="campo"><label for="nombre-admin">Nombre visible</label><input id="nombre-admin" name="nombre_admin" maxlength="80" value="<?= e($u['nombre_admin'] ?? '') ?>" placeholder="Ej.: Equipo Sin Filtro"></div>
        <button class="boton boton--primario" type="submit">Guardar</button>
      </form>
      <p><a class="enlace" href="<?= e(url('admin/')) ?>">Ir al panel de administración</a></p>
    </section>
  <?php endif; ?>

  <section class="caja" id="privacidad" aria-labelledby="priv-titulo">
    <h2 class="caja__titulo" id="priv-titulo"><?= icono('candado-privado') ?>Privacidad</h2>
    <ul class="lista-check">
      <li>No usamos rastreadores, publicidad ni servicios de terceros.</li>
      <li>Tus búsquedas no quedan asociadas a tu cuenta.</li>
      <li>El orden de los resultados es el mismo para todas las personas.</li>
    </ul>
    <form class="interruptor-form" method="post">
      <?= csrf_campo() ?><input type="hidden" name="accion" value="historial">
      <input type="hidden" name="guardar" value="<?= $u['guardar_historial'] ? '0' : '1' ?>">
      <div class="interruptor-fila">
        <span id="hist-txt"><strong>Guardar lo que abro</strong><span>Videos, fuentes y enlaces que abriste, para encontrarlos de nuevo. Solo tú lo ves.</span></span>
        <button class="interruptor" type="submit" role="switch" aria-checked="<?= $u['guardar_historial'] ? 'true' : 'false' ?>" aria-labelledby="hist-txt"><span></span></button>
      </div>
    </form>
    <?php if ($u['guardar_historial']): ?>
      <?php if ($clics): ?>
        <ul class="actividad">
          <?php foreach ($clics as $c): ?>
            <li><span class="actividad__tipo"><?= e($etiquetaClic[$c['tipo']] ?? $c['tipo']) ?></span><a href="<?= e(url('video.php', ['v' => $c['slug']])) ?>"><?= e($c['titulo']) ?></a><time datetime="<?= e(fecha_iso($c['fecha'])) ?>"><?= e(fecha_relativa($c['fecha'])) ?></time></li>
          <?php endforeach; ?>
        </ul>
        <form method="post"><?= csrf_campo() ?><input type="hidden" name="accion" value="borrar_historial"><button class="boton boton--suave" type="submit"><?= icono('eliminar') ?>Borrar historial</button></form>
      <?php else: ?>
        <p class="vacio-mini">Todavía no abres nada. Lo que veas a partir de ahora aparecerá aquí.</p>
      <?php endif; ?>
    <?php endif; ?>
  </section>

  <section class="caja" id="seguridad" aria-labelledby="clave-titulo">
    <h2 class="caja__titulo" id="clave-titulo"><?= icono('escudo') ?>Contraseña</h2>
    <?php
    $prueba = ['admin' => config('cuenta_admin'), 'demo' => config('cuenta_demo')];
    $clavePublica = false;
    foreach ($prueba as $c) {
        if (is_array($c) && $u['email'] === ($c['email'] ?? '') && password_verify((string) $c['clave'], (string) valor('SELECT clave_hash FROM usuarios WHERE id = ?', [$id]))) {
            $clavePublica = true;
        }
    }
    if ($clavePublica): ?>
      <p class="caja__txt">Esta es una cuenta de prueba con contraseña pública. Cámbiala antes de publicar el sitio.</p>
    <?php endif; ?>
    <details class="plegable"<?= $erroresClave ? ' open' : '' ?>>
      <summary class="boton boton--suave">Cambiar contraseña</summary>
      <form class="form" method="post">
        <?= csrf_campo() ?><input type="hidden" name="accion" value="clave">
        <input type="email" name="email" value="<?= e($u['email']) ?>" autocomplete="username" hidden>
        <?php foreach (['clave_actual' => ['Contraseña actual', 'current-password'], 'clave_nueva' => ['Nueva contraseña', 'new-password']] as $campo => [$etiqueta, $auto]): $errC = $erroresClave[$campo] ?? ''; ?>
          <div class="campo">
            <label for="<?= $campo ?>"><?= $etiqueta ?></label>
            <input id="<?= $campo ?>" name="<?= $campo ?>" type="password" autocomplete="<?= $auto ?>" required<?= $campo === 'clave_nueva' ? ' minlength="' . (int) config('seguridad.clave_min', 8) . '" maxlength="128" aria-describedby="' . ($errC ? 'clave_nueva-error ' : '') . 'clave_nueva-ayuda"' : ($errC ? ' aria-describedby="' . $campo . '-error"' : '') ?><?= $errC ? ' aria-invalid="true"' : '' ?>>
            <?php if ($campo === 'clave_nueva'): ?><p class="campo__ayuda" id="clave_nueva-ayuda">Al menos <?= (int) config('seguridad.clave_min', 8) ?> caracteres. Una frase larga es más segura que una palabra con símbolos.</p><?php endif; ?>
            <?php if ($errC): ?><p class="campo__error" id="<?= $campo ?>-error"><?= icono('alerta') ?><span><?= e($errC) ?></span></p><?php endif; ?>
          </div>
        <?php endforeach; ?>
        <button class="boton boton--primario" type="submit">Guardar contraseña</button>
      </form>
    </details>
  </section>

  <section class="caja caja--peligro" aria-labelledby="borrar-titulo">
    <h2 class="caja__titulo" id="borrar-titulo">Eliminar mi cuenta</h2>
    <p class="caja__txt">Se borran tu cuenta, tus comentarios y tu historial de forma permanente. No se puede deshacer.</p>
    <details class="plegable"<?= $errorEliminar ? ' open' : '' ?>>
      <summary class="boton boton--suave">Quiero eliminar mi cuenta</summary>
      <form class="form" method="post">
        <?= csrf_campo() ?><input type="hidden" name="accion" value="eliminar">
        <div class="campo">
          <label for="clave-eliminar">Escribe tu contraseña para confirmar</label>
          <input id="clave-eliminar" name="clave" type="password" autocomplete="current-password" required<?= $errorEliminar ? ' aria-invalid="true" aria-describedby="clave-eliminar-error"' : '' ?>>
          <?php if ($errorEliminar): ?><p class="campo__error" id="clave-eliminar-error"><?= icono('alerta') ?><span><?= e($errorEliminar) ?></span></p><?php endif; ?>
        </div>
        <button class="boton boton--peligro" type="submit"><?= icono('eliminar') ?>Eliminar mi cuenta para siempre</button>
      </form>
    </details>
  </section>

  <form method="post" action="<?= e(url('salir.php')) ?>" class="cuenta__salir">
    <?= csrf_campo() ?>
    <button class="boton boton--suave" type="submit"><?= icono('salir') ?>Cerrar sesión</button>
  </form>
</div>
<?php vista('pie', ['seccion' => 'cuenta']); ?>
