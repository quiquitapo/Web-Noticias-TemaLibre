<?php
/** Compatibilidad: la búsqueda vive en videos.php. */
declare(strict_types=1);
require __DIR__ . '/videos.php';
