# Sin Filtro — buscador privado de noticias y videos

> Contra la corrupción y los videos falsos: el algoritmo lo controlas tú.

Sitio en PHP 8 sin frameworks ni dependencias. Funciona como una galería de videos estilo YouTube donde también viven las **noticias**, las **fotos** y los **productos**, organizados en secciones con subcategorías. Cada publicación muestra **a qué orientación apunta** (izquierda, centro-izquierda, centro, centro-derecha, derecha o sin orientación política) y **si está verificada**, y nadie decide por ti el orden: lo eliges tú con filtros y categorías.

- Cualquiera puede explorar, buscar, leer y leer los comentarios.
- Para **ver un video**, abrir el **enlace de un producto**, la **fuente de una noticia**, las **redes sociales** o **comentar** hay que iniciar sesión. La protección ocurre en el servidor: sin sesión esas URL nunca llegan al HTML.
- Las personas con **rol admin** suben videos, fotos y noticias, editan, eliminan, moderan comentarios y administran categorías, subcategorías y roles desde `/admin/`.
- Cada persona puede elegir un **estilo visual** (Sin Filtro, **Frutiger Aero**, Periódico, Neón, Escritorio 98 o Neobrutalismo), ajustar **colores, tamaño del texto, contraste y animaciones**, y **escuchar en voz alta** publicaciones, descripciones y comentarios.
- Cada cuenta puede **crear su avatar** con muchas piezas (o subir una **foto de perfil**), que aparece en sus comentarios.
- Los **27 videos de ejemplo son videos reales de YouTube**: se ven con la misma miniatura que tienen en YouTube y se reproducen dentro del sitio (con sesión iniciada). El resto del contenido de ejemplo son noticias y fotos sin archivos de video, para que el paquete pese poco. Los videos que subas desde el panel, o los enlaces de YouTube que pegues, funcionan igual.
- Cada video puede verse también como **«Noticias en la prensa»**: enlaces a artículos reales de medios sobre el mismo tema (los 27 videos de ejemplo traen 74 artículos).
- Un **asistente de preguntas rápidas** (botón «Pregúntame») responde según dónde estás: en una publicación te dice su URL de origen, fecha, quién la subió, creador, por qué tiene sus etiquetas y más; en una sección, qué hay en ella.

## Secciones

| Sección | Subcategorías |
|---|---|
| Noticias | Política, Economía, Corrupción y transparencia, Sociedad |
| Deportes | Fútbol, Básquetbol, Tenis, Atletismo y running |
| Tecnología | Proyectos en GitHub, Inteligencia artificial, Cámaras y celulares, Cuántica y computación, Avances y lanzamientos |
| Productos (antes «Ventas») | Tecnología, Hogar, Deportes y aire libre, Fotografía |
| Análisis y debate | Debates, Explicadores, Entrevistas, **Existencial** (por ejemplo, ¿existe Dios? y el argumento de la primera causa, con ambas posturas) |
| Verificación | Desmentidos, Campañas coordinadas, Deepfakes y montajes |
| Conflictos y seguridad | Conflictos globales, Crimen y seguridad local |
| Aciertos y errores | Logros, Errores. Aquí la orientación indica el signo del **gobierno evaluado**; hay un logro y un error de cada orientación |
| Curiosidades y diversión | Ciencia ficción y especulación, Biología especulativa, Series, películas y anime, Ejercicio y bienestar, Mitos desmentidos |

Todas viven dentro de Videos (`videos.php?cat=…`) y se crean, renombran o mueven desde el panel. Una sección puede tener una **nota** destacada (Curiosidades la usa para explicar por qué existe; Aciertos y errores, para explicar cómo leer la orientación). Las direcciones antiguas de Ventas (`?cat=ventas`, `ventas.php`) redirigen a Productos.

## Puesta en marcha

**Requisitos:** PHP 8.1 o superior con `pdo_sqlite` y **GD con WebP** (para procesar miniaturas y fotos). Ambas vienen activadas en XAMPP, Laragon, MAMP y en la mayoría de los hostings. Opcional: `ffprobe` (de ffmpeg) para leer la duración de los videos en el servidor.

### Servidor integrado de PHP

```bash
cd buscador-sin-filtro
PHP_CLI_SERVER_WORKERS=4 php -d upload_max_filesize=600M -d post_max_size=620M -S localhost:8000 router.php
```

Abre <http://localhost:8000>. `PHP_CLI_SERVER_WORKERS` permite reproducir video mientras navegas; los `-d` permiten subir videos grandes desde el panel. En Windows: `set PHP_CLI_SERVER_WORKERS=4` antes del comando.

### XAMPP / Apache / hosting

Copia la carpeta a `htdocs/` y abre `http://localhost/buscador-sin-filtro/`. El `.htaccess` bloquea las carpetas internas y sube los límites de subida si usas mod_php; con PHP-FPM o en un hosting compartido se aplica `.user.ini` (600 MB por subida, 128 MB de memoria).

La primera visita crea la base SQLite en `sql/buscador.sqlite` con el contenido de ejemplo. Necesitan permiso de escritura:

```
sql/                      base de datos
logs/                     registros
media/portadas/subidas/   miniaturas y fotos subidas desde el panel
media/portadas/youtube/   miniaturas de YouTube que el servidor descarga solo
media/portadas/avatares/  fotos de perfil (se crea sola)
media/videos/             videos y subtítulos
```

### Actualizar desde la versión anterior

Copia los archivos nuevos encima de los anteriores **conservando** `sql/buscador.sqlite`, `media/portadas/subidas/` y los videos que hayas subido a `media/videos/`. En la primera visita la base se actualiza sola, también en MySQL:

- **v2 → v3:** comentarios y notas de sección, Ventas pasa a llamarse Productos, Tecnología pasa a ser una sección, se crean las categorías nuevas y se suma el contenido de ejemplo que falte.
- **v3 → v4:** se agrega el campo del video de YouTube y las publicaciones de ejemplo que **no editaste** pasan a sus videos reales de YouTube (los debates políticos y los videos de productos de ejemplo pasan a ser noticias y fotos). Cuatro publicaciones de ejemplo cambian de dirección y las antiguas redirigen (301) a las nuevas.
- **v4 → v5:** se agregan las noticias de prensa; las publicaciones de ejemplo que todavía no tengan ninguna reciben las suyas.
- **v5 → v6:** se agregan los avatares (cada cuenta sigue con sus iniciales hasta que cree uno); las cuatro personas de la comunidad de ejemplo reciben el suyo.

No se borra ni se modifica nada de lo que subiste o editaste.

### Cuentas de prueba

| Rol | Correo | Contraseña |
|---|---|---|
| Admin | `admin@sinfiltro.test` | `admin1234` |
| Usuario | `demo@sinfiltro.test` | `demo1234` |

El formulario de acceso tiene botones para usarlas. **Cámbialas o bórralas antes de publicar** (ver más abajo).

## Panel de administración (`/admin/`)

| Sección | Qué hace |
|---|---|
| **Resumen** | Cifras, equilibrio de orientaciones del catálogo (avisa si una postura queda sin contenido), publicaciones pendientes de verificar y las últimas subidas. |
| **Publicaciones** | Lista con búsqueda y filtros por tipo, categoría y verificación. Ver, editar o eliminar (con confirmación). |
| **Subir** | Formulario para **video**, **fotos** o **noticia** (detalle abajo). |
| **Categorías** | Crear, renombrar, mover, ordenar y eliminar categorías y subcategorías (dos niveles), con una nota opcional por sección. Al eliminar una con contenido, eliges a dónde mover sus publicaciones. |
| **Comentarios** | Buscar y eliminar comentarios con spam, amenazas o datos personales. Cada eliminación queda en `logs/admin.log`. |
| **Usuarios** | Dar o quitar el rol admin. No se puede quitar el rol al último admin. |

**Al subir una publicación** se completa:

- **Archivo o enlace de YouTube:** video MP4 (H.264) o WebM hasta 512 MB con subtítulos opcionales (.vtt o .srt, el SRT se convierte solo), o **un enlace de YouTube** (watch, youtu.be, shorts, live o embed), o hasta 12 fotos con texto alternativo, o el texto de una noticia. Con un enlace de YouTube, el botón **Completar con YouTube** llena el título, el canal y la fuente.
- **Miniatura:** PNG recomendado (también JPG o WebP). Se recorta al centro en 16:9 y se guarda en WebP en tres tamaños. En videos puedes **usar un cuadro del video** como miniatura con un clic; con un enlace de YouTube es opcional (se usa la del video); en publicaciones de fotos, si no subes miniatura se usa la primera foto.
- **Título, descripción y etiquetas.**
- **Categoría o subcategoría** y fecha de publicación; opción de destacar en la portada.
- **Creador original** (canal, medio o persona) y su sitio.
- **Subido por:** tu nombre de admin, que se muestra en la publicación. Puedes guardarlo para las próximas subidas.
- **Orientación** y **verificación** (verificado, sin verificar o engañoso), cada una con una nota que explica el porqué. Lo engañoso se muestra difuminado y con aviso.
- **Enlaces:** URL de la noticia o fuente original y redes sociales adjuntas (YouTube, Instagram, TikTok, X, Facebook, WhatsApp y LinkedIn).
- **Noticias en la prensa** (opcional, hasta 12): URL y titular de cada artículo, más medio (si lo dejas vacío se toma del dominio), fecha e idioma.
- **Datos de venta** (opcional): tienda, enlace, precio, precio anterior y ficha técnica.

La subida muestra el progreso, valida en el navegador y otra vez en el servidor, y si algo falla borra los archivos ya creados.

## Filtros y orientación

En **Videos** (`videos.php`) se combinan:

- **Categorías y subcategorías** como chips arriba de la galería.
- **Tipo:** video, fotos o noticia.
- **Orientación:** las cinco posturas más “sin orientación política”. Todas se dibujan en el mismo color neutro para no premiar ninguna.
- **Verificación:** verificado, sin verificar o engañoso. Marca solo las dos primeras para dejar fuera lo engañoso.
- **Con:** fuente enlazada, noticias de prensa, subtítulos o enlace de venta.
- **Fecha, duración y creador.**
- **Orden:** más recientes, más antiguos, más vistos, relevancia o **vista equilibrada**, que intercala las posturas para que ninguna domine los primeros resultados.

Cada filtro muestra cuántos resultados hay detrás. Cada publicación explica **por qué tiene sus etiquetas** y sugiere **otras miradas** sobre el mismo tema desde otras posturas. La página **Cómo funciona** (`transparencia.php`) explica el criterio completo.

La búsqueda entiende prefijos (“transp” encuentra “transporte”), ignora tildes y mayúsculas y usa sinónimos (“gratis” también busca “gratuito”).

## Videos de YouTube

- **Miniaturas:** se ve siempre la misma miniatura que el video tiene en YouTube.
  1. La primera vez, el servidor la descarga (la de mayor resolución disponible), la recorta a 16:9 y la guarda en WebP en `media/portadas/youtube/`. Desde entonces se sirve desde el propio sitio. Si PHP no encuentra los certificados del sistema (habitual en XAMPP para Windows), usa los de `includes/certificados.pem`.
  2. Si el servidor no logra descargarla (sin internet o con la salida bloqueada), el navegador la pide directo a `i.ytimg.com`, sin cookies ni referer, y el servidor vuelve a intentar una hora después. `SF_YT_MINIATURA_DIRECTA=0` desactiva este respaldo.
  3. Solo si tampoco el navegador llega a YouTube se muestra una portada neutra del sitio.
- **Canal:** si el creador quedó como «Canal de YouTube», en esa misma descarga se completa con el nombre y el enlace real del canal (oEmbed público de YouTube, sin clave de API).
- **Reproductor:** con sesión iniciada, la publicación muestra la miniatura con un botón **Reproducir**. Recién al pulsarlo se carga el reproductor de `youtube-nocookie.com` (modo de privacidad mejorada). Sin sesión, el identificador del video no aparece en el HTML de la página.

## Noticias en la prensa

Encima del reproductor hay dos opciones: **Video** y **Noticias en la prensa (N)**. La segunda muestra artículos de medios reales sobre el mismo tema, para leerlo en vez de verlo y para contrastar.

- Funciona sin recargar la página (y sin JavaScript, con `video.php?v=…&vista=noticias`). Al cambiar de vista, el video que se estaba reproduciendo se detiene.
- Sin sesión se ven el medio y el titular; la dirección y el dominio solo con sesión, por `ir.php?t=prensa` (igual que fuentes, tiendas y redes). Cada apertura queda en el historial opcional de la cuenta.
- Las tarjetas de la galería muestran cuántas noticias de prensa tiene cada publicación, y el filtro **Con → Noticias de prensa** las reúne.
- La verificación y la orientación de la publicación no aplican a los artículos enlazados: la página lo aclara.
- Se agregan, ordenan y quitan desde el panel, al subir o editar cualquier publicación (no solo videos).
- **Verificación:** los videos reales de ejemplo están marcados como «sin verificar»: la moderación todavía no revisa sus afirmaciones y la fuente es el propio video.
- Las descargas del servidor solo van a `i.ytimg.com` y `www.youtube.com`, con el identificador validado, sin seguir redirecciones y con límites de tiempo y tamaño. Para usar otra dirección (por ejemplo, un proxy) existen `SF_YT_MINIATURAS`, `SF_YT_OEMBED` y `SF_YT_HOSTS`.

## Asistente de preguntas rápidas

El **robot ayudante** (abajo a la derecha, con el globo «Pregúntame») abre un asistente que **sabe dónde estás**.

- **Se mueve:** arrástralo manteniendo presionado el clic (o el dedo en el celular) y suéltalo donde no estorbe; también se mueve con las flechas del teclado cuando tiene el foco (Mayús + flecha, más rápido). Recuerda su lugar en este navegador y el panel se abre a su lado. El botón con la casita lo devuelve a su esquina.
- **Tiene vida:** flota, parpadea, saluda al pasar el mouse, «piensa» mientras busca la respuesta y mueve la boca al contestar. Con «reducir movimiento» se queda quieto. Se viste según el estilo visual elegido.

Qué responde:


- **En una publicación:** URL de origen, noticias de prensa sobre el tema, enlace de YouTube, fecha de publicación, quién la subió, creador o canal, categoría, por qué tiene su orientación y su verificación, otras miradas, relacionados, vistas, duración, precio y tienda, redes, etiquetas, comentarios y enlace para compartir. También entiende varias preguntas a la vez («fecha y fuente»).
- **En una sección o una búsqueda:** qué hay en ella, lo más visto, lo más reciente y cuántas publicaciones hay de cada orientación y estado de verificación.
- **En cualquier página:** busca por ti («busca maratón»), te lleva a una sección («llévame a Deportes») y explica el orden, la privacidad, las preferencias, los estilos, el avatar y la cuenta.
- Si preguntas por otra publicación por su nombre («¿cuál es la fuente del video de Kardashev?»), la encuentra y responde sobre ella.

Respeta las mismas reglas que el resto del sitio: **sin sesión no entrega URL de fuentes, tiendas, redes ni YouTube**, solo un enlace para iniciar sesión. Responde con reglas y con los datos de la base, **sin servicios externos ni IA de terceros**, y **no guarda las preguntas** (van por POST, no quedan ni en los registros del servidor). La conversación vive solo en la pestaña (`sessionStorage`) y se descarta al cambiar de cuenta. Cada respuesta se puede escuchar en voz alta. Tiene un límite de 30 preguntas por minuto por sesión, y sin JavaScript funciona como página (`asistente.php`).

## Comentarios

- Se leen sin cuenta; para comentar hay que iniciar sesión. Cada comentario muestra el nombre de la cuenta.
- No se ocultan ni ordenan opiniones por su postura: el orden es por fecha (más recientes o más antiguos), sin «me gusta» ni ranking.
- Cada persona puede borrar los suyos; una persona admin puede borrar cualquiera desde la publicación o desde **Panel → Comentarios**.
- Hasta 2.000 caracteres, sin HTML, con freno al spam (máximo 3 por minuto y 10 cada 10 minutos, sin repetir el mismo texto). Si algo falla, el texto queda como borrador.
- Al eliminar una cuenta se borran también sus comentarios.

## Avatares y foto de perfil

En **Mi cuenta → Crea tu avatar** (`avatar.php`) cada persona elige cómo se la ve en los comentarios, la cabecera y su cuenta:

- **Avatar creado con piezas**, con vista previa al instante y botón **Al azar**: forma de cara, 8 tonos de piel, mejillas y pecas; 11 peinados y 11 colores de pelo; 6 tipos de ojos y 6 colores; 6 cejas; 7 bocas; 5 barbas; lentes, gorros (gorra, gorro de lana, audífonos, cintillo, flor, corona) y aros; 5 prendas en 12 colores, con color de detalles; 12 fondos y 4 diseños de fondo. Son miles de combinaciones.
- **Foto de perfil:** PNG, JPG o WebP; se recorta en cuadrado y se guarda como imagen nueva en WebP, sin los metadatos de la foto original (como la ubicación GPS). Se puede eliminar del servidor en cualquier momento, y se borra sola al eliminar la cuenta.
- **Iniciales**, como antes (el valor por defecto).

El avatar se dibuja en el servidor como SVG solo con piezas y colores de una lista fija: nunca se guarda ni se muestra SVG escrito por la persona. Funciona sin JavaScript (cada cambio se ve al enviar el formulario).

## Preferencias de lectura y voz alta

El botón **Aa** de la cabecera (o `preferencias.php`, que funciona sin JavaScript) permite elegir:

- **Estilo visual:**
  - **Sin Filtro**: el diseño original.
  - **Frutiger Aero**: cielo y pasto de fondo, paneles de vidrio, botones de gel brillante y burbujas; con versión oscura «noche de acuario».
  - **Periódico**: papel de diario, titulares con serifa, filetes negros y rojo de imprenta; con versión oscura sepia.
  - **Neón**: noche, cuadrícula, magenta y cian con brillo (siempre oscuro).
  - **Escritorio 98**: gris plata, biseles y barras de título azul marino (siempre claro).
  - **Neobrutalismo**: bordes negros, sombras duras y colores planos (siempre claro).

  Todos cumplen contraste AA y se combinan con el color de acento, el tamaño del texto y el contraste alto. La hoja de estilos (`assets/css/estilos.css`, 5 KB comprimida) solo se descarga si eliges uno.
- **Tema:** según el sistema, claro u oscuro.
- **Color de acento:** azul, violeta, verde, terracota o grafito. Todos cumplen contraste AA en claro y oscuro.
- **Tamaño del texto:** pequeño, normal, grande o muy grande.
- **Espacio entre líneas**, **alto contraste** y **animaciones reducidas**.
- **Lectura en voz alta:** el botón **Escuchar** aparece en el título y la descripción de cada publicación, en el texto de las noticias, en las notas de sección y en cada comentario. Se puede pausar y detener, y elegir velocidad y voz. Usa la Web Speech API del navegador y prefiere las voces del dispositivo, así el texto no sale del equipo.

Las preferencias se guardan en una cookie propia (`sf_pref`) sin datos personales, para aplicarlas antes de pintar la página. La voz elegida queda solo en el navegador.

## Privacidad

- Sin rastreadores, sin publicidad y sin scripts de terceros. Fuentes y archivos alojados en el propio sitio.
- “Lo más buscado” guarda solo el término, sin usuario ni IP (`SF_REGISTRAR_BUSQUEDAS=0` lo desactiva).
- Dos cookies propias y ninguna de seguimiento: la de sesión y, solo si cambias algo, la de preferencias de lectura.
- Las IP de los registros se guardan recortadas.
- El historial de enlaces abiertos es opcional y cada persona lo apaga o borra en **Mi cuenta**, donde también puede eliminar su cuenta.
- `Referrer-Policy: same-origin`: los sitios externos no saben desde qué página llegaste. La única excepción es el reproductor de YouTube, que exige saber en qué sitio está insertado: recibe solo el dominio, y solo cuando pulsas reproducir.
- Si el servidor no pudo guardar la miniatura de un video de YouTube, tu navegador la pide a `i.ytimg.com` (servidor de imágenes de YouTube, sin cookies y sin decirle desde qué página vienes). Con `SF_YT_MINIATURA_DIRECTA=0` eso nunca ocurre.
- El asistente no guarda tus preguntas.

## Bajo consumo de memoria

- Filtros, conteos, orden y paginación se resuelven en SQL; PHP solo recibe la página que se muestra (24 resultados).
- SQLite con caché de 2 MB y temporales en disco.
- Cada página consume del orden de **400 KB** de memoria en el servidor; el pie de página muestra el valor real.
- Las fotos grandes (hasta 6000 px por lado) se reducen antes de rotarlas y recortarlas: una foto de celular de 12 MP se procesa con 128 MB. Si una imagen no cabe en `memory_limit`, el panel lo dice en vez de fallar.
- En el navegador: CSS 28 KB y JS 18 KB comprimidos (el JS del panel solo se carga en `/admin/`), imágenes WebP con `srcset` y carga diferida. La lectura en voz alta usa la síntesis del propio navegador: no descarga nada.

## Seguridad

- Contraseñas con `password_hash()`; 5 intentos fallidos por correo e IP cada 15 minutos.
- Token CSRF en todos los formularios; cierre de sesión solo por POST.
- Cookie de sesión `HttpOnly`, `SameSite=Lax` y `Secure` con HTTPS.
- Content-Security-Policy con nonce, `X-Frame-Options`, `nosniff` y HSTS con HTTPS. El único sitio externo que puede insertarse es `www.youtube-nocookie.com`, y el único de donde se aceptan imágenes externas es `i.ytimg.com` (se quita si desactivas el respaldo de miniaturas).
- Las únicas conexiones que hace el servidor son a YouTube (miniaturas y nombre del canal), a direcciones fijas y con el identificador validado: no se puede usar para pedir otras URL.
- Consultas preparadas en todo el sitio; todo texto se escapa.
- **Subidas:**
  - el tipo real del archivo se revisa por su contenido, no por su extensión, y se guarda con un nombre aleatorio;
  - las imágenes se recodifican a WebP, lo que descarta cualquier contenido oculto (también las fotos de perfil);
  - los videos quedan en una carpeta bloqueada y se entregan solo con sesión por `stream.php`, que permite adelantar;
  - nada ejecutable se sirve desde `media/`.
- El panel exige rol admin en cada página y acción (403 para el resto).

## Accesibilidad

- Navegación completa con teclado, foco visible, “Saltar al contenido”. `/` o `Ctrl+K` abren el buscador.
- Buscador con patrón *combobox* de ARIA; diálogos nativos con retorno del foco.
- Formularios con errores asociados a cada campo y un resumen de errores con enlaces.
- Videos con subtítulos; texto alternativo en las fotos subidas.
- Preferencias de color, tamaño de texto, interlineado, contraste y animaciones, y lectura en voz alta.
- Auditado con axe-core (WCAG 2.2 AA) en tema claro y oscuro, escritorio y móvil, incluido el panel y cada color de acento. Respeta “reducir movimiento”.
- Funciona sin JavaScript (formularios, filtros y acceso por página completa).

## MySQL o MariaDB

1. Crea una base **vacía**: `CREATE DATABASE buscador_sin_filtro CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`
2. En `includes/config.php` cambia `'driver'` a `'mysql'` y completa usuario y contraseña. También puedes usar las variables `SF_DB_DRIVER=mysql`, `SF_DB_USUARIO`, `SF_DB_CLAVE`, `SF_DB_HOST` y `SF_DB_NOMBRE`.
3. Abre el sitio: la primera visita crea las tablas y carga el contenido de ejemplo. Por seguridad, no instala nada si la base ya tiene tablas con los mismos nombres que usa Sin Filtro (por ejemplo, `usuarios` de otra aplicación).

Si prefieres importar a mano desde phpMyAdmin, genera el volcado con `php includes/instalar.php --exportar` (crea `sql/buscador_mysql.sql`).

Probado con MariaDB 10.11 (requiere MySQL 8 o MariaDB 10.3 o superior).

## Estructura

```
index.php            Portada: lema, equilibrio del catálogo, recientes, “todas las miradas”, aciertos y errores y una fila por sección
videos.php           Galería con categorías, filtros y orden (buscar.php usa la misma página)
video.php            Página de cada publicación: reproductor o fotos, noticia, venta, redes, otras miradas
transparencia.php    Cómo funcionan las etiquetas, el orden, los comentarios y las preferencias
comentar.php         Publicar o eliminar comentarios
preferencias.php     Preferencias de lectura (versión sin JavaScript)
avatar.php           Crear tu avatar, subir tu foto de perfil o volver a tus iniciales
entrar.php  registro.php  salir.php  cuenta.php
ir.php               Redirección protegida a fuentes, ventas, redes, YouTube y noticias de prensa
stream.php           Entrega protegida de videos y subtítulos
asistente.php        Asistente de preguntas rápidas (JSON para el panel flotante y página sin JavaScript)
miniatura-youtube.php  Descarga y guarda la miniatura de un video de YouTube la primera vez que se pide
api/buscar.php       Sugerencias en vivo (JSON)
admin/               Panel: resumen, publicaciones, subir, categorías, comentarios y usuarios (admin/youtube.php: «Completar con YouTube»)
includes/            Configuración, conexión, sesión, consultas, subidas, panel, YouTube, asistente, avatares e instalador
                     (certificados.pem: certificados raíz de Mozilla para descargar miniaturas en servidores sin ellos)
includes/vistas/     Plantillas (cabecera, pie, tarjeta, explorador, etiquetas…)
assets/              CSS (app.css y estilos.css, los estilos visuales opcionales), JS, fuentes e íconos
media/portadas/      Imágenes en WebP (subidas/ guarda las del panel; youtube/, las miniaturas descargadas)
media/videos/        Videos y subtítulos (carpeta protegida)
sql/                 datos_demo.json, volcado MySQL y base SQLite
```

`noticias.php`, `noticia.php`, `ventas.php` y `producto.php` redirigen (301) a sus equivalentes nuevos para no romper enlaces antiguos.

## Contenido de ejemplo

El contenido de ejemplo vive en `sql/datos_demo.json`. Para volver al estado inicial:

```bash
php includes/instalar.php --reiniciar   # borra la base y la vuelve a llenar (pierdes lo subido desde el panel)
php includes/instalar.php --exportar    # genera sql/buscador_mysql.sql para importar en phpMyAdmin
```

Los 27 videos de YouTube son reales y pertenecen a sus canales (la publicación enlaza al original). Sus 74 noticias de prensa también son reales: se buscaron y revisaron el 13 de octubre de 2026 (titular, medio y, cuando el medio la indica, la fecha); con el tiempo un medio puede mover o borrar un artículo, y se corrige desde el panel. Algunos temas no tienen buena cobertura en español y llevan artículos en inglés, marcados como tales. Las noticias, marcas, tiendas, precios, ciudades, gobiernos y personas de la comunidad son ficticios. Las URL de ejemplo usan el dominio reservado `.example`. Las cuentas de la comunidad que firman los comentarios de ejemplo no pueden iniciar sesión (tienen contraseñas aleatorias).

## Peso del paquete

El zip pesa unos 2,9 MB (antes, 40 MB): sin archivos de video de ejemplo (los de YouTube se reproducen desde YouTube y sus miniaturas reales se obtienen al usarse, así que no viajan en el paquete), imágenes WebP recomprimidas según su ancho (las miniaturas grandes se ven igual con menos calidad nominal), imágenes que nadie usaba eliminadas, fuentes reducidas a los caracteres del español y el volcado SQL generado bajo demanda. El código y las protecciones no cambian.

## Antes de publicar

- `SF_ENTORNO=produccion`: oculta los errores y los guarda en `logs/`.
- `SF_CUENTA_DEMO=0`: oculta los botones de cuentas de prueba. Cambia la contraseña del admin en **Mi cuenta → Contraseña** (la página avisa mientras siga siendo la de prueba), o crea tu cuenta, dale rol admin en **Usuarios** y elimina las de prueba.
- Usa HTTPS.
- En una subcarpeta con Apache, ajusta `ErrorDocument 404` en `.htaccess`.
- Con Nginx, bloquea las carpetas internas y sube el límite de subida:

```nginx
client_max_body_size 620m;
location ~ ^/(includes|sql|logs|media/videos)/ { deny all; }
location ~ ^/media/.*\.(php\d?|phtml|phar|html?|svg)$ { deny all; }
location ~ /\. { deny all; }
location = /router.php { deny all; }
# Miniaturas de YouTube: si todavía no existen, las genera PHP
location ~ ^/media/portadas/youtube/([a-z0-9-]+)-(480|960|1600)\.webp$ {
    try_files $uri /miniatura-youtube.php?s=$1&w=$2;
}
```

El servidor necesita salida a internet hacia `i.ytimg.com` y `www.youtube.com` (HTTPS) para las miniaturas de YouTube.
