<?php
/**
 * Miniatura de un video de YouTube (media/portadas/youtube/{slug}-{ancho}.webp).
 * La primera vez el servidor la descarga desde YouTube y la guarda; desde ahí la entrega el servidor web
 * como un archivo estático más. Si no hay conexión, el navegador la pide directo a YouTube y el servidor vuelve a intentar en una hora.
 */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

$slug = is_string($_GET['s'] ?? null) ? $_GET['s'] : '';
$ancho = (int) ($_GET['w'] ?? 0);
if (!preg_match('/^[a-z0-9-]{1,160}$/', $slug) || !in_array($ancho, ANCHOS_MINIATURA, true)) {
    http_response_code(404);
    exit;
}
$dir = APP_DIR . '/media/portadas/youtube';
$archivo = "{$dir}/{$slug}-{$ancho}.webp";
$servir = static function (string $ruta, bool $definitiva): never {
    header('Content-Type: image/webp');
    header('Cache-Control: ' . ($definitiva ? 'public, max-age=31536000, immutable' : 'no-store'));
    header('Content-Length: ' . filesize($ruta));
    readfile($ruta);
    exit;
};
if (is_file($archivo)) {
    $servir($archivo, true);
}
$p = fila('SELECT id, slug, youtube_id, creador FROM publicaciones WHERE slug = ? AND youtube_id IS NOT NULL', [$slug]);
if (!$p) {
    http_response_code(404);
    exit;
}
$marca = "{$dir}/.sin-conexion-{$slug}";
if (!is_file($marca) || filemtime($marca) < time() - 3600) {
    // Un solo intento a la vez por video, aunque la página pida varios tamaños en paralelo
    $cerrojo = fopen(sys_get_temp_dir() . '/sf-yt-' . md5(APP_DIR . $slug) . '.lock', 'c');
    if ($cerrojo) {
        flock($cerrojo, LOCK_EX);
    }
    if (!is_file($archivo)) {
        if (youtube_completar($p)) {
            @unlink($marca);
        } elseif (is_dir($dir) || @mkdir($dir, 0775, true)) {
            @touch($marca);
        }
    }
    if ($cerrojo) {
        flock($cerrojo, LOCK_UN);
        fclose($cerrojo);
    }
    if (is_file($archivo)) {
        $servir($archivo, true);
    }
}
// El servidor no pudo guardarla (sin internet o salida bloqueada): el navegador la pide directo a YouTube,
// así siempre se ve la miniatura real del video. Se puede desactivar con SF_YT_MINIATURA_DIRECTA=0.
if (config('youtube.miniatura_directa', true)) {
    header('Cache-Control: no-store');
    header('Location: ' . youtube_miniatura_externa((string) $p['youtube_id']), true, 302);
    exit;
}
$servir(APP_DIR . "/assets/img/video-{$ancho}.webp", false);
