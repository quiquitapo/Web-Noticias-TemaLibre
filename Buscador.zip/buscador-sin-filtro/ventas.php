<?php
/** Compatibilidad con la versión anterior: Ventas ahora se llama Productos y es una categoría de Videos. */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
redirigir(url('videos.php', ['cat' => 'productos']), 301);
