<?php
/**
 * Avatares: iniciales (por defecto), un avatar creado con piezas o una foto subida.
 * El SVG se arma en el servidor solo con piezas y colores de esta lista: nunca se guarda ni se imprime
 * SVG o texto escrito por la persona, así que no hay forma de inyectar código.
 */
declare(strict_types=1);

const AVATAR_COLORES = [
    'piel' => ['1' => '#ffe0c7', '2' => '#f6cba6', '3' => '#e8b48a', '4' => '#d39a6a', '5' => '#b97a4f', '6' => '#8d5a36', '7' => '#6b4226', '8' => '#4a2e1b'],
    'pelo' => ['negro' => '#1f1b1a', 'oscuro' => '#3b2416', 'castano' => '#6b4126', 'rubio' => '#d8b26a', 'pelirrojo' => '#b4502a', 'gris' => '#9b9b9b',
        'blanco' => '#ebe7e0', 'azul' => '#3b6fd8', 'rosa' => '#e66aa8', 'verde' => '#3fa66b', 'morado' => '#7a4fd0'],
    'iris' => ['cafe' => '#4a2c1a', 'avellana' => '#8a5a2b', 'verde' => '#3f7d4a', 'azul' => '#3b6fb6', 'gris' => '#6b7280', 'negro' => '#1d1b26'],
    'ropa' => ['azul' => '#2340f5', 'cielo' => '#38a3e8', 'verde' => '#16a34a', 'menta' => '#5ccfa8', 'amarillo' => '#f5c518', 'naranjo' => '#f97316',
        'rojo' => '#dc2626', 'rosa' => '#ec6aa8', 'morado' => '#7c3aed', 'gris' => '#6b7280', 'negro' => '#1f2937', 'blanco' => '#f4f4f5'],
    'fondo' => ['lavanda' => '#c7d2fe', 'cielo' => '#bae6fd', 'menta' => '#bbf7d0', 'limon' => '#fef08a', 'durazno' => '#fed7aa', 'rosa' => '#fbcfe8',
        'lila' => '#ddd6fe', 'gris' => '#e5e7eb', 'azul' => '#2340f5', 'noche' => '#1e1b4b', 'verde' => '#047857', 'coral' => '#fb7185'],
];

/** Opciones de forma: clave => [etiqueta]. La primera de cada grupo es la predeterminada. */
const AVATAR_FORMAS = [
    'cara'   => ['redonda' => 'Redonda', 'ovalada' => 'Ovalada', 'cuadrada' => 'Cuadrada'],
    'pelo_estilo' => ['corto' => 'Corto', 'flequillo' => 'Flequillo', 'largo' => 'Largo', 'rizado' => 'Rizado', 'mono' => 'Moño', 'coleta' => 'Coleta',
        'afro' => 'Afro', 'puntas' => 'En puntas', 'mohicano' => 'Mohicano', 'rapado' => 'Rapado', 'calvo' => 'Sin pelo'],
    'cejas'  => ['normales' => 'Normales', 'arqueadas' => 'Arqueadas', 'gruesas' => 'Gruesas', 'enojadas' => 'Decididas', 'preocupadas' => 'Preocupadas', 'ninguna' => 'Sin cejas'],
    'ojos'   => ['normales' => 'Normales', 'grandes' => 'Grandes', 'felices' => 'Felices', 'guino' => 'Guiño', 'sueno' => 'Con sueño', 'estrellas' => 'Estrellas'],
    'boca'   => ['sonrisa' => 'Sonrisa', 'risa' => 'Risa', 'neutra' => 'Neutra', 'sorpresa' => 'Sorpresa', 'lengua' => 'Lengua afuera', 'seria' => 'Seria', 'labios' => 'Labios pintados'],
    'barba'  => ['ninguna' => 'Sin barba', 'bigote' => 'Bigote', 'perilla' => 'Perilla', 'corta' => 'Barba corta', 'larga' => 'Barba larga'],
    'lentes' => ['ninguno' => 'Sin lentes', 'redondos' => 'Redondos', 'cuadrados' => 'Cuadrados', 'sol' => 'De sol'],
    'gorro'  => ['ninguno' => 'Nada', 'gorra' => 'Gorra', 'beanie' => 'Gorro de lana', 'audifonos' => 'Audífonos', 'cintillo' => 'Cintillo', 'flor' => 'Flor', 'corona' => 'Corona'],
    'aros'   => ['ninguno' => 'Sin aros', 'aros' => 'Argollas', 'perlas' => 'Perlas'],
    'ropa_estilo' => ['polera' => 'Polera', 'poleron' => 'Polerón', 'camisa' => 'Camisa', 'chaqueta' => 'Chaqueta', 'cuello' => 'Cuello alto'],
    'patron' => ['liso' => 'Liso', 'luz' => 'Luz', 'puntos' => 'Puntos', 'rayas' => 'Rayas'],
    'mejillas' => ['no' => 'No', 'si' => 'Sí'],
    'pecas'  => ['no' => 'No', 'si' => 'Sí'],
];

/** Colores: opción => grupo de AVATAR_COLORES. */
const AVATAR_COLOR_DE = ['piel' => 'piel', 'pelo' => 'pelo', 'iris' => 'iris', 'ropa' => 'ropa', 'detalle' => 'ropa', 'fondo' => 'fondo'];

function avatar_por_defecto(): array
{
    $o = [];
    foreach (AVATAR_FORMAS as $k => $v) {
        $o[$k] = (string) array_key_first($v);
    }
    return $o + ['piel' => '3', 'pelo' => 'castano', 'iris' => 'cafe', 'ropa' => 'azul', 'detalle' => 'amarillo', 'fondo' => 'lavanda'];
}

/** Valida opciones (desde el formulario o la base): solo valores conocidos. */
function avatar_opciones(array $in): array
{
    $o = avatar_por_defecto();
    foreach (AVATAR_FORMAS as $k => $v) {
        if (is_string($in[$k] ?? null) && isset($v[$in[$k]])) {
            $o[$k] = $in[$k];
        }
    }
    foreach (AVATAR_COLOR_DE as $k => $grupo) {
        if (is_string($in[$k] ?? null) && isset(AVATAR_COLORES[$grupo][$in[$k]])) {
            $o[$k] = $in[$k];
        }
    }
    return $o;
}

function avatar_aleatorio(): array
{
    $o = [];
    foreach (AVATAR_FORMAS as $k => $v) {
        $o[$k] = (string) array_rand($v);
    }
    foreach (AVATAR_COLOR_DE as $k => $g) {
        $o[$k] = (string) array_rand(AVATAR_COLORES[$g]);
    }
    if (random_int(0, 2) > 0) {
        $o['gorro'] = 'ninguno';
        $o['barba'] = random_int(0, 2) ? 'ninguna' : $o['barba'];
    }
    return avatar_opciones($o);
}

/** Color de cejas: el del pelo, oscurecido para que se vea sobre cualquier piel. */
function avatar_ceja(string $hex): string
{
    $c = array_map(static fn($x) => (int) round(hexdec($x) * .62), str_split(ltrim($hex, '#'), 2));
    return vsprintf('#%02x%02x%02x', $c);
}

/** Piezas del avatar por capa (de atrás hacia adelante). */
function avatar_piezas(): array
{
    $trazo = static fn(string $d, string $color, float $w = 2.6) => '<path d="' . $d . '" fill="none" stroke="' . $color . '" stroke-width="' . $w . '" stroke-linecap="round" stroke-linejoin="round"/>';
    $ojoNormal = static fn(float $x) => '<circle cx="' . $x . '" cy="53" r="3.6" fill="var(--iris)"/><circle cx="' . $x . '" cy="53" r="1.6" fill="#141218"/><circle cx="' . ($x + 1.3) . '" cy="51.6" r="1.1" fill="#fff"/>';
    $ojoGrande = static fn(float $x) => '<ellipse cx="' . $x . '" cy="53" rx="5.4" ry="6" fill="#fff" stroke="#000" stroke-opacity=".12"/><circle cx="' . $x . '" cy="54" r="3.6" fill="var(--iris)"/><circle cx="' . $x . '" cy="54" r="1.7" fill="#141218"/><circle cx="' . ($x + 1.4) . '" cy="52.3" r="1.2" fill="#fff"/>';
    $estrella = static fn(float $x) => '<path d="M' . $x . ' 47.5l1.7 3.6 3.9.5-2.9 2.7.8 3.9-3.5-2-3.5 2 .8-3.9-2.9-2.7 3.9-.5z" fill="#f5b301" stroke="#c98a00" stroke-width=".8"/>';
    $capCorta = 'M32 52C30 28 44 18 61 18C78 18 91 28 88 52C86 42 80 34 70 32C62 36 48 36 40 40C36 44 34 48 32 52Z';
    return [
        'patron' => [
            'liso' => '',
            'luz' => '<circle cx="30" cy="24" r="62" fill="#fff" opacity=".22"/><circle cx="30" cy="24" r="34" fill="#fff" opacity=".18"/>',
            'puntos' => '<g fill="#fff" opacity=".35"><circle cx="14" cy="16" r="4"/><circle cx="40" cy="8" r="3"/><circle cx="102" cy="18" r="5"/><circle cx="112" cy="48" r="3"/><circle cx="8" cy="52" r="3"/><circle cx="18" cy="86" r="4"/><circle cx="104" cy="86" r="4"/><circle cx="84" cy="6" r="2.5"/></g>',
            'rayas' => '<path d="M-10 30L30-10h14L-10 44zM-10 70L70-10h14L-10 84zM-10 110L110-10h14L-10 124zM30 130L130 30v14L44 130zM70 130l60-60v14l-46 46z" fill="#fff" opacity=".22"/>',
        ],
        'pelo_estilo:atras' => [
            'largo' => '<path d="M30 52C28 26 44 16 60 16S92 26 90 52l2 46c-8 4-16 2-20-6H48c-4 8-12 10-20 6z" fill="var(--pelo)"/>',
            'coleta' => '<path d="M82 36c18 2 24 22 16 50-5-9-8-20-10-30z" fill="var(--pelo)"/>',
            'afro' => '<g fill="var(--pelo)"><circle cx="60" cy="44" r="34"/><circle cx="30" cy="40" r="12"/><circle cx="90" cy="40" r="12"/><circle cx="40" cy="18" r="12"/><circle cx="80" cy="18" r="12"/><circle cx="60" cy="10" r="12"/><circle cx="28" cy="60" r="9"/><circle cx="92" cy="60" r="9"/></g>',
        ],
        'ropa_estilo' => [
            'polera' => '<path d="M49 86q11 10 22 0" fill="none" stroke="#000" stroke-opacity=".18" stroke-width="2"/>',
            'poleron' => '<path d="M38 91c4-9 12-11 22-7 10-4 18-2 22 7-8-3-16-1-22 5-6-6-14-8-22-5z" fill="#000" opacity=".2"/><path d="M55 96l-1 12m11-12 1 12" stroke="var(--detalle)" stroke-width="2.2" stroke-linecap="round"/>',
            'camisa' => '<path d="M50 86l6 12 4-6 4 6 6-12q-10 6-20 0z" fill="#fff"/><path d="M60 92v28" stroke="#000" stroke-opacity=".15" stroke-width="1.5"/><circle cx="60" cy="104" r="1.6" fill="var(--detalle)"/><circle cx="60" cy="113" r="1.6" fill="var(--detalle)"/>',
            'chaqueta' => '<path d="M51 87l9 25 9-25q-9 5-18 0z" fill="var(--detalle)"/><path d="M51 87l9 25h-8l-8-20zm18 0-9 25h8l8-20z" fill="#000" opacity=".22"/>',
            'cuello' => '<path d="M48 79h24v11q-12 6-24 0z" fill="var(--ropa)"/><path d="M48 79h24v11q-12 6-24 0z" fill="#000" opacity=".12"/><path d="M52 81v8m4-8v9m4-9v9m4-9v9m4-9v8" stroke="#000" stroke-opacity=".15" stroke-width="1.2"/>',
        ],
        'cara' => [
            'redonda' => '<ellipse cx="60" cy="53" rx="27" ry="29" fill="var(--piel)"/>',
            'ovalada' => '<path d="M33 50c0-20 12-29 27-29s27 9 27 29-11 34-27 34-27-14-27-34z" fill="var(--piel)"/>',
            'cuadrada' => '<rect x="33" y="24" width="54" height="58" rx="17" fill="var(--piel)"/>',
        ],
        'pecas' => ['no' => '', 'si' => '<g fill="#7a3f1f" opacity=".55"><circle cx="44" cy="61" r=".95"/><circle cx="47.5" cy="63.5" r=".95"/><circle cx="50" cy="60" r=".95"/><circle cx="70" cy="60" r=".95"/><circle cx="72.5" cy="63.5" r=".95"/><circle cx="76" cy="61" r=".95"/></g>'],
        'mejillas' => ['no' => '', 'si' => '<circle cx="42" cy="64" r="5.5" fill="#ff5c7c" opacity=".26"/><circle cx="78" cy="64" r="5.5" fill="#ff5c7c" opacity=".26"/>'],
        'barba' => [
            'ninguna' => '',
            'bigote' => '<path d="M50 67q5-4 10-1 5-3 10 1-5 1.5-10 .5-5 1-10-.5z" fill="var(--pelo)"/>',
            'perilla' => '<path d="M55 77q5 10 10 0-5 3-10 0z" fill="var(--pelo)"/>',
            'corta' => '<path d="M33 56c1 16 11 28 27 28s26-12 27-28c-3 10-7 18-17 20q-10-4-20 0c-10-2-14-10-17-20z" fill="var(--pelo)" opacity=".88"/>',
            'larga' => '<path d="M33 56c0 22 11 42 27 44 16-2 27-22 27-44-3 12-7 18-17 20q-10-4-20 0c-10-2-14-8-17-20z" fill="var(--pelo)"/>',
        ],
        'boca' => [
            'sonrisa' => $trazo('M51 69q9 8 18 0', '#5a2430'),
            'risa' => '<path d="M50 68q10 14 20 0z" fill="#5a1f2b"/><path d="M52 68.6h16l-1 2.4H53z" fill="#fff"/>',
            'neutra' => $trazo('M53 71h14', '#5a2430'),
            'sorpresa' => '<ellipse cx="60" cy="71" rx="4" ry="5" fill="#5a1f2b"/>',
            'lengua' => $trazo('M51 69q9 8 18 0', '#5a2430') . '<path d="M56 72.6q4 7 8 0z" fill="#f07a8a"/>',
            'seria' => $trazo('M52 73q8-6 16 0', '#5a2430'),
            'labios' => '<path d="M51 69q4-3 9-1 5-2 9 1-9 8-18 0z" fill="#c2185b"/>',
        ],
        'ojos' => [
            'normales' => $ojoNormal(49) . $ojoNormal(71),
            'grandes' => $ojoGrande(49) . $ojoGrande(71),
            'felices' => $trazo('M44 55q5-7 10 0m12 0q5-7 10 0', '#1d1b26', 2.8),
            'guino' => $ojoNormal(49) . $trazo('M66 55q5-7 10 0', '#1d1b26', 2.8),
            'sueno' => $trazo('M44 53q5 4 10 0m12 0q5 4 10 0', '#1d1b26', 2.6) . $trazo('M44 51h10m12 0h10', '#000', 1.2),
            'estrellas' => $estrella(49) . $estrella(71),
        ],
        'cejas' => [
            'normales' => $trazo('M42 43q6-3 12 0m12 0q6-3 12 0', 'var(--ceja)', 2.8),
            'arqueadas' => $trazo('M42 44q6-7 12-2m12 0q6-5 12 2', 'var(--ceja)', 2.8),
            'gruesas' => $trazo('M42 43q6-3 12 0m12 0q6-3 12 0', 'var(--ceja)', 4.6),
            'enojadas' => $trazo('M42 40l12 4m12 0 12-4', 'var(--ceja)', 3),
            'preocupadas' => $trazo('M42 44l12-4m12 0 12 4', 'var(--ceja)', 3),
            'ninguna' => '',
        ],
        'pelo_estilo' => [
            'corto' => '<path d="' . $capCorta . '" fill="var(--pelo)"/>',
            'flequillo' => '<path d="M32 54C29 28 44 17 60 17s32 11 28 37c-2-8-4-12-6-14l-2 6-6-8-4 7-6-8-5 8-6-8-5 8-5-7-4 8c-3 0-5 4-7 8z" fill="var(--pelo)"/>',
            'largo' => '<path d="M31 56C28 28 44 17 60 17s32 11 29 39c-3-16-13-26-27-26-8 6-18 8-26 14-3 4-4 8-5 12z" fill="var(--pelo)"/>',
            'rizado' => '<g fill="var(--pelo)"><circle cx="40" cy="33" r="9"/><circle cx="50" cy="25" r="10"/><circle cx="62" cy="22" r="10"/><circle cx="74" cy="25" r="10"/><circle cx="83" cy="33" r="9"/><circle cx="34" cy="43" r="7"/><circle cx="87" cy="43" r="7"/></g>',
            'mono' => '<circle cx="60" cy="13" r="10" fill="var(--pelo)"/><path d="' . $capCorta . '" fill="var(--pelo)"/>',
            'coleta' => '<path d="' . $capCorta . '" fill="var(--pelo)"/><circle cx="85" cy="36" r="3.5" fill="var(--detalle)"/>',
            'afro' => '<path d="M34 46c2-16 14-22 26-22s24 6 26 22c-6-8-16-10-26-9-10-1-20 1-26 9z" fill="var(--pelo)"/>',
            'puntas' => '<path d="M32 52c-1-12 2-20 6-24l-2-12 10 8 4-14 8 12 6-14 5 14 9-10 1 14 9-4-2 12c3 6 3 12 2 18-4-10-12-16-28-16-14 0-24 6-28 16z" fill="var(--pelo)"/>',
            'mohicano' => '<path d="' . $capCorta . '" fill="var(--pelo)" opacity=".28"/><path d="M53 40c-1-14 1-28 7-34 6 6 8 20 7 34-3-4-11-4-14 0z" fill="var(--pelo)"/>',
            'rapado' => '<path d="' . $capCorta . '" fill="var(--pelo)" opacity=".5"/>',
            'calvo' => '<ellipse cx="49" cy="31" rx="8" ry="3.6" fill="#fff" opacity=".28" transform="rotate(-18 49 31)"/>',
        ],
        'aros' => [
            'ninguno' => '',
            'aros' => '<circle cx="33" cy="65" r="3.4" fill="none" stroke="#e0a800" stroke-width="1.8"/><circle cx="87" cy="65" r="3.4" fill="none" stroke="#e0a800" stroke-width="1.8"/>',
            'perlas' => '<circle cx="33" cy="63.5" r="2.3" fill="#fff" stroke="#d4d4d8"/><circle cx="87" cy="63.5" r="2.3" fill="#fff" stroke="#d4d4d8"/>',
        ],
        'lentes' => [
            'ninguno' => '',
            'redondos' => '<g fill="none" stroke="#1d1b26" stroke-width="2.2"><circle cx="49" cy="53" r="8"/><circle cx="71" cy="53" r="8"/><path d="M57 53q3-3 6 0M41 52l-7-2m45 2 7-2"/></g>',
            'cuadrados' => '<g fill="none" stroke="#1d1b26" stroke-width="2.2"><rect x="40.5" y="46.5" width="17" height="13" rx="3"/><rect x="62.5" y="46.5" width="17" height="13" rx="3"/><path d="M57.5 52h5M40.5 50l-6-1.5m45 1.5 6-1.5"/></g>',
            'sol' => '<g fill="#1d1b26" stroke="#1d1b26" stroke-width="2"><rect x="40.5" y="46.5" width="17" height="12" rx="4" opacity=".92"/><rect x="62.5" y="46.5" width="17" height="12" rx="4" opacity=".92"/><path d="M57.5 51h5M40.5 50l-6-1.5m45 1.5 6-1.5" fill="none"/></g><path d="M44 49l4 0m18 0 4 0" stroke="#fff" stroke-width="1.6" opacity=".6" stroke-linecap="round"/>',
        ],
        'gorro' => [
            'ninguno' => '',
            'gorra' => '<path d="M31 42c0-20 14-28 29-28s29 8 29 28z" fill="var(--detalle)"/><path d="M60 40c18-2 36 0 44 6-12 2-30 0-44-2z" fill="var(--detalle)"/><path d="M60 40c18-2 36 0 44 6-12 2-30 0-44-2z" fill="#000" opacity=".2"/><circle cx="60" cy="15" r="2.5" fill="#000" opacity=".25"/>',
            'beanie' => '<path d="M32 44c0-22 14-31 28-31s28 9 28 31z" fill="var(--detalle)"/><rect x="30" y="37" width="60" height="11" rx="5.5" fill="var(--detalle)"/><rect x="30" y="37" width="60" height="11" rx="5.5" fill="#000" opacity=".16"/><circle cx="60" cy="11" r="6" fill="#fff"/>',
            'audifonos' => '<path d="M30 56c-2-30 14-42 30-42s32 12 30 42" fill="none" stroke="var(--detalle)" stroke-width="5"/><rect x="24" y="47" width="12" height="19" rx="6" fill="var(--detalle)"/><rect x="84" y="47" width="12" height="19" rx="6" fill="var(--detalle)"/>',
            'cintillo' => '<path d="M33 40c5-14 17-18 27-18s22 4 27 18" fill="none" stroke="var(--detalle)" stroke-width="5" stroke-linecap="round"/>',
            'flor' => '<g transform="translate(80 30)"><g fill="var(--detalle)"><circle cx="0" cy="-6" r="5"/><circle cx="5.7" cy="-1.9" r="5"/><circle cx="3.5" cy="4.9" r="5"/><circle cx="-3.5" cy="4.9" r="5"/><circle cx="-5.7" cy="-1.9" r="5"/></g><circle r="3.4" fill="#fde047"/></g>',
            'corona' => '<path d="M40 30V14l8 8 6-12 6 10 6-10 6 12 8-8v16z" fill="#f5b301" stroke="#c98a00" stroke-width="1.5" stroke-linejoin="round"/><circle cx="60" cy="25" r="2.4" fill="#dc2626"/><circle cx="48" cy="26" r="1.8" fill="#2340f5"/><circle cx="72" cy="26" r="1.8" fill="#16a34a"/>',
        ],
    ];
}

/** Variables de color del avatar (para el atributo style). */
function avatar_estilo(array $o): string
{
    $pelo = AVATAR_COLORES['pelo'][$o['pelo']];
    return '--piel:' . AVATAR_COLORES['piel'][$o['piel']] . ';--pelo:' . $pelo . ';--ceja:' . avatar_ceja($pelo) . ';--iris:' . AVATAR_COLORES['iris'][$o['iris']]
        . ';--ropa:' . AVATAR_COLORES['ropa'][$o['ropa']] . ';--detalle:' . AVATAR_COLORES['ropa'][$o['detalle']] . ';--fondo:' . AVATAR_COLORES['fondo'][$o['fondo']];
}

/**
 * SVG del avatar. Con $editor = true incluye todas las variantes (ocultas las no elegidas)
 * para que el creador cambie piezas al instante sin pedir nada al servidor.
 */
function avatar_svg(array $o, bool $editor = false, string $titulo = ''): string
{
    $o = avatar_opciones($o);
    $p = avatar_piezas();
    $capa = static function (string $clave) use ($p, $o, $editor): string {
        $opcion = explode(':', $clave)[0];
        $html = '';
        foreach ($p[$clave] as $v => $svg) {
            $elegida = $o[$opcion] === $v;
            if (!$editor && !$elegida) {
                continue;
            }
            if ($svg === '' && !$editor) {
                continue;
            }
            $html .= $editor ? '<g data-capa="' . $opcion . '" data-v="' . $v . '"' . ($elegida ? '' : ' display="none"') . '>' . $svg . '</g>' : $svg;
        }
        return $html;
    };
    $orejas = '<g fill="var(--piel)"><ellipse cx="33.5" cy="55" rx="5.5" ry="7"/><ellipse cx="86.5" cy="55" rx="5.5" ry="7"/></g><g fill="#000" opacity=".1"><ellipse cx="33.5" cy="55" rx="2.6" ry="3.6"/><ellipse cx="86.5" cy="55" rx="2.6" ry="3.6"/></g>';
    $cuello = '<path d="M50 70v18q10 6 20 0V70z" fill="var(--piel)"/><path d="M50 78q10 7 20 0v-4q-10 7-20 0z" fill="#000" opacity=".12"/>';
    $cuerpo = '<path d="M12 120c1-21 18-32 38-34q10 6 20 0c20 2 37 13 38 34z" fill="var(--ropa)"/>';
    $nariz = '<path d="M60 57q-3 6 0 7 2 0 3-1" fill="none" stroke="#000" stroke-opacity=".22" stroke-width="2" stroke-linecap="round"/>';
    return '<svg class="avatar-svg" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="' . e(avatar_estilo($o)) . '"'
        . ($titulo !== '' ? ' role="img" aria-label="' . e($titulo) . '"' : ' aria-hidden="true"') . ' focusable="false"' . ($editor ? ' data-avatar-vista' : '') . '>'
        . '<rect width="120" height="120" fill="var(--fondo)"/>' . $capa('patron')
        . $capa('pelo_estilo:atras') . $cuello . $cuerpo . $capa('ropa_estilo') . $orejas . $capa('cara')
        . $capa('pecas') . $capa('mejillas') . $nariz . $capa('barba') . $capa('boca') . $capa('ojos') . $capa('cejas')
        . $capa('aros') . $capa('pelo_estilo') . $capa('lentes') . $capa('gorro')
        . '</svg>';
}

/** Avatar de una persona: foto, avatar creado o iniciales. $u necesita nombre y, si existen, avatar_tipo, avatar y avatar_foto. */
function avatar_html(array $u, string $clase = '', int $ancho = 96): string
{
    $tipo = (string) ($u['avatar_tipo'] ?? 'iniciales');
    if ($tipo === 'foto' && !empty($u['avatar_foto']) && preg_match('#^avatares/[a-z0-9-]+$#', (string) $u['avatar_foto'])) {
        return '<img class="av av--foto ' . e($clase) . '" src="' . e(imagen((string) $u['avatar_foto'], $ancho > 96 ? 256 : 96)) . '" alt="" width="96" height="96" loading="lazy" decoding="async">';
    }
    if ($tipo === 'creado' && !empty($u['avatar'])) {
        $o = json_decode((string) $u['avatar'], true);
        if (is_array($o)) {
            return '<span class="av av--creado ' . e($clase) . '" aria-hidden="true">' . avatar_svg($o) . '</span>';
        }
    }
    return '<span class="av av--iniciales ' . e($clase) . '" style="--av: ' . e(color_avatar((string) $u['nombre'])) . '" aria-hidden="true">' . e(iniciales((string) $u['nombre'])) . '</span>';
}

/** Guarda una foto de perfil (cuadrada, WebP en dos tamaños) y borra la anterior. */
function guardar_foto_avatar(int $uid, array $archivo): array
{
    try {
        $img = subir_imagen($archivo, 'avatares', 'perfil', [96, 256], 1.0, 'foto');
    } catch (ErrorSubida $e) {
        return ['ok' => false, 'error' => $e->getMessage()];
    }
    $anterior = (string) valor('SELECT avatar_foto FROM usuarios WHERE id = ?', [$uid]);
    consulta("UPDATE usuarios SET avatar_tipo = 'foto', avatar_foto = ? WHERE id = ?", [$img['base'], $uid]);
    borrar_foto_avatar($anterior);
    return ['ok' => true];
}

function borrar_foto_avatar(?string $base): void
{
    if (!$base || !preg_match('#^avatares/[a-z0-9-]+$#', $base)) {
        return;
    }
    foreach ([96, 256] as $w) {
        $ruta = APP_DIR . '/media/portadas/' . $base . '-' . $w . '.webp';
        if (is_file($ruta)) {
            @unlink($ruta);
        }
    }
}
