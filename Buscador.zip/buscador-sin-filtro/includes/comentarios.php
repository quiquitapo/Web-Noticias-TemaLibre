<?php
/**
 * Comentarios. Cualquiera puede leerlos; para comentar hay que iniciar sesión.
 * No se ocultan opiniones por su postura: solo se eliminan spam, amenazas o datos personales,
 * y cada persona puede borrar los suyos. No hay "me gusta" ni ranking: el orden es por fecha.
 */
declare(strict_types=1);

const COMENTARIO_MIN = 2;
const COMENTARIO_MAX = 2000;
const COMENTARIOS_POR_PAGINA = 20;

/** @return array{items: array, total: int, pagina: int, paginas: int, orden: string} */
function comentarios_de(int $pubId, string $orden = 'recientes', int $pagina = 1): array
{
    $orden = $orden === 'antiguos' ? 'antiguos' : 'recientes';
    $total = (int) valor('SELECT COUNT(*) FROM comentarios WHERE publicacion_id = ?', [$pubId]);
    $paginas = max(1, (int) ceil($total / COMENTARIOS_POR_PAGINA));
    $pagina = min(max(1, $pagina), $paginas);
    $dir = $orden === 'antiguos' ? 'ASC' : 'DESC';
    $items = filas('SELECT c.id, c.texto, c.creado_en, c.usuario_id, u.nombre, u.rol, u.avatar_tipo, u.avatar, u.avatar_foto
        FROM comentarios c JOIN usuarios u ON u.id = c.usuario_id
        WHERE c.publicacion_id = ? ORDER BY c.creado_en ' . $dir . ', c.id ' . $dir . '
        LIMIT ' . COMENTARIOS_POR_PAGINA . ' OFFSET ' . (($pagina - 1) * COMENTARIOS_POR_PAGINA), [$pubId]);
    return ['items' => $items, 'total' => $total, 'pagina' => $pagina, 'paginas' => $paginas, 'orden' => $orden];
}

/** Limpia el texto: sin caracteres de control, espacios repetidos ni más de una línea en blanco seguida. */
function texto_comentario(string $t): string
{
    $t = str_replace(["\r\n", "\r"], "\n", $t);
    $t = (string) preg_replace('/[^\P{C}\n\x{200D}]+/u', '', $t);
    $t = (string) preg_replace('/[ \t]+/u', ' ', $t);
    $t = (string) preg_replace("/\n{3,}/", "\n\n", $t);
    return trim($t);
}

/** @return array{ok: bool, error?: string, id?: int} */
function crear_comentario(array $usuario, int $pubId, string $texto): array
{
    $texto = texto_comentario($texto);
    $largo = mb_strlen($texto);
    if ($largo < COMENTARIO_MIN) {
        return ['ok' => false, 'error' => $largo === 0 ? 'Escribe tu comentario.' : 'El comentario es demasiado corto.'];
    }
    if ($largo > COMENTARIO_MAX) {
        return ['ok' => false, 'error' => 'El comentario puede tener hasta ' . COMENTARIO_MAX . " caracteres (tiene {$largo})."];
    }
    if (!valor('SELECT 1 FROM publicaciones WHERE id = ?', [$pubId])) {
        return ['ok' => false, 'error' => 'La publicación ya no existe.'];
    }
    $uid = (int) $usuario['id'];
    // Freno al spam: pocos comentarios por minuto y nada repetido
    $haceUnMinuto = date('Y-m-d H:i:s', time() - 60);
    $haceDiez = date('Y-m-d H:i:s', time() - 600);
    if ((int) valor('SELECT COUNT(*) FROM comentarios WHERE usuario_id = ? AND creado_en > ?', [$uid, $haceUnMinuto]) >= 3
        || (int) valor('SELECT COUNT(*) FROM comentarios WHERE usuario_id = ? AND creado_en > ?', [$uid, $haceDiez]) >= 10) {
        return ['ok' => false, 'error' => 'Estás comentando muy seguido. Espera un minuto y vuelve a intentarlo.'];
    }
    if (valor('SELECT 1 FROM comentarios WHERE usuario_id = ? AND publicacion_id = ? AND texto = ? AND creado_en > ?', [$uid, $pubId, $texto, $haceDiez])) {
        return ['ok' => false, 'error' => 'Ya publicaste este mismo comentario.'];
    }
    consulta('INSERT INTO comentarios (publicacion_id, usuario_id, texto, creado_en) VALUES (?, ?, ?, ?)', [$pubId, $uid, $texto, ahora()]);
    return ['ok' => true, 'id' => (int) db()->lastInsertId()];
}

/** La autora o autor del comentario, o una persona admin, pueden eliminarlo. */
function eliminar_comentario(array $usuario, int $id): array
{
    $c = fila('SELECT id, usuario_id, publicacion_id FROM comentarios WHERE id = ?', [$id]);
    if (!$c) {
        return ['ok' => false, 'error' => 'El comentario ya no existe.'];
    }
    $propio = (int) $c['usuario_id'] === (int) $usuario['id'];
    if (!$propio && ($usuario['rol'] ?? '') !== 'admin') {
        return ['ok' => false, 'error' => 'Solo puedes eliminar tus propios comentarios.'];
    }
    consulta('DELETE FROM comentarios WHERE id = ?', [$id]);
    if (!$propio) {
        registrar_log('admin', "eliminó el comentario #{$id} de la publicación #{$c['publicacion_id']} por usuario #{$usuario['id']}");
    }
    return ['ok' => true, 'publicacion_id' => (int) $c['publicacion_id']];
}

/** Para el panel: comentarios recientes de todo el sitio, con búsqueda. */
function comentarios_recientes(string $q, int $pagina, int $porPagina = 30): array
{
    $where = '';
    $prm = [];
    if ($q !== '') {
        $where = ' WHERE c.texto LIKE ? OR u.nombre LIKE ? OR p.titulo LIKE ?';
        $prm = array_fill(0, 3, '%' . $q . '%');
    }
    $desde = ' FROM comentarios c JOIN usuarios u ON u.id = c.usuario_id JOIN publicaciones p ON p.id = c.publicacion_id';
    $total = (int) valor('SELECT COUNT(*)' . $desde . $where, $prm);
    $paginas = max(1, (int) ceil($total / $porPagina));
    $pagina = min(max(1, $pagina), $paginas);
    $items = filas('SELECT c.id, c.texto, c.creado_en, u.nombre, u.email, u.rol, p.titulo, p.slug' . $desde . $where
        . ' ORDER BY c.creado_en DESC, c.id DESC LIMIT ' . $porPagina . ' OFFSET ' . (($pagina - 1) * $porPagina), $prm);
    return ['items' => $items, 'total' => $total, 'pagina' => $pagina, 'paginas' => $paginas];
}
