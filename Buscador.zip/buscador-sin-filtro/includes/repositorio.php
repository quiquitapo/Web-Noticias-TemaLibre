<?php
/**
 * Consultas a la base de datos. Todas usan sentencias preparadas.
 * Para gastar poca memoria, los listados piden solo las columnas que muestran y filtran,
 * ordenan y paginan dentro de la base de datos (PHP nunca carga el catálogo completo).
 */
declare(strict_types=1);

// --- Vocabulario --------------------------------------------------------------------

/** clave => [etiqueta, posición en la escala 1–5 (0 = no aplica)] */
const ORIENTACIONES = [
    'izquierda'        => ['Izquierda', 1],
    'centro-izquierda' => ['Centro-izquierda', 2],
    'centro'           => ['Centro', 3],
    'centro-derecha'   => ['Centro-derecha', 4],
    'derecha'          => ['Derecha', 5],
    'no-aplica'        => ['Sin orientación política', 0],
];

/** clave => [etiqueta, explicación corta] */
const VERIFICACIONES = [
    'verificado'    => ['Verificado', 'La moderación comprobó el origen y que no fue alterado.'],
    'sin-verificar' => ['Sin verificar', 'Todavía no se revisa el origen.'],
    'enganoso'      => ['Engañoso', 'Contiene afirmaciones falsas o está fuera de contexto.'],
];

/** clave => [etiqueta, etiqueta en plural] */
const TIPOS = [
    'video'   => ['Video', 'Videos'],
    'noticia' => ['Noticia', 'Noticias'],
    'imagen'  => ['Fotos', 'Fotos'],
];

const FECHAS = ['hoy' => ['Hoy', 1], 'semana' => ['Esta semana', 7], 'mes' => ['Este mes', 31], 'anio' => ['Este año', 366]];
const DURACIONES = ['corta' => ['Menos de 4 minutos', 0, 239], 'media' => ['De 4 a 20 minutos', 240, 1200], 'larga' => ['Más de 20 minutos', 1201, 999999]];
const CARACTERISTICAS = ['fuente' => ['Con fuente', 'p.fuente_url IS NOT NULL'], 'prensa' => ['Con noticias de prensa', 'EXISTS (SELECT 1 FROM enlaces_prensa ep WHERE ep.publicacion_id = p.id)'],
    'venta' => ['Con enlace de venta', 'p.venta_url IS NOT NULL'], 'subtitulos' => ['Con subtítulos', 'p.subtitulos IS NOT NULL']];
const ORDENES = [
    'recientes'   => 'Más recientes',
    'relevancia'  => 'Relevancia',
    'equilibrado' => 'Vista equilibrada',
    'vistas'      => 'Más vistos',
    'antiguos'    => 'Más antiguos',
];

const SINONIMOS = [
    ['video', 'videos', 'clip'],
    ['noticia', 'noticias', 'nota'],
    ['falso', 'falsos', 'falsa', 'enganoso', 'fake', 'bulo', 'desinformacion'],
    ['deepfake', 'montaje', 'manipulado', 'editado'],
    ['bots', 'bot', 'cuentas falsas', 'campana coordinada', 'trolls'],
    ['corrupcion', 'transparencia', 'licitacion', 'gasto publico'],
    ['eleccion', 'elecciones', 'votacion', 'campana'],
    ['impuesto', 'impuestos', 'tributo', 'tributario'],
    ['transporte', 'micro', 'bus', 'buses', 'pasaje', 'metro'],
    ['gratis', 'gratuito', 'gratuita', 'gratuidad'],
    ['audifonos', 'auriculares', 'headphones', 'cascos'],
    ['celular', 'celulares', 'telefono', 'smartphone', 'movil'],
    ['notebook', 'laptop', 'computador'],
    ['zapatillas', 'running'],
    ['parlante', 'altavoz', 'speaker'],
    ['reloj', 'smartwatch'],
    ['dron', 'drone', 'drones'],
    ['oferta', 'ofertas', 'descuento', 'descuentos', 'rebaja', 'venta', 'ventas'],
    ['camara', 'camaras', 'fotografia'],
    ['producto', 'productos', 'compra', 'comprar'],
    ['deporte', 'deportes', 'deportivo', 'deportiva'],
    ['futbol', 'soccer', 'balompie'],
    ['basquetbol', 'basquet', 'baloncesto', 'basketball'],
    ['ia', 'inteligencia artificial', 'ai'],
    ['cuantica', 'cuantico', 'cuanticos', 'qubit', 'qubits'],
    ['github', 'codigo abierto', 'open source', 'software libre'],
    ['dios', 'teismo', 'ateismo', 'religion'],
    ['guerra', 'guerras', 'conflicto', 'conflictos', 'belico'],
    ['delito', 'delitos', 'crimen', 'crimenes', 'delincuencia'],
    ['estafa', 'estafas', 'fraude', 'fraudes', 'timo'],
    ['serie', 'series', 'temporada'],
    ['pelicula', 'peliculas', 'cine'],
    ['anime', 'manga'],
    ['ejercicio', 'ejercicios', 'entrenamiento', 'rutina'],
    ['mito', 'mitos', 'leyenda urbana'],
    ['extraterrestre', 'alien', 'vida extraterrestre'],
    ['logro', 'logros', 'acierto', 'aciertos'],
    ['error', 'errores', 'fracaso', 'fracasos'],
];

// --- Categorías ---------------------------------------------------------------------

/** Árbol de categorías con conteo de publicaciones (las madres suman las de sus hijas). */
function categorias_arbol(): array
{
    static $arbol = null;
    if ($arbol !== null) {
        return $arbol;
    }
    $filas = filas('SELECT c.id, c.slug, c.nombre, c.descripcion, c.nota, c.padre_id, c.orden,
        (SELECT COUNT(*) FROM publicaciones p WHERE p.categoria_id = c.id) AS total
        FROM categorias c ORDER BY c.orden, c.nombre');
    $raices = [];
    $hijas = [];
    foreach ($filas as $f) {
        $f['total'] = (int) $f['total'];
        if ($f['padre_id'] === null) {
            $raices[$f['id']] = $f + ['subs' => []];
        } else {
            $hijas[] = $f;
        }
    }
    foreach ($hijas as $h) {
        if (isset($raices[$h['padre_id']])) {
            $raices[$h['padre_id']]['subs'][] = $h;
            $raices[$h['padre_id']]['total'] += $h['total'];
        }
    }
    return $arbol = array_values($raices);
}

function categoria_por_slug(string $slug): ?array
{
    return fila('SELECT c.*, pc.slug AS padre_slug, pc.nombre AS padre_nombre FROM categorias c
        LEFT JOIN categorias pc ON pc.id = c.padre_id WHERE c.slug = ?', [$slug]);
}

function categoria_por_id(int $id): ?array
{
    return fila('SELECT c.*, pc.slug AS padre_slug, pc.nombre AS padre_nombre FROM categorias c
        LEFT JOIN categorias pc ON pc.id = c.padre_id WHERE c.id = ?', [$id]);
}

// --- Listados y búsqueda -------------------------------------------------------------

const SQL_TARJETA = 'SELECT p.id, p.slug, p.tipo, p.titulo, p.orientacion, p.verificacion, p.creador, p.miniatura, p.miniatura_color,
    p.duracion_seg, p.vistas, p.publicado_en, p.precio, p.precio_antes, p.venta_url IS NOT NULL AS con_venta, (p.video_archivo IS NOT NULL OR p.youtube_id IS NOT NULL) AS con_video, p.youtube_id IS NOT NULL AS es_youtube,
    c.nombre AS categoria_nombre, c.slug AS categoria_slug, pc.nombre AS padre_nombre, pc.slug AS padre_slug,
    (SELECT COUNT(*) FROM imagenes i WHERE i.publicacion_id = p.id) AS n_imagenes,
    (SELECT COUNT(*) FROM enlaces_prensa ep WHERE ep.publicacion_id = p.id) AS n_prensa';
const SQL_DESDE = ' FROM publicaciones p JOIN categorias c ON c.id = p.categoria_id LEFT JOIN categorias pc ON pc.id = c.padre_id';

/** Cada término de búsqueda se convierte en un grupo de alternativas (sinónimos). */
function grupos_busqueda(array $terminos): array
{
    $grupos = [];
    foreach ($terminos as $t) {
        $alt = [$t];
        foreach (SINONIMOS as $g) {
            if (in_array($t, $g, true)) {
                $alt = array_values(array_unique(array_merge($alt, $g)));
            }
        }
        $grupos[] = $alt;
    }
    return $grupos;
}

/** Lee y valida los filtros desde la URL. Solo se aceptan valores conocidos. */
function filtros_desde_url(array $get): array
{
    $lista = static function ($v, array $validos): array {
        $v = is_array($v) ? $v : ($v === null || $v === '' ? [] : explode(',', (string) $v));
        return array_values(array_intersect(array_map('strval', $v), array_keys($validos)));
    };
    $orden = (string) ($get['orden'] ?? '');
    $q = mb_substr(trim((string) ($get['q'] ?? '')), 0, 120);
    return [
        'q'           => $q,
        'cat'         => preg_replace('/[^a-z0-9-]/', '', (string) ($get['cat'] ?? '')),
        'tipo'        => $lista($get['tipo'] ?? null, TIPOS),
        'orientacion' => $lista($get['orientacion'] ?? null, ORIENTACIONES),
        'verificacion'=> $lista($get['verificacion'] ?? null, VERIFICACIONES),
        'fecha'       => isset(FECHAS[$get['fecha'] ?? '']) ? $get['fecha'] : '',
        'duracion'    => isset(DURACIONES[$get['duracion'] ?? '']) ? $get['duracion'] : '',
        'con'         => $lista($get['con'] ?? null, CARACTERISTICAS),
        'creador'     => mb_substr(trim((string) ($get['creador'] ?? '')), 0, 120),
        'orden'       => isset(ORDENES[$orden]) ? $orden : ($q !== '' ? 'relevancia' : 'recientes'),
        'pagina'      => max(1, (int) ($get['pagina'] ?? 1)),
    ];
}

/** Parámetros de URL para un conjunto de filtros (omite los vacíos y los valores por defecto). */
function filtros_a_url(array $f, array $cambios = []): array
{
    $f = array_merge($f, $cambios);
    $porDefecto = $f['q'] !== '' ? 'relevancia' : 'recientes';
    return array_filter([
        'q' => $f['q'],
        'cat' => $f['cat'],
        'tipo' => implode(',', $f['tipo']),
        'orientacion' => implode(',', $f['orientacion']),
        'verificacion' => implode(',', $f['verificacion']),
        'fecha' => $f['fecha'],
        'duracion' => $f['duracion'],
        'con' => implode(',', $f['con']),
        'creador' => $f['creador'],
        'orden' => $f['orden'] !== $porDefecto ? $f['orden'] : '',
        'pagina' => ($f['pagina'] ?? 1) > 1 ? $f['pagina'] : '',
    ], static fn($v) => $v !== '' && $v !== null);
}

/**
 * Construye las condiciones SQL. Devuelve [condiciones por faceta, parámetros por faceta, expresión de puntaje, parámetros del puntaje].
 * Separarlas por faceta permite contar cada opción de filtro sin ella misma (conteos honestos).
 */
function condiciones(array $f, bool $todosLosTerminos = true): array
{
    $w = [];
    $p = [];
    $puntaje = '0';
    $pp = [];
    if ($f['q'] !== '') {
        $grupos = grupos_busqueda(terminos_busqueda($f['q']));
        if ($grupos) {
            $partes = [];
            $prm = [];
            $sumas = [];
            foreach ($grupos as $alt) {
                $o = [];
                foreach ($alt as $i => $t) {
                    // Lo escrito coincide con el inicio de una palabra ("transp" encuentra "transporte");
                    // los sinónimos, solo con palabras completas (evita que "bus" encuentre "buscar").
                    $patron = $i === 0 ? '% ' . $t . '%' : '% ' . $t . ' %';
                    $o[] = 'p.busqueda LIKE ?';
                    $prm[] = $patron;
                    $peso = $i === 0 ? 1 : 0.8;
                    $sumas[] = "(CASE WHEN p.titulo_norm LIKE ? THEN " . (9 * $peso) . " WHEN p.busqueda LIKE ? THEN " . (2 * $peso) . " ELSE 0 END)";
                    array_push($pp, $patron, $patron);
                }
                $partes[] = '(' . implode(' OR ', $o) . ')';
            }
            $w['q'] = '(' . implode($todosLosTerminos ? ' AND ' : ' OR ', $partes) . ')';
            $p['q'] = $prm;
            $puntaje = implode(' + ', $sumas);
        }
    }
    if ($f['cat'] !== '' && ($cat = categoria_por_slug($f['cat']))) {
        $w['cat'] = '(c.id = ? OR c.padre_id = ?)';
        $p['cat'] = [(int) $cat['id'], (int) $cat['id']];
    }
    foreach (['tipo' => 'p.tipo', 'orientacion' => 'p.orientacion', 'verificacion' => 'p.verificacion'] as $k => $col) {
        if ($f[$k]) {
            $w[$k] = $col . ' IN (' . implode(',', array_fill(0, count($f[$k]), '?')) . ')';
            $p[$k] = $f[$k];
        }
    }
    if ($f['fecha'] !== '') {
        $w['fecha'] = 'p.publicado_en >= ?';
        $p['fecha'] = [date('Y-m-d H:i:s', time() - FECHAS[$f['fecha']][1] * 86400)];
    }
    if ($f['duracion'] !== '') {
        [, $min, $max] = DURACIONES[$f['duracion']];
        $w['duracion'] = "(p.tipo = 'video' AND p.duracion_seg BETWEEN ? AND ?)";
        $p['duracion'] = [$min, $max];
    }
    foreach ($f['con'] as $c) {
        $w['con_' . $c] = CARACTERISTICAS[$c][1];
    }
    if ($f['creador'] !== '') {
        $w['creador'] = 'p.creador = ?';
        $p['creador'] = [$f['creador']];
    }
    return [$w, $p, $puntaje, $pp];
}

function where_sql(array $w, array $p, array $excluir = []): array
{
    $cond = [];
    $prm = [];
    foreach ($w as $k => $sql) {
        if (in_array($k, $excluir, true) || in_array(strtok($k, '_'), $excluir, true)) {
            continue;
        }
        $cond[] = $sql;
        array_push($prm, ...($p[$k] ?? []));
    }
    return [$cond ? ' WHERE ' . implode(' AND ', $cond) : '', $prm];
}

/**
 * Explora publicaciones con filtros, búsqueda y orden. Devuelve solo la página pedida.
 * @return array{items: array, total: int, paginas: int, pagina: int, exacto: bool, terminos: array}
 */
function explorar(array $f, ?int $porPagina = null): array
{
    $porPagina = $porPagina ?? (int) config('app.por_pagina', 24);
    $terminos = terminos_busqueda($f['q']);
    [$w, $p, $puntaje, $pp] = condiciones($f, true);
    [$where, $prm] = where_sql($w, $p);
    $total = (int) valor('SELECT COUNT(*)' . SQL_DESDE . $where, $prm);
    $exacto = true;
    if ($total === 0 && count($terminos) > 1) {
        // Ninguna publicación tiene todas las palabras: se muestran las que tienen alguna.
        [$w, $p, $puntaje, $pp] = condiciones($f, false);
        [$where, $prm] = where_sql($w, $p);
        $total = (int) valor('SELECT COUNT(*)' . SQL_DESDE . $where, $prm);
        $exacto = false;
    }
    $paginas = max(1, (int) ceil($total / $porPagina));
    $pagina = min($f['pagina'], $paginas);
    $offset = ($pagina - 1) * $porPagina;
    $orden = match ($f['orden']) {
        'antiguos' => 'p.publicado_en ASC',
        'vistas' => 'p.vistas DESC, p.publicado_en DESC',
        'relevancia' => 'puntaje DESC, p.publicado_en DESC',
        default => 'p.publicado_en DESC',
    };
    $sel = SQL_TARJETA . ', (' . $puntaje . ') AS puntaje' . SQL_DESDE . $where;
    $todos = array_merge($pp, $prm);
    if ($f['orden'] === 'equilibrado') {
        // Intercala orientaciones: primero lo mejor de cada una, luego el segundo de cada una, etc.
        $escala = 'CASE t.orientacion ' . implode(' ', array_map(static fn($k, $v) => "WHEN '{$k}' THEN {$v[1]}", array_keys(ORIENTACIONES), ORIENTACIONES)) . ' END';
        $sql = 'SELECT * FROM (SELECT x.*, ROW_NUMBER() OVER (PARTITION BY x.orientacion ORDER BY x.puntaje DESC, x.publicado_en DESC) AS turno FROM (' . $sel . ') x) t'
            . " ORDER BY t.turno, CASE WHEN t.orientacion = 'no-aplica' THEN 1 ELSE 0 END, {$escala} LIMIT {$porPagina} OFFSET {$offset}";
    } else {
        $sql = $sel . " ORDER BY {$orden} LIMIT {$porPagina} OFFSET {$offset}";
    }
    return ['items' => filas($sql, $todos), 'total' => $total, 'paginas' => $paginas, 'pagina' => $pagina, 'exacto' => $exacto, 'terminos' => $terminos];
}

/** Conteo de cada opción de filtro con los demás filtros aplicados. */
function facetas(array $f): array
{
    [$w, $p] = condiciones($f, true);
    $out = [];
    foreach (['tipo' => 'p.tipo', 'orientacion' => 'p.orientacion', 'verificacion' => 'p.verificacion'] as $k => $col) {
        [$where, $prm] = where_sql($w, $p, [$k]);
        $out[$k] = array_column(filas("SELECT {$col} AS v, COUNT(*) AS n" . SQL_DESDE . $where . " GROUP BY {$col}", $prm), 'n', 'v');
    }
    return $out;
}

function publicaciones_recientes(int $limite = 12, array $extra = []): array
{
    $f = filtros_desde_url($extra);
    return explorar($f + ['pagina' => 1], $limite)['items'];
}

// --- Detalle -----------------------------------------------------------------------

function publicacion_por_slug(string $slug): ?array
{
    return fila('SELECT p.*, c.nombre AS categoria_nombre, c.slug AS categoria_slug, pc.nombre AS padre_nombre, pc.slug AS padre_slug
        ' . SQL_DESDE . ' WHERE p.slug = ?', [$slug]);
}

function publicacion_por_id(int $id): ?array
{
    return fila('SELECT p.*, c.nombre AS categoria_nombre, c.slug AS categoria_slug, pc.nombre AS padre_nombre, pc.slug AS padre_slug
        ' . SQL_DESDE . ' WHERE p.id = ?', [$id]);
}

function imagenes_de(int $id): array
{
    return filas('SELECT id, base, color, alt FROM imagenes WHERE publicacion_id = ? ORDER BY orden, id', [$id]);
}

function redes_de(int $id): array
{
    return filas('SELECT id, red, usuario, url FROM redes_sociales WHERE publicacion_id = ? ORDER BY id', [$id]);
}

/** Artículos de prensa sobre el tema de una publicación, en el orden que eligió la administración. */
function prensa_de(int $id): array
{
    return filas('SELECT id, titulo, medio, url, fecha, idioma FROM enlaces_prensa WHERE publicacion_id = ? ORDER BY orden, id', [$id]);
}

function prensa_por_id(int $id): ?array
{
    return fila('SELECT e.*, p.slug AS publicacion_slug FROM enlaces_prensa e JOIN publicaciones p ON p.id = e.publicacion_id WHERE e.id = ?', [$id]);
}

function red_por_id(int $id): ?array
{
    return fila('SELECT r.*, p.slug AS publicacion_slug, p.titulo AS publicacion_titulo FROM redes_sociales r
        JOIN publicaciones p ON p.id = r.publicacion_id WHERE r.id = ?', [$id]);
}

/** Otras miradas: mismo tema (etiquetas en común) con distinta orientación primero. */
function perspectivas(array $pub, int $limite = 6): array
{
    $tags = array_filter(array_map(static fn($t) => normalizar($t), explode(',', (string) $pub['etiquetas'])), static fn($t) => mb_strlen($t) > 3);
    if (!$tags) {
        return [];
    }
    $o = [];
    $prm = [];
    foreach (array_slice($tags, 0, 6) as $t) {
        $o[] = 'p.titulo_norm LIKE ?';
        $prm[] = '% ' . $t . ' %';
    }
    $sql = SQL_TARJETA . ', 0 AS puntaje' . SQL_DESDE . " WHERE p.id <> ? AND (p.orientacion <> 'no-aplica' OR p.categoria_id = ?) AND (" . implode(' OR ', $o) . ')'
        . " ORDER BY CASE WHEN p.orientacion <> ? AND p.orientacion <> 'no-aplica' THEN 0 ELSE 1 END, p.publicado_en DESC LIMIT " . $limite;
    return filas($sql, array_merge([(int) $pub['id'], (int) $pub['categoria_id']], $prm, [$pub['orientacion']]));
}

function relacionadas(array $pub, array $excluir, int $limite = 10): array
{
    $ids = array_map('intval', array_merge([$pub['id']], $excluir));
    $padre = $pub['padre_slug'] ?: $pub['categoria_slug'];
    $catId = (int) (categoria_por_slug((string) $padre)['id'] ?? 0);
    $sql = SQL_TARJETA . ', 0 AS puntaje' . SQL_DESDE . ' WHERE p.id NOT IN (' . implode(',', $ids) . ')'
        . ' ORDER BY CASE WHEN c.id = ? OR c.padre_id = ? THEN 0 ELSE 1 END, p.publicado_en DESC LIMIT ' . $limite;
    return filas($sql, [$catId, $catId]);
}

/** Suma una vista como máximo una vez por sesión y publicación. */
function contar_vista(array $pub): void
{
    if (!empty($_SESSION['visto'][$pub['id']])) {
        return;
    }
    $_SESSION['visto'][$pub['id']] = 1;
    consulta('UPDATE publicaciones SET vistas = vistas + 1 WHERE id = ?', [(int) $pub['id']]);
}

// --- Transparencia --------------------------------------------------------------------

/** Cuántas publicaciones hay por orientación y por verificación (para el panel de equilibrio). */
function equilibrio(): array
{
    $o = array_column(filas('SELECT orientacion AS v, COUNT(*) AS n FROM publicaciones GROUP BY orientacion'), 'n', 'v');
    $v = array_column(filas('SELECT verificacion AS v, COUNT(*) AS n FROM publicaciones GROUP BY verificacion'), 'n', 'v');
    $t = array_column(filas('SELECT tipo AS v, COUNT(*) AS n FROM publicaciones GROUP BY tipo'), 'n', 'v');
    return ['orientacion' => array_map('intval', $o), 'verificacion' => array_map('intval', $v), 'tipo' => array_map('intval', $t),
        'total' => (int) array_sum($t)];
}

function creadores(): array
{
    return array_column(filas("SELECT DISTINCT creador FROM publicaciones WHERE creador <> '' ORDER BY creador"), 'creador');
}

// --- Sugerencias en vivo --------------------------------------------------------------

function resultado_compacto(array $f, array $terminos): array
{
    $o = ORIENTACIONES[$f['orientacion']] ?? ORIENTACIONES['no-aplica'];
    return [
        'titulo' => $f['titulo'],
        'titulo_html' => resaltar($f['titulo'], $terminos),
        'url' => url('video.php', ['v' => $f['slug']]),
        'imagen' => imagen($f['miniatura'], 480),
        'color' => $f['miniatura_color'],
        'etiqueta' => $f['creador'],
        'detalle' => $f['tipo'] === 'video' ? duracion((int) $f['duracion_seg']) : TIPOS[$f['tipo']][0],
        'orientacion' => $o[1] ? $o[0] : '',
        'verificacion' => $f['verificacion'],
        'precio' => $f['precio'] !== null ? precio((int) $f['precio']) : null,
    ];
}

// --- Búsquedas populares (anónimas) -----------------------------------------------------

function registrar_busqueda(string $q, int $resultados): void
{
    if (!config('privacidad.registrar_busquedas', true)) {
        return;
    }
    $t = mb_substr(trim((string) preg_replace('/\s+/u', ' ', mb_strtolower($q))), 0, 120);
    if (mb_strlen(normalizar($t)) < 2) {
        return;
    }
    consulta('INSERT INTO busquedas (termino, resultados, creado_en) VALUES (?, ?, ?)', [$t, $resultados, ahora()]);
}

function tendencias(int $limite = 6): array
{
    $desde = date('Y-m-d H:i:s', time() - 14 * 86400);
    $top = [];
    foreach (filas('SELECT termino, COUNT(*) AS veces FROM busquedas WHERE creado_en > ? AND resultados > 0
        GROUP BY termino ORDER BY veces DESC LIMIT ' . (int) ($limite * 3), [$desde]) as $r) {
        $clave = normalizar($r['termino']);
        if ($clave !== '' && !isset($top[$clave]) && count($top) < $limite) {
            $top[$clave] = $r['termino'];
        }
    }
    $top = array_values($top);
    foreach (['video falso', 'corrupción', 'transporte gratuito', 'campaña coordinada', 'licitación', 'impuestos', 'audífonos'] as $b) {
        if (count($top) >= $limite) {
            break;
        }
        if (!in_array(normalizar($b), array_map('normalizar', $top), true)) {
            $top[] = $b;
        }
    }
    return array_slice($top, 0, $limite);
}

// --- Historial personal (solo si la persona lo activa) ------------------------------------

function registrar_clic(array $usuario, int $publicacionId, string $tipo): void
{
    if (empty($usuario['guardar_historial'])) {
        return;
    }
    consulta('INSERT INTO clics (usuario_id, publicacion_id, tipo, creado_en) VALUES (?, ?, ?, ?)', [(int) $usuario['id'], $publicacionId, $tipo, ahora()]);
}

function clics_recientes(int $usuarioId, int $limite = 10): array
{
    return filas('SELECT k.tipo, MAX(k.creado_en) AS fecha, p.slug, p.titulo FROM clics k JOIN publicaciones p ON p.id = k.publicacion_id
        WHERE k.usuario_id = ? GROUP BY k.tipo, p.id, p.slug, p.titulo ORDER BY fecha DESC LIMIT ' . (int) $limite, [$usuarioId]);
}

// --- Texto de búsqueda ---------------------------------------------------------------

/** Texto normalizado para buscar sin importar tildes ni mayúsculas. */
function texto_busqueda(?string ...$partes): string
{
    $txt = normalizar(implode(' ', array_map(static fn($p) => (string) $p, $partes)));
    return ' ' . trim((string) preg_replace('/[^a-z0-9]+/', ' ', $txt)) . ' ';
}

/** Datos de búsqueda de una publicación (se usa al instalar y al guardar desde el panel). */
function campos_busqueda(array $p, string $categoria, string $padre): array
{
    $etiquetas = (string) ($p['etiquetas'] ?? '');
    return [
        'titulo_norm' => mb_substr(texto_busqueda($p['titulo'], $etiquetas), 0, 400),
        'busqueda' => texto_busqueda(
            $p['titulo'], $p['descripcion'], mb_substr((string) ($p['cuerpo'] ?? ''), 0, 3000), $categoria, $padre,
            $p['creador'] ?? '', $p['autor'] ?? '', $etiquetas, $p['tienda'] ?? '',
            TIPOS[$p['tipo']][0] ?? '', ORIENTACIONES[$p['orientacion']][0] ?? '', VERIFICACIONES[$p['verificacion']][0] ?? ''
        ),
    ];
}
