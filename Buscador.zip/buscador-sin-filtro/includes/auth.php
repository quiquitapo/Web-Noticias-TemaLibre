<?php
/**
 * Cuentas de usuario: acceso, registro, cierre de sesión y límite de intentos.
 * Las contraseñas se guardan con password_hash() y nunca en texto plano.
 */
declare(strict_types=1);

function usuario_actual(): ?array
{
    static $usuario = false;
    if ($usuario !== false) {
        return $usuario;
    }
    $id = (int) ($_SESSION['uid'] ?? 0);
    $usuario = $id ? fila('SELECT id, nombre, email, rol, nombre_admin, guardar_historial, avatar_tipo, avatar, avatar_foto, creado_en, ultimo_acceso FROM usuarios WHERE id = ?', [$id]) : null;
    if ($id && !$usuario) {
        unset($_SESSION['uid']);
    }
    return $usuario;
}

function sesion_iniciada(): bool
{
    return usuario_actual() !== null;
}

function es_admin(): bool
{
    return (usuario_actual()['rol'] ?? '') === 'admin';
}

/** Solo administradores. Sin sesión lleva al acceso; con sesión de usuario común responde 403. */
function requerir_admin(): void
{
    requerir_sesion('admin');
    if (!es_admin()) {
        http_response_code(403);
        $GLOBALS['error_403'] = true;
        require APP_DIR . '/404.php';
        exit;
    }
}

/** Borra la cuenta y todo lo asociado (historial). Las publicaciones subidas por un admin se conservan. */
function eliminar_cuenta(int $id, string $clave): array
{
    $u = fila('SELECT clave_hash, rol, avatar_foto FROM usuarios WHERE id = ?', [$id]);
    if (!$u || !password_verify($clave, $u['clave_hash'])) {
        return ['ok' => false, 'error' => 'La contraseña no coincide.'];
    }
    if ($u['rol'] === 'admin' && (int) valor("SELECT COUNT(*) FROM usuarios WHERE rol = 'admin'") <= 1) {
        return ['ok' => false, 'error' => 'Eres el único administrador. Nombra a otra persona como admin antes de eliminar tu cuenta.'];
    }
    consulta('DELETE FROM usuarios WHERE id = ?', [$id]);
    borrar_foto_avatar($u['avatar_foto']); // la foto de perfil se borra del disco junto con la cuenta
    registrar_log('accesos', "cuenta eliminada #{$id}");
    cerrar_sesion();
    return ['ok' => true];
}

/** Cambia la contraseña tras comprobar la actual. Renueva el id de sesión. */
function cambiar_clave(int $id, string $actual, string $nueva): array
{
    $min = (int) config('seguridad.clave_min', 8);
    $hash = (string) valor('SELECT clave_hash FROM usuarios WHERE id = ?', [$id]);
    if ($hash === '' || !password_verify($actual, $hash)) {
        return ['ok' => false, 'errores' => ['clave_actual' => 'La contraseña actual no coincide.']];
    }
    if (mb_strlen($nueva) < $min || mb_strlen($nueva) > 128) {
        return ['ok' => false, 'errores' => ['clave_nueva' => "La nueva contraseña debe tener entre {$min} y 128 caracteres."]];
    }
    if (hash_equals($actual, $nueva)) {
        return ['ok' => false, 'errores' => ['clave_nueva' => 'La nueva contraseña debe ser distinta de la actual.']];
    }
    consulta('UPDATE usuarios SET clave_hash = ? WHERE id = ?', [password_hash($nueva, PASSWORD_DEFAULT), $id]);
    session_regenerate_id(true);
    registrar_log('accesos', "contraseña cambiada #{$id}");
    return ['ok' => true];
}

/** Redirige a la página de acceso si no hay sesión. */
function requerir_sesion(string $motivo = ''): void
{
    if (sesion_iniciada()) {
        return;
    }
    if (es_peticion_json()) {
        json_respuesta(['ok' => false, 'error' => 'Necesitas iniciar sesión.', 'acceso' => url('entrar.php')], 401);
    }
    redirigir(url('entrar.php', ['volver' => url_actual(), 'motivo' => $motivo]));
}

function clave_intentos(string $email): string
{
    return hash('sha256', mb_strtolower($email) . '|' . ip_cliente());
}

function intentos_restantes(string $email): array
{
    $ventana = (int) config('seguridad.ventana_min', 15);
    $max = (int) config('seguridad.max_intentos', 5);
    $desde = date('Y-m-d H:i:s', time() - $ventana * 60);
    $n = (int) valor('SELECT COUNT(*) FROM intentos_acceso WHERE clave = ? AND creado_en > ?', [clave_intentos($email), $desde]);
    return [$max - $n, $ventana];
}

/**
 * @return array{ok: bool, error?: string, campo?: string}
 */
function iniciar_sesion(string $email, string $clave): array
{
    $email = mb_strtolower(trim($email));
    if ($email === '' || $clave === '') {
        return ['ok' => false, 'error' => 'Escribe tu correo y tu contraseña.', 'campo' => $email === '' ? 'email' : 'clave'];
    }
    [$restantes, $ventana] = intentos_restantes($email);
    if ($restantes <= 0) {
        registrar_log('accesos', "bloqueado {$email}");
        return ['ok' => false, 'error' => "Demasiados intentos fallidos. Espera {$ventana} minutos y vuelve a intentarlo.", 'campo' => 'clave'];
    }

    $u = fila('SELECT id, clave_hash FROM usuarios WHERE email = ?', [$email]);
    // Se verifica siempre un hash para que el tiempo de respuesta no revele si el correo existe.
    $hash = $u['clave_hash'] ?? password_hash(bin2hex(random_bytes(8)), PASSWORD_DEFAULT);
    $correcta = password_verify($clave, $hash) && $u !== null;

    if (!$correcta) {
        consulta('INSERT INTO intentos_acceso (clave, creado_en) VALUES (?, ?)', [clave_intentos($email), ahora()]);
        registrar_log('accesos', "fallido {$email}");
        $quedan = $restantes - 1;
        $extra = match (true) {
            $quedan === 1 => ' Te queda 1 intento.',
            $quedan === 2 => ' Te quedan 2 intentos.',
            $quedan <= 0 => " Por seguridad, espera {$ventana} minutos antes de volver a intentarlo.",
            default => '',
        };
        return ['ok' => false, 'error' => 'El correo o la contraseña no coinciden.' . $extra, 'campo' => 'clave'];
    }

    if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
        consulta('UPDATE usuarios SET clave_hash = ? WHERE id = ?', [password_hash($clave, PASSWORD_DEFAULT), $u['id']]);
    }
    consulta('DELETE FROM intentos_acceso WHERE clave = ?', [clave_intentos($email)]);
    abrir_sesion((int) $u['id']);
    registrar_log('accesos', "ok {$email}");
    return ['ok' => true];
}

function abrir_sesion(int $id): void
{
    session_regenerate_id(true);
    $_SESSION['uid'] = $id;
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    $_SESSION['recien_desbloqueado'] = true;
    consulta('UPDATE usuarios SET ultimo_acceso = ? WHERE id = ?', [ahora(), $id]);
}

/**
 * @return array{ok: bool, errores?: array<string,string>}
 */
function registrar_usuario(string $nombre, string $email, string $clave): array
{
    $nombre = trim(preg_replace('/\s+/', ' ', $nombre) ?? '');
    $email = mb_strtolower(trim($email));
    $min = (int) config('seguridad.clave_min', 8);
    $errores = [];

    if (mb_strlen($nombre) < 2 || mb_strlen($nombre) > 60) {
        $errores['nombre'] = 'Escribe tu nombre (entre 2 y 60 caracteres).';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190) {
        $errores['email'] = 'Escribe un correo válido, por ejemplo nombre@correo.cl.';
    } elseif (valor('SELECT 1 FROM usuarios WHERE email = ?', [$email])) {
        $errores['email'] = 'Ya existe una cuenta con este correo. Inicia sesión.';
    }
    if (mb_strlen($clave) < $min) {
        $errores['clave'] = "La contraseña debe tener al menos {$min} caracteres.";
    } elseif (mb_strlen($clave) > 128) {
        $errores['clave'] = 'La contraseña no puede superar 128 caracteres.';
    }
    if ($errores) {
        return ['ok' => false, 'errores' => $errores];
    }

    consulta("INSERT INTO usuarios (nombre, email, clave_hash, rol, creado_en) VALUES (?, ?, ?, 'usuario', ?)",
        [$nombre, $email, password_hash($clave, PASSWORD_DEFAULT), ahora()]);
    $id = (int) db()->lastInsertId();
    abrir_sesion($id);
    registrar_log('accesos', "registro {$email}");
    return ['ok' => true];
}

function cerrar_sesion(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', ['expires' => time() - 42000, 'path' => $p['path'], 'secure' => $p['secure'], 'httponly' => true, 'samesite' => 'Lax']);
    }
    session_destroy();
}

/** Devuelve true una sola vez justo después de iniciar sesión (para la animación de desbloqueo). */
function recien_desbloqueado(): bool
{
    $v = !empty($_SESSION['recien_desbloqueado']);
    unset($_SESSION['recien_desbloqueado']);
    return $v;
}
