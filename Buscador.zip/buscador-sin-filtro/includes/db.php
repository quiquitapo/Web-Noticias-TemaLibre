<?php
/**
 * Conexión PDO. SQLite por defecto (sin configuración); MySQL/MariaDB con SF_DB_DRIVER=mysql.
 * Con SQLite, la base se crea y se llena con datos de ejemplo la primera vez.
 */
declare(strict_types=1);

/** Versión del esquema. Si la base SQLite tiene otra, se reinstala sola (solo datos de ejemplo). */
const ESQUEMA_VERSION = '6';

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $driver = config('db.driver', 'sqlite');
    $opciones = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    if ($driver === 'mysql') {
        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', config('db.host'), config('db.puerto'), config('db.nombre'));
        $pdo = new PDO($dsn, (string) config('db.usuario'), (string) config('db.clave'), $opciones);
        $pdo->exec("SET time_zone = '" . date('P') . "'");
        revisar_esquema($pdo, 'mysql');
        return $pdo;
    }

    $ruta = (string) config('db.sqlite_ruta');
    $pdo = new PDO('sqlite:' . $ruta, null, null, $opciones);
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('PRAGMA journal_mode = WAL');
    $pdo->exec('PRAGMA busy_timeout = 3000');
    // Memoria acotada: caché de páginas pequeña y temporales en disco.
    $pdo->exec('PRAGMA cache_size = -2000');
    $pdo->exec('PRAGMA temp_store = FILE');
    revisar_esquema($pdo, 'sqlite');
    return $pdo;
}

/**
 * Base nueva: se instala con datos de ejemplo (en MySQL, solo si no hay tablas con los mismos nombres).
 * Base v2 (Sin Filtro v4): se migra sola, sin borrar nada. Otra versión: error con instrucciones.
 */
function revisar_esquema(PDO $pdo, string $driver): void
{
    try {
        $version = $pdo->query("SELECT valor FROM meta WHERE clave = 'esquema'")->fetchColumn();
    } catch (Throwable) {
        $version = null;
    }
    if ($version === ESQUEMA_VERSION) {
        return;
    }
    if (in_array($version, ['2', '3', '4', '5'], true) || (($version === false || $version === null) && $driver === 'sqlite')) {
        require_once INC_DIR . '/instalar.php';
        instalar($pdo, $driver);
        return;
    }
    if ($version === false || $version === null) {
        // MySQL vacía: se instala sola, pero nunca encima de tablas ajenas con los mismos nombres
        require_once INC_DIR . '/instalar.php';
        $nombres = "'" . implode("','", array_merge(TABLAS, TABLAS_V1)) . "'";
        $ajenas = (int) $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name IN ({$nombres})")->fetchColumn();
        if ($ajenas > 0) {
            throw new RuntimeException('La base MySQL ya tiene tablas con nombres que usa Sin Filtro. Usa una base vacía (ver README).');
        }
        instalar($pdo, $driver);
        return;
    }
    throw new RuntimeException("La base de datos usa el esquema v{$version} y esta versión del sitio necesita v" . ESQUEMA_VERSION . '.');
}

function db_driver(): string
{
    return config('db.driver', 'sqlite') === 'mysql' ? 'mysql' : 'sqlite';
}

function consulta(string $sql, array $params = []): PDOStatement
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

function fila(string $sql, array $params = []): ?array
{
    $r = consulta($sql, $params)->fetch();
    return $r === false ? null : $r;
}

function filas(string $sql, array $params = []): array
{
    return consulta($sql, $params)->fetchAll();
}

function valor(string $sql, array $params = [])
{
    $v = consulta($sql, $params)->fetchColumn();
    return $v === false ? null : $v;
}

function ahora(): string
{
    return date('Y-m-d H:i:s');
}
