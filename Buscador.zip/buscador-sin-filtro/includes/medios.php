<?php
/**
 * Procesamiento de archivos subidos desde el panel.
 * - Imágenes: se valida el tipo real (no la extensión), se corrige la orientación, se recortan y se guardan en WebP.
 * - Videos: MP4 (H.264) o WebM. Se guardan tal cual, con nombre aleatorio, en media/videos/ (carpeta protegida).
 * - Subtítulos: WebVTT o SRT (se convierte a WebVTT).
 * La memoria se controla limitando el tamaño en píxeles, reduciendo primero las fotos grandes
 * y liberando cada imagen apenas se usa.
 */
declare(strict_types=1);

const ANCHOS_MINIATURA = [480, 960, 1600];
const ANCHOS_FOTO = [400, 800, 1200];

final class ErrorSubida extends RuntimeException
{
}

function archivo_presente(?array $f): bool
{
    return is_array($f) && ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
}

/** Normaliza $_FILES['campo'] múltiple a una lista de archivos. */
function lista_archivos(?array $f): array
{
    if (!is_array($f) || !is_array($f['name'] ?? null)) {
        return archivo_presente($f) ? [$f] : [];
    }
    $out = [];
    foreach (array_keys($f['name']) as $i) {
        $uno = ['name' => $f['name'][$i], 'type' => $f['type'][$i], 'tmp_name' => $f['tmp_name'][$i], 'error' => $f['error'][$i], 'size' => $f['size'][$i]];
        if (archivo_presente($uno)) {
            $out[] = $uno;
        }
    }
    return $out;
}

function verificar_subida(array $f, int $maxBytes, string $que): void
{
    $msg = match ((int) $f['error']) {
        UPLOAD_ERR_OK => null,
        UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => "El {$que} supera el límite del servidor (" . ini_get('upload_max_filesize') . '). Sube uno más liviano o aumenta upload_max_filesize.',
        UPLOAD_ERR_PARTIAL => "El {$que} se subió a medias. Vuelve a intentarlo.",
        UPLOAD_ERR_NO_TMP_DIR, UPLOAD_ERR_CANT_WRITE => 'El servidor no pudo guardar el archivo temporal. Revisa los permisos.',
        default => "No se pudo recibir el {$que}.",
    };
    if ($msg) {
        throw new ErrorSubida($msg);
    }
    if (!is_uploaded_file($f['tmp_name'])) {
        throw new ErrorSubida("El {$que} no llegó como subida válida.");
    }
    if ((int) $f['size'] > $maxBytes) {
        throw new ErrorSubida("El {$que} pesa " . tamano_legible((int) $f['size']) . '; el máximo es ' . tamano_legible($maxBytes) . '.');
    }
}

function mime_real(string $ruta): string
{
    return (string) (new finfo(FILEINFO_MIME_TYPE))->file($ruta);
}

function nombre_aleatorio(string $slug): string
{
    return mb_substr($slug, 0, 60) . '-' . bin2hex(random_bytes(4));
}

/** Memoria disponible aproximada para procesar una imagen. */
function memoria_libre(): int
{
    $lim = ini_get('memory_limit');
    if ($lim === '-1' || $lim === false) {
        return PHP_INT_MAX;
    }
    $n = (int) $lim;
    $u = strtolower(substr(trim($lim), -1));
    $bytes = match ($u) { 'g' => $n * 1073741824, 'm' => $n * 1048576, 'k' => $n * 1024, default => $n };
    return $bytes - memory_get_usage();
}

/**
 * Procesa una imagen subida: valida, recorta a $aspecto (si se indica) y guarda en WebP en varios anchos.
 * @return array{base: string, color: string}
 */
function subir_imagen(array $f, string $carpeta, string $slug, array $anchos, ?float $aspecto, string $que = 'imagen'): array
{
    if (!function_exists('imagewebp')) {
        throw new ErrorSubida('Tu PHP no tiene GD con soporte WebP. Actívalo para subir imágenes.');
    }
    verificar_subida($f, (int) config('subidas.imagen_max_mb', 8) * 1048576, $que);
    $mime = mime_real($f['tmp_name']);
    if (!in_array($mime, ['image/png', 'image/jpeg', 'image/webp'], true)) {
        throw new ErrorSubida("La {$que} debe ser PNG, JPG o WebP (recibimos {$mime}).");
    }
    $info = @getimagesize($f['tmp_name']);
    if (!$info) {
        throw new ErrorSubida("La {$que} está dañada o no es una imagen.");
    }
    [$w, $h] = $info;
    $maxPx = (int) config('subidas.imagen_max_px', 6000);
    if ($w > $maxPx || $h > $maxPx) {
        throw new ErrorSubida("La {$que} mide {$w}×{$h} px; el máximo es {$maxPx} px por lado.");
    }
    // GD usa ~4 bytes por píxel; el margen cubre la copia reducida y su rotación (máx. 2400 px por lado)
    if ($w * $h * 4 + 36 * 1048576 > memoria_libre()) {
        throw new ErrorSubida("La {$que} ({$w}×{$h} px) es demasiado grande para la memoria del servidor. Reduce su tamaño o sube memory_limit.");
    }
    $src = match ($mime) {
        'image/png' => imagecreatefrompng($f['tmp_name']),
        'image/jpeg' => imagecreatefromjpeg($f['tmp_name']),
        default => imagecreatefromwebp($f['tmp_name']),
    };
    if (!$src) {
        throw new ErrorSubida("No pudimos leer la {$que}.");
    }
    // Las fotos grandes se reducen primero: rotar, recortar y escalar sobre una copia liviana ahorra memoria y tiempo
    $lado = 2400;
    if (max($w, $h) > $lado) {
        $k = $lado / max($w, $h);
        [$nw, $nh] = [max(1, (int) round($w * $k)), max(1, (int) round($h * $k))];
        $chica = imagecreatetruecolor($nw, $nh);
        imagealphablending($chica, false);
        imagesavealpha($chica, true);
        imagecopyresampled($chica, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
        imagedestroy($src);
        [$src, $w, $h] = [$chica, $nw, $nh];
    }
    // Fotos de celular: respeta la orientación EXIF
    if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
        $o = (int) (@exif_read_data($f['tmp_name'])['Orientation'] ?? 1);
        $grados = [3 => 180, 6 => -90, 8 => 90][$o] ?? 0;
        if ($grados) {
            $rot = imagerotate($src, $grados, 0);
            imagedestroy($src);
            $src = $rot;
            [$w, $h] = [imagesx($src), imagesy($src)];
        }
    }
    // Recorte centrado al aspecto pedido
    [$cx, $cy, $cw, $ch] = [0, 0, $w, $h];
    if ($aspecto) {
        if ($w / $h > $aspecto) {
            $cw = (int) round($h * $aspecto);
            $cx = (int) (($w - $cw) / 2);
        } else {
            $ch = (int) round($w / $aspecto);
            $cy = (int) (($h - $ch) / 2);
        }
    }
    $dirAbs = APP_DIR . '/media/portadas/' . $carpeta;
    if (!is_dir($dirAbs) && !mkdir($dirAbs, 0775, true) && !is_dir($dirAbs)) {
        imagedestroy($src);
        throw new ErrorSubida('No se pudo crear la carpeta de imágenes. Revisa los permisos de media/portadas.');
    }
    $nombre = nombre_aleatorio($slug);
    $base = $carpeta . '/' . $nombre;
    $creados = [];
    try {
        foreach ($anchos as $aw) {
            $ah = (int) round($aw * $ch / $cw);
            $dst = imagecreatetruecolor($aw, $ah);
            imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255)); // las transparencias quedan sobre blanco
            imagecopyresampled($dst, $src, 0, 0, $cx, $cy, $aw, $ah, $cw, $ch);
            $ruta = APP_DIR . '/media/portadas/' . $base . '-' . $aw . '.webp';
            if (!imagewebp($dst, $ruta, 80)) {
                throw new ErrorSubida('No se pudo guardar la imagen. Revisa los permisos de media/portadas.');
            }
            imagedestroy($dst);
            $creados[] = $ruta;
        }
        $px = imagecreatetruecolor(1, 1);
        imagecopyresampled($px, $src, 0, 0, $cx, $cy, 1, 1, $cw, $ch);
        $rgb = imagecolorat($px, 0, 0);
        imagedestroy($px);
    } catch (Throwable $e) {
        foreach ($creados as $c) {
            @unlink($c);
        }
        imagedestroy($src);
        throw $e;
    }
    imagedestroy($src);
    return ['base' => $base, 'color' => sprintf('#%02x%02x%02x', ($rgb >> 16) & 255, ($rgb >> 8) & 255, $rgb & 255)];
}

/** @return array{archivo: string, formato: string} */
function subir_video(array $f, string $slug): array
{
    verificar_subida($f, (int) config('subidas.video_max_mb', 512) * 1048576, 'video');
    $mime = mime_real($f['tmp_name']);
    $ext = ['video/mp4' => 'mp4', 'video/webm' => 'webm', 'audio/webm' => 'webm'][$mime] ?? null;
    if (!$ext) {
        throw new ErrorSubida("El video debe ser MP4 (H.264) o WebM (recibimos {$mime}). Si es .mov, expórtalo como MP4.");
    }
    $nombre = nombre_aleatorio($slug) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], APP_DIR . '/media/videos/' . $nombre)) {
        throw new ErrorSubida('No se pudo guardar el video. Revisa los permisos de media/videos.');
    }
    return ['archivo' => $nombre, 'formato' => $ext];
}

/** Acepta WebVTT o SRT; los SRT se convierten a WebVTT. */
function subir_subtitulos(array $f, string $slug): string
{
    verificar_subida($f, 1048576, 'archivo de subtítulos');
    $txt = (string) file_get_contents($f['tmp_name']);
    $txt = preg_replace('/^\xEF\xBB\xBF/', '', $txt) ?? '';
    if (!mb_check_encoding($txt, 'UTF-8')) {
        $txt = mb_convert_encoding($txt, 'UTF-8', 'Windows-1252');
    }
    $txt = str_replace(["\r\n", "\r"], "\n", $txt);
    if (!str_starts_with(ltrim($txt), 'WEBVTT')) {
        if (!preg_match('/\d{2}:\d{2}:\d{2},\d{3}\s*-->/', $txt)) {
            throw new ErrorSubida('Los subtítulos deben estar en formato WebVTT (.vtt) o SRT (.srt).');
        }
        $txt = "WEBVTT\n\n" . preg_replace('/(\d{2}:\d{2}:\d{2}),(\d{3})/', '$1.$2', $txt);
    }
    $txt = strip_tags($txt, '<b><i><u><c><v><lang><ruby><rt>');
    $nombre = nombre_aleatorio($slug) . '.vtt';
    file_put_contents(APP_DIR . '/media/videos/' . $nombre, $txt);
    return $nombre;
}

/** Duración del video con ffprobe si el servidor lo tiene (si no, la calcula el navegador al elegir el archivo). */
function duracion_video(string $archivo): int
{
    if (!function_exists('shell_exec') || in_array('shell_exec', array_map('trim', explode(',', (string) ini_get('disable_functions'))), true)) {
        return 0;
    }
    $ffprobe = trim((string) @shell_exec('command -v ffprobe 2>/dev/null'));
    if ($ffprobe === '') {
        return 0;
    }
    $out = @shell_exec(escapeshellarg($ffprobe) . ' -v error -show_entries format=duration -of csv=p=0 ' . escapeshellarg(APP_DIR . '/media/videos/' . basename($archivo)));
    return max(0, (int) round((float) $out));
}

/** Borra archivos de imagen de una base (todos los anchos conocidos) si ninguna otra publicación la usa. */
function borrar_imagen_si_huerfana(string $base): void
{
    $usos = (int) valor('SELECT COUNT(*) FROM publicaciones WHERE miniatura = ?', [$base]) + (int) valor('SELECT COUNT(*) FROM imagenes WHERE base = ?', [$base]);
    if ($usos > 0 || $base === '' || str_contains($base, '..')) {
        return;
    }
    foreach (array_unique(array_merge(ANCHOS_MINIATURA, ANCHOS_FOTO)) as $w) {
        $ruta = APP_DIR . '/media/portadas/' . $base . '-' . $w . '.webp';
        if (is_file($ruta)) {
            @unlink($ruta);
        }
    }
}

function borrar_video_si_huerfano(?string $archivo): void
{
    if (!$archivo) {
        return;
    }
    $usos = (int) valor('SELECT COUNT(*) FROM publicaciones WHERE video_archivo = ? OR video_webm = ? OR subtitulos = ?', [$archivo, $archivo, $archivo]);
    $ruta = APP_DIR . '/media/videos/' . basename($archivo);
    if ($usos === 0 && is_file($ruta)) {
        @unlink($ruta);
    }
}
