<?php
/**
 * Escala de orientación (1 = izquierda … 5 = derecha). Diseño neutro: sin colores partidistas.
 * Variables: $orientacion, $compacta (bool)
 */
[$texto, $pos] = ORIENTACIONES[$orientacion] ?? ORIENTACIONES['no-aplica'];
$compacta = $compacta ?? false;
?>
<?php if ($pos === 0): ?>
  <span class="escala escala--na"><?= $compacta ? '' : '<span class="escala__txt">' . e($texto) . '</span>' ?><?= $compacta ? '<span class="sr">' . e($texto) . '</span>' : '' ?></span>
<?php else: ?>
  <span class="escala<?= $compacta ? ' escala--compacta' : '' ?>" role="img" aria-label="Orientación: <?= e($texto) ?> (posición <?= $pos ?> de 5, de izquierda a derecha)">
    <span class="escala__puntos" aria-hidden="true"><?php for ($i = 1; $i <= 5; $i++): ?><i<?= $i === $pos ? ' class="on"' : '' ?>></i><?php endfor; ?></span>
    <span class="escala__txt" aria-hidden="true"><?= e($texto) ?></span>
  </span>
<?php endif; ?>
