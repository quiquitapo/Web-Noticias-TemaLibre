<?php
/**
 * Formulario de búsqueda con sugerencias en vivo (patrón combobox de ARIA).
 * Variables: $id, $variante ('hero'|'dialogo'|'pagina'), $valor, $tipo
 */
$valor = $valor ?? '';
$tipo = $tipo ?? '';
$etiquetas = [
    'hero'    => '¿Qué quieres encontrar?',
    'dialogo' => 'Buscar videos, noticias y fotos',
    'pagina'  => 'Buscar',
];
?>
<form class="buscador buscador--<?= e($variante) ?>" action="<?= e(url('videos.php')) ?>" method="get" role="search" data-buscador>
  <?php if ($variante === 'hero'): ?>
    <label class="buscador__label" for="<?= e($id) ?>"><?= e($etiquetas[$variante]) ?></label>
  <?php else: ?>
    <label class="sr" for="<?= e($id) ?>"><?= e($etiquetas[$variante]) ?></label>
  <?php endif; ?>
  <div class="buscador__campo">
    <?= icono('buscar', 'buscador__lupa') ?>
    <input class="buscador__input" id="<?= e($id) ?>" name="q" type="search" value="<?= e($valor) ?>"
           autocomplete="off" autocapitalize="off" spellcheck="false" enterkeyhint="search" maxlength="120"
           role="combobox" aria-expanded="false" aria-autocomplete="list" aria-controls="<?= e($id) ?>-lista"
           aria-describedby="<?= e($id) ?>-estado"
           placeholder="<?= $variante === 'hero' ? 'video falso, corrupción, debate…' : 'Busca videos, noticias, verificaciones…' ?>"
           <?= $variante === 'hero' ? 'data-placeholder-animado' : '' ?>>
    <?php foreach ($ocultos ?? [] as $k => $v): ?><input type="hidden" name="<?= e($k) ?>" value="<?= e((string) $v) ?>"><?php endforeach; ?>
    <button class="buscador__limpiar icono-btn" type="button" data-limpiar<?= $valor === '' ? ' hidden' : '' ?>><?= icono('cerrar') ?><span class="sr">Borrar búsqueda</span></button>
    <button class="buscador__enviar" type="submit"><span class="buscador__enviar-txt">Buscar</span><?= icono('flecha', 'buscador__enviar-ico') ?></button>
  </div>
  <div class="buscador__panel" data-panel hidden>
    <div class="buscador__lista" id="<?= e($id) ?>-lista" role="listbox" aria-label="Sugerencias"></div>
  </div>
  <p class="sr" id="<?= e($id) ?>-estado" aria-live="polite" data-estado></p>
</form>
