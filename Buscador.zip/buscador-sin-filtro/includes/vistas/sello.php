<?php
/** Sello de verificación. Variables: $verificacion, $compacto (bool) */
[$texto, $ayuda] = VERIFICACIONES[$verificacion] ?? VERIFICACIONES['sin-verificar'];
$ico = ['verificado' => 'check-circulo', 'sin-verificar' => 'pendiente', 'enganoso' => 'alerta'][$verificacion] ?? 'pendiente';
?>
<span class="sello sello--<?= e($verificacion) ?><?= !empty($compacto) ? ' sello--compacto' : '' ?>" title="<?= e($ayuda) ?>">
  <?= icono($ico) ?><span class="sello__txt<?= !empty($compacto) ? ' sr' : '' ?>"><?= e($texto) ?></span>
</span>
