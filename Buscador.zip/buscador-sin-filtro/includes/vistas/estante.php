<?php
/**
 * Fila de publicaciones de una sección en la portada.
 * Variables: $id, $titulo, $icono, $desc (opcional), $items, $href, $enlace, $clase (opcional), $cinco (opcional)
 */
if (!$items) {
    return;
}
?>
<section class="seccion<?= !empty($clase) ? ' ' . e($clase) : '' ?>" aria-labelledby="<?= e($id) ?>">
  <div class="contenedor">
    <div class="seccion__cabeza">
      <div>
        <h2 class="seccion__titulo" id="<?= e($id) ?>"><?= icono($icono) ?><?= e($titulo) ?></h2>
        <?php if (!empty($desc)): ?><p class="seccion__desc"><?= e($desc) ?></p><?php endif; ?>
      </div>
      <a class="enlace-mas" href="<?= e($href) ?>"><?= e($enlace) ?><?= icono('der') ?></a>
    </div>
    <ul class="rejilla-videos<?= !empty($cinco) ? ' rejilla-videos--cinco' : '' ?>">
      <?php foreach ($items as $p): ?><li><?php vista('tarjeta', ['p' => $p]); ?></li><?php endforeach; ?>
    </ul>
  </div>
</section>
