<?php
/**
 * Redes sociales adjuntas a una publicación. Sin sesión se ven las plataformas, no los perfiles.
 * Variables: $redes, $nombre (creador), $titulo
 */
if (!$redes) {
    return;
}
$conSesion = sesion_iniciada();
?>
<section class="redes<?= $conSesion ? '' : ' redes--bloqueadas' ?>" aria-labelledby="redes-titulo" id="redes">
  <h2 class="caja__titulo" id="redes-titulo"><?= e($titulo ?? 'Redes sociales') ?></h2>
  <ul class="redes__lista">
    <?php foreach ($redes as $r): [$nombreRed, $ico] = red_info($r['red']); ?>
      <li>
        <?php if ($conSesion): ?>
          <a class="red" href="<?= e(url('ir.php', ['t' => 'red', 'id' => $r['id']])) ?>" target="_blank" rel="noopener nofollow" data-desbloqueado>
            <?= icono($ico, 'red__ico') ?>
            <span class="red__txt"><span class="red__nombre"><?= e($nombreRed) ?></span><span class="red__usuario">@<?= e($r['usuario']) ?></span></span>
            <?= icono('externo', 'red__ext') ?><span class="sr"> (se abre en una pestaña nueva)</span>
          </a>
        <?php else: ?>
          <span class="red red--oculta">
            <?= icono($ico, 'red__ico') ?>
            <span class="red__txt"><span class="red__nombre"><?= e($nombreRed) ?></span><span class="red__usuario" aria-hidden="true">@••••••••</span><span class="sr">, perfil oculto</span></span>
          </span>
        <?php endif; ?>
      </li>
    <?php endforeach; ?>
  </ul>
  <?php if (!$conSesion): ?>
    <?php vista('bloqueo', ['texto' => 'Ver perfiles de ' . $nombre, 'motivo' => 'Inicia sesión para ver las redes sociales de ' . $nombre . '.', 'clave' => 'red', 'clase' => 'boton--suave', 'ancla' => 'redes']); ?>
  <?php endif; ?>
</section>
