<?php
/**
 * Comentarios de una publicación.
 * Variables: $p (publicación), $usuario (o null)
 */
$orden = ($_GET['co'] ?? '') === 'antiguos' ? 'antiguos' : 'recientes';
$com = comentarios_de((int) $p['id'], $orden, max(1, (int) ($_GET['cp'] ?? 1)));
$borrador = (string) ($_SESSION['borrador_comentario'][(int) $p['id']] ?? '');
$errorCom = (string) ($_SESSION['error_comentario'] ?? '');
unset($_SESSION['error_comentario']);
$enlaceCom = static fn(array $q) => url('video.php', ['v' => $p['slug']] + array_filter($q)) . '#comentarios';
?>
<section class="comentarios" id="comentarios" aria-labelledby="com-titulo">
  <div class="comentarios__cabeza">
    <h2 class="comentarios__titulo" id="com-titulo"><?= icono('comentario') ?><?= e(plural($com['total'], 'comentario', 'comentarios')) ?></h2>
    <?php if ($com['total'] > 1): ?>
      <nav class="comentarios__orden" aria-label="Orden de los comentarios">
        <a href="<?= e($enlaceCom([])) ?>"<?= $orden === 'recientes' ? ' aria-current="true"' : '' ?>>Más recientes</a>
        <a href="<?= e($enlaceCom(['co' => 'antiguos'])) ?>"<?= $orden === 'antiguos' ? ' aria-current="true"' : '' ?>>Más antiguos</a>
      </nav>
    <?php endif; ?>
  </div>
  <p class="comentarios__norma"><?= icono('escudo') ?><span>No ocultamos opiniones por su postura. Solo se eliminan spam, amenazas o datos personales. Sin «me gusta»: el orden es por fecha.</span></p>

  <?php if ($usuario): ?>
    <form class="comentar" id="comentar" method="post" action="<?= e(url('comentar.php')) ?>">
      <?= csrf_campo() ?><input type="hidden" name="publicacion" value="<?= (int) $p['id'] ?>">
      <?= avatar_html($usuario, 'avatar-creador') ?>
      <div class="comentar__campo">
        <label class="sr" for="comentario-texto">Escribe un comentario</label>
        <textarea id="comentario-texto" name="texto" rows="3" maxlength="<?= COMENTARIO_MAX ?>" required placeholder="Escribe un comentario…"
          aria-describedby="comentario-ayuda<?= $errorCom ? ' comentario-error' : '' ?>"<?= $errorCom ? ' aria-invalid="true"' : '' ?> data-contador><?= e($borrador) ?></textarea>
        <?php if ($errorCom): ?><p class="campo__error" id="comentario-error"><?= icono('alerta') ?><span><?= e($errorCom) ?></span></p><?php endif; ?>
        <div class="comentar__pie">
          <p class="campo__ayuda" id="comentario-ayuda">Se publicará con tu nombre, <?= e($usuario['nombre']) ?>. Hasta <?= COMENTARIO_MAX ?> caracteres.</p>
          <button class="boton boton--primario" type="submit">Comentar</button>
        </div>
      </div>
    </form>
  <?php else: ?>
    <div class="comentar comentar--cta" id="comentar">
      <p>Leer los comentarios es libre. Para comentar, inicia sesión.</p>
      <a class="boton boton--suave" href="<?= e(url_acceso('comentar', 'comentar')) ?>" data-acceso><?= icono('candado') ?>Iniciar sesión para comentar</a>
    </div>
  <?php endif; ?>

  <?php if ($com['items']): ?>
    <ol class="comentarios__lista">
      <?php foreach ($com['items'] as $c): $cid = (int) $c['id']; $propio = $usuario && (int) $usuario['id'] === (int) $c['usuario_id']; ?>
        <li class="comentario" id="comentario-<?= $cid ?>">
          <?= avatar_html($c, 'avatar-creador') ?>
          <article class="comentario__cuerpo" aria-labelledby="comentario-<?= $cid ?>-autor">
            <p class="comentario__meta">
              <strong id="comentario-<?= $cid ?>-autor"><?= e($c['nombre']) ?></strong>
              <?php if ($c['rol'] === 'admin'): ?><span class="rol-chip rol-chip--chico"><?= icono('escudo') ?>Admin</span><?php endif; ?>
              <?php if ($propio): ?><span class="comentario__tu">(tú)</span><?php endif; ?>
              <time datetime="<?= e(fecha_iso($c['creado_en'])) ?>" title="<?= e(fecha_larga($c['creado_en'], true)) ?>"><?= e(fecha_relativa($c['creado_en'])) ?></time>
            </p>
            <div class="comentario__texto" id="comentario-<?= $cid ?>-texto"><?= parrafos($c['texto']) ?></div>
            <div class="comentario__acciones">
              <button class="boton-texto" type="button" data-leer="#comentario-<?= $cid ?>-texto" data-leer-titulo="Comentario de <?= e($c['nombre']) ?>" hidden><?= icono('altavoz') ?>Escuchar<span class="sr"> el comentario de <?= e($c['nombre']) ?></span></button>
              <?php if ($propio || ($usuario && $usuario['rol'] === 'admin')): ?>
                <form method="post" action="<?= e(url('comentar.php')) ?>" data-confirmar="<?= $propio ? '¿Eliminar tu comentario?' : '¿Eliminar el comentario de ' . e($c['nombre']) . '? Hazlo solo si es spam, una amenaza o expone datos personales.' ?>">
                  <?= csrf_campo() ?><input type="hidden" name="accion" value="eliminar"><input type="hidden" name="id" value="<?= $cid ?>">
                  <button class="boton-texto boton-texto--peligro" type="submit"><?= icono('eliminar') ?>Eliminar<span class="sr"> el comentario de <?= e($c['nombre']) ?></span></button>
                </form>
              <?php endif; ?>
            </div>
          </article>
        </li>
      <?php endforeach; ?>
    </ol>
    <?php if ($com['paginas'] > 1): ?>
      <nav class="comentarios__paginas" aria-label="Páginas de comentarios">
        <?php if ($com['pagina'] > 1): ?><a class="boton boton--suave boton--chico" href="<?= e($enlaceCom(['co' => $orden === 'antiguos' ? 'antiguos' : '', 'cp' => $com['pagina'] - 1])) ?>"><?= icono('izq') ?>Anteriores</a><?php endif; ?>
        <span>Página <?= $com['pagina'] ?> de <?= $com['paginas'] ?></span>
        <?php if ($com['pagina'] < $com['paginas']): ?><a class="boton boton--suave boton--chico" href="<?= e($enlaceCom(['co' => $orden === 'antiguos' ? 'antiguos' : '', 'cp' => $com['pagina'] + 1])) ?>">Siguientes<?= icono('der') ?></a><?php endif; ?>
      </nav>
    <?php endif; ?>
  <?php else: ?>
    <p class="comentarios__vacio">Todavía no hay comentarios. <?= $usuario ? 'Puedes ser la primera persona en comentar.' : '' ?></p>
  <?php endif; ?>
</section>
