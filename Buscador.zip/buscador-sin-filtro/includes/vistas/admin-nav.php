<?php
/** Encabezado y pestañas del panel. Variables: $activa, $titulo, $accion (html opcional) */
$tabs = [
    'resumen'       => ['Resumen', 'admin/', 'panel'],
    'publicaciones' => ['Publicaciones', 'admin/publicaciones.php', 'video'],
    'publicar'      => ['Subir', 'admin/publicar.php', 'subir'],
    'categorias'    => ['Categorías', 'admin/categorias.php', 'carpeta'],
    'comentarios'   => ['Comentarios', 'admin/comentarios.php', 'comentario'],
    'usuarios'      => ['Usuarios', 'admin/usuarios.php', 'usuarios'],
];
$u = usuario_actual();
?>
<div class="admin">
  <header class="admin__cabeza">
    <div class="contenedor">
      <p class="admin__rol"><?= icono('escudo') ?>Administración<span class="admin__quien">Conectado como <?= e($u['nombre_admin'] ?: $u['nombre']) ?></span></p>
      <div class="admin__titulo-fila">
        <h1 class="admin__titulo"><?= e($titulo) ?></h1>
        <?php if (!empty($accion)): ?><div class="admin__accion"><?= $accion ?></div><?php endif; ?>
      </div>
      <nav class="admin__tabs" aria-label="Secciones del panel">
        <ul>
          <?php foreach ($tabs as $k => [$t, $ruta, $ico]): ?>
            <li><a href="<?= e(url($ruta)) ?>"<?= $activa === $k ? ' aria-current="page"' : '' ?>><?= icono($ico) ?><?= e($t) ?></a></li>
          <?php endforeach; ?>
        </ul>
      </nav>
    </div>
  </header>
  <div class="admin__cuerpo contenedor">
