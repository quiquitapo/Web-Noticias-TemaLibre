<?php
/**
 * Acción protegida para visitantes sin sesión: abre el diálogo de acceso (o la página de acceso sin JavaScript).
 * Variables: $texto, $motivo (texto para el diálogo), $clave (clave de MOTIVOS_ACCESO para la URL), $clase, $ancla
 */
?>
<a class="boton boton--bloqueado <?= e($clase ?? '') ?>" href="<?= e(url_acceso($clave ?? '', $ancla ?? '')) ?>" data-acceso data-motivo="<?= e($motivo) ?>">
  <span class="candado"><?= icono('candado') ?></span>
  <span><?= e($texto) ?></span>
</a>
