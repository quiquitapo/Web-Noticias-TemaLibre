<ul class="desbloquea">
  <li><?= icono('play') ?><span><strong>Videos completos</strong> con subtítulos.</span></li>
  <li><?= icono('noticia') ?><span><strong>Fuente original</strong> de cada noticia.</span></li>
  <li><?= icono('etiqueta') ?><span><strong>Enlaces de venta</strong> de cada producto.</span></li>
  <li><?= icono('redes') ?><span><strong>Redes sociales</strong> de cada creador.</span></li>
</ul>
