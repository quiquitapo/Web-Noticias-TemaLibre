<?php
/** Paginación accesible. Variables: $pagina, $paginas, $ruta, $params */
if ($paginas <= 1) {
    return;
}
$params = $params ?? [];
?>
<nav class="paginacion" aria-label="Paginación">
  <?php if ($pagina > 1): ?>
    <a class="boton boton--suave" href="<?= e(url($ruta, ['pagina' => $pagina - 1 > 1 ? $pagina - 1 : null] + $params)) ?>" rel="prev"><?= icono('izq') ?>Anterior</a>
  <?php endif; ?>
  <ol class="paginacion__lista">
    <?php for ($i = 1; $i <= $paginas; $i++): ?>
      <li><a class="paginacion__num" href="<?= e(url($ruta, ['pagina' => $i > 1 ? $i : null] + $params)) ?>"<?= $i === $pagina ? ' aria-current="page"' : '' ?>><span class="sr">Página </span><?= $i ?></a></li>
    <?php endfor; ?>
  </ol>
  <?php if ($pagina < $paginas): ?>
    <a class="boton boton--suave" href="<?= e(url($ruta, ['pagina' => $pagina + 1] + $params)) ?>" rel="next">Siguiente<?= icono('der') ?></a>
  <?php endif; ?>
</nav>
