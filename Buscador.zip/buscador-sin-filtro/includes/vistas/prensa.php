<?php
/**
 * Vista «Noticias en la prensa»: artículos de medios reales sobre el tema de la publicación.
 * Sin sesión se ven el medio y el titular; el enlace (y el dominio) solo con sesión, igual que el resto del sitio.
 * Variables: $prensa (filas de prensa_de), $p (publicación), $oculta (bool)
 */
$conSesion = sesion_iniciada();
?>
<section class="prensa" id="prensa" aria-labelledby="prensa-titulo" tabindex="-1" data-vista-panel="noticias"<?= !empty($oculta) ? ' hidden' : '' ?>>
  <div class="prensa__cabeza">
    <h2 class="prensa__titulo" id="prensa-titulo"><?= icono('periodico') ?>Noticias en la prensa</h2>
    <p class="prensa__bajada">Artículos de medios reales sobre este mismo tema, para leerlo en otro formato y contrastar. Se abren en el sitio de cada medio<?= $conSesion ? '' : ', con tu sesión iniciada' ?>.</p>
  </div>
  <ol class="prensa__lista">
    <?php foreach ($prensa as $a): $dom = dominio((string) $a['url']); ?>
      <li class="prensa__item">
        <?php if ($conSesion): ?>
          <a class="prensa__enlace" href="<?= e(url('ir.php', ['t' => 'prensa', 'id' => (int) $a['id']])) ?>" target="_blank" rel="noopener nofollow" data-desbloqueado>
        <?php else: ?>
          <div class="prensa__enlace prensa__enlace--bloqueado">
        <?php endif; ?>
            <span class="prensa__medio">
              <span class="prensa__inicial" style="--av: <?= e(color_avatar($a['medio'])) ?>" aria-hidden="true"><?= e(mb_strtoupper(mb_substr($a['medio'], 0, 1))) ?></span>
              <span class="prensa__medio-txt"><?= e($a['medio']) ?><?php if ($conSesion): ?><span class="prensa__dominio"><?= e($dom) ?></span><?php endif; ?></span>
            </span>
            <span class="prensa__titular"><?= e($a['titulo']) ?></span>
            <?php if ($a['fecha'] || $a['idioma'] !== 'es'): ?>
              <span class="prensa__meta">
                <?php if ($a['fecha']): ?><time datetime="<?= e($a['fecha']) ?>"><?= e(fecha_larga($a['fecha'])) ?></time><?php endif; ?>
                <?php if ($a['idioma'] !== 'es'): ?><span class="prensa__idioma"><?= e(['en' => 'En inglés', 'pt' => 'En portugués', 'fr' => 'En francés'][$a['idioma']] ?? 'En otro idioma') ?></span><?php endif; ?>
              </span>
            <?php endif; ?>
            <?php if ($conSesion): ?>
              <span class="prensa__ir" aria-hidden="true"><?= icono('externo') ?></span><span class="sr"> (se abre en una pestaña nueva en <?= e($dom) ?>)</span>
            <?php else: ?>
              <span class="prensa__ir prensa__ir--candado" aria-hidden="true"><?= icono('candado') ?></span>
            <?php endif; ?>
        <?php if ($conSesion): ?>
          </a>
        <?php else: ?>
          </div>
        <?php endif; ?>
      </li>
    <?php endforeach; ?>
  </ol>
  <?php if (!$conSesion): ?>
    <div class="prensa__acceso">
      <?php vista('bloqueo', ['texto' => 'Inicia sesión para abrir las noticias', 'motivo' => 'Inicia sesión para abrir los artículos de prensa sobre este tema.', 'clave' => 'prensa', 'clase' => 'boton--primario', 'ancla' => 'prensa']); ?>
      <p class="prensa__nota">Crear una cuenta es gratis. Sin sesión puedes ver qué medios hablaron del tema y sus titulares.</p>
    </div>
  <?php endif; ?>
  <p class="prensa__aviso"><?= icono('balanza') ?><span>Sin Filtro no controla esos sitios: la verificación y la orientación de esta publicación no aplican a los artículos enlazados.</span></p>
</section>
