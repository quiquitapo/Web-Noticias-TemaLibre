<?php
/**
 * Cabecera común.
 * Variables: $titulo, $descripcion, $seccion, $nav_activo, $variante ('hero'|'normal'), $og_imagen, $og_tipo, $json_ld, $sin_indexar
 */
$usuario = usuario_actual();
$seccion = $seccion ?? '';
$variante = $variante ?? 'normal';
$nombreApp = config('app.nombre');
$tituloCompleto = isset($titulo) && $titulo ? $titulo . ' | ' . $nombreApp : $nombreApp . ': ' . config('app.descripcion');
$descripcion = $descripcion ?? config('app.descripcion');
$ogImagen = $og_imagen ?? url_absoluta(imagen('publicaciones/datos-abiertos-seguir-gasto-publico', 1600));
$navActivo = $nav_activo ?? ($seccion === 'videos' ? 'videos' : '');
$nav = ['videos' => ['Videos', url('videos.php'), 1]];
foreach (SECCIONES_NAV as $slug => [$texto, $prioridad]) {
    $nav[$slug] = [$texto, url('videos.php', ['cat' => $slug]), $prioridad];
}
?><!doctype html>
<html lang="es-CL" class="no-js"<?= atributos_preferencias() ?>>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <title><?= e($tituloCompleto) ?></title>
  <meta name="description" content="<?= e($descripcion) ?>">
  <meta name="color-scheme" content="light dark">
  <meta name="theme-color" content="<?= $variante === 'hero' ? '#2340F5' : '#ffffff' ?>" media="(prefers-color-scheme: light)">
  <meta name="theme-color" content="#0b0d18" media="(prefers-color-scheme: dark)">
  <?php if (!empty($sin_indexar)): ?><meta name="robots" content="noindex"><?php endif; ?>
  <link rel="icon" href="<?= e(asset('img/favicon.svg')) ?>" type="image/svg+xml">
  <link rel="preload" href="<?= e(asset('fonts/archivo-var.woff2')) ?>" as="font" type="font/woff2" crossorigin>
  <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
  <?php if (preferencias()['estilo'] !== 'actual'): ?><link rel="stylesheet" href="<?= e(asset('css/estilos.css')) ?>" data-estilos><?php endif; ?>
  <?php if (!empty($esperar)): ?><link rel="expect" href="#<?= e($esperar) ?>" blocking="render"><?php endif; ?>
  <meta name="sf-estilos" content="<?= e(asset('css/estilos.css')) ?>">
  <meta property="og:site_name" content="<?= e($nombreApp) ?>">
  <meta property="og:title" content="<?= e($titulo ?? $nombreApp) ?>">
  <meta property="og:description" content="<?= e($descripcion) ?>">
  <meta property="og:type" content="<?= e($og_tipo ?? 'website') ?>">
  <meta property="og:image" content="<?= e($ogImagen) ?>">
  <meta property="og:locale" content="es_CL">
  <meta name="twitter:card" content="summary_large_image">
  <script nonce="<?= e(csp_nonce()) ?>">
    (function () {
      var d = document.documentElement, t = null;
      d.classList.replace('no-js', 'js');
      // Animación del logo: una vez por sesión, nunca con «reducir movimiento» (del sistema o de las preferencias)
      try {
        if (!sessionStorage.getItem('sf-intro') && !matchMedia('(prefers-reduced-motion: reduce)').matches && d.dataset.movimiento !== 'reducido') {
          d.classList.add('intro-activa');
          sessionStorage.setItem('sf-intro', '1');
        }
      } catch (e) {}
      // Transición desde una tarjeta: el reproductor recibe el mismo nombre que la miniatura (ver transicionMedio en app.js)
      if ('onpagereveal' in window) addEventListener('pagereveal', function (e) {
        if (!e.viewTransition) return;
        var m = document.querySelector('.ver__media:not([hidden])');
        if (!m) return;
        m.style.viewTransitionName = 'medio';
        e.viewTransition.finished.finally(function () { m.style.viewTransitionName = ''; });
      });
      // Tema elegido en versiones anteriores (antes de la cookie de preferencias)
      if (!d.dataset.theme && document.cookie.indexOf('sf_pref=') < 0) {
        try { t = localStorage.getItem('sf-tema'); } catch (e) {}
        if (t === 'oscuro' || t === 'claro') d.dataset.theme = t === 'oscuro' ? 'dark' : 'light';
      }
    })();
  </script>
  <script type="module" src="<?= e(asset('js/app.js')) ?>"></script>
  <?php if ($seccion === 'admin'): ?><script type="module" src="<?= e(asset('js/admin.js')) ?>"></script><?php endif; ?>
  <?php if (!empty($json_ld)): ?>
  <script type="application/ld+json" nonce="<?= e(csp_nonce()) ?>"><?= json_encode($json_ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) ?></script>
  <?php endif; ?>
</head>
<body class="pagina-<?= e($seccion ?: 'general') ?><?= $usuario ? ' con-sesion' : '' ?><?= $usuario && $usuario['rol'] === 'admin' ? ' es-admin' : '' ?>"
      data-base="<?= e(url_base()) ?>" data-sesion="<?= $usuario ? '1' : '0' ?>"<?= $usuario && recien_desbloqueado() ? ' data-desbloqueo' : '' ?>>
<a class="saltar" href="#contenido">Saltar al contenido</a>
<div class="intro" aria-hidden="true" data-intro>
  <div class="intro__fondo"><div class="intro__burbujas"><i></i><i></i><i></i><i></i><i></i><i></i></div></div>
  <div class="intro__marca" data-intro-marca>
    <svg class="intro__logo" viewBox="0 0 32 32" focusable="false"><circle class="intro__aro" cx="13" cy="13" r="8.6" pathLength="100"/><circle class="intro__punto" cx="22.2" cy="22.2" r="6.2"/></svg>
    <span class="intro__nombre"><?php foreach (preg_split('//u', 'sin filtro', -1, PREG_SPLIT_NO_EMPTY) as $i => $letra): ?><span style="--i: <?= $i ?>"><?= $letra === ' ' ? '&nbsp;' : e($letra) ?></span><?php endforeach; ?></span>
  </div>
  <p class="intro__lema"><?= e(config('app.lema')) ?></p>
</div>
<?php require INC_DIR . '/vistas/iconos.php'; ?>

<header class="cabecera" data-variante="<?= e($variante) ?>">
  <div class="cabecera__in contenedor">
    <a class="marca" href="<?= e(url()) ?>"<?= $seccion === 'inicio' ? ' aria-current="page"' : '' ?>>
      <svg class="marca__logo" aria-hidden="true" focusable="false"><use href="#i-logo"/></svg>
      <span class="marca__nombre">sin filtro</span>
      <span class="sr">, ir al inicio</span>
    </a>

    <nav class="nav-principal" aria-label="Secciones">
      <ul>
        <?php foreach ($nav as $clave => [$texto, $href, $prioridad]): ?>
          <li data-prioridad="<?= (int) $prioridad ?>"><a href="<?= e($href) ?>"<?= $navActivo === $clave ? ' aria-current="page"' : '' ?>><?= e($texto) ?></a></li>
        <?php endforeach; ?>
      </ul>
    </nav>

    <div class="cabecera__acciones">
      <a class="boton-buscar" href="<?= e(url('buscar.php')) ?>" data-abrir-buscador aria-haspopup="dialog" aria-keyshortcuts="/ Control+K">
        <?= icono('buscar') ?><span class="boton-buscar__txt">Buscar</span><kbd aria-hidden="true">/</kbd>
      </a>
      <a class="icono-btn pref-btn" href="<?= e(url('preferencias.php', ['volver' => url_actual()])) ?>" data-abrir-preferencias aria-haspopup="dialog" title="Preferencias de lectura: colores, tamaño de texto y voz">
        <?= icono('texto') ?><span class="sr">Preferencias de lectura</span>
      </a>
      <button class="icono-btn tema-btn" type="button" data-tema aria-pressed="false" title="Cambiar entre tema claro y oscuro">
        <?= icono('sol', 'tema-btn__sol') ?><?= icono('luna', 'tema-btn__luna') ?>
        <span class="sr">Tema oscuro</span>
      </button>
      <?php if ($usuario && $usuario['rol'] === 'admin'): ?>
        <a class="boton boton--panel" href="<?= e(url('admin/')) ?>"<?= $seccion === 'admin' ? ' aria-current="page"' : '' ?>><?= icono('panel') ?><span class="boton--panel__txt">Panel</span></a>
      <?php endif; ?>
      <?php if ($usuario): ?>
        <a class="avatar" href="<?= e(url('cuenta.php')) ?>"<?= $seccion === 'cuenta' ? ' aria-current="page"' : '' ?>>
          <?= avatar_html($usuario, 'avatar__img') ?><span class="sr">Tu cuenta (<?= e($usuario['nombre']) ?>)</span>
        </a>
      <?php else: ?>
        <a class="boton boton--cabecera" href="<?= e(url_acceso()) ?>" data-acceso>Iniciar sesión</a>
      <?php endif; ?>
    </div>
  </div>
</header>

<main id="contenido" tabindex="-1">
