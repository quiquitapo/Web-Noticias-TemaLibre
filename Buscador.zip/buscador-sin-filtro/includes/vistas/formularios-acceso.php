<?php
/**
 * Pestañas "Iniciar sesión" / "Crear cuenta". Se usa en el diálogo y en las páginas entrar.php y registro.php.
 * Variables: $prefijo (ids únicos), $volver, $demo (array|null), $activa ('entrar'|'registro'),
 *            $errores (array campo => mensaje), $error_general, $valores (array)
 */
$activa = $activa ?? 'entrar';
$errores = $errores ?? [];
$valores = $valores ?? [];
$error_general = $error_general ?? '';
$p = $prefijo;
$campoError = static function (string $id, string $campo) use ($errores): string {
    $msg = $errores[$campo] ?? '';
    return '<p class="campo__error" id="' . e($id) . '-error" data-error-de="' . e($campo) . '"' . ($msg ? '' : ' hidden') . '>'
        . icono('alerta') . '<span>' . e($msg) . '</span></p>';
};
$invalid = static fn(string $campo) => isset($errores[$campo]) ? ' aria-invalid="true"' : '';
?>
<div class="pestanas" data-pestanas>
  <div class="pestanas__lista" role="tablist" aria-label="Acceso">
    <button class="pestanas__tab" role="tab" type="button" id="<?= e($p) ?>-tab-entrar" aria-controls="<?= e($p) ?>-panel-entrar"
            aria-selected="<?= $activa === 'entrar' ? 'true' : 'false' ?>"<?= $activa === 'entrar' ? '' : ' tabindex="-1"' ?> data-tab="entrar">Iniciar sesión</button>
    <button class="pestanas__tab" role="tab" type="button" id="<?= e($p) ?>-tab-registro" aria-controls="<?= e($p) ?>-panel-registro"
            aria-selected="<?= $activa === 'registro' ? 'true' : 'false' ?>"<?= $activa === 'registro' ? '' : ' tabindex="-1"' ?> data-tab="registro">Crear cuenta</button>
    <span class="pestanas__indicador" aria-hidden="true"></span>
  </div>

  <div class="pestanas__panel" role="tabpanel" id="<?= e($p) ?>-panel-entrar" aria-labelledby="<?= e($p) ?>-tab-entrar"<?= $activa === 'entrar' ? '' : ' hidden' ?>>
    <form class="form" method="post" action="<?= e(url('entrar.php')) ?>" data-form-acceso novalidate>
      <?= csrf_campo() ?>
      <input type="hidden" name="volver" value="<?= e($volver) ?>" data-volver>
      <p class="form__error" role="alert" data-error-general<?= $activa === 'entrar' && $error_general ? '' : ' hidden' ?>><?= icono('alerta') ?><span><?= $activa === 'entrar' ? e($error_general) : '' ?></span></p>
      <div class="campo">
        <label for="<?= e($p) ?>-e-email">Correo</label>
        <input id="<?= e($p) ?>-e-email" name="email" type="email" inputmode="email" autocomplete="email" required
               value="<?= e($activa === 'entrar' ? ($valores['email'] ?? '') : '') ?>" aria-describedby="<?= e($p) ?>-e-email-error"<?= $activa === 'entrar' ? $invalid('email') : '' ?>>
        <?= $campoError($p . '-e-email', 'email') ?>
      </div>
      <div class="campo">
        <label for="<?= e($p) ?>-e-clave">Contraseña</label>
        <div class="campo__clave">
          <input id="<?= e($p) ?>-e-clave" name="clave" type="password" autocomplete="current-password" required
                 aria-describedby="<?= e($p) ?>-e-clave-error"<?= $activa === 'entrar' ? $invalid('clave') : '' ?>>
          <button class="icono-btn" type="button" data-ver-clave aria-pressed="false"><?= icono('ojo', 'ver') ?><?= icono('ojo-off', 'ocultar') ?><span class="sr">Mostrar contraseña</span></button>
        </div>
        <?= $campoError($p . '-e-clave', 'clave') ?>
      </div>
      <button class="boton boton--primario boton--ancho" type="submit" data-enviar>
        <span class="boton__txt">Iniciar sesión</span><span class="boton__cargando" aria-hidden="true"></span>
      </button>
      <?php if ($demo): ?>
        <p class="form__demo">¿Solo quieres probar? <button class="enlace" type="button" data-usar-demo data-email="<?= e($demo['email']) ?>" data-clave="<?= e($demo['clave']) ?>">Usa la cuenta de prueba</button></p>
      <?php endif; ?>
    </form>
  </div>

  <div class="pestanas__panel" role="tabpanel" id="<?= e($p) ?>-panel-registro" aria-labelledby="<?= e($p) ?>-tab-registro"<?= $activa === 'registro' ? '' : ' hidden' ?>>
    <form class="form" method="post" action="<?= e(url('registro.php')) ?>" data-form-acceso novalidate>
      <?= csrf_campo() ?>
      <input type="hidden" name="volver" value="<?= e($volver) ?>" data-volver>
      <p class="form__error" role="alert" data-error-general<?= $activa === 'registro' && $error_general ? '' : ' hidden' ?>><?= icono('alerta') ?><span><?= $activa === 'registro' ? e($error_general) : '' ?></span></p>
      <div class="campo">
        <label for="<?= e($p) ?>-r-nombre">Nombre</label>
        <input id="<?= e($p) ?>-r-nombre" name="nombre" type="text" autocomplete="name" required maxlength="60"
               value="<?= e($activa === 'registro' ? ($valores['nombre'] ?? '') : '') ?>" aria-describedby="<?= e($p) ?>-r-nombre-error"<?= $activa === 'registro' ? $invalid('nombre') : '' ?>>
        <?= $campoError($p . '-r-nombre', 'nombre') ?>
      </div>
      <div class="campo">
        <label for="<?= e($p) ?>-r-email">Correo</label>
        <input id="<?= e($p) ?>-r-email" name="email" type="email" inputmode="email" autocomplete="email" required
               value="<?= e($activa === 'registro' ? ($valores['email'] ?? '') : '') ?>" aria-describedby="<?= e($p) ?>-r-email-error"<?= $activa === 'registro' ? $invalid('email') : '' ?>>
        <?= $campoError($p . '-r-email', 'email') ?>
      </div>
      <div class="campo">
        <label for="<?= e($p) ?>-r-clave">Contraseña</label>
        <div class="campo__clave">
          <input id="<?= e($p) ?>-r-clave" name="clave" type="password" autocomplete="new-password" required minlength="<?= (int) config('seguridad.clave_min', 8) ?>"
                 aria-describedby="<?= e($p) ?>-r-clave-ayuda <?= e($p) ?>-r-clave-error"<?= $activa === 'registro' ? $invalid('clave') : '' ?> data-medidor>
          <button class="icono-btn" type="button" data-ver-clave aria-pressed="false"><?= icono('ojo', 'ver') ?><?= icono('ojo-off', 'ocultar') ?><span class="sr">Mostrar contraseña</span></button>
        </div>
        <div class="medidor" aria-hidden="true"><span></span><span></span><span></span></div>
        <p class="campo__ayuda" id="<?= e($p) ?>-r-clave-ayuda">Mínimo <?= (int) config('seguridad.clave_min', 8) ?> caracteres.</p>
        <?= $campoError($p . '-r-clave', 'clave') ?>
      </div>
      <button class="boton boton--primario boton--ancho" type="submit" data-enviar>
        <span class="boton__txt">Crear cuenta gratis</span><span class="boton__cargando" aria-hidden="true"></span>
      </button>
      <p class="form__nota">Solo usamos tu correo para que puedas entrar.</p>
    </form>
  </div>
</div>
