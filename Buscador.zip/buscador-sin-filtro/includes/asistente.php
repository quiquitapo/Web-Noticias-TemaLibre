<?php
/**
 * Asistente de preguntas rápidas.
 * Responde con los datos del sitio según dónde está la persona (una publicación, una sección o la portada).
 * Funciona sin servicios externos ni inteligencia artificial de terceros: reconoce la intención con reglas
 * y responde con datos de la base. No guarda las preguntas. Respeta las mismas reglas de acceso del sitio:
 * los enlaces protegidos (fuente, venta, redes, YouTube) solo se entregan con sesión iniciada.
 */
declare(strict_types=1);

const ASISTENTE_MAX = 300;

/** Intenciones reconocidas (texto normalizado: minúsculas y sin tildes). El orden define el orden de las respuestas. */
const ASISTENTE_INTENCIONES = [
    'saludo'       => '/^(hola|buenas|buenos dias|buenas tardes|buenas noches|hey|saludos|que tal)\b/',
    'gracias'      => '/\b(gracias|muchas gracias|te pasaste|genial gracias)\b/',
    'ayuda'        => '/\b(ayuda|que puedes hacer|que sabes hacer|como funcionas|que te puedo preguntar|que puedo preguntar|opciones)\b/',
    'resumen'      => '/\b(resumen|resumeme|resume|de que (trata|se trata|va|habla)|sobre que (es|trata)|que es esto|descripcion|explicame)\b/',
    'fuente'       => '/\b(fuentes?|origen|urls?|enlaces?|links?|direccion web|de donde (sale|viene|es|lo sacaron|lo sacan)|original|sitio web|pagina web)\b/',
    'prensa'       => '/\b(prensa|articulos?|periodicos?|diarios?|medios de comunicacion|que dicen los medios|noticias (reales|de prensa|sobre (esto|este tema|el tema))|otras noticias|links? de noticias|enlaces? de noticias|leer (sobre|mas sobre) (esto|el tema)|en (formato de )?texto|leerlo en vez de verlo)\b/',
    'youtube'      => '/\b(youtube|ver (el )?video|como (lo )?veo|reproduc\w*|mirar (el )?video|donde lo veo|no (se )?(ve|reproduce|carga)|play)\b/',
    'fecha'        => '/\b(fechas?|cuando|que dia|hace cuanto|antiguedad|de que ano|dia de publicacion)\b/',
    'subido'       => '/\b(quien (lo |la )?(subio|publico|agrego|puso)|subid[oa] por|publicad[oa] por|que admin\w*|cual admin\w*)\b/',
    'creador'      => '/\b(creador\w*|autor\w*|canal|quien (lo |la )?(hizo|creo|grabo|escribio|habla|produjo)|periodista|de quien es)\b/',
    'categoria'    => '/\b(categorias?|subcategorias?|en que seccion|que seccion es)\b/',
    'orientacion'  => '/\b(orientacion\w*|posturas?|izquierda|derecha|sesgos?|ideologia|politic\w*|tendencia|de que lado)\b/',
    'verificacion' => '/\b(verificad\w*|verificacion|falso|falsa|fake|enganos\w*|confiable|es real|es verdad|es cierto|chequeo)\b/',
    'miradas'      => '/\b(otras miradas|otra mirada|otras posturas|otra postura|contraparte|la otra version|opinan distinto|punto de vista contrario)\b/',
    'relacionados' => '/\b(relacionad\w*|parecid\w*|similar\w*|mas como (esto|este|esta)|que mas (me )?recomiendas|recomienda\w*)\b/',
    'vistas'       => '/\b(vistas?|visitas?|reproducciones|cuantas personas|cuanta gente|que tan popular)\b/',
    'duracion'     => '/\b(duracion|cuanto dura|cuantos minutos|es largo)\b/',
    'precio'       => '/\b(precio|cuanto cuesta|cuanto vale|comprar|tienda|descuento|donde (lo )?compro)\b/',
    'redes'        => '/\b(redes|instagram|tiktok|facebook|twitter|linkedin|whatsapp|perfiles)\b/',
    'comentarios'  => '/\b(comentari\w*|opiniones|comentar)\b/',
    'etiquetas'    => '/\b(etiquetas?|hashtags?|tags?|palabras clave|temas que toca)\b/',
    'escuchar'     => '/\b(escuchar|voz alta|leer en voz|en audio|leemelo|lee la noticia)\b/',
    'compartir'    => '/\b(compartir|comparto|copiar (el )?(enlace|link)|mandar(lo|selo)?|enviar(lo|selo)?)\b/',
    'preferencias' => '/\b(tamano (de )?(la )?(letra|fuente|texto)|letras? (mas )?(grandes?|chicas?|pequenas?)|texto (mas )?(grande|chico)|agrandar|achicar|colores?|modo oscuro|tema (oscuro|claro)|contraste|accesibilidad|preferencias|tipografia)\b/',
    'avatar'       => '/\b(avatar|foto de perfil|mi foto|cambiar (mi )?(foto|imagen|cara)|personaje|crear (mi|un) avatar)\b/',
    'robot'        => '/\b(quien eres|que eres|eres un robot|como te llamas|moverte|te muevo|muevo|mover(te| el robot| al robot)|arrastrar\w*|te puedo mover)\b/',
    'estilo'       => '/\b(estilos?|frutiger|aero|neon|retro|brutal\w*|periodico|apariencia|aspecto de la (web|pagina)|diseno)\b/',
    'privacidad'   => '/\b(privacidad|mis datos|datos personales|datos (guardan|guarda|recogen|recopilan|tienen|piden|saben)|que (guardan|saben) de mi|cookies?|rastre\w*|seguimiento|me (espian|siguen)|anonim\w*)\b/',
    'algoritmo'    => '/\b(algoritmo|como ordenan|el orden|vista equilibrada|equilibrad\w*|burbuja)\b/',
    'cuenta'       => '/\b(crear (una )?cuenta|registr\w*|iniciar sesion|inicio sesion|login|contrasena|clave|mi cuenta)\b/',
    'seccion'      => '/\b(que hay (aca|aqui|en esta seccion)|que es esta seccion|de que trata esta seccion|que subcategorias|esta seccion)\b/',
    'masvisto'     => '/\b(mas vist\w*|mas popular\w*|top|lo mejor)\b/',
    'reciente'     => '/\b(mas recientes?|lo ultimo|ultimas|ultimos|novedades|que hay de nuevo|lo nuevo)\b/',
];

/** Intenciones que necesitan una publicación concreta. */
const ASISTENTE_DE_PUBLICACION = ['resumen', 'fuente', 'prensa', 'youtube', 'fecha', 'subido', 'creador', 'categoria', 'orientacion', 'verificacion',
    'miradas', 'relacionados', 'vistas', 'duracion', 'precio', 'redes', 'etiquetas', 'compartir'];

/** Valida el contexto que envía la página. Nunca se confía en él para permisos: solo indica dónde está la persona. */
function asistente_contexto(array $c): array
{
    $tipo = (string) ($c['tipo'] ?? '');
    $ref = mb_substr((string) ($c['ref'] ?? ''), 0, 160);
    if ($tipo === 'publicacion' && preg_match('/^[a-z0-9-]+$/', $ref) && ($p = publicacion_por_slug($ref))) {
        return ['tipo' => 'publicacion', 'p' => $p];
    }
    if ($tipo === 'seccion') {
        $cat = preg_match('/^[a-z0-9-]+$/', $ref) ? categoria_por_slug($ref) : null;
        return ['tipo' => 'seccion', 'cat' => $cat, 'q' => mb_substr(trim((string) ($c['q'] ?? '')), 0, 120)];
    }
    if ($tipo === 'inicio') {
        return ['tipo' => 'inicio'];
    }
    return ['tipo' => 'pagina', 'nombre' => preg_match('/^[a-z-]{1,30}$/', $ref) ? $ref : ''];
}

function asistente_intenciones(string $n): array
{
    $hay = [];
    foreach (ASISTENTE_INTENCIONES as $k => $re) {
        if (preg_match($re, $n)) {
            $hay[] = $k;
        }
    }
    $tiene = static fn(string $k) => in_array($k, $hay, true);
    $quitar = static function (string ...$k) use (&$hay): void { $hay = array_diff($hay, $k); };
    // Desambiguación: «tamaño de la fuente» es tipografía; «copiar el enlace» es compartir, no la fuente
    if ($tiene('preferencias') && preg_match('/\b(letras?|tamano|tipografia)\b/', $n)) {
        $quitar('fuente');
    }
    if ($tiene('compartir') && !preg_match('/\b(fuentes?|origen|original)\b/', $n)) {
        $quitar('fuente');
    }
    // «links de noticias» pide la prensa, no la fuente original
    if ($tiene('prensa') && $tiene('fuente') && !preg_match('/\b(fuentes?|origen|original|url)\b/', $n)) {
        $quitar('fuente');
    }
    // «link de YouTube» pide la dirección; «cómo veo el video» pide reproducirlo
    if ($tiene('youtube') && $tiene('fuente')) {
        preg_match('/\b(urls?|links?|enlaces?|direccion|fuentes?|origen|original)\b/', $n) && !preg_match('/\b(ver|veo|reproduc\w*|mirar|carga)\b/', $n) ? $quitar('youtube') : $quitar('fuente');
    }
    // «¿de qué canal de YouTube es?» pregunta por el canal, no por cómo verlo
    if ($tiene('youtube') && $tiene('creador') && !preg_match('/\b(ver|veo|reproduc\w*|mirar|carga)\b/', $n)) {
        $quitar('youtube');
    }
    if (count($hay) > 1) {
        $hay = array_diff($hay, ['saludo', 'gracias']);
    }
    return array_values($hay);
}

/** Palabras que quedan al quitar las de la intención: sirven para buscar a qué publicación se refiere. */
function asistente_palabras_tema(string $n): string
{
    $sin = $n;
    foreach (ASISTENTE_INTENCIONES as $re) {
        $sin = (string) preg_replace($re, ' ', $sin);
    }
    $vacias = ['cual', 'cuales', 'es', 'son', 'la', 'el', 'los', 'las', 'de', 'del', 'un', 'una', 'que', 'me', 'mi', 'por', 'para', 'sobre', 'video', 'videos',
        'noticia', 'noticias', 'publicacion', 'esta', 'este', 'esto', 'eso', 'se', 'lo', 'le', 'y', 'o', 'en', 'con', 'quiero', 'saber', 'dime', 'puedes', 'decirme',
        'hay', 'tiene', 'tienen', 'a', 'al', 'como', 'donde', 'quien', 'cuanto', 'cuantos', 'favor', 'porfa', 'porfavor', 'ver', 'busca', 'buscar', 'encuentra',
        'tan', 'muy', 'bien', 'bueno', 'buena', 'esa', 'ese', 'aca', 'aqui', 'ahi', 'sus', 'su', 'mas', 'pero', 'porque', 'si', 'no', 'ya', 'era', 'fue', 'hoy',
        'pagina', 'sitio', 'seccion', 'dato', 'datos', 'info', 'informacion', 'necesito', 'podrias', 'sabes', 'conoces'];
    $palabras = array_filter(preg_split('/[^a-z0-9]+/', $sin) ?: [], static fn($w) => mb_strlen($w) > 2 && !in_array($w, $vacias, true));
    return implode(' ', array_slice(array_values($palabras), 0, 6));
}

/** Respuesta principal. */
function asistente_responder(string $pregunta, array $ctx, ?array $usuario): array
{
    $pregunta = trim(mb_substr((string) preg_replace('/\s+/u', ' ', $pregunta), 0, ASISTENTE_MAX));
    $n = trim((string) preg_replace('/[^a-z0-9ñ ]+/', ' ', normalizar($pregunta)));
    $r = ['mensajes' => [], 'sugerencias' => asistente_sugerencias($ctx)];
    if ($n === '') {
        $r['mensajes'][] = asistente_msj('Escribe una pregunta. Por ejemplo: «¿cuál es la fuente?» o «¿cuándo se publicó?».');
        return $r;
    }

    // Órdenes explícitas: buscar e ir a una sección
    if (preg_match('/^(busca|buscame|buscar|encuentra|encuentrame|quiero ver|muestrame|hay algo (de|sobre)|tienes algo (de|sobre)|videos? (de|sobre)|noticias? (de|sobre))\s+(.+)$/', $n, $m)
        && !preg_match('/^(la )?(prensa|medios)\b/', (string) end($m))) {
        return ['mensajes' => [asistente_buscar(end($m), $ctx)], 'sugerencias' => $r['sugerencias']];
    }
    if (preg_match('/^(ir a|ve a|llevame a|abre|abrir|vamos a|quiero ir a)\s+(.+)$/', $n, $m) && ($dest = asistente_destino($m[2]))) {
        return ['mensajes' => [$dest], 'sugerencias' => $r['sugerencias']];
    }

    $intenciones = asistente_intenciones($n);
    $p = $ctx['tipo'] === 'publicacion' ? $ctx['p'] : null;
    $prefijo = '';
    // ¿La pregunta nombra otra publicación? («¿cuál es la fuente del video de Kardashev?»)
    if (array_intersect($intenciones, ASISTENTE_DE_PUBLICACION) && ($tema = asistente_palabras_tema($n)) !== '') {
        $palabras = explode(' ', $tema);
        $textoActual = $p ? normalizar($p['titulo'] . ' ' . $p['etiquetas'] . ' ' . $p['creador'] . ' ' . $p['categoria_nombre']) : '';
        $nombraActual = $p && array_filter($palabras, static fn($w) => str_contains($textoActual, $w));
        if (!$nombraActual) {
            $cat = $ctx['tipo'] === 'seccion' && $ctx['cat'] ? $ctx['cat']['slug'] : '';
            $res = explorar(filtros_desde_url(['q' => $tema, 'cat' => $cat]), 1);
            if (!$res['items'] && $cat !== '') {
                $res = explorar(filtros_desde_url(['q' => $tema]), 1);
            }
            $otra = $res['items'][0] ?? null;
            // Estando en una publicación, solo se cambia de tema si el título de la otra contiene todas las palabras
            $titulo = $otra ? normalizar($otra['titulo']) : '';
            if ($otra && (!$p || ($otra['slug'] !== $p['slug'] && !array_filter($palabras, static fn($w) => !str_contains($titulo, $w))))
                && ($otraP = publicacion_por_slug($otra['slug']))) {
                $p = $otraP;
                $prefijo = 'Sobre «' . $p['titulo'] . '»: ';
            }
        }
    }

    $pidioPublicacion = false;
    foreach (array_slice($intenciones, 0, 3) as $i) {
        if (in_array($i, ASISTENTE_DE_PUBLICACION, true)) {
            if ($p) {
                $m = asistente_de_publicacion($i, $p, $usuario);
                if ($prefijo !== '' && $r['mensajes'] === []) {
                    $m['texto'] = $prefijo . $m['texto'];
                    $m['enlaces'][] = ['texto' => 'Abrir la publicación', 'url' => url_publicacion($p)];
                }
                $r['mensajes'][] = $m;
            } elseif ($i === 'prensa') {
                $r['mensajes'][] = asistente_con_prensa($ctx);
            } elseif ($ctx['tipo'] === 'seccion' && $ctx['cat'] && in_array($i, ['orientacion', 'verificacion', 'categoria', 'resumen'], true)) {
                $r['mensajes'][] = asistente_de_seccion($i === 'resumen' || $i === 'categoria' ? 'seccion' : $i, $ctx);
            } elseif (!$pidioPublicacion) {
                $pidioPublicacion = true;
                $r['mensajes'][] = asistente_elige_publicacion($ctx);
            }
            continue;
        }
        $r['mensajes'][] = match ($i) {
            'seccion', 'masvisto', 'reciente' => asistente_de_seccion($i, $ctx),
            default => asistente_general($i, $ctx, $usuario),
        };
    }

    if (!$r['mensajes']) {
        // Sin intención clara: se busca la pregunta como texto
        $m = asistente_buscar($n, $ctx, true);
        $r['mensajes'][] = $m;
    }
    return $r;
}

/** Falta saber de qué publicación habla: se ofrecen las más recientes del lugar actual. */
function asistente_elige_publicacion(array $ctx): array
{
    $cat = $ctx['tipo'] === 'seccion' && $ctx['cat'] ? $ctx['cat']['slug'] : '';
    $q = $ctx['tipo'] === 'seccion' ? $ctx['q'] : '';
    $items = explorar(filtros_desde_url(['cat' => $cat, 'q' => $q]), 4)['items'];
    return asistente_msj('Esa pregunta es sobre una publicación. Ábrela y vuelve a preguntarme, o nómbrala: por ejemplo, «¿cuál es la fuente del video de Kardashev?».'
        . ($items ? ($q !== '' ? ' De estos resultados:' : ($cat !== '' ? ' Algunas de esta sección:' : ' Algunas de las más recientes:')) : ''),
        array_map(static fn($x) => ['texto' => $x['titulo'], 'url' => url_publicacion($x)], $items));
}

/** Sin una publicación abierta: cuáles tienen noticias de prensa (en la sección actual, si hay una). */
function asistente_con_prensa(array $ctx): array
{
    $cat = $ctx['tipo'] === 'seccion' && $ctx['cat'] ? $ctx['cat']['slug'] : '';
    $res = explorar(filtros_desde_url(['con' => 'prensa', 'cat' => $cat]), 4);
    if (!$res['items']) {
        return asistente_msj('Todavía no hay publicaciones con noticias de prensa' . ($cat !== '' ? ' en esta sección.' : '.'));
    }
    return asistente_msj(plural($res['total'], 'publicación tiene', 'publicaciones tienen') . ' noticias de prensa enlazadas' . ($cat !== '' ? ' en esta sección' : '')
        . '. Ábrelas y elige «Noticias en la prensa» para leer sobre el tema en medios reales:',
        array_merge(array_map(static fn($x) => ['texto' => $x['titulo'], 'url' => url_publicacion($x)], $res['items']),
            [['texto' => 'Ver todas', 'url' => url('videos.php', array_filter(['con' => 'prensa', 'cat' => $cat]))]]));
}

function asistente_msj(string $texto, array $enlaces = []): array
{
    return ['texto' => $texto, 'enlaces' => $enlaces];
}

function asistente_acceso(string $motivo, string $volver): array
{
    return ['texto' => 'Iniciar sesión (es gratis)', 'url' => url('entrar.php', ['volver' => $volver, 'motivo' => $motivo])];
}

/** Respuestas sobre la publicación actual. Los enlaces protegidos solo se entregan con sesión. */
function asistente_de_publicacion(string $i, array $p, ?array $usuario): array
{
    $id = (int) $p['id'];
    $volver = url_publicacion($p);
    $yt = !empty($p['youtube_id']) && !$p['video_archivo'];
    switch ($i) {
        case 'resumen':
            $txt = recortar(trim((string) preg_replace('/\s+/', ' ', $p['descripcion'])), 320);
            if ($p['tipo'] === 'noticia' && $p['cuerpo']) {
                $primero = trim((string) strtok((string) $p['cuerpo'], "\n"));
                $txt .= ' ' . recortar($primero, 260);
            }
            return asistente_msj($txt);
        case 'fuente':
            if (!$p['fuente_url']) {
                return asistente_msj('Esta publicación no tiene una fuente externa enlazada. La creó ' . $p['creador'] . '.');
            }
            $dom = dominio((string) $p['fuente_url']);
            if (!$usuario) {
                // Sin sesión no se entrega ni la dirección ni el dominio, igual que en la página
                return asistente_msj(($yt ? 'La fuente es el video original en YouTube.' : 'Esta publicación tiene una fuente original enlazada.')
                    . ' Para ver su dirección y abrirla necesitas iniciar sesión: así funcionan todos los enlaces externos del sitio.', [asistente_acceso('fuente', $volver)]);
            }
            return asistente_msj("La fuente original es {$p['fuente_url']} (sitio: {$dom}).", [['texto' => $yt ? 'Ver en YouTube' : 'Abrir la fuente', 'url' => url('ir.php', ['t' => 'fuente', 'id' => $id]), 'externo' => true]]);
        case 'prensa':
            $lista = prensa_de($id);
            $enPagina = url('video.php', ['v' => $p['slug'], 'vista' => 'noticias']);
            if (!$lista) {
                return asistente_msj('Esta publicación todavía no tiene noticias de prensa enlazadas.', [['texto' => 'Publicaciones con noticias de prensa', 'url' => url('videos.php', ['con' => 'prensa'])]]);
            }
            $medios = implode(', ', array_unique(array_column($lista, 'medio')));
            if (!$usuario) {
                return asistente_msj('Hay ' . plural(count($lista), 'noticia', 'noticias') . " de prensa sobre este tema, de {$medios}. Puedes ver los titulares en la vista «Noticias en la prensa»; para abrir los artículos necesitas iniciar sesión.",
                    [['texto' => 'Ver los titulares', 'url' => $enPagina], asistente_acceso('prensa', $enPagina)]);
            }
            return asistente_msj('Noticias de prensa sobre este tema (' . count($lista) . '):', array_merge(
                array_map(static fn($a) => ['texto' => $a['medio'] . ': ' . recortar($a['titulo'], 90), 'url' => url('ir.php', ['t' => 'prensa', 'id' => (int) $a['id']]), 'externo' => true], array_slice($lista, 0, 5)),
                [['texto' => 'Verlas en la página', 'url' => $enPagina]]));
        case 'youtube':
            if ($p['tipo'] !== 'video') {
                return asistente_msj('Esta publicación no es un video: es ' . ($p['tipo'] === 'noticia' ? 'una noticia' : 'una galería de fotos') . '.');
            }
            if (!$p['video_archivo'] && empty($p['youtube_id'])) {
                return asistente_msj('Este video no tiene archivo disponible: solo se conserva su miniatura y descripción.');
            }
            if (!$usuario) {
                return asistente_msj('El video se reproduce aquí mismo, pero necesitas iniciar sesión para verlo.', [asistente_acceso('video', $volver . '#reproductor')]);
            }
            if ($yt) {
                return asistente_msj('Pulsa «Reproducir» sobre la imagen: el video se carga desde YouTube, en modo de privacidad mejorada, recién en ese momento. Si prefieres, ábrelo directo en YouTube.',
                    [['texto' => 'Ir al reproductor', 'url' => $volver . '#reproductor'], ['texto' => 'Ver en YouTube', 'url' => url('ir.php', ['t' => 'youtube', 'id' => $id]), 'externo' => true]]);
            }
            return asistente_msj('El video se reproduce aquí mismo, con los controles del reproductor' . ($p['subtitulos'] ? ' y subtítulos en español' : '') . '.', [['texto' => 'Ir al reproductor', 'url' => $volver . '#reproductor']]);
        case 'fecha':
            $rel = fecha_relativa($p['publicado_en']);
            $t = 'Se publicó en Sin Filtro el ' . fecha_larga($p['publicado_en'], true) . (str_starts_with($rel, 'hace') || $rel === 'ayer' ? " ({$rel})." : '.');
            if ($p['actualizado_en']) {
                $t .= ' Se actualizó por última vez el ' . fecha_larga($p['actualizado_en'], true) . '.';
            }
            if ($yt) {
                $t .= ' La fecha en que el canal lo subió a YouTube aparece en la página del video en YouTube.';
            }
            return asistente_msj($t);
        case 'subido':
            return asistente_msj('Subido por ' . ($p['subido_por'] ?: 'la administración') . ', desde el panel de administración de Sin Filtro.');
        case 'creador':
            $t = $p['creador'] === YOUTUBE_CANAL_PENDIENTE ? 'Es un video de YouTube; el nombre del canal se completa cuando el servidor consulta YouTube.' : 'El contenido es de ' . $p['creador'] . '.';
            if ($p['autor']) {
                $t .= ' Lo escribió ' . $p['autor'] . '.';
            }
            if ($p['creador_url'] && !$usuario) {
                $t .= ' El enlace a su sitio se ve con sesión iniciada.';
            }
            $enl = $p['creador'] === YOUTUBE_CANAL_PENDIENTE ? [] : [['texto' => 'Más de ' . $p['creador'], 'url' => url('videos.php', ['creador' => $p['creador']])]];
            if ($p['creador_url']) {
                $enl[] = $usuario ? ['texto' => 'Sitio del creador', 'url' => url('ir.php', ['t' => 'creador', 'id' => $id]), 'externo' => true] : asistente_acceso('red', $volver);
            }
            return asistente_msj($t, $enl);
        case 'categoria':
            $enl = [];
            if ($p['padre_slug']) {
                $enl[] = ['texto' => $p['padre_nombre'], 'url' => url('videos.php', ['cat' => $p['padre_slug']])];
            }
            $enl[] = ['texto' => $p['categoria_nombre'], 'url' => url('videos.php', ['cat' => $p['categoria_slug']])];
            return asistente_msj('Está en ' . ($p['padre_nombre'] ? $p['padre_nombre'] . ' › ' : '') . $p['categoria_nombre'] . '.', $enl);
        case 'orientacion':
            $o = ORIENTACIONES[$p['orientacion']][0] ?? 'Sin orientación';
            $nota = $p['orientacion_nota'] ?: ($p['orientacion'] === 'no-aplica' ? 'No toma postura política o no trata temas políticos.' : 'Etiqueta asignada por la moderación.');
            $t = "Orientación: {$o}. {$nota} La etiqueta describe la postura, no la califica: para saber si es confiable, mira la verificación.";
            return asistente_msj($t, [['texto' => 'Ver la vista equilibrada', 'url' => url('videos.php', ['orden' => 'equilibrado'])], ['texto' => 'Cómo asignamos las etiquetas', 'url' => url('transparencia.php') . '#orientacion']]);
        case 'verificacion':
            $v = VERIFICACIONES[$p['verificacion']];
            return asistente_msj('Estado: ' . $v[0] . '. ' . ($p['verificacion_nota'] ?: $v[1]), [['texto' => 'Qué significa cada estado', 'url' => url('transparencia.php') . '#verificacion']]);
        case 'miradas':
            $ps = perspectivas($p, 4);
            if (!$ps) {
                return asistente_msj('Todavía no hay otras miradas sobre este mismo tema. Puedes probar la vista equilibrada.', [['texto' => 'Vista equilibrada', 'url' => url('videos.php', ['orden' => 'equilibrado'])]]);
            }
            return asistente_msj('Otras miradas sobre este tema:', array_map(static fn($x) => ['texto' => $x['titulo'] . ($x['orientacion'] !== 'no-aplica' ? ' (' . ORIENTACIONES[$x['orientacion']][0] . ')' : ''), 'url' => url_publicacion($x)], $ps));
        case 'relacionados':
            $rel = relacionadas($p, [], 4);
            return asistente_msj($rel ? 'Te pueden interesar:' : 'No encontré publicaciones relacionadas.', array_map(static fn($x) => ['texto' => $x['titulo'], 'url' => url_publicacion($x)], $rel));
        case 'vistas':
            return asistente_msj('Tiene ' . number_format((int) $p['vistas'], 0, ',', '.') . ' vistas. Ojo: lo popular no siempre es lo más confiable.');
        case 'duracion':
            if ((int) $p['duracion_seg'] > 0) {
                return asistente_msj('Dura ' . duracion_texto((int) $p['duracion_seg']) . '.');
            }
            return asistente_msj($yt ? 'La duración aparece en el reproductor de YouTube al reproducirlo.' : 'Esta publicación no tiene un video con duración registrada.');
        case 'precio':
            if ($p['precio'] === null && !$p['venta_url']) {
                return asistente_msj('Esta publicación no tiene precio ni enlace de venta.', [['texto' => 'Ver productos', 'url' => url('videos.php', ['cat' => 'productos'])]]);
            }
            $t = $p['precio'] !== null ? 'Cuesta ' . precio((int) $p['precio']) . ($p['tienda'] ? ' en ' . $p['tienda'] : '') . '.' : 'Se vende' . ($p['tienda'] ? ' en ' . $p['tienda'] : '') . '.';
            if ($p['precio'] !== null && $p['precio_antes'] && ($d = descuento((int) $p['precio'], (int) $p['precio_antes']))) {
                $t .= ' Antes costaba ' . precio((int) $p['precio_antes']) . " ({$d} % de descuento).";
            }
            $enl = [];
            if ($p['venta_url']) {
                $enl[] = $usuario ? ['texto' => 'Ir a la tienda', 'url' => url('ir.php', ['t' => 'venta', 'id' => $id]), 'externo' => true] : asistente_acceso('venta', $volver);
            }
            return asistente_msj($t, $enl);
        case 'redes':
            $redes = redes_de($id);
            if (!$redes) {
                return asistente_msj('Esta publicación no tiene redes sociales adjuntas.');
            }
            $nombres = implode(', ', array_unique(array_map(static fn($x) => red_info($x['red'])[0], $redes)));
            if (!$usuario) {
                return asistente_msj("Tiene perfiles en {$nombres}. Para ver los enlaces inicia sesión.", [asistente_acceso('red', $volver)]);
            }
            return asistente_msj("Redes adjuntas: {$nombres}.", array_map(static fn($x) => ['texto' => red_info($x['red'])[0] . ': @' . ltrim((string) $x['usuario'], '@'), 'url' => url('ir.php', ['t' => 'red', 'id' => (int) $x['id']]), 'externo' => true], $redes));
        case 'etiquetas':
            $tags = array_filter(array_map('trim', explode(',', (string) $p['etiquetas'])));
            return asistente_msj($tags ? 'Etiquetas: ' . implode(', ', $tags) . '.' : 'No tiene etiquetas.', array_map(static fn($t) => ['texto' => '#' . str_replace(' ', '', $t), 'url' => url('videos.php', ['q' => $t])], array_slice($tags, 0, 4)));
        case 'compartir':
            $abs = url_absoluta(url_publicacion($p));
            return asistente_msj("El enlace de esta publicación es {$abs}. También puedes usar el botón «Copiar enlace».");
    }
    return asistente_msj('No tengo ese dato.');
}

function asistente_de_seccion(string $i, array $ctx): array
{
    $cat = $ctx['cat'] ?? null;
    if ($ctx['tipo'] === 'seccion' && !$cat && $ctx['q'] !== '' && in_array($i, ['seccion', 'masvisto', 'reciente'], true)) {
        // Resultados de una búsqueda
        $res = explorar(filtros_desde_url(['q' => $ctx['q'], 'orden' => $i === 'masvisto' ? 'vistas' : ($i === 'reciente' ? 'recientes' : 'relevancia')]), 4);
        return asistente_msj('Estás viendo los resultados de «' . $ctx['q'] . '»: ' . plural($res['total'], 'publicación', 'publicaciones')
            . ($i === 'masvisto' ? '. Las más vistas:' : ($i === 'reciente' ? '. Las más recientes:' : '. Las primeras:')),
            array_map(static fn($x) => ['texto' => $x['titulo'], 'url' => url_publicacion($x)], $res['items']));
    }
    if ($ctx['tipo'] !== 'seccion' || !$cat) {
        $f = filtros_desde_url(['orden' => $i === 'masvisto' ? 'vistas' : 'recientes']);
        if ($i === 'seccion') {
            $arbol = categorias_arbol();
            return asistente_msj('Estas son las secciones:', array_map(static fn($r) => ['texto' => $r['nombre'] . ' (' . $r['total'] . ')', 'url' => url('videos.php', ['cat' => $r['slug']])], $arbol));
        }
        $items = explorar($f, 4)['items'];
        return asistente_msj($i === 'masvisto' ? 'Lo más visto del sitio:' : 'Lo más reciente del sitio:', array_map(static fn($x) => ['texto' => $x['titulo'], 'url' => url_publicacion($x)], $items));
    }
    $base = ['cat' => $cat['slug']];
    if ($i === 'masvisto' || $i === 'reciente') {
        $items = explorar(filtros_desde_url($base + ['orden' => $i === 'masvisto' ? 'vistas' : 'recientes']), 4)['items'];
        return asistente_msj(($i === 'masvisto' ? 'Lo más visto en ' : 'Lo más reciente en ') . $cat['nombre'] . ':', array_map(static fn($x) => ['texto' => $x['titulo'], 'url' => url_publicacion($x)], $items));
    }
    $fac = facetas(filtros_desde_url($base));
    if ($i === 'orientacion') {
        $partes = [];
        foreach (ORIENTACIONES as $k => [$t]) {
            if (!empty($fac['orientacion'][$k])) {
                $partes[] = "{$t}: " . $fac['orientacion'][$k];
            }
        }
        return asistente_msj('Orientaciones en ' . $cat['nombre'] . ': ' . implode(', ', $partes) . '.', [['texto' => 'Verla en vista equilibrada', 'url' => url('videos.php', $base + ['orden' => 'equilibrado'])]]);
    }
    if ($i === 'verificacion') {
        $partes = [];
        foreach (VERIFICACIONES as $k => [$t]) {
            $partes[] = "{$t}: " . (int) ($fac['verificacion'][$k] ?? 0);
        }
        return asistente_msj('Verificación en ' . $cat['nombre'] . ': ' . implode(', ', $partes) . '.');
    }
    // Información de la sección
    $total = (int) valor('SELECT COUNT(*) FROM publicaciones p JOIN categorias c ON c.id = p.categoria_id WHERE c.id = ? OR c.padre_id = ?', [(int) $cat['id'], (int) $cat['id']]);
    $t = $cat['nombre'] . ': ' . ($cat['descripcion'] ?: 'sección del sitio') . ' Tiene ' . plural($total, 'publicación', 'publicaciones') . '.';
    if ($cat['nota']) {
        $t .= ' ' . recortar((string) $cat['nota'], 260);
    }
    $subs = filas('SELECT slug, nombre FROM categorias WHERE padre_id = ? ORDER BY orden, nombre', [(int) $cat['id']]);
    return asistente_msj($t, array_map(static fn($s) => ['texto' => $s['nombre'], 'url' => url('videos.php', ['cat' => $s['slug']])], $subs));
}

function asistente_general(string $i, array $ctx, ?array $usuario): array
{
    return match ($i) {
        'saludo' => asistente_msj(asistente_bienvenida($ctx)),
        'gracias' => asistente_msj('¡De nada! Si tienes otra duda, pregúntame.'),
        'robot' => asistente_msj('Soy el robot ayudante de Sin Filtro: respondo con los datos del sitio, sin inteligencia artificial externa. Si te tapo algo, arrástrame manteniendo presionado el clic (o el dedo), o llega a mí con la tecla Tab y usa las flechas. El botón con la casita me devuelve a mi lugar.'),
        'estilo' => asistente_msj('En Preferencias (botón Aa) eliges el estilo visual: Sin Filtro, Frutiger Aero, Periódico, Neón, Escritorio 98 o Neobrutalismo. Se aplica al instante y se guarda solo en tu navegador.', [['texto' => 'Elegir estilo', 'url' => url('preferencias.php')]]),
        'avatar' => $usuario
            ? asistente_msj('Puedes crear tu avatar con piezas (cara, pelo, ojos, ropa, accesorios y fondo) o subir una foto de perfil. Se muestra en tus comentarios y en tu cuenta.', [['texto' => 'Crear mi avatar', 'url' => url('avatar.php')]])
            : asistente_msj('Con una cuenta (gratis) puedes crear tu avatar con muchas piezas o subir una foto de perfil para tus comentarios.', [['texto' => 'Crear cuenta', 'url' => url('registro.php')], ['texto' => 'Iniciar sesión', 'url' => url('entrar.php')]]),
        'ayuda' => asistente_msj('Puedo decirte la fuente, la fecha, quién subió una publicación, quién la creó, qué noticias de prensa hablan del tema, por qué tiene sus etiquetas de orientación y verificación, otras miradas sobre el mismo tema, el precio de un producto y sus redes. También busco por ti («busca vacunas») y te llevo a una sección («llévame a Deportes»). Respondo según la página en la que estás.', [['texto' => 'Cómo funciona el asistente', 'url' => url('transparencia.php') . '#asistente']]),
        'comentarios' => $ctx['tipo'] === 'publicacion'
            ? asistente_msj('Tiene ' . plural((int) valor('SELECT COUNT(*) FROM comentarios WHERE publicacion_id = ?', [(int) $ctx['p']['id']]), 'comentario', 'comentarios') . '. Leerlos es libre; para comentar hay que iniciar sesión. No se ocultan opiniones por su postura.',
                [['texto' => 'Ir a los comentarios', 'url' => url_publicacion($ctx['p']) . '#comentarios']] + ($usuario ? [] : [1 => asistente_acceso('comentar', url_publicacion($ctx['p']) . '#comentar')]))
            : asistente_msj('Los comentarios están al final de cada publicación. Leerlos es libre; para comentar hay que iniciar sesión.'),
        'escuchar' => asistente_msj('Pulsa «Escuchar» junto al título (o en cada comentario) y el navegador lo lee en voz alta con una voz de tu dispositivo. En las preferencias (botón Aa) eliges la velocidad y la voz.', [['texto' => 'Preferencias de lectura', 'url' => url('preferencias.php')]]),
        'preferencias' => asistente_msj('Con el botón Aa de la cabecera eliges el estilo visual (por ejemplo Frutiger Aero o Neón), tema claro u oscuro, color de acento, tamaño del texto, espacio entre líneas, alto contraste, menos animaciones y la voz para escuchar.', [['texto' => 'Abrir preferencias', 'url' => url('preferencias.php')]]),
        'privacidad' => asistente_msj('Sin Filtro no usa rastreadores ni publicidad. Solo hay dos cookies propias: la de sesión y, si cambias algo, la de preferencias. Las búsquedas se guardan sin usuario ni IP, y este asistente no guarda tus preguntas. Los videos de YouTube solo se conectan con YouTube cuando pulsas reproducir (sus miniaturas, solo si el servidor no pudo guardarlas).', [['texto' => 'Privacidad, en detalle', 'url' => url('transparencia.php') . '#privacidad']]),
        'algoritmo' => asistente_msj('No hay un algoritmo oculto: con los mismos filtros, todas las personas ven el mismo orden. Eliges entre más recientes, relevancia, más vistos y la vista equilibrada, que intercala publicaciones de cada orientación.', [['texto' => 'Cómo funciona', 'url' => url('transparencia.php')], ['texto' => 'Vista equilibrada', 'url' => url('videos.php', ['orden' => 'equilibrado'])]]),
        'cuenta' => $usuario
            ? asistente_msj('Ya iniciaste sesión como ' . $usuario['nombre'] . '. En tu cuenta puedes cambiar la contraseña, el historial y eliminar la cuenta.', [['texto' => 'Mi cuenta', 'url' => url('cuenta.php')]])
            : asistente_msj('Crear una cuenta es gratis. Con ella ves los videos, las fuentes, los enlaces de venta y las redes, y puedes comentar.', [['texto' => 'Crear cuenta', 'url' => url('registro.php')], ['texto' => 'Iniciar sesión', 'url' => url('entrar.php')]]),
        default => asistente_msj('No tengo una respuesta para eso todavía.'),
    };
}

function asistente_buscar(string $texto, array $ctx, bool $comoRespaldo = false): array
{
    $q = trim(mb_substr($texto, 0, 120));
    $cat = $ctx['tipo'] === 'seccion' && $ctx['cat'] ? $ctx['cat']['slug'] : '';
    $res = explorar(filtros_desde_url(['q' => $q, 'cat' => $cat]), 4);
    if (!$res['items'] && $cat !== '') {
        $res = explorar(filtros_desde_url(['q' => $q]), 4);
        $cat = '';
    }
    if (!$res['items']) {
        return asistente_msj($comoRespaldo
            ? 'No estoy seguro de entender. Puedo decirte la fuente, la fecha, quién lo subió, por qué tiene sus etiquetas, o buscar por ti («busca …»).'
            : "No encontré publicaciones sobre «{$q}». Prueba con otras palabras.");
    }
    $enl = array_map(static fn($x) => ['texto' => $x['titulo'], 'url' => url_publicacion($x)], $res['items']);
    if ($res['total'] > count($res['items'])) {
        $enl[] = ['texto' => 'Ver los ' . $res['total'] . ' resultados', 'url' => url('videos.php', array_filter(['q' => $q, 'cat' => $cat]))];
    }
    return asistente_msj(($comoRespaldo ? 'No estoy seguro de qué buscas, pero encontré esto' : 'Encontré esto') . ($cat !== '' ? ' en esta sección' : '') . ':', $enl);
}

/** «Llévame a Deportes»: busca la sección por nombre. */
function asistente_destino(string $texto): ?array
{
    $t = trim((string) preg_replace('/^(la |el |los |las |seccion (de )?)/', '', $texto));
    $paginas = ['inicio' => url(), 'portada' => url(), 'como funciona' => url('transparencia.php'), 'transparencia' => url('transparencia.php'),
        'mi cuenta' => url('cuenta.php'), 'cuenta' => url('cuenta.php'), 'preferencias' => url('preferencias.php'), 'vista equilibrada' => url('videos.php', ['orden' => 'equilibrado'])];
    foreach ($paginas as $k => $u) {
        if (str_starts_with($t, $k)) {
            return asistente_msj('Aquí tienes:', [['texto' => ucfirst($k), 'url' => $u]]);
        }
    }
    foreach (filas('SELECT slug, nombre FROM categorias ORDER BY padre_id IS NOT NULL, orden') as $c) {
        $nom = normalizar($c['nombre']);
        if ($t === $nom || str_starts_with($nom, $t) || str_starts_with($t, $nom) || ($t !== '' && str_contains($nom, $t) && mb_strlen($t) > 3)) {
            return asistente_msj('Aquí tienes:', [['texto' => $c['nombre'], 'url' => url('videos.php', ['cat' => $c['slug']])]]);
        }
    }
    return null;
}

function asistente_bienvenida(array $ctx): string
{
    return match ($ctx['tipo']) {
        'publicacion' => 'Hola. Estás en «' . $ctx['p']['titulo'] . '». Pregúntame por su fuente, la fecha, quién lo subió, por qué tiene sus etiquetas u otras miradas sobre el tema.',
        'seccion' => $ctx['cat'] ? 'Hola. Estás en ' . $ctx['cat']['nombre'] . '. Puedo contarte qué hay aquí, lo más visto o lo más reciente, o buscar algo dentro de la sección.' : 'Hola. Estás en la galería. Puedo buscar por ti, mostrarte lo más visto o llevarte a una sección.',
        'inicio' => 'Hola. Puedo buscar por ti, llevarte a una sección o explicarte cómo funciona el sitio. En una publicación, te digo su fuente, fecha y más.',
        default => 'Hola. Pregúntame cómo funciona el sitio, busca algo o pide que te lleve a una sección.',
    };
}

function asistente_sugerencias(array $ctx): array
{
    if ($ctx['tipo'] === 'publicacion') {
        $p = $ctx['p'];
        $s = ['¿Cuál es la fuente?', '¿Cuándo se publicó?', '¿Quién lo subió?', '¿Por qué tiene esta orientación?', 'Otras miradas'];
        if ((int) valor('SELECT COUNT(*) FROM enlaces_prensa WHERE publicacion_id = ?', [(int) $p['id']]) > 0) {
            array_splice($s, 1, 0, ['Noticias en la prensa']);
        }
        if ($p['tipo'] === 'video') {
            array_splice($s, 1, 0, ['¿Cómo veo el video?']);
        }
        if ($p['precio'] !== null) {
            array_splice($s, 1, 0, ['¿Cuánto cuesta?']);
        }
        return array_slice($s, 0, 6);
    }
    if ($ctx['tipo'] === 'seccion' && ($ctx['cat'] ?? null)) {
        return ['¿Qué hay en esta sección?', 'Lo más visto', 'Lo más reciente', '¿Qué orientaciones hay?'];
    }
    return ['¿Cómo funciona el algoritmo?', 'Busca ciencia', 'Llévame a Deportes', '¿Qué datos guardan de mí?'];
}

/** Límite simple por sesión para que nadie use el asistente como robot de consultas. */
function asistente_permitido(): bool
{
    $ahora = time();
    $marcas = array_filter((array) ($_SESSION['asistente'] ?? []), static fn($t) => is_int($t) && $t > $ahora - 60);
    if (count($marcas) >= 30) {
        $_SESSION['asistente'] = $marcas;
        return false;
    }
    $marcas[] = $ahora;
    $_SESSION['asistente'] = array_values($marcas);
    return true;
}

/** Nombre corto del lugar donde está la persona (se muestra en el asistente). */
function asistente_etiqueta(array $ctx): string
{
    return match ($ctx['tipo']) {
        'publicacion' => $ctx['p']['titulo'],
        'seccion' => $ctx['q'] !== '' ? 'Resultados de «' . $ctx['q'] . '»' . ($ctx['cat'] ? ' en ' . $ctx['cat']['nombre'] : '')
            : ($ctx['cat'] ? ($ctx['cat']['padre_nombre'] ? $ctx['cat']['padre_nombre'] . ' › ' : '') . $ctx['cat']['nombre'] : 'Todos los videos'),
        'inicio' => 'Portada',
        default => ['transparencia' => 'Cómo funciona', 'cuenta' => 'Tu cuenta', 'preferencias' => 'Preferencias', 'error' => 'Página no encontrada'][$ctx['nombre'] ?? ''] ?? 'Sin Filtro',
    };
}

/** Datos del lugar que la página entrega al asistente (atributos data-* y campos ocultos). */
function asistente_ctx_datos(array $ctx): array
{
    return match ($ctx['tipo']) {
        'publicacion' => ['tipo' => 'publicacion', 'ref' => $ctx['p']['slug'], 'q' => ''],
        'seccion' => ['tipo' => 'seccion', 'ref' => $ctx['cat']['slug'] ?? '', 'q' => $ctx['q']],
        'inicio' => ['tipo' => 'inicio', 'ref' => '', 'q' => ''],
        default => ['tipo' => 'pagina', 'ref' => $ctx['nombre'] ?? '', 'q' => ''],
    };
}

/** Dónde volver desde la página del asistente (versión sin JavaScript). */
function asistente_url_lugar(array $ctx): string
{
    return match ($ctx['tipo']) {
        'publicacion' => url_publicacion($ctx['p']),
        'seccion' => url('videos.php', array_filter(['cat' => $ctx['cat']['slug'] ?? '', 'q' => $ctx['q']])),
        default => ['transparencia' => url('transparencia.php'), 'cuenta' => url('cuenta.php'), 'preferencias' => url('preferencias.php')][$ctx['nombre'] ?? ''] ?? url(),
    };
}

/** Robot ayudante en SVG (lanzador y cara del asistente). Las partes animadas se controlan con CSS. */
function robot_svg(string $clase = ''): string
{
    return '<svg class="robot ' . e($clase) . '" viewBox="0 0 64 72" aria-hidden="true" focusable="false">'
        . '<ellipse class="robot__sombra" cx="32" cy="69" rx="15" ry="2.6"/>'
        . '<g class="robot__todo">'
        . '<line class="robot__antena" x1="32" y1="13" x2="32" y2="6"/>'
        . '<circle class="robot__luz" cx="32" cy="5" r="3.6"/>'
        . '<rect class="robot__oreja" x="4.5" y="24" width="7" height="13" rx="3.5"/>'
        . '<rect class="robot__oreja" x="52.5" y="24" width="7" height="13" rx="3.5"/>'
        . '<rect class="robot__cabeza" x="9" y="12" width="46" height="36" rx="15"/>'
        . '<rect class="robot__brillo" x="14" y="14.5" width="24" height="5" rx="2.5"/>'
        . '<rect class="robot__visor" x="15" y="20" width="34" height="21" rx="10"/>'
        . '<g class="robot__ojos"><ellipse class="robot__ojo" cx="25" cy="29.5" rx="3.4" ry="4.2"/><ellipse class="robot__ojo" cx="39" cy="29.5" rx="3.4" ry="4.2"/></g>'
        . '<path class="robot__boca" d="M27.5 35.2q4.5 3.2 9 0"/>'
        . '<circle class="robot__mejilla" cx="19.5" cy="35" r="2"/><circle class="robot__mejilla" cx="44.5" cy="35" r="2"/>'
        . '<rect class="robot__cuerpo" x="19" y="49" width="26" height="15" rx="7"/>'
        . '<circle class="robot__pecho" cx="32" cy="56.5" r="3"/>'
        . '<rect class="robot__brazo robot__brazo--izq" x="12" y="51" width="6" height="10" rx="3"/>'
        . '<rect class="robot__brazo robot__brazo--der" x="46" y="51" width="6" height="10" rx="3"/>'
        . '</g></svg>';
}
