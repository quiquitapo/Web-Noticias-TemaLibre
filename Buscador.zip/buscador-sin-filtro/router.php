<?php
/**
 * Enrutador para el servidor integrado de PHP (solo desarrollo):
 *   php -S localhost:8000 router.php
 * Bloquea carpetas internas igual que el .htaccess de Apache.
 */
$ruta = urldecode((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

if (preg_match('#^/(includes|sql|logs|media/videos)(/|$)|/\.|router\.php$|^/media/.*\.(php\d?|phtml|phar|html?|svg)$#i', $ruta)) {
    http_response_code(403);
    echo 'Acceso denegado';
    return true;
}
$archivo = __DIR__ . $ruta;
// Miniaturas de YouTube que todavía no están guardadas (igual que la regla del .htaccess)
if (!is_file($archivo) && preg_match('#^/media/portadas/youtube/([a-z0-9-]+)-(480|960|1600)\.webp$#', $ruta, $m)) {
    $_GET = ['s' => $m[1], 'w' => $m[2]];
    require __DIR__ . '/miniatura-youtube.php';
    return true;
}
if ($ruta !== '/' && is_file($archivo)) {
    if (str_ends_with($ruta, '.php')) {
        return false;
    }
    $tipos = ['webp' => 'image/webp', 'woff2' => 'font/woff2', 'svg' => 'image/svg+xml', 'css' => 'text/css; charset=utf-8', 'js' => 'text/javascript; charset=utf-8'];
    $ext = strtolower(pathinfo($archivo, PATHINFO_EXTENSION));
    if (isset($tipos[$ext])) {
        header('Content-Type: ' . $tipos[$ext]);
        header('Cache-Control: public, max-age=31536000, immutable');
        readfile($archivo);
        return true;
    }
    return false;
}
if ($ruta === '/' || is_dir($archivo)) {
    $indice = rtrim($archivo, '/') . '/index.php';
    if (is_file($indice)) {
        $_SERVER['SCRIPT_NAME'] = rtrim($ruta, '/') . '/index.php';
        $_SERVER['SCRIPT_FILENAME'] = $indice;
        require $indice;
        return true;
    }
}
http_response_code(404);
require __DIR__ . '/404.php';
return true;
