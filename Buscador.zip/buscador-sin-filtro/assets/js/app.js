/* ==========================================================================
   Sin Filtro — interacción
   Mejora progresiva: todo funciona sin JavaScript; esto agrega búsqueda en vivo,
   diálogos, animaciones y atajos de teclado.
   ========================================================================== */

const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
const BASE = document.body.dataset.base || '';
const mqMovimiento = matchMedia('(prefers-reduced-motion: reduce)');
// Animaciones reducidas: lo pide el sistema o la persona en sus preferencias de lectura
const menosMovimiento = { get matches() { return mqMovimiento.matches || document.documentElement.dataset.movimiento === 'reducido'; } };
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const icono = (n, clase = '') => `<svg class="ico ${clase}" aria-hidden="true" focusable="false"><use href="#i-${n}"/></svg>`;

/* --- Imágenes: aparecen suavemente cuando terminan de cargar ---------------- */
// Si una miniatura de YouTube no se puede cargar (sin conexión con YouTube), se muestra la portada neutra del sitio
const respaldoYoutube = (img) => {
  if (img.dataset.respaldo || !/\/portadas\/youtube\//.test(img.currentSrc || img.src)) return;
  img.dataset.respaldo = '1';
  img.removeAttribute('srcset');
  img.src = `${BASE}/assets/img/video-960.webp`;
};
document.addEventListener('error', (e) => { if (e.target instanceof HTMLImageElement) respaldoYoutube(e.target); }, true);

function imagenes(raiz = document) {
  for (const img of $$('img.img[src*="/portadas/youtube/"]', raiz)) {
    if (img.complete && !img.naturalWidth) respaldoYoutube(img);
  }
  for (const img of $$('img.img[loading="lazy"]', raiz)) {
    const listo = () => img.classList.add('cargada');
    if (img.complete && img.naturalWidth) listo();
    else {
      img.addEventListener('load', listo, { once: true });
      img.addEventListener('error', listo, { once: true });
    }
  }
}

/* --- Tema claro / oscuro ------------------------------------------------------ */
function tema() {
  const btn = $('[data-tema]');
  if (!btn) return;
  const raiz = document.documentElement;
  const sistema = matchMedia('(prefers-color-scheme: dark)');
  const actual = () => raiz.dataset.theme || (sistema.matches ? 'dark' : 'light');
  const pintar = () => btn.setAttribute('aria-pressed', String(actual() === 'dark'));
  btn.addEventListener('click', () => {
    const nuevo = actual() === 'dark' ? 'light' : 'dark';
    const aplicar = () => {
      raiz.dataset.theme = nuevo;
      Prefs.guardar({ tema: nuevo === 'dark' ? 'oscuro' : 'claro' });
      try { localStorage.removeItem('sf-tema'); } catch { /* sin almacenamiento */ }
      pintar();
      document.dispatchEvent(new CustomEvent('sf:prefs'));
    };
    if (document.startViewTransition && !menosMovimiento.matches) document.startViewTransition(aplicar);
    else aplicar();
  });
  sistema.addEventListener('change', pintar);
  document.addEventListener('sf:prefs', pintar);
  pintar();
}

/* --- Preferencias de lectura (cookie propia, sin datos personales) ---------------------- */
const Prefs = {
  defecto: { tema: 'sistema', acento: 'azul', texto: 'normal', linea: 'normal', contraste: 'normal', movimiento: 'sistema', velocidad: '1' },
  leer() {
    const m = document.cookie.match(/(?:^|; )sf_pref=([^;]*)/);
    const p = { ...this.defecto };
    if (m) for (const [k, v] of new URLSearchParams(decodeURIComponent(m[1]))) if (k in p) p[k] = v;
    return p;
  },
  guardar(cambios) {
    const p = { ...this.leer(), ...cambios };
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(p)) if (v !== this.defecto[k]) q.set(k, v);
    const s = q.toString();
    const ruta = (BASE || '') + '/';
    document.cookie = `sf_pref=${encodeURIComponent(s)}; path=${ruta}; max-age=${s ? 31536000 : 0}; samesite=lax${location.protocol === 'https:' ? '; secure' : ''}`;
    return p;
  },
  aplicar(p) {
    const d = document.documentElement;
    if (p.tema === 'sistema') delete d.dataset.theme; else d.dataset.theme = p.tema === 'oscuro' ? 'dark' : 'light';
    for (const k of ['acento', 'texto', 'linea', 'contraste', 'movimiento']) {
      if (p[k] === this.defecto[k]) delete d.dataset[k]; else d.dataset[k] = p[k];
    }
  },
};

function preferencias() {
  const dlg = $('#dlg-preferencias');
  if (dlg) prepararDialogo(dlg);
  for (const a of $$('[data-abrir-preferencias]')) {
    if (!dlg) continue;
    a.addEventListener('click', (e) => { e.preventDefault(); abrirDialogo(dlg, a); });
  }
  for (const form of $$('[data-preferencias]')) {
    const enDialogo = !!form.closest('dialog');
    const sincronizar = () => {
      const p = Prefs.leer();
      for (const r of $$('input[data-pref]', form)) r.checked = p[r.dataset.pref] === r.value;
    };
    form.addEventListener('change', (e) => {
      const r = e.target.closest('input[data-pref]');
      if (!r) return;
      const p = Prefs.guardar({ [r.dataset.pref]: r.value });
      const aplicar = () => Prefs.aplicar(p);
      if (r.dataset.pref === 'tema' && document.startViewTransition && !menosMovimiento.matches) document.startViewTransition(aplicar);
      else aplicar();
      document.dispatchEvent(new CustomEvent('sf:prefs'));
      anunciar(`${r.closest('fieldset').querySelector('legend').textContent}: ${r.closest('label').textContent.trim().replace(/\s+/g, ' ')}`);
    });
    // Con JavaScript los cambios ya están aplicados: «Guardar» solo cierra y «Restablecer» vuelve a los valores de fábrica.
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (e.submitter?.hasAttribute('data-restablecer')) {
        Prefs.aplicar(Prefs.guardar({ ...Prefs.defecto }));
        try { localStorage.removeItem('sf-voz'); } catch { /* sin almacenamiento */ }
        sincronizar();
        const sel = $('[data-voces]', form);
        if (sel) sel.value = '';
        document.dispatchEvent(new CustomEvent('sf:prefs'));
        anunciar('Preferencias restablecidas.');
        return;
      }
      if (enDialogo) cerrarDialogo(dlg);
      else location.href = form.elements.volver?.value || BASE + '/';
    });
    document.addEventListener('sf:prefs', sincronizar);
    const listo = $('[data-listo]', form);
    if (listo) listo.textContent = enDialogo ? 'Listo' : 'Listo, volver';
  }
}

function anunciar(texto) {
  const r = $('[data-lector-anuncio]');
  if (!r) return;
  r.textContent = '';
  setTimeout(() => { r.textContent = texto; }, 60);
}

/* --- Lectura en voz alta (Web Speech API, voces del dispositivo) ------------------------ */
function lector() {
  const sintesis = window.speechSynthesis;
  if (!sintesis || !('SpeechSynthesisUtterance' in window)) return;
  const barra = $('[data-lector]');
  const estado = $('[data-lector-estado]');
  const tituloBarra = $('[data-lector-titulo]');
  const btnPausa = $('[data-lector-pausa]');
  const btnDetener = $('[data-lector-detener]');
  let trozos = [], i = 0, activo = null, pausado = false, turno = 0, resaltados = [];

  for (const b of $$('[data-leer]')) b.hidden = false;
  for (const g of $$('[data-prefs-voz]')) g.hidden = false;

  const voces = () => sintesis.getVoices().filter((v) => /^es\b|^es-/i.test(v.lang));
  const elegirVoz = () => {
    let nombre = '';
    try { nombre = localStorage.getItem('sf-voz') || ''; } catch { /* sin almacenamiento */ }
    const lista = voces();
    return lista.find((v) => v.name === nombre)
      || lista.find((v) => v.localService && /CL|419|MX|US|AR/i.test(v.lang))
      || lista.find((v) => v.localService)
      || lista[0] || null;
  };
  const partir = (texto) => {
    const frases = texto.replace(/\s+/g, ' ').trim().split(/(?<=[.!?…:;])\s+/);
    const out = [];
    for (let f of frases) {
      while (f.length > 220) {
        let corte = f.lastIndexOf(', ', 220);
        if (corte < 80) corte = f.lastIndexOf(' ', 220);
        if (corte < 1) corte = 220;
        out.push(f.slice(0, corte + 1));
        f = f.slice(corte + 1).trim();
      }
      if (f) out.push(f);
    }
    return out;
  };
  const marcar = (b, si) => {
    b.setAttribute('aria-pressed', String(si));
    b.classList.toggle('leyendo', si);
  };
  const decir = () => {
    if (i >= trozos.length) return detener(true);
    const t = ++turno;
    const u = new SpeechSynthesisUtterance(trozos[i]);
    const v = elegirVoz();
    if (v) u.voice = v;
    u.lang = v?.lang || 'es-CL';
    u.rate = Number(Prefs.leer().velocidad) || 1;
    u.onend = () => { if (t === turno && !pausado) { i++; decir(); } };
    u.onerror = (e) => { if (t === turno && !['interrupted', 'canceled'].includes(e.error)) fallo(); };
    sintesis.speak(u);
  };
  const pintarBarra = () => {
    estado.textContent = pausado ? 'En pausa' : 'Leyendo';
    btnPausa.querySelector('use').setAttribute('href', pausado ? '#i-play' : '#i-pausa');
    $('[data-lector-pausa-txt]', btnPausa).textContent = pausado ? 'Seguir leyendo' : 'Pausar';
    barra.classList.toggle('lector--pausa', pausado);
  };
  // Sin voces instaladas o con la síntesis bloqueada: se avisa en vez de fallar en silencio
  function fallo() {
    const b = activo;
    turno++;
    estado.textContent = 'No se pudo leer';
    tituloBarra.textContent = 'Este navegador no tiene una voz disponible. Revisa las voces de tu sistema.';
    barra.classList.add('lector--pausa');
    anunciar('No se pudo leer en voz alta: este navegador no tiene una voz disponible.');
    setTimeout(() => { if (activo === b) detener(); }, 4500);
  }
  function detener(terminado = false) {
    turno++;
    sintesis.cancel();
    if (activo) marcar(activo, false);
    for (const el of resaltados) el.classList.remove('en-lectura');
    resaltados = [];
    activo = null;
    pausado = false;
    barra.hidden = true;
    anunciar(terminado ? 'Lectura terminada.' : 'Lectura detenida.');
  }
  const leer = (b) => {
    if (activo === b) return detener();
    if (activo) detener();
    const els = b.dataset.leer.split(',').map((s) => $(s.trim())).filter(Boolean);
    const texto = els.map((el) => el.innerText.trim()).filter(Boolean).join('. \n');
    trozos = partir(texto);
    if (!trozos.length) return;
    i = 0;
    pausado = false;
    activo = b;
    marcar(b, true);
    resaltados = els;
    for (const el of els) el.classList.add('en-lectura');
    tituloBarra.textContent = b.dataset.leerTitulo || '';
    barra.hidden = false;
    pintarBarra();
    sintesis.cancel();
    decir();
  };
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-leer]');
    if (b) leer(b);
  });
  btnPausa.addEventListener('click', () => {
    if (!activo) return;
    pausado = !pausado;
    turno++;
    // Pausar cancelando y retomando la frase actual funciona igual en todos los navegadores
    sintesis.cancel();
    if (!pausado) decir();
    pintarBarra();
  });
  btnDetener.addEventListener('click', () => detener());
  addEventListener('pagehide', () => sintesis.cancel());
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && activo && !document.querySelector('dialog[open]')) detener(); });

  // Selector de voz y botón «Probar» en las preferencias
  const llenar = () => {
    let guardada = '';
    try { guardada = localStorage.getItem('sf-voz') || ''; } catch { /* sin almacenamiento */ }
    for (const sel of $$('[data-voces]')) {
      const lista = voces();
      sel.length = 1;
      for (const v of lista) sel.add(new Option(`${v.name} (${v.lang})${v.localService ? '' : ', en línea'}`, v.name));
      sel.value = lista.some((v) => v.name === guardada) ? guardada : '';
      sel.disabled = !lista.length;
    }
  };
  llenar();
  sintesis.addEventListener?.('voiceschanged', llenar);
  for (const sel of $$('[data-voces]')) {
    sel.addEventListener('change', () => {
      try { if (sel.value) localStorage.setItem('sf-voz', sel.value); else localStorage.removeItem('sf-voz'); } catch { /* sin almacenamiento */ }
    });
  }
  for (const b of $$('[data-probar-voz]')) {
    b.addEventListener('click', () => {
      if (activo) detener();
      sintesis.cancel();
      const u = new SpeechSynthesisUtterance('Hola. Así suena esta voz a la velocidad que elegiste.');
      const v = elegirVoz();
      if (v) u.voice = v;
      u.lang = v?.lang || 'es-CL';
      u.rate = Number(Prefs.leer().velocidad) || 1;
      sintesis.speak(u);
    });
  }
}

/* --- YouTube: el reproductor se carga recién al pulsar «Reproducir» ------------------------ */
function youtube() {
  document.addEventListener('click', (e) => {
    const a = e.target.closest('[data-yt-play]');
    if (!a || e.ctrlKey || e.metaKey || e.shiftKey || e.button !== 0) return; // abrir en pestaña nueva sigue funcionando
    const caja = a.closest('[data-yt]');
    const id = caja?.dataset.yt || '';
    if (!/^[A-Za-z0-9_-]{11}$/.test(id)) return;
    e.preventDefault();
    const f = document.createElement('iframe');
    f.className = 'yt__iframe';
    f.src = `https://www.youtube-nocookie.com/embed/${id}?autoplay=1&rel=0&hl=es&cc_lang_pref=es`;
    f.title = `${caja.dataset.ytTitulo || 'Video'} (YouTube)`;
    f.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen';
    f.allowFullscreen = true;
    // YouTube exige saber desde qué sitio se inserta el video (el resto del sitio no envía esa información)
    f.referrerPolicy = 'strict-origin-when-cross-origin';
    caja._fachada = caja.innerHTML; // para volver a la miniatura si se cambia de vista
    caja.replaceChildren(f);
    caja.classList.add('yt--activo');
    f.focus();
  });
}

/* --- Vista de una publicación: el contenido o las noticias de prensa del mismo tema ------------- */
function vistas() {
  const sel = $('[data-vista-sel]');
  if (!sel) return;
  const paneles = $$('[data-vista-panel]');
  // Al ocultar el reproductor, el video se detiene (y el de YouTube vuelve a su miniatura)
  const detener = (panel) => {
    for (const v of $$('video', panel)) v.pause();
    for (const caja of $$('.yt--activo', panel)) {
      if (caja._fachada) { caja.innerHTML = caja._fachada; caja.classList.remove('yt--activo'); }
    }
  };
  sel.addEventListener('click', (e) => {
    const a = e.target.closest('[data-vista]');
    if (!a || e.ctrlKey || e.metaKey || e.shiftKey || e.button !== 0) return;
    e.preventDefault();
    if (a.getAttribute('aria-current') === 'true') return;
    for (const o of $$('[data-vista]', sel)) {
      if (o === a) o.setAttribute('aria-current', 'true'); else o.removeAttribute('aria-current');
    }
    let destino = null;
    for (const p of paneles) {
      const ver = p.dataset.vistaPanel === a.dataset.vista;
      if (!ver && !p.hidden) detener(p);
      p.hidden = !ver;
      if (ver) destino = p;
    }
    try { history.replaceState(history.state, '', a.href); } catch { /* sin historial */ }
    if (destino) {
      if (!destino.hasAttribute('tabindex')) destino.tabIndex = -1;
      destino.focus({ preventScroll: true });
      if (!menosMovimiento.matches) { destino.classList.add('entrando'); destino.addEventListener('animationend', () => destino.classList.remove('entrando'), { once: true }); }
    }
    anunciar(a.dataset.vista === 'noticias' ? 'Mostrando las noticias de prensa sobre este tema.' : 'Mostrando la publicación.');
  });
}

/* --- Contador de caracteres (comentarios) ------------------------------------------- */
function contadores() {
  for (const t of $$('textarea[data-contador]')) {
    const max = Number(t.maxLength) || 0;
    if (!max) continue;
    const c = document.createElement('span');
    c.className = 'contador';
    c.setAttribute('aria-hidden', 'true');
    const pintar = () => {
      c.textContent = `${t.value.length} / ${max}`;
      c.classList.toggle('contador--cerca', t.value.length > max * 0.9);
    };
    t.after(c);
    t.addEventListener('input', pintar);
    pintar();
  }
}

/* --- Cabecera: cambia de azul a sólida al pasar la portada ------------------ */
function cabecera() {
  const cab = $('.cabecera');
  if (!cab) return;
  const hero = $('.hero');
  const meta = $('meta[name="theme-color"][media*="light"]');
  if (hero && 'IntersectionObserver' in window) {
    const io = new IntersectionObserver(([e]) => {
      const solida = !e.isIntersecting;
      cab.classList.toggle('cabecera--solida', solida);
      if (meta) meta.content = solida ? '#ffffff' : '#2340F5';
    }, { rootMargin: `-${cab.offsetHeight}px 0px 0px 0px` });
    io.observe(hero);
  } else {
    let pendiente = false;
    const revisar = () => { cab.classList.toggle('cabecera--solida', scrollY > 4); pendiente = false; };
    addEventListener('scroll', () => { if (!pendiente) { pendiente = true; requestAnimationFrame(revisar); } }, { passive: true });
    revisar();
  }
}

/* --- Diálogos con animación de cierre ---------------------------------------- */
const anteriorFoco = new WeakMap();
function abrirDialogo(dlg, origen) {
  if (dlg.open) return;
  anteriorFoco.set(dlg, origen || document.activeElement);
  dlg.showModal();
  document.documentElement.style.overflow = 'hidden';
}
function cerrarDialogo(dlg) {
  if (!dlg.open || dlg.classList.contains('cerrando')) return;
  const fin = () => {
    dlg.classList.remove('cerrando');
    dlg.close();
  };
  if (menosMovimiento.matches) fin();
  else {
    dlg.classList.add('cerrando');
    dlg.addEventListener('animationend', fin, { once: true });
    setTimeout(() => dlg.open && fin(), 400);
  }
}
function prepararDialogo(dlg) {
  dlg.addEventListener('cancel', (e) => { e.preventDefault(); cerrarDialogo(dlg); });
  dlg.addEventListener('close', () => {
    document.documentElement.style.overflow = '';
    const f = anteriorFoco.get(dlg);
    if (f && document.contains(f)) f.focus({ preventScroll: true });
  });
  // Clic fuera del contenido (en el fondo) cierra
  dlg.addEventListener('pointerdown', (e) => { dlg._fondo = e.target === dlg; });
  dlg.addEventListener('click', (e) => { if (e.target === dlg && dlg._fondo) cerrarDialogo(dlg); });
  for (const b of $$('[data-cerrar]', dlg)) b.addEventListener('click', () => cerrarDialogo(dlg));
}

/* --- Buscador en vivo (patrón combobox de ARIA) ------------------------------ */
const cacheBusqueda = new Map();

class Buscador {
  constructor(form) {
    this.form = form;
    this.input = $('.buscador__input', form);
    this.panel = $('[data-panel]', form);
    this.lista = $('[role="listbox"]', form);
    this.estado = $('[data-estado]', form);
    this.limpiar = $('[data-limpiar]', form);
    this.enDialogo = form.classList.contains('buscador--dialogo');
    this.opciones = [];
    this.activo = -1;
    this.ctrl = null;
    this.temporizador = 0;
    if (this.enDialogo) this.panel.hidden = false;

    this.input.addEventListener('input', () => this.alEscribir());
    this.input.addEventListener('keydown', (e) => this.teclado(e));
    this.input.addEventListener('focus', () => { if (this.opciones.length && this.input.value.trim().length >= 2) this.abrir(); });
    this.limpiar?.addEventListener('click', () => {
      this.input.value = '';
      this.alEscribir();
      this.input.focus();
    });
    document.addEventListener('pointerdown', (e) => {
      if (!this.enDialogo && !this.form.contains(e.target)) this.cerrar();
    });
    this.form.addEventListener('focusout', (e) => {
      if (!this.enDialogo && e.relatedTarget && !this.form.contains(e.relatedTarget)) this.cerrar();
    });
    this.lista.addEventListener('pointermove', (e) => {
      const op = e.target.closest('[role="option"]');
      if (op) this.marcar(this.opciones.indexOf(op), false);
    });
  }

  alEscribir() {
    const q = this.input.value.trim();
    if (this.limpiar) this.limpiar.hidden = this.input.value === '';
    clearTimeout(this.temporizador);
    if (q.length < 2) {
      this.ctrl?.abort();
      this.pintar(null);
      return;
    }
    this.temporizador = setTimeout(() => this.buscar(q), 140);
  }

  async buscar(q) {
    if (cacheBusqueda.has(q)) return this.pintar(cacheBusqueda.get(q));
    this.ctrl?.abort();
    this.ctrl = new AbortController();
    const cargando = setTimeout(() => this.cargando(), 180);
    try {
      const r = await fetch(`${BASE}/api/buscar.php?q=${encodeURIComponent(q)}`, {
        signal: this.ctrl.signal,
        headers: { Accept: 'application/json' },
      });
      if (!r.ok) throw new Error(r.status);
      const datos = await r.json();
      cacheBusqueda.set(q, datos);
      if (q === this.input.value.trim()) this.pintar(datos);
    } catch (err) {
      if (err.name !== 'AbortError') {
        this.lista.innerHTML = `<p class="sug-vacio">No pudimos cargar sugerencias. Presiona Enter para buscar igual.</p>`;
        this.abrir();
      }
    } finally {
      clearTimeout(cargando);
    }
  }

  cargando() {
    this.lista.innerHTML = '<div class="sug-cargando" aria-hidden="true"><span></span><span></span><span></span></div>';
    this.opciones = [];
    this.abrir();
  }

  pintar(datos) {
    this.activo = -1;
    this.input.removeAttribute('aria-activedescendant');
    if (!datos) {
      this.lista.innerHTML = '';
      this.opciones = [];
      this.estado.textContent = '';
      this.cerrar();
      return;
    }
    const id = this.lista.id;
    let n = 0;
    let html = '';
    if (!datos.total) {
      html = `<p class="sug-vacio">No encontramos nada para <strong>“${esc(datos.q)}”</strong>. Prueba con otra palabra o presiona Enter para ver ideas.</p>`;
    } else {
      for (const g of datos.grupos) {
        const gid = `${id}-g-${g.tipo}`;
        html += `<div class="sug-grupo" role="group" aria-labelledby="${gid}">
          <div class="sug-grupo__titulo" id="${gid}"><span class="punto punto--${g.tipo}" aria-hidden="true"></span>${esc(g.etiqueta)} <span class="sr">, ${g.total} resultados</span>
          ${g.total > g.items.length ? `<a class="sug-grupo__mas" href="${esc(g.ver_mas)}" tabindex="-1">Ver ${g.total}</a>` : ''}</div>`;
        for (const it of g.items) {
          const extra = it.verificacion === 'enganoso'
            ? `<span class="sug__extra sug__extra--engano">${icono('alerta')}Engañoso</span>`
            : it.precio ? `<span class="sug__extra">${esc(it.precio)}</span>` : '<span></span>';
          const orient = it.orientacion ? ` <span aria-hidden="true">—</span> ${esc(it.orientacion)}` : '';
          html += `<a class="sug sug--${g.tipo}" role="option" id="${id}-o${n}" href="${esc(it.url)}" tabindex="-1" aria-selected="false" style="--i:${n}">
            <span class="sug__img" style="--ph:${esc(it.color)}"><img src="${esc(it.imagen)}" alt="" width="64" height="40" decoding="async"></span>
            <span><span class="sug__titulo">${it.titulo_html}</span><span class="sug__meta">${esc(it.etiqueta)}${it.detalle ? ` <span aria-hidden="true">—</span> ${esc(it.detalle)}` : ''}${orient}</span></span>
            ${extra}
          </a>`;
          n++;
        }
      }
      html += `<a class="sug sug--todo" role="option" id="${id}-o${n}" href="${esc(datos.ver_todo)}" tabindex="-1" aria-selected="false" style="--i:${n}">
        <span>Ver los ${datos.total} resultados para “${esc(datos.q)}”</span>${icono('flecha')}</a>`;
    }
    this.lista.innerHTML = html;
    this.opciones = $$('[role="option"]', this.lista);
    this.estado.textContent = datos.total
      ? `${datos.total} resultados. Usa las flechas para recorrerlos.`
      : `Sin resultados para ${datos.q}.`;
    this.abrir();
  }

  abrir() {
    if (this.enDialogo) {
      this.input.setAttribute('aria-expanded', String(this.opciones.length > 0));
      return;
    }
    if (this.panel.hidden) {
      this.panel.hidden = false;
      if (!menosMovimiento.matches) {
        this.panel.classList.add('abriendo');
        this.panel.addEventListener('animationend', () => this.panel.classList.remove('abriendo'), { once: true });
      }
    }
    this.input.setAttribute('aria-expanded', 'true');
  }

  cerrar() {
    if (!this.enDialogo) this.panel.hidden = true;
    this.input.setAttribute('aria-expanded', 'false');
    this.marcar(-1);
  }

  marcar(i, desplazar = true) {
    this.opciones[this.activo]?.setAttribute('aria-selected', 'false');
    this.activo = i;
    const op = this.opciones[i];
    if (op) {
      op.setAttribute('aria-selected', 'true');
      this.input.setAttribute('aria-activedescendant', op.id);
      if (desplazar) op.scrollIntoView({ block: 'nearest' });
    } else {
      this.input.removeAttribute('aria-activedescendant');
    }
  }

  teclado(e) {
    const total = this.opciones.length;
    const abierto = this.enDialogo || !this.panel.hidden;
    switch (e.key) {
      case 'ArrowDown':
        if (!total) return;
        e.preventDefault();
        if (!abierto) this.abrir();
        this.marcar(this.activo + 1 >= total ? 0 : this.activo + 1);
        break;
      case 'ArrowUp':
        if (!total) return;
        e.preventDefault();
        if (!abierto) this.abrir();
        this.marcar(this.activo - 1 < 0 ? total - 1 : this.activo - 1);
        break;
      case 'Home':
      case 'End':
        if (!total || this.activo < 0) return;
        e.preventDefault();
        this.marcar(e.key === 'Home' ? 0 : total - 1);
        break;
      case 'Enter':
        if (this.activo >= 0 && this.opciones[this.activo]) {
          e.preventDefault();
          location.assign(this.opciones[this.activo].href);
        }
        break;
      case 'Escape':
        if (this.enDialogo) {
          e.preventDefault();
          cerrarDialogo(this.form.closest('dialog'));
        } else if (abierto) {
          e.preventDefault();
          this.cerrar();
        } else if (!this.enDialogo && this.input.value) {
          e.preventDefault();
          this.input.value = '';
          this.alEscribir();
        }
        break;
    }
  }
}

/* Texto de ejemplo que se escribe solo en la portada */
function placeholderAnimado(input) {
  const ejemplos = ['video falso de la inundación', 'licitación pública', 'transporte gratuito', 'campaña de cuentas falsas', 'impuesto al patrimonio', 'cómo detectar un deepfake'];
  if (menosMovimiento.matches) return;
  let i = 0, j = 0, borrando = false, visible = true, t = 0;
  const original = input.placeholder;
  const paso = () => {
    if (!visible || document.activeElement === input || input.value) {
      input.placeholder = document.activeElement === input ? 'Escribe lo que buscas' : original;
      t = setTimeout(paso, 600);
      return;
    }
    const txt = ejemplos[i];
    j += borrando ? -1 : 1;
    input.placeholder = txt.slice(0, j) || ' ';
    let espera = borrando ? 28 : 62;
    if (!borrando && j >= txt.length) { borrando = true; espera = 1700; }
    else if (borrando && j <= 0) { borrando = false; i = (i + 1) % ejemplos.length; espera = 350; }
    t = setTimeout(paso, espera);
  };
  new IntersectionObserver(([e]) => { visible = e.isIntersecting; }).observe(input);
  document.addEventListener('visibilitychange', () => { clearTimeout(t); if (!document.hidden) t = setTimeout(paso, 400); });
  t = setTimeout(paso, 900);
}

function buscadores() {
  for (const form of $$('[data-buscador]')) new Buscador(form);
  const hero = $('[data-placeholder-animado]');
  if (hero) placeholderAnimado(hero);

  const dlg = $('#dlg-buscador');
  if (!dlg) return;
  prepararDialogo(dlg);
  const input = $('.buscador__input', dlg);
  const abrir = (origen) => {
    abrirDialogo(dlg, origen);
    requestAnimationFrame(() => { input.focus(); input.select(); });
  };
  for (const a of $$('[data-abrir-buscador]')) {
    a.addEventListener('click', (e) => {
      if (e.metaKey || e.ctrlKey || e.shiftKey) return;
      e.preventDefault();
      abrir(a);
    });
  }
  document.addEventListener('keydown', (e) => {
    const t = e.target;
    const escribiendo = t.isContentEditable || /^(input|textarea|select)$/i.test(t.tagName);
    if ((e.key === '/' && !escribiendo && !e.metaKey && !e.ctrlKey) || ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k')) {
      if ($('dialog[open]') && !dlg.open) return;
      e.preventDefault();
      const heroInput = $('#q-hero');
      if (heroInput && heroInput.getBoundingClientRect().bottom > 0 && !dlg.open) heroInput.focus();
      else abrir(document.activeElement);
    }
  });
}

/* --- Acceso: diálogo, pestañas y formularios ---------------------------------- */
function pestanas(raiz) {
  const tabs = $$('[role="tab"]', raiz);
  const activar = (tab, foco = true) => {
    for (const t of tabs) {
      const sel = t === tab;
      t.setAttribute('aria-selected', String(sel));
      t.tabIndex = sel ? 0 : -1;
      const panel = document.getElementById(t.getAttribute('aria-controls'));
      if (panel.hidden === sel) {
        panel.hidden = !sel;
        if (sel && !menosMovimiento.matches) {
          panel.classList.add('entrando');
          panel.addEventListener('animationend', () => panel.classList.remove('entrando'), { once: true });
        }
      }
    }
    raiz.dataset.activa = tab.dataset.tab;
    if (foco) tab.focus();
  };
  for (const t of tabs) {
    t.addEventListener('click', () => activar(t));
    t.addEventListener('keydown', (e) => {
      const i = tabs.indexOf(t);
      const sig = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: tabs.length - 1 }[e.key];
      if (sig === undefined) return;
      e.preventDefault();
      activar(tabs[(sig + tabs.length) % tabs.length]);
    });
  }
  const sel = tabs.find((t) => t.getAttribute('aria-selected') === 'true') || tabs[0];
  raiz.dataset.activa = sel.dataset.tab;
  return { activar: (nombre) => activar(tabs.find((t) => t.dataset.tab === nombre) || tabs[0], false) };
}

function errorCampo(input, msg) {
  const campo = input.closest('.campo');
  const p = $('.campo__error', campo);
  if (msg) {
    input.setAttribute('aria-invalid', 'true');
    if (p) { $('span', p).textContent = msg; p.hidden = false; }
  } else {
    input.removeAttribute('aria-invalid');
    if (p) p.hidden = true;
  }
}

function validar(form) {
  const errores = [];
  for (const input of $$('input[required]', form)) {
    const v = input.value.trim();
    let msg = '';
    if (!v) {
      msg = { email: 'Escribe tu correo.', clave: 'Escribe tu contraseña.', nombre: 'Escribe tu nombre.' }[input.name] || 'Completa este campo.';
    } else if (input.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) {
      msg = 'Escribe un correo válido, por ejemplo nombre@correo.cl.';
    } else if (input.minLength > 0 && input.value.length < input.minLength) {
      msg = `La contraseña debe tener al menos ${input.minLength} caracteres.`;
    }
    errorCampo(input, msg);
    if (msg) errores.push(input);
  }
  return errores;
}

function formulariosAcceso() {
  for (const raiz of $$('[data-pestanas]')) raiz._pestanas = pestanas(raiz);

  for (const form of $$('[data-form-acceso]')) {
    const general = $('[data-error-general]', form);
    const boton = $('[data-enviar]', form);
    for (const input of $$('input', form)) {
      input.addEventListener('input', () => { if (input.getAttribute('aria-invalid')) errorCampo(input, ''); });
    }
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      general.hidden = true;
      const invalidos = validar(form);
      if (invalidos.length) { invalidos[0].focus(); return; }
      boton.setAttribute('aria-busy', 'true');
      boton.disabled = true;
      try {
        const r = await fetch(form.action, {
          method: 'POST',
          body: new FormData(form),
          headers: { Accept: 'application/json', 'X-Requested-With': 'fetch' },
          credentials: 'same-origin',
        });
        const datos = await r.json();
        if (datos.ok) {
          irA(datos.redirigir);
          return;
        }
        if (datos.csrf) for (const c of $$('input[name="csrf"]')) c.value = datos.csrf;
        let primero = null;
        for (const [campo, msg] of Object.entries(datos.errores || {})) {
          const input = form.elements[campo];
          if (input) { errorCampo(input, msg); primero ||= input; }
        }
        if (datos.error && !primero) {
          $('span', general).textContent = datos.error;
          general.hidden = false;
          general.classList.remove('sacudir');
          void general.offsetWidth;
          general.classList.add('sacudir');
          const clave = form.elements.clave;
          if (clave) { clave.value = ''; clave.focus(); }
        } else primero?.focus();
      } catch {
        $('span', general).textContent = 'No hay conexión con el servidor. Revisa tu internet y vuelve a intentarlo.';
        general.hidden = false;
      } finally {
        boton.removeAttribute('aria-busy');
        boton.disabled = false;
      }
    });
  }

  // Mostrar u ocultar contraseña
  for (const b of $$('[data-ver-clave]')) {
    b.addEventListener('click', () => {
      const input = $('input', b.parentElement);
      const ver = input.type === 'password';
      input.type = ver ? 'text' : 'password';
      b.setAttribute('aria-pressed', String(ver));
      input.focus();
    });
  }

  // Cuenta de prueba
  for (const b of $$('[data-usar-demo]')) {
    b.addEventListener('click', () => {
      const form = b.closest('form');
      form.elements.email.value = b.dataset.email;
      form.elements.clave.value = b.dataset.clave;
      form.requestSubmit();
    });
  }

  // Medidor de contraseña
  for (const input of $$('[data-medidor]')) {
    const m = $('.medidor', input.closest('.campo'));
    input.addEventListener('input', () => {
      const v = input.value;
      let nivel = 0;
      if (v.length >= 8) nivel = 1;
      if (nivel && /[a-z]/i.test(v) && /\d/.test(v)) nivel = 2;
      if (nivel === 2 && v.length >= 12 && (/[^a-z0-9]/i.test(v) || /[A-Z]/.test(v))) nivel = 3;
      m.dataset.nivel = v ? Math.max(1, nivel) : 0;
    });
  }

  // Diálogo de acceso
  const dlg = $('#dlg-acceso');
  if (!dlg) return;
  prepararDialogo(dlg);
  const motivo = $('[data-motivo-texto]', dlg);
  const motivoBase = motivo.textContent;
  const pest = $('[data-pestanas]', dlg)._pestanas;
  for (const a of $$('[data-acceso]')) {
    a.addEventListener('click', (e) => {
      if (e.metaKey || e.ctrlKey || e.shiftKey) return;
      e.preventDefault();
      motivo.textContent = a.dataset.motivo ? `${a.dataset.motivo} Con una cuenta gratis también ves:` : motivoBase;
      const volver = new URL(a.href, location.href).searchParams.get('volver') || location.pathname + location.search;
      for (const v of $$('[data-volver]', dlg)) v.value = volver;
      for (const err of $$('[data-error-general]', dlg)) err.hidden = true;
      pest.activar(a.dataset.pestana || 'entrar');
      abrirDialogo(dlg, a);
      requestAnimationFrame(() => {
        const panel = $('[role="tabpanel"]:not([hidden])', dlg);
        $('input:not([type="hidden"])', panel)?.focus();
      });
    });
  }
}

/** Navega al destino; si es la misma página, recarga para mostrar el contenido desbloqueado. */
function irA(destino) {
  const url = new URL(destino || location.href, location.href);
  const mismaPagina = url.pathname === location.pathname && url.search === location.search;
  if (mismaPagina) {
    if (url.hash) history.replaceState(null, '', url.hash);
    location.reload();
  } else {
    location.assign(url.href);
  }
}

/* --- Galería de producto ---------------------------------------------------- */
function galerias() {
  for (const g of $$('[data-galeria]')) {
    const imgs = $$('.galeria__img', g);
    const minis = $$('.galeria__mini', g);
    imgs.forEach((im, i) => {
      im.hidden = false;
      if (i) im.setAttribute('aria-hidden', 'true');
    });
    const mostrar = (i) => {
      imgs.forEach((im, k) => {
        const activa = k === i;
        im.toggleAttribute('data-activa', activa);
        if (activa) im.removeAttribute('aria-hidden'); else im.setAttribute('aria-hidden', 'true');
        const img = $('img', im);
        if (activa && img.loading === 'lazy') img.loading = 'eager';
      });
      minis.forEach((m, k) => m.setAttribute('aria-pressed', String(k === i)));
      const c = $('[data-contador]', g);
      if (c) c.textContent = `${i + 1} / ${imgs.length}`;
    };
    minis.forEach((m, i) => {
      m.addEventListener('click', () => mostrar(i));
      m.addEventListener('keydown', (e) => {
        const d = { ArrowRight: 1, ArrowLeft: -1 }[e.key];
        if (!d) return;
        e.preventDefault();
        const sig = (i + d + minis.length) % minis.length;
        minis[sig].focus();
        mostrar(sig);
      });
    });
  }
}

/* --- Carrusel de videos ----------------------------------------------------- */
function carruseles() {
  for (const ctrl of $$('[data-carrusel-controles]')) {
    const rail = document.getElementById(ctrl.dataset.carruselControles);
    if (!rail) continue;
    const [prev, next] = $$('button', ctrl);
    const estado = () => {
      prev.disabled = rail.scrollLeft < 8;
      next.disabled = rail.scrollLeft + rail.clientWidth >= rail.scrollWidth - 8;
    };
    for (const b of [prev, next]) {
      b.addEventListener('click', () => rail.scrollBy({
        left: Number(b.dataset.dir) * rail.clientWidth * 0.8,
        behavior: menosMovimiento.matches ? 'auto' : 'smooth',
      }));
    }
    let pendiente = false;
    rail.addEventListener('scroll', () => {
      if (pendiente) return;
      pendiente = true;
      requestAnimationFrame(() => { estado(); pendiente = false; });
    }, { passive: true });
    addEventListener('resize', estado, { passive: true });
    estado();
  }
}

/* --- Avisos ------------------------------------------------------------------ */
function avisos() {
  const cont = $('[data-avisos]');
  if (!cont) return;
  for (const [i, a] of $$('.aviso', cont).entries()) {
    const quitar = () => {
      a.classList.add('saliendo');
      a.addEventListener('animationend', () => a.remove(), { once: true });
      setTimeout(() => a.remove(), 500);
    };
    a.addEventListener('click', quitar);
    setTimeout(quitar, 5200 + i * 600);
  }
}

/* --- Formularios que se envían solos (ordenar) -------------------------------- */
function autoenviar() {
  for (const f of $$('[data-autoenviar]')) {
    f.addEventListener('change', () => f.requestSubmit());
  }
}

/* --- Filtros de la galería ------------------------------------------------------ */
function filtros() {
  const form = $('[data-filtros]');
  if (!form) return;
  const boton = $('[data-filtros-toggle]', form);
  const panel = $('[data-filtros-panel]', form);
  const estado = $('[data-panel-estado]', form);
  const abrir = (si) => {
    boton.setAttribute('aria-expanded', String(si));
    panel.toggleAttribute('data-cerrado', !si);
    estado.disabled = !si;
  };
  abrir(boton.getAttribute('aria-expanded') === 'true');
  boton.addEventListener('click', () => {
    const si = boton.getAttribute('aria-expanded') !== 'true';
    abrir(si);
    if (si) $('input', panel)?.focus();
  });
  // Cada cambio aplica el filtro al instante (sin JavaScript, se usa el botón "Aplicar filtros").
  let t = 0;
  form.addEventListener('change', (e) => {
    if (!e.target.matches('input, select')) return;
    clearTimeout(t);
    t = setTimeout(() => form.requestSubmit(), e.target.type === 'checkbox' ? 350 : 0);
  });
  panel.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { abrir(false); boton.focus(); }
  });
}

/* --- Descripción plegable (como en las plataformas de video) --------------------- */
function descripciones() {
  for (const d of $$('[data-plegable]')) {
    if (d.scrollHeight < 120) continue;
    d.setAttribute('data-plegado', '');
    d.id ||= 'desc-' + Math.random().toString(36).slice(2, 8);
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'descripcion__mas';
    b.setAttribute('aria-expanded', 'false');
    b.setAttribute('aria-controls', d.id);
    b.textContent = 'Mostrar más';
    b.addEventListener('click', () => {
      const abierto = d.toggleAttribute('data-plegado') === false;
      b.setAttribute('aria-expanded', String(abierto));
      b.textContent = abierto ? 'Mostrar menos' : 'Mostrar más';
    });
    d.after(b);
  }
}

/* --- Compartir: copia el enlace (o usa el menú del sistema en móviles) ------------- */
function compartir() {
  for (const b of $$('[data-compartir]')) {
    const txt = $('[data-compartir-txt]', b);
    b.addEventListener('click', async () => {
      const url = location.href.split('#')[0];
      if (navigator.share && matchMedia('(pointer: coarse)').matches) {
        try { await navigator.share({ title: b.dataset.titulo, url }); return; } catch { /* cancelado */ }
      }
      try {
        await navigator.clipboard.writeText(url);
        txt.textContent = 'Enlace copiado';
      } catch {
        txt.textContent = 'Copia la dirección del navegador';
      }
      setTimeout(() => { txt.textContent = 'Copiar enlace'; }, 2200);
    });
  }
}

/* --- Animación de desbloqueo después de iniciar sesión ----------------------- */
function desbloqueo() {
  if (!document.body.hasAttribute('data-desbloqueo')) return;
  setTimeout(() => document.body.removeAttribute('data-desbloqueo'), 2600);
}

/* --- Precarga de páginas internas al pasar el cursor ------------------------- */
function precarga() {
  if (navigator.connection?.saveData) return;
  const hechas = new Set();
  let t = 0;
  const precargar = (a) => {
    const url = new URL(a.href, location.href);
    if (url.origin !== location.origin || hechas.has(url.href) || /(ir|salir|stream)\.php/.test(url.pathname) || url.href === location.href) return;
    hechas.add(url.href);
    const l = document.createElement('link');
    l.rel = 'prefetch';
    l.href = url.href;
    document.head.append(l);
  };
  document.addEventListener('pointerover', (e) => {
    const a = e.target.closest('a[href]');
    if (!a) return;
    clearTimeout(t);
    t = setTimeout(() => precargar(a), 70);
  }, { passive: true });
  document.addEventListener('touchstart', (e) => {
    const a = e.target.closest('a[href]');
    if (a) precargar(a);
  }, { passive: true });
}

/* --- Confirmación accesible (reemplaza a confirm()) ---------------------------- */
function confirmar(mensaje, aceptar = 'Eliminar') {
  return new Promise((resolver) => {
    const dlg = document.createElement('dialog');
    dlg.className = 'dlg dlg-confirmar';
    dlg.setAttribute('aria-labelledby', 'conf-titulo');
    dlg.innerHTML = `<div class="confirmar">
      <span class="confirmar__ico">${icono('alerta')}</span>
      <h2 class="confirmar__titulo" id="conf-titulo">${esc(mensaje)}</h2>
      <div class="confirmar__botones">
        <button class="boton boton--suave" type="button" value="no">Cancelar</button>
        <button class="boton boton--peligro" type="button" value="si">${esc(aceptar)}</button>
      </div></div>`;
    document.body.append(dlg);
    const cerrar = (v) => { dlg.close(); dlg.remove(); resolver(v); };
    dlg.addEventListener('click', (e) => {
      const b = e.target.closest('button');
      if (b) cerrar(b.value === 'si');
      else if (e.target === dlg) cerrar(false);
    });
    dlg.addEventListener('cancel', (e) => { e.preventDefault(); cerrar(false); });
    dlg.showModal();
    $('button[value="no"]', dlg).focus();
  });
}

function confirmaciones() {
  for (const f of $$('form[data-confirmar]')) {
    f.addEventListener('submit', async (e) => {
      if (f.dataset.confirmado) return;
      e.preventDefault();
      const boton = e.submitter;
      const txt = boton?.textContent.trim().split(' ')[0] || 'Confirmar';
      if (await confirmar(f.dataset.confirmar, /quitar|hacer/i.test(txt) ? 'Confirmar' : 'Eliminar')) {
        f.dataset.confirmado = '1';
        f.requestSubmit(boton);
      }
    });
  }
}


/* --- Asistente de preguntas rápidas ------------------------------------------------
   Responde según la página: la publicación abierta, la sección o la portada. La conversación
   se guarda solo en esta pestaña (sessionStorage) y se borra al cambiar de cuenta. */
function asistente() {
  const panel = $('[data-asis]');
  const lanzar = $('[data-asis-lanzar]');
  if (!panel || !lanzar || !window.fetch) return;
  const log = $('[data-asis-log]', panel);
  const form = $('[data-asis-form]', panel);
  const input = $('#asis-q', panel);
  const enviarBtn = $('.asis__enviar', panel);
  const sugs = $('[data-asis-sug]', panel);
  const lugar = $('[data-asis-lugar]', panel).textContent;
  const { clave, sesion, bienvenida } = panel.dataset;
  const CLAVE = 'sf-asistente';
  const MAX = 40;
  const hayVoz = 'speechSynthesis' in window;
  let estado = { sesion, items: [], abierto: false };
  let ocupado = false;
  let n = 0;

  try {
    const g = JSON.parse(sessionStorage.getItem(CLAVE) || 'null');
    if (g && g.sesion === sesion && Array.isArray(g.items)) estado = { sesion, items: g.items.slice(-MAX), abierto: !!g.abierto };
  } catch { /* sin almacenamiento: la conversación dura lo que dure la página */ }
  const guardar = () => {
    estado.items = estado.items.slice(-MAX);
    try { sessionStorage.setItem(CLAVE, JSON.stringify(estado)); } catch { /* sin almacenamiento */ }
  };

  // Solo enlaces del propio sitio (los externos pasan por ir.php, que exige sesión)
  const seguro = (u) => {
    try { const x = new URL(u, location.href); return x.origin === location.origin ? x.href : null; } catch { return null; }
  };
  const el = (tag, clase, texto) => {
    const e = document.createElement(tag);
    if (clase) e.className = clase;
    if (texto != null) e.textContent = texto;
    return e;
  };
  const pintar = (m) => {
    if (m.de === 'lugar') {
      const p = el('p', 'asis-cambio');
      p.append('Ahora estás en ', el('strong', '', m.texto));
      return p;
    }
    const caja = el('div', `asis-msj asis-msj--${m.de}`);
    const p = el('p', 'asis-msj__txt');
    const id = `asis-m-${++n}`;
    p.append(el('span', 'sr', m.de === 'yo' ? 'Tú: ' : 'Asistente: '));
    const t = el('span', '', m.texto);
    t.id = id;
    p.append(t);
    caja.append(p);
    const enlaces = (m.enlaces || []).map((l) => ({ ...l, url: seguro(l.url) })).filter((l) => l.url);
    if (enlaces.length) {
      const ul = el('ul', 'asis-msj__enlaces');
      for (const l of enlaces) {
        const a = el('a', '', l.texto);
        a.href = l.url;
        if (l.externo) {
          a.target = '_blank';
          a.rel = 'noopener nofollow';
          a.insertAdjacentHTML('beforeend', icono('externo'));
          a.append(el('span', 'sr', ' (se abre en una pestaña nueva)'));
        }
        const li = el('li');
        li.append(a);
        ul.append(li);
      }
      caja.append(ul);
    }
    if (m.de === 'bot' && hayVoz) {
      const b = el('button', 'boton-texto asis-msj__escuchar');
      b.type = 'button';
      b.dataset.leer = `#${id}`;
      b.dataset.leerTitulo = 'Respuesta del asistente';
      b.setAttribute('aria-pressed', 'false');
      b.innerHTML = `${icono('altavoz')}Escuchar<span class="sr"> la respuesta</span>`;
      caja.append(b);
    }
    return caja;
  };
  const alFinal = () => { log.scrollTop = log.scrollHeight; };
  const agregar = (m, guardarlo = true) => {
    log.append(pintar(m));
    if (guardarlo && m.de !== 'error') { estado.items.push(m); guardar(); }
    alFinal();
  };
  const sugerencias = (lista) => {
    if (!Array.isArray(lista)) return;
    sugs.replaceChildren(...lista.slice(0, 6).map((s) => {
      const b = el('button', 'asis__chip', s);
      b.type = 'button';
      b.dataset.asisSugerencia = '';
      return b;
    }));
  };
  // Al llegar a otra página se marca el cambio de lugar y se saluda con el contexto nuevo
  const preparar = () => {
    const ultimo = [...estado.items].reverse().find((m) => m.clave);
    if (!ultimo || ultimo.clave !== clave) {
      if (estado.items.length) estado.items.push({ de: 'lugar', texto: lugar });
      estado.items.push({ de: 'bot', texto: bienvenida, clave });
      guardar();
    }
    log.replaceChildren(...estado.items.map(pintar));
  };

  lanzar.setAttribute('role', 'button');
  lanzar.setAttribute('aria-expanded', 'false');
  const abrir = (foco = true) => {
    if (!panel.hidden) return;
    preparar(); // antes de mostrarlo: el historial no se vuelve a anunciar
    panel.hidden = false;
    lanzar.setAttribute('aria-expanded', 'true');
    document.body.classList.add('asis-abierto');
    estado.abierto = true;
    guardar();
    alFinal();
    if (foco) input.focus({ preventScroll: true });
  };
  const cerrar = (foco = true) => {
    if (panel.hidden) return;
    panel.hidden = true;
    lanzar.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('asis-abierto');
    estado.abierto = false;
    guardar();
    if (foco) lanzar.focus({ preventScroll: true });
  };
  lanzar.addEventListener('click', (e) => {
    if (e.ctrlKey || e.metaKey || e.shiftKey || e.button !== 0) return; // abrir la página del asistente en otra pestaña sigue funcionando
    e.preventDefault();
    if (panel.hidden) abrir(); else cerrar();
  });
  lanzar.addEventListener('keydown', (e) => { if (e.key === ' ') { e.preventDefault(); lanzar.click(); } });
  $('[data-asis-cerrar]', panel).addEventListener('click', () => cerrar());
  panel.addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.stopPropagation(); cerrar(); } });
  $('[data-asis-limpiar]', panel).addEventListener('click', () => {
    estado.items = [];
    guardar();
    preparar();
    anunciar('Conversación borrada.');
    input.focus();
  });
  panel.addEventListener('click', (e) => {
    const b = e.target.closest('[data-asis-sugerencia]');
    if (!b || ocupado) return;
    input.value = b.textContent.trim();
    form.requestSubmit();
  });

  const pedir = async (datos, reintento = false) => {
    const r = await fetch(form.action, {
      method: 'POST',
      body: datos,
      headers: { Accept: 'application/json', 'X-Requested-With': 'fetch' },
      credentials: 'same-origin',
    });
    const j = await r.json().catch(() => ({}));
    // La sesión se renovó (por ejemplo, tras iniciar sesión en otra pestaña): se reintenta una vez con el token nuevo
    if (r.status === 403 && j.csrf && !reintento) {
      for (const c of $$('input[name="csrf"]')) c.value = j.csrf;
      datos.set('csrf', j.csrf);
      return pedir(datos, true);
    }
    return j;
  };
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const texto = input.value.trim();
    if (!texto || ocupado) return;
    ocupado = true;
    form.setAttribute('aria-busy', 'true');
    enviarBtn.disabled = true;
    const datos = new FormData(form);
    input.value = '';
    agregar({ de: 'yo', texto });
    const escribiendo = el('div', 'asis-escribiendo');
    escribiendo.setAttribute('aria-hidden', 'true');
    escribiendo.append(el('i'), el('i'), el('i'));
    log.append(escribiendo);
    alFinal();
    try {
      const j = await pedir(datos);
      escribiendo.remove();
      if (j.ok) {
        for (const m of j.mensajes || []) agregar({ de: 'bot', texto: String(m.texto || ''), enlaces: m.enlaces || [] });
        sugerencias(j.sugerencias);
      } else {
        agregar({ de: 'error', texto: j.error || 'No pude responder. Vuelve a intentarlo.' });
      }
    } catch {
      escribiendo.remove();
      agregar({ de: 'error', texto: 'Sin conexión con el servidor. Revisa tu internet y vuelve a intentarlo.' });
    } finally {
      ocupado = false;
      form.removeAttribute('aria-busy');
      enviarBtn.disabled = false;
      input.focus({ preventScroll: true });
    }
  });

  // Si la persona lo dejó abierto y siguió un enlace del asistente, sigue abierto en pantallas anchas
  if (estado.abierto && matchMedia('(min-width: 760px)').matches) abrir(false);
  else if (estado.abierto) { estado.abierto = false; guardar(); }
}

/* --- Inicio ------------------------------------------------------------------- */
imagenes();
tema();
cabecera();
buscadores();
formulariosAcceso();
galerias();
carruseles();
avisos();
autoenviar();
filtros();
descripciones();
compartir();
desbloqueo();
precarga();
confirmaciones();
preferencias();
lector();
contadores();
youtube();
vistas();
asistente();
