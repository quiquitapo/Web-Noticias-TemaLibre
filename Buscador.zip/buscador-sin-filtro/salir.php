<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

if (!es_post()) {
    redirigir(url(sesion_iniciada() ? 'cuenta.php' : ''));
}
if (!csrf_valido()) {
    flash('error', 'No pudimos cerrar la sesión. Vuelve a intentarlo.');
    redirigir(url('cuenta.php'));
}
cerrar_sesion();
session_start();
flash('info', 'Cerraste sesión. Puedes seguir explorando sin cuenta.');
redirigir(url());
