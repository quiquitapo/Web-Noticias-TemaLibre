<?php
/** Compatibilidad con la versión anterior: las noticias ahora viven dentro de Videos. */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
redirigir(url('videos.php', ['cat' => 'noticias']), 301);
