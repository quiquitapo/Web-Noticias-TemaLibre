<?php
/** Ver una publicación: video, fotos o noticia. */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

// Publicaciones de ejemplo que cambiaron de dirección al pasar a videos reales de YouTube
const SLUGS_ANTERIORES = [
    'kardashev-imperio-de-vael' => 'escala-de-kardashev-explicada',
    'cinco-mitos-desmentidos' => 'mitos-cientificos-falsos',
    'orbita-muda-resumen-temporada-1' => 'stranger-things-resumen-temporada-1',
    'teoria-luna-de-kaiju' => 'teorias-one-piece',
];
$p = publicacion_por_slug(entrada('v'));
if (!$p && isset(SLUGS_ANTERIORES[entrada('v')]) && publicacion_por_slug(SLUGS_ANTERIORES[entrada('v')])) {
    redirigir(url('video.php', ['v' => SLUGS_ANTERIORES[entrada('v')]]), 301);
}
$p ??= no_encontrado();
$id = (int) $p['id'];
$imgs = imagenes_de($id);
$redes = redes_de($id);
$prensa = prensa_de($id);
// Vista elegida: el contenido principal (video, fotos o noticia) o las noticias de prensa sobre el mismo tema
$vistaPrensa = $prensa && entrada('vista') === 'noticias';
$persp = perspectivas($p);
$rel = relacionadas($p, array_column($persp, 'id'));
$usuario = usuario_actual();
$conSesion = $usuario !== null;
$enganoso = $p['verificacion'] === 'enganoso';
$ficha = $p['ficha'] ? (json_decode((string) $p['ficha'], true) ?: []) : [];
$antes = $p['precio_antes'] !== null ? (int) $p['precio_antes'] : null;
$desc = $p['precio'] !== null ? descuento((int) $p['precio'], $antes) : 0;
$etiquetas = array_filter(array_map('trim', explode(',', (string) $p['etiquetas'])));
contar_vista($p);
// Un archivo propio tiene prioridad sobre YouTube (no sale tráfico a terceros)
$esYoutube = $p['tipo'] === 'video' && !$p['video_archivo'] && !empty($p['youtube_id']);
$sinArchivo = $p['tipo'] === 'video' && !$p['video_archivo'] && !$esYoutube;
if ($conSesion && $p['tipo'] === 'video' && !$sinArchivo) {
    registrar_clic($usuario, $id, 'video');
}

$jsonLd = match ($sinArchivo ? 'imagen' : $p['tipo']) {
    'video' => ['@type' => 'VideoObject', 'name' => $p['titulo'], 'description' => recortar($p['descripcion'], 300),
        'thumbnailUrl' => [url_absoluta(imagen($p['miniatura'], 1600))], 'uploadDate' => fecha_iso($p['publicado_en']),
        'duration' => 'PT' . (int) $p['duracion_seg'] . 'S'],
    'noticia' => ['@type' => 'NewsArticle', 'headline' => $p['titulo'], 'description' => $p['descripcion'],
        'image' => [url_absoluta(imagen($p['miniatura'], 1600))], 'datePublished' => fecha_iso($p['publicado_en']),
        'author' => ['@type' => 'Organization', 'name' => $p['creador']]],
    default => ['@type' => 'ImageGallery', 'name' => $p['titulo'], 'description' => recortar($p['descripcion'], 300)],
};
vista('cabecera', [
    'titulo' => $p['titulo'],
    'sin_indexar' => $vistaPrensa,
    'seccion' => 'videos',
    'nav_activo' => nav_de_seccion($p['padre_slug'] ?: $p['categoria_slug']),
    'descripcion' => recortar($p['descripcion'], 160),
    'og_tipo' => $p['tipo'] === 'noticia' ? 'article' : ($p['tipo'] === 'video' ? 'video.other' : 'website'),
    'og_imagen' => url_absoluta(imagen($p['miniatura'], 1600)),
    'json_ld' => ['@context' => 'https://schema.org'] + $jsonLd,
]);
$videoSrc = static fn(array $extra = []) => url('stream.php', ['v' => $p['slug']] + $extra);
?>
<div class="ver">
  <div class="ver__principal">
    <?php if ($enganoso): ?>
      <div class="alerta-engano" role="note" aria-labelledby="engano-titulo">
        <?= icono('alerta') ?>
        <div>
          <h2 class="alerta-engano__titulo" id="engano-titulo">Contenido engañoso</h2>
          <p><?= e($p['verificacion_nota'] ?: VERIFICACIONES['enganoso'][1]) ?></p>
          <a class="enlace" href="<?= e(url('videos.php', ['cat' => 'verificacion'])) ?>">Ver verificaciones</a>
        </div>
      </div>
    <?php endif; ?>

    <?php if ($prensa): ?>
      <nav class="vista-sel" aria-label="Cómo quieres ver esta publicación" data-vista-sel>
        <a class="vista-sel__op" href="<?= e(url_publicacion($p)) ?>" data-vista="principal"<?= $vistaPrensa ? '' : ' aria-current="true"' ?>>
          <?= icono(['video' => 'video', 'imagen' => 'fotos', 'noticia' => 'noticia'][$p['tipo']] ?? 'video') ?><?= e(['video' => 'Video', 'imagen' => 'Fotos', 'noticia' => 'Noticia'][$p['tipo']] ?? 'Publicación') ?>
        </a>
        <a class="vista-sel__op" href="<?= e(url('video.php', ['v' => $p['slug'], 'vista' => 'noticias'])) ?>" data-vista="noticias"<?= $vistaPrensa ? ' aria-current="true"' : '' ?>>
          <?= icono('periodico') ?>Noticias en la prensa<span class="vista-sel__n"><?= count($prensa) ?></span>
        </a>
      </nav>
    <?php endif; ?>

    <div class="ver__media ver__media--<?= e($p['tipo']) ?>" id="reproductor" data-vista-panel="principal"<?= $vistaPrensa ? ' hidden' : '' ?>>
      <?php if ($sinArchivo): ?>
        <div class="reproductor__bloqueado reproductor__bloqueado--sin-archivo">
          <?= img($p['miniatura'], [960, 1600], '(min-width: 1100px) 860px, 100vw', '', 1600, 900, $p['miniatura_color'], ['prioridad' => true, 'vt' => 'pub-' . $id]) ?>
          <p class="reproductor__aviso"><?= icono('video') ?><span>Video no disponible: esta publicación conserva su miniatura, descripción y enlaces.<?php if ($usuario && $usuario['rol'] === 'admin'): ?> <a href="<?= e(url('admin/publicar.php', ['id' => $id])) ?>">Subir el archivo</a><?php endif; ?></span></p>
        </div>
      <?php elseif ($p['tipo'] === 'video'): ?>
        <?php if ($conSesion && $esYoutube): ?>
          <?php $ytHtml = '<div class="yt" data-yt="' . e((string) $p['youtube_id']) . '" data-yt-titulo="' . e($p['titulo']) . '">'
              . img($p['miniatura'], [960, 1600], '(min-width: 1100px) 860px, 100vw', '', 1600, 900, $p['miniatura_color'], ['prioridad' => true, 'clase' => 'yt__img', 'vt' => 'pub-' . $id])
              . '<a class="yt__play" href="' . e(url('ir.php', ['t' => 'youtube', 'id' => $id])) . '" target="_blank" rel="noopener" data-yt-play data-desbloqueado>'
              . '<span class="yt__boton" aria-hidden="true">' . icono('play') . '</span><span class="yt__txt">Reproducir<span class="sr"> «' . e($p['titulo']) . '»</span></span></a>'
              . '<p class="yt__nota">' . icono('candado-privado') . '<span>Se carga desde YouTube, en modo de privacidad mejorada, solo cuando pulsas reproducir.</span></p>'
              . '</div>'; ?>
          <?php if ($enganoso): ?>
            <details class="velo">
              <summary class="velo__resumen">
                <?= img($p['miniatura'], [960, 1600], '(min-width: 1100px) 860px, 100vw', '', 1600, 900, $p['miniatura_color'], ['prioridad' => true, 'clase' => 'velo__img']) ?>
                <span class="velo__capa"><?= icono('alerta') ?><strong>Este video fue marcado como engañoso</strong><span class="boton boton--blanco">Verlo de todas formas</span></span>
              </summary>
              <?= $ytHtml ?>
            </details>
          <?php else: ?>
            <?= $ytHtml ?>
          <?php endif; ?>
        <?php elseif ($conSesion && $p['video_archivo']): ?>
          <?php $videoHtml = '<video class="reproductor__video" controls playsinline preload="metadata" width="1280" height="720" poster="' . e(imagen($p['miniatura'], 1600)) . '" style="view-transition-name: pub-' . $id . '" data-desbloqueado>'
              . ($p['video_webm'] ? '<source src="' . e($videoSrc(['formato' => 'webm'])) . '" type="video/webm">' : '')
              . '<source src="' . e($videoSrc()) . '" type="' . (str_ends_with((string) $p['video_archivo'], '.webm') ? 'video/webm' : 'video/mp4') . '">'
              . ($p['subtitulos'] ? '<track kind="captions" src="' . e($videoSrc(['pista' => 'vtt'])) . '" srclang="es" label="Español" default>' : '')
              . 'Tu navegador no puede reproducir este video.</video>'; ?>
          <?php if ($enganoso): ?>
            <details class="velo">
              <summary class="velo__resumen">
                <?= img($p['miniatura'], [960, 1600], '(min-width: 1100px) 860px, 100vw', '', 1600, 900, $p['miniatura_color'], ['prioridad' => true, 'clase' => 'velo__img']) ?>
                <span class="velo__capa"><?= icono('alerta') ?><strong>Este video fue marcado como engañoso</strong><span class="boton boton--blanco">Verlo de todas formas</span></span>
              </summary>
              <?= $videoHtml ?>
            </details>
          <?php else: ?>
            <?= $videoHtml ?>
          <?php endif; ?>
        <?php else: ?>
          <div class="reproductor__bloqueado">
            <?= img($p['miniatura'], [960, 1600], '(min-width: 1100px) 860px, 100vw', '', 1600, 900, $p['miniatura_color'], ['prioridad' => true, 'vt' => 'pub-' . $id]) ?>
            <div class="reproductor__capa">
              <span class="reproductor__candado" aria-hidden="true"><?= icono('candado') ?></span>
              <h2 class="reproductor__titulo">Inicia sesión para ver este video</h2>
              <p class="reproductor__txt">Es gratis.<?= (int) $p['duracion_seg'] > 0 ? ' Dura ' . e(duracion_texto((int) $p['duracion_seg'])) . ($p['subtitulos'] ? ' y tiene subtítulos en español' : '') . '.' : '' ?><?= $esYoutube ? ' Se reproduce desde YouTube, sin rastreo hasta que pulses reproducir.' : '' ?></p>
              <div class="reproductor__botones">
                <a class="boton boton--blanco" href="<?= e(url_acceso('video', 'reproductor')) ?>" data-acceso data-motivo="Inicia sesión para ver el video «<?= e($p['titulo']) ?>».">Iniciar sesión</a>
                <a class="boton boton--transparente" href="<?= e(url('registro.php', ['volver' => url_actual()])) ?>" data-acceso data-pestana="registro" data-motivo="Crea tu cuenta gratis para ver el video «<?= e($p['titulo']) ?>».">Crear cuenta</a>
              </div>
            </div>
          </div>
        <?php endif; ?>
      <?php elseif ($p['tipo'] === 'imagen' && $imgs): ?>
        <div class="galeria galeria--ancha" data-galeria>
          <div class="galeria__principal">
            <?php foreach ($imgs as $i => $im): ?>
              <div class="galeria__img" id="galeria-<?= $i ?>"<?= $i === 0 ? ' data-activa' : ' hidden' ?>>
                <?= img($im['base'], [400, 800, 1200], '(min-width: 1100px) 860px, 100vw', $im['alt'] ?: $p['titulo'], 1200, 1200, $im['color'], ['prioridad' => $i === 0, 'lazy' => $i !== 0, 'vt' => $i === 0 ? 'pub-' . $id : null]) ?>
              </div>
            <?php endforeach; ?>
            <span class="galeria__contador" aria-hidden="true" data-contador>1 / <?= count($imgs) ?></span>
          </div>
          <?php if (count($imgs) > 1): ?>
            <div class="galeria__miniaturas" role="group" aria-label="Fotos de la publicación">
              <?php foreach ($imgs as $i => $im): ?>
                <button class="galeria__mini" type="button" aria-controls="galeria-<?= $i ?>" aria-pressed="<?= $i === 0 ? 'true' : 'false' ?>" data-indice="<?= $i ?>">
                  <?= img($im['base'], [400], '88px', '', 400, 400, $im['color']) ?><span class="sr">Ver foto <?= $i + 1 ?>: <?= e($im['alt']) ?></span>
                </button>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      <?php else: ?>
        <figure class="ver__portada"><?= img($p['miniatura'], [960, 1600], '(min-width: 1100px) 860px, 100vw', '', 1600, 900, $p['miniatura_color'], ['prioridad' => true, 'vt' => 'pub-' . $id]) ?></figure>
      <?php endif; ?>
    </div>
    <?php if ($prensa) { vista('prensa', ['prensa' => $prensa, 'p' => $p, 'oculta' => !$vistaPrensa]); } ?>

    <h1 class="ver__titulo" id="ver-titulo"><?= e($p['titulo']) ?></h1>

    <div class="ver__barra">
      <p class="ver__creador">
        <span class="avatar-creador avatar-creador--grande" style="--av: <?= e(color_avatar($p['creador'])) ?>" aria-hidden="true"><?= e(iniciales($p['creador'])) ?></span>
        <span class="ver__creador-txt">
          <a class="ver__creador-nombre" href="<?= e(url('videos.php', ['creador' => $p['creador']])) ?>"><?= e($p['creador']) ?></a>
          <span class="ver__subido">Subido por <?= e($p['subido_por'] ?: 'la administración') ?></span>
        </span>
      </p>
      <div class="ver__acciones">
        <button class="boton boton--suave" type="button" data-leer="#ver-titulo, #desc-texto<?= $p['tipo'] === 'noticia' && $p['cuerpo'] ? ', #noticia-cuerpo' : '' ?>" data-leer-titulo="<?= e($p['titulo']) ?>" hidden><?= icono('altavoz') ?>Escuchar<span class="sr"> <?= $p['tipo'] === 'noticia' ? 'la noticia' : 'el título y la descripción' ?></span></button>
        <button class="boton boton--suave" type="button" data-compartir data-titulo="<?= e($p['titulo']) ?>"><?= icono('copiar') ?><span data-compartir-txt>Copiar enlace</span></button>
        <?php if ($p['fuente_url']): ?>
          <?php if ($conSesion): ?>
            <a class="boton boton--suave" href="<?= e(url('ir.php', ['t' => 'fuente', 'id' => $id])) ?>" target="_blank" rel="noopener nofollow" data-desbloqueado>
              <span class="candado candado--abierto"><?= icono('candado-abierto') ?></span><?= $esYoutube ? 'Ver en YouTube' : 'Fuente de la noticia' ?><?= icono('externo') ?><span class="sr"> (se abre en una pestaña nueva)</span>
            </a>
          <?php else: ?>
            <?php vista('bloqueo', ['texto' => $esYoutube ? 'Ver en YouTube' : 'Fuente de la noticia', 'motivo' => $esYoutube ? 'Inicia sesión para ver este video y su enlace de YouTube.' : 'Inicia sesión para ver la fuente original de esta publicación.', 'clave' => 'fuente', 'clase' => 'boton--suave', 'ancla' => 'reproductor']); ?>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>

    <div class="ver__etiquetas">
      <?php vista('sello', ['verificacion' => $p['verificacion']]); ?>
      <?php vista('escala', ['orientacion' => $p['orientacion']]); ?>
    </div>

    <section class="descripcion" aria-label="Descripción">
      <p class="descripcion__meta">
        <span><?= e(number_format((int) $p['vistas'], 0, ',', '.')) ?> vistas</span>
        <time datetime="<?= e(fecha_iso($p['publicado_en'])) ?>"><?= e(fecha_larga($p['publicado_en'])) ?></time>
        <?php if ($p['padre_slug']): ?><a href="<?= e(url('videos.php', ['cat' => $p['padre_slug']])) ?>"><?= e($p['padre_nombre']) ?></a><?php endif; ?>
        <a href="<?= e(url('videos.php', ['cat' => $p['categoria_slug']])) ?>"><?= e($p['categoria_nombre']) ?></a>
      </p>
      <div class="descripcion__txt" id="desc-texto" data-plegable><?= parrafos($p['descripcion']) ?></div>
      <?php if ($etiquetas): ?>
        <ul class="descripcion__tags" aria-label="Etiquetas">
          <?php foreach ($etiquetas as $t): ?><li><a href="<?= e(url('videos.php', ['q' => $t])) ?>">#<?= e(str_replace(' ', '', $t)) ?></a></li><?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </section>

    <?php if ($p['tipo'] === 'noticia' && $p['cuerpo']): ?>
      <article class="ver__noticia prosa" aria-label="Noticia completa">
        <?php if ($p['autor']): ?><p class="ver__autor">Por <?= e($p['autor']) ?>, <?= e($p['creador']) ?></p><?php endif; ?>
        <div id="noticia-cuerpo"><?= parrafos($p['cuerpo']) ?></div>
      </article>
    <?php endif; ?>

    <?php if ($p['venta_url'] || $p['precio'] !== null): ?>
      <section class="caja caja--venta" id="enlace-venta" aria-labelledby="venta-titulo">
        <h2 class="caja__titulo" id="venta-titulo">En venta<?= $p['tienda'] ? ' en ' . e($p['tienda']) : '' ?></h2>
        <?php if ($p['precio'] !== null): ?>
          <p class="precio precio--grande"><span class="sr">Precio: </span><strong class="precio__actual"><?= e(precio((int) $p['precio'])) ?></strong>
            <?php if ($antes && $desc): ?><s class="precio__antes"><span class="sr">Antes: </span><?= e(precio($antes)) ?></s><?php endif; ?></p>
          <?php if ($antes && $desc): ?><p class="ahorro"><?= icono('etiqueta') ?>Ahorras <?= e(precio($antes - (int) $p['precio'])) ?> (<?= $desc ?>%)</p><?php endif; ?>
        <?php endif; ?>
        <?php if ($p['venta_url']): ?>
          <div class="caja--venta__cta">
            <?php if ($conSesion): ?>
              <a class="boton boton--primario boton--grande boton--ancho" href="<?= e(url('ir.php', ['t' => 'venta', 'id' => $id])) ?>" target="_blank" rel="noopener nofollow sponsored" data-desbloqueado>
                <span class="candado candado--abierto"><?= icono('candado-abierto') ?></span><span>Ir a <?= e($p['tienda'] ?: 'la tienda') ?></span><?= icono('externo') ?><span class="sr"> (se abre en una pestaña nueva)</span>
              </a>
              <p class="destino"><?= icono('enlace') ?>Te lleva a <?= e(dominio($p['venta_url'])) ?></p>
            <?php else: ?>
              <?php vista('bloqueo', ['texto' => 'Ver enlace de venta', 'motivo' => 'Inicia sesión para ver el enlace de venta de esta publicación.', 'clave' => 'venta', 'clase' => 'boton--primario boton--grande boton--ancho', 'ancla' => 'enlace-venta']); ?>
              <p class="destino">Crear una cuenta es gratis y toma menos de un minuto.</p>
            <?php endif; ?>
          </div>
        <?php endif; ?>
        <?php if ($ficha): ?>
          <dl class="specs">
            <?php foreach ($ficha as $k => $val): ?><div class="specs__fila"><dt><?= e((string) $k) ?></dt><dd><?= e((string) $val) ?></dd></div><?php endforeach; ?>
          </dl>
        <?php endif; ?>
      </section>
    <?php endif; ?>

    <?php if ($imgs && $p['tipo'] !== 'imagen'): ?>
      <section class="ver__fotos" aria-labelledby="fotos-titulo">
        <h2 class="caja__titulo" id="fotos-titulo">Fotos</h2>
        <ul class="mosaico">
          <?php foreach ($imgs as $im): ?><li><?= img($im['base'], [400, 800], '(min-width: 1100px) 280px, 33vw', $im['alt'], 1200, 1200, $im['color']) ?></li><?php endforeach; ?>
        </ul>
      </section>
    <?php endif; ?>

    <?php vista('redes', ['redes' => $redes, 'nombre' => $p['creador'], 'titulo' => 'Redes sociales adjuntas']); ?>

    <section class="caja caja--etiquetas" aria-labelledby="porque-titulo">
      <h2 class="caja__titulo" id="porque-titulo">Por qué ves estas etiquetas</h2>
      <dl class="porque">
        <div><dt><?php vista('sello', ['verificacion' => $p['verificacion']]); ?></dt><dd><?= e($p['verificacion_nota'] ?: VERIFICACIONES[$p['verificacion']][1]) ?></dd></div>
        <div><dt><?php vista('escala', ['orientacion' => $p['orientacion']]); ?></dt><dd><?= e($p['orientacion_nota'] ?: ($p['orientacion'] === 'no-aplica' ? 'No toma postura política o no trata temas políticos.' : 'Etiqueta asignada por la moderación.')) ?></dd></div>
      </dl>
      <a class="enlace" href="<?= e(url('transparencia.php')) ?>">Cómo asignamos las etiquetas</a>
    </section>

    <?php vista('comentarios', ['p' => $p, 'usuario' => $usuario]); ?>
  </div>

  <aside class="ver__lado" aria-label="Más publicaciones">
    <?php if ($persp): ?>
      <section class="lado-seccion lado-seccion--perspectivas" aria-labelledby="persp-titulo">
        <h2 class="lado-seccion__titulo" id="persp-titulo"><?= icono('balanza') ?>Otras miradas sobre este tema</h2>
        <p class="lado-seccion__desc"><?= $p['orientacion'] === 'no-aplica' ? 'El mismo tema desde otras posturas. Compara antes de formarte una opinión.' : 'Mismo tema contado desde otras orientaciones. Compara antes de formarte una opinión.' ?></p>
        <ul class="lista-filas">
          <?php foreach ($persp as $x): ?><li><?php vista('tarjeta', ['p' => $x, 'variante' => 'fila']); ?></li><?php endforeach; ?>
        </ul>
      </section>
    <?php endif; ?>
    <section class="lado-seccion" aria-labelledby="rel-titulo">
      <h2 class="lado-seccion__titulo" id="rel-titulo">Relacionados</h2>
      <ul class="lista-filas">
        <?php foreach ($rel as $x): ?><li><?php vista('tarjeta', ['p' => $x, 'variante' => 'fila']); ?></li><?php endforeach; ?>
      </ul>
    </section>
  </aside>
</div>
<?php vista('pie', ['seccion' => 'videos', 'asistente' => ['tipo' => 'publicacion', 'p' => $p]]); ?>
