<?php
declare(strict_types=1);
if (!defined('APP_DIR')) {
    require __DIR__ . '/includes/bootstrap.php';
}
$codigo = !empty($GLOBALS['error_500']) ? 500 : (!empty($GLOBALS['error_403']) ? 403 : 404);
http_response_code($codigo);
[$titulo, $texto] = [
    500 => ['Algo falló de nuestro lado', 'Ya quedó registrado. Vuelve a intentarlo en un momento.'],
    403 => ['Esta sección es solo para administración', 'Tu cuenta no tiene permisos de administración. Si crees que es un error, pide a un admin que te los asigne.'],
    404 => ['Esta página no existe o cambió de dirección', 'Revisa la dirección o busca lo que necesitas.'],
][$codigo];
vista('cabecera', ['titulo' => $titulo, 'seccion' => 'error', 'sin_indexar' => true]);
?>
<div class="contenedor contenedor--texto error-pagina">
  <p class="error-pagina__codigo" aria-hidden="true"><?= $codigo ?></p>
  <h1 class="error-pagina__titulo"><?= e($titulo) ?></h1>
  <p><?= e($texto) ?></p>
  <?php vista('buscador', ['id' => 'q-error', 'variante' => 'pagina']); ?>
  <p class="error-pagina__links">
    <a class="boton boton--suave" href="<?= e(url()) ?>">Ir al inicio</a>
    <a class="boton boton--suave" href="<?= e(url('videos.php')) ?>">Ver todos los videos</a>
  </p>
</div>
<?php vista('pie', ['seccion' => 'error']); ?>
