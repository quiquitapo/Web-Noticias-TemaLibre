<?php
/**
 * Entrega protegida de videos y subtítulos, con soporte de rangos (permite adelantar el video).
 * Los archivos viven en media/videos/, que no es accesible directamente.
 */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

$usuario = usuario_actual();
$v = fila("SELECT id, video_archivo, video_webm, subtitulos FROM publicaciones WHERE slug = ? AND tipo = 'video'", [entrada('v')]);
$pista = entrada('pista');
// Libera la sesión: el navegador hace varias peticiones de rango en paralelo.
session_write_close();

if (!$usuario) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    exit('Inicia sesión para ver este video.');
}
if (!$v) {
    http_response_code(404);
    exit;
}

$webm = entrada('formato') === 'webm' && $v['video_webm'];
$nombre = match (true) {
    $pista === 'vtt' => (string) $v['subtitulos'],
    (bool) $webm => (string) $v['video_webm'],
    default => (string) $v['video_archivo'],
};
if ($nombre === '') {
    http_response_code(404);
    exit;
}
$archivo = APP_DIR . '/media/videos/' . basename($nombre);
if (!is_file($archivo)) {
    http_response_code(404);
    exit;
}

$tamano = filesize($archivo);
$inicio = 0;
$fin = $tamano - 1;
header('Content-Type: ' . ($pista === 'vtt' ? 'text/vtt; charset=utf-8' : (str_ends_with($archivo, '.webm') ? 'video/webm' : 'video/mp4')));
header('Accept-Ranges: bytes');
header('Cache-Control: private, max-age=3600');
header('Last-Modified: ' . gmdate('D, d M Y H:i:s', (int) filemtime($archivo)) . ' GMT');

if (isset($_SERVER['HTTP_RANGE'])) {
    if (!preg_match('/^bytes=(\d*)-(\d*)$/', trim($_SERVER['HTTP_RANGE']), $m) || ($m[1] === '' && $m[2] === '')) {
        http_response_code(416);
        header("Content-Range: bytes */{$tamano}");
        exit;
    }
    if ($m[1] === '') {            // últimos N bytes
        $inicio = max(0, $tamano - (int) $m[2]);
    } else {
        $inicio = (int) $m[1];
        $fin = $m[2] !== '' ? min((int) $m[2], $tamano - 1) : $fin;
    }
    if ($inicio > $fin || $inicio >= $tamano) {
        http_response_code(416);
        header("Content-Range: bytes */{$tamano}");
        exit;
    }
    http_response_code(206);
    header("Content-Range: bytes {$inicio}-{$fin}/{$tamano}");
}

$largo = $fin - $inicio + 1;
header('Content-Length: ' . $largo);
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'HEAD') {
    exit;
}

while (ob_get_level() > 0) {
    ob_end_clean();
}
$fp = fopen($archivo, 'rb');
fseek($fp, $inicio);
$restante = $largo;
while ($restante > 0 && !feof($fp) && !connection_aborted()) {
    $bloque = fread($fp, min(65536, $restante));
    if ($bloque === false) {
        break;
    }
    echo $bloque;
    flush();
    $restante -= strlen($bloque);
}
fclose($fp);
