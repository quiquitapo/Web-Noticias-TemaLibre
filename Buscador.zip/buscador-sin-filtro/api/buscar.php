<?php
/** Sugerencias en vivo para el buscador. GET ?q=texto  →  JSON agrupado por tipo. No se registra nada. */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
session_write_close();

$f = filtros_desde_url(['q' => entrada('q'), 'orden' => 'relevancia']);
$res = explorar($f, 8);
$grupos = [];
foreach (TIPOS as $tipo => [, $plural]) {
    $items = array_values(array_filter($res['items'], static fn($x) => $x['tipo'] === $tipo));
    if (!$items) {
        continue;
    }
    $grupos[] = [
        'tipo' => $tipo,
        'etiqueta' => $plural,
        'total' => count($items),
        'ver_mas' => url('videos.php', ['q' => $f['q'], 'tipo' => $tipo]),
        'items' => array_map(static fn($x) => resultado_compacto($x, $res['terminos']), array_slice($items, 0, 4)),
    ];
}
header('Cache-Control: private, max-age=60');
json_respuesta([
    'q' => $f['q'],
    'total' => $res['total'],
    'exacto' => $res['exacto'],
    'grupos' => $grupos,
    'ver_todo' => url('videos.php', ['q' => $f['q']]),
]);
