<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

$volver = volver_seguro(entrada('volver'));
if (sesion_iniciada()) {
    redirigir($volver);
}

$errores = [];
$general = '';
$valores = ['nombre' => '', 'email' => ''];

if (es_post()) {
    $valores = ['nombre' => entrada('nombre'), 'email' => entrada('email')];
    if (!csrf_valido()) {
        $general = 'El formulario expiró por seguridad. Vuelve a intentarlo.';
        http_response_code(400);
    } else {
        $r = registrar_usuario($valores['nombre'], $valores['email'], (string) ($_POST['clave'] ?? ''));
        if ($r['ok']) {
            flash('exito', 'Cuenta creada. Ya puedes ver enlaces, fuentes, videos y redes.');
            if (es_peticion_json()) {
                json_respuesta(['ok' => true, 'redirigir' => $volver]);
            }
            redirigir($volver);
        }
        $errores = $r['errores'];
        $general = 'Revisa los campos marcados.';
        http_response_code(422);
    }
    if (es_peticion_json()) {
        json_respuesta(['ok' => false, 'error' => $general, 'errores' => $errores, 'csrf' => csrf_token()], http_response_code() ?: 422);
    }
}

vista('cabecera', ['titulo' => 'Crear cuenta', 'seccion' => 'cuenta', 'sin_indexar' => true]);
vista('pagina-acceso', [
    'prefijo' => 'pg', 'volver' => $volver, 'activa' => 'registro', 'demo' => null,
    'errores' => $errores, 'error_general' => $general, 'valores' => $valores,
    'motivo_txt' => MOTIVOS_ACCESO[entrada('motivo')] ?? '',
]);
vista('pie', ['seccion' => 'cuenta']);
