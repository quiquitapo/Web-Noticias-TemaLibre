<?php
/**
 * Tu avatar: créalo con piezas (vista previa al instante), sube una foto de perfil o vuelve a tus iniciales.
 * Funciona sin JavaScript: cada formulario se envía y la página muestra el resultado.
 */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

requerir_sesion('cuenta');
$u = usuario_actual();
$id = (int) $u['id'];
$errorFoto = '';
$guardadas = is_array($j = json_decode((string) ($u['avatar'] ?? ''), true)) ? avatar_opciones($j) : avatar_por_defecto();
$o = $guardadas;

if (es_post()) {
    if (!csrf_valido()) {
        flash('error', 'El formulario expiró por seguridad. Vuelve a intentarlo.');
        redirigir(url('avatar.php'));
    }
    switch (entrada('accion')) {
        case 'guardar':
            $o = avatar_opciones($_POST);
            consulta("UPDATE usuarios SET avatar_tipo = 'creado', avatar = ? WHERE id = ?", [json_encode($o), $id]);
            flash('exito', 'Avatar guardado. Así te verán en tus comentarios.');
            redirigir(url('avatar.php'));
        case 'aleatorio':
            // Sin JavaScript: propone uno al azar (aún sin guardar)
            $o = avatar_aleatorio();
            break;
        case 'foto':
            $r = guardar_foto_avatar($id, $_FILES['foto'] ?? []);
            if ($r['ok']) {
                flash('exito', 'Foto de perfil actualizada.');
                redirigir(url('avatar.php'));
            }
            $errorFoto = $r['error'];
            http_response_code(422);
            break;
        case 'usar':
            $tipo = entrada('tipo');
            if ($tipo === 'creado' || $tipo === 'iniciales' || ($tipo === 'foto' && $u['avatar_foto'])) {
                if ($tipo === 'creado' && !$u['avatar']) {
                    consulta('UPDATE usuarios SET avatar = ? WHERE id = ?', [json_encode($o), $id]);
                }
                consulta('UPDATE usuarios SET avatar_tipo = ? WHERE id = ?', [$tipo, $id]);
                flash('exito', ['creado' => 'Ahora usas tu avatar.', 'foto' => 'Ahora usas tu foto de perfil.', 'iniciales' => 'Ahora usas tus iniciales.'][$tipo]);
            }
            redirigir(url('avatar.php'));
        case 'borrar_foto':
            borrar_foto_avatar((string) $u['avatar_foto']);
            consulta("UPDATE usuarios SET avatar_foto = NULL, avatar_tipo = CASE WHEN avatar_tipo = 'foto' THEN 'iniciales' ELSE avatar_tipo END WHERE id = ?", [$id]);
            flash('exito', 'Foto de perfil eliminada del servidor.');
            redirigir(url('avatar.php'));
    }
}

$tipo = (string) $u['avatar_tipo'];
// Grupos del creador: [título, [[opción, etiqueta, 'forma'|'color'], ...]]
$grupos = [
    'cara' => ['Cara', [['cara', 'Forma', 'forma'], ['piel', 'Tono de piel', 'color'], ['mejillas', 'Mejillas sonrojadas', 'forma'], ['pecas', 'Pecas', 'forma']]],
    'pelo' => ['Pelo', [['pelo_estilo', 'Peinado', 'forma'], ['pelo', 'Color', 'color']]],
    'ojos' => ['Ojos y cejas', [['ojos', 'Ojos', 'forma'], ['iris', 'Color de ojos', 'color'], ['cejas', 'Cejas', 'forma']]],
    'boca' => ['Boca y barba', [['boca', 'Boca', 'forma'], ['barba', 'Barba', 'forma']]],
    'accesorios' => ['Accesorios', [['lentes', 'Lentes', 'forma'], ['gorro', 'En la cabeza', 'forma'], ['aros', 'Aros', 'forma']]],
    'ropa' => ['Ropa', [['ropa_estilo', 'Prenda', 'forma'], ['ropa', 'Color', 'color'], ['detalle', 'Color de detalles y accesorios', 'color']]],
    'fondo' => ['Fondo', [['fondo', 'Color', 'color'], ['patron', 'Diseño', 'forma']]],
];
$nombresColor = [
    'piel' => ['1' => 'Muy clara', '2' => 'Clara', '3' => 'Clara media', '4' => 'Media', '5' => 'Morena', '6' => 'Morena oscura', '7' => 'Oscura', '8' => 'Muy oscura'],
];
$colores = [];
foreach (AVATAR_COLOR_DE as $k => $g) {
    $colores[$k] = AVATAR_COLORES[$g];
}
vista('cabecera', ['titulo' => 'Tu avatar', 'seccion' => 'cuenta', 'sin_indexar' => true]);
?>
<div class="contenedor avatar-pagina">
  <p class="avatar-pagina__volver"><a class="enlace" href="<?= e(url('cuenta.php')) ?>"><?= icono('izq') ?>Volver a tu cuenta</a></p>
  <h1 class="avatar-pagina__titulo">Tu avatar</h1>
  <p class="avatar-pagina__intro">Así te verán en los comentarios y en tu cuenta. Crea uno con piezas, sube una foto o quédate con tus iniciales.</p>

  <div class="avatar-modo" role="group" aria-label="Qué se muestra ahora">
    <?php foreach (['creado' => 'Avatar creado', 'foto' => 'Foto de perfil', 'iniciales' => 'Iniciales'] as $t => $txt): ?>
      <div class="avatar-modo__op<?= $tipo === $t ? ' avatar-modo__op--activo' : '' ?>">
        <?php if ($t === 'creado'): ?><span class="av av--creado" aria-hidden="true"><?= avatar_svg($guardadas) ?></span>
        <?php elseif ($t === 'foto'): ?><?= $u['avatar_foto'] ? avatar_html(['avatar_tipo' => 'foto', 'avatar_foto' => $u['avatar_foto'], 'nombre' => $u['nombre']]) : '<span class="av av--vacio" aria-hidden="true">' . icono('fotos') . '</span>' ?>
        <?php else: ?><?= avatar_html(['nombre' => $u['nombre']]) ?><?php endif; ?>
        <span class="avatar-modo__txt"><?= e($txt) ?><?php if ($tipo === $t): ?><span class="avatar-modo__actual"><?= icono('check') ?>En uso</span><?php endif; ?></span>
        <?php if ($tipo !== $t && ($t !== 'foto' || $u['avatar_foto'])): ?>
          <form method="post"><?= csrf_campo() ?><input type="hidden" name="accion" value="usar"><input type="hidden" name="tipo" value="<?= e($t) ?>">
            <button class="boton boton--suave boton--chico" type="submit">Usar<span class="sr"> <?= e(mb_strtolower($txt)) ?></span></button>
          </form>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>

  <section class="avatar-crear" aria-labelledby="crear-titulo">
    <h2 class="avatar-crear__titulo" id="crear-titulo"><?= icono('chispa') ?>Crea tu avatar</h2>
    <form class="avatar-crear__form" method="post" data-avatar-form data-colores="<?= e(json_encode($colores)) ?>">
      <?= csrf_campo() ?>
      <div class="avatar-crear__vista">
        <div class="avatar-crear__lienzo"><?= avatar_svg($o, true, 'Vista previa de tu avatar') ?></div>
        <div class="avatar-crear__botones">
          <button class="boton boton--suave" type="submit" name="accion" value="aleatorio" data-avatar-azar><?= icono('chispa') ?>Al azar</button>
          <button class="boton boton--primario" type="submit" name="accion" value="guardar"><?= icono('check') ?>Guardar y usar</button>
        </div>
        <p class="avatar-crear__nota" data-avatar-estado aria-live="polite"><?= $o !== $guardadas ? 'Propuesta al azar: guárdala si te gusta.' : 'Los cambios se ven al instante; se guardan con «Guardar y usar».' ?></p>
      </div>
      <div class="avatar-crear__opciones">
        <?php foreach ($grupos as $gid => [$titulo, $campos]): ?>
          <fieldset class="avatar-grupo">
            <legend class="avatar-grupo__titulo"><?= e($titulo) ?></legend>
            <?php foreach ($campos as [$k, $etq, $tipoCampo]): ?>
              <div class="avatar-campo" role="radiogroup" aria-labelledby="ac-<?= e($k) ?>">
                <p class="avatar-campo__etq" id="ac-<?= e($k) ?>"><?= e($etq) ?></p>
                <div class="avatar-campo__ops avatar-campo__ops--<?= $tipoCampo ?>">
                  <?php if ($tipoCampo === 'color'): ?>
                    <?php foreach ($colores[$k] as $v => $hex): ?>
                      <label class="avatar-color" title="<?= e($nombresColor[$k][$v] ?? ucfirst((string) $v)) ?>">
                        <input type="radio" name="<?= e($k) ?>" value="<?= e((string) $v) ?>"<?= $o[$k] === (string) $v ? ' checked' : '' ?>>
                        <span class="avatar-color__muestra" style="--c: <?= e($hex) ?>"></span><span class="sr"><?= e($nombresColor[$k][$v] ?? ucfirst((string) $v)) ?></span>
                      </label>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <?php foreach (AVATAR_FORMAS[$k] as $v => $t): ?>
                      <label class="avatar-op"><input type="radio" name="<?= e($k) ?>" value="<?= e($v) ?>"<?= $o[$k] === $v ? ' checked' : '' ?>><span><?= e($t) ?></span></label>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </div>
              </div>
            <?php endforeach; ?>
          </fieldset>
        <?php endforeach; ?>
      </div>
    </form>
  </section>

  <section class="avatar-foto caja" aria-labelledby="foto-titulo">
    <h2 class="caja__titulo" id="foto-titulo"><?= icono('fotos') ?>O sube una foto de perfil</h2>
    <p class="caja__txt">PNG, JPG o WebP de hasta <?= (int) config('subidas.imagen_max_mb', 8) ?> MB. Se recorta en cuadrado al centro y se guarda como una imagen nueva: los datos ocultos de la foto (como la ubicación GPS) se descartan. La verán quienes lean tus comentarios.</p>
    <form class="avatar-foto__form" method="post" enctype="multipart/form-data" data-avatar-foto>
      <?= csrf_campo() ?><input type="hidden" name="accion" value="foto">
      <div class="avatar-foto__fila">
        <span class="av av--vista-foto" data-avatar-foto-vista aria-hidden="true"><?= $u['avatar_foto'] ? avatar_html(['avatar_tipo' => 'foto', 'avatar_foto' => $u['avatar_foto'], 'nombre' => $u['nombre']], '', 256) : icono('usuario') ?></span>
        <div class="campo">
          <label for="foto">Elige una imagen</label>
          <input id="foto" name="foto" type="file" accept="image/png,image/jpeg,image/webp" required<?= $errorFoto ? ' aria-invalid="true" aria-describedby="foto-error"' : '' ?>>
          <?php if ($errorFoto): ?><p class="campo__error" id="foto-error"><?= icono('alerta') ?><span><?= e($errorFoto) ?></span></p><?php endif; ?>
        </div>
      </div>
      <div class="avatar-foto__botones">
        <button class="boton boton--primario" type="submit"><?= icono('subir') ?>Subir y usar</button>
      </div>
    </form>
    <?php if ($u['avatar_foto']): ?>
      <form method="post" data-confirmar="¿Eliminar tu foto de perfil del servidor?"><?= csrf_campo() ?><input type="hidden" name="accion" value="borrar_foto">
        <button class="boton-texto boton-texto--peligro" type="submit"><?= icono('eliminar') ?>Eliminar mi foto del servidor</button>
      </form>
    <?php endif; ?>
  </section>
</div>
<?php vista('pie', ['seccion' => 'cuenta']); ?>
