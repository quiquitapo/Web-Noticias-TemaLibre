<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

$volver = volver_seguro(entrada('volver'));
if (sesion_iniciada()) {
    redirigir($volver);
}

$errores = [];
$general = '';
$valores = ['email' => ''];

if (es_post()) {
    $valores['email'] = entrada('email');
    if (!csrf_valido()) {
        $general = 'El formulario expiró por seguridad. Vuelve a intentarlo.';
        http_response_code(400);
    } else {
        $r = iniciar_sesion($valores['email'], (string) ($_POST['clave'] ?? ''));
        if ($r['ok']) {
            flash('exito', 'Sesión iniciada. Ya puedes ver enlaces, fuentes, videos y redes.');
            if (es_peticion_json()) {
                json_respuesta(['ok' => true, 'redirigir' => $volver]);
            }
            redirigir($volver);
        }
        $general = $r['error'];
        http_response_code(422);
    }
    if (es_peticion_json()) {
        json_respuesta(['ok' => false, 'error' => $general, 'csrf' => csrf_token()], http_response_code() ?: 422);
    }
}

vista('cabecera', ['titulo' => 'Iniciar sesión', 'seccion' => 'cuenta', 'sin_indexar' => true]);
vista('pagina-acceso', [
    'prefijo' => 'pg', 'volver' => $volver, 'activa' => 'entrar',
    'demo' => config('app.mostrar_cuenta_demo') ? config('cuenta_demo') : null,
    'errores' => $errores, 'error_general' => $general, 'valores' => $valores,
    'motivo_txt' => MOTIVOS_ACCESO[entrada('motivo')] ?? '',
]);
vista('pie', ['seccion' => 'cuenta']);
