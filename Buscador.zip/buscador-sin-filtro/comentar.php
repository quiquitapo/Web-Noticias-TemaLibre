<?php
/** Publicar o eliminar un comentario (formulario normal: funciona sin JavaScript). */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

if (!es_post()) {
    redirigir(url('videos.php'));
}
$accion = entrada('accion');
$usuario = usuario_actual();

if ($accion === 'eliminar') {
    $c = fila('SELECT c.id, p.slug FROM comentarios c JOIN publicaciones p ON p.id = c.publicacion_id WHERE c.id = ?', [(int) entrada('id')]);
    $volver = $c ? url('video.php', ['v' => $c['slug']]) . '#comentarios' : url('videos.php');
    if (!$usuario) {
        redirigir(url('entrar.php', ['volver' => $volver, 'motivo' => 'comentar']));
    }
    if (!csrf_valido()) {
        flash('error', 'El formulario expiró por seguridad. Vuelve a intentarlo.');
        redirigir($volver);
    }
    $r = eliminar_comentario($usuario, (int) entrada('id'));
    flash($r['ok'] ? 'exito' : 'error', $r['ok'] ? 'Comentario eliminado.' : $r['error']);
    redirigir($volver);
}

$pub = fila('SELECT id, slug FROM publicaciones WHERE id = ?', [(int) entrada('publicacion')]) ?? no_encontrado();
$volver = url('video.php', ['v' => $pub['slug']]);
if (!$usuario) {
    redirigir(url('entrar.php', ['volver' => $volver . '#comentar', 'motivo' => 'comentar']));
}
if (!csrf_valido()) {
    flash('error', 'El formulario expiró por seguridad. Tu comentario quedó guardado como borrador.');
    $_SESSION['borrador_comentario'][(int) $pub['id']] = mb_substr((string) ($_POST['texto'] ?? ''), 0, COMENTARIO_MAX + 200);
    redirigir($volver . '#comentar');
}
$r = crear_comentario($usuario, (int) $pub['id'], (string) ($_POST['texto'] ?? ''));
if (!$r['ok']) {
    $_SESSION['borrador_comentario'][(int) $pub['id']] = mb_substr((string) ($_POST['texto'] ?? ''), 0, COMENTARIO_MAX + 200);
    $_SESSION['error_comentario'] = $r['error'];
    redirigir($volver . '#comentar');
}
unset($_SESSION['borrador_comentario'][(int) $pub['id']]);
flash('exito', 'Comentario publicado.');
redirigir($volver . '#comentario-' . $r['id']);
