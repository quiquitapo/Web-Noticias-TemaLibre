<?php
/** Cómo funciona: el orden, las etiquetas, la verificación y la privacidad, explicados sin letra chica. */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

$eq = equilibrio();
vista('cabecera', ['titulo' => 'Cómo funciona', 'seccion' => 'transparencia', 'descripcion' => 'Cómo ordena Sin Filtro los resultados, cómo asigna etiquetas de orientación y verificación, y qué datos guarda.']);
?>
<article class="contenedor contenedor--texto transparencia">
  <header class="transparencia__cabeza">
    <h1 class="transparencia__titulo">Cómo funciona Sin Filtro</h1>
    <p class="transparencia__bajada"><?= e(config('app.lema')) ?> Aquí está todo lo que hace el buscador, sin letra chica.</p>
  </header>

  <nav class="indice" aria-label="En esta página">
    <ol>
      <li><a href="#orden">El orden lo eliges tú</a></li>
      <li><a href="#orientacion">Etiquetas de orientación</a></li>
      <li><a href="#verificacion">Verificación</a></li>
      <li><a href="#comentarios">Comentarios sin censura de opiniones</a></li>
      <li><a href="#lectura">Lectura cómoda y en voz alta</a></li>
      <li><a href="#asistente">Asistente de preguntas rápidas</a></li>
      <li><a href="#youtube">Videos de YouTube</a></li>
      <li><a href="#prensa">Noticias en la prensa</a></li>
      <li><a href="#privacidad">Privacidad</a></li>
      <li><a href="#ligero">Liviano a propósito</a></li>
    </ol>
  </nav>

  <section id="orden" class="transparencia__seccion">
    <h2>El orden lo eliges tú</h2>
    <p>No hay un algoritmo oculto que decida qué ves. Con los mismos filtros, todas las personas ven exactamente el mismo orden. Nadie paga por aparecer más arriba y no usamos tu historial para personalizar.</p>
    <dl class="definiciones">
      <div><dt>Más recientes</dt><dd>Por fecha de publicación, de la más nueva a la más antigua. Es el orden por defecto.</dd></div>
      <div><dt>Relevancia</dt><dd>Al buscar, suma puntos por cada palabra: 9 si está en el título o las etiquetas, 2 si está en la descripción. Los sinónimos valen un poco menos. Desempata la fecha.</dd></div>
      <div><dt>Vista equilibrada</dt><dd>Muestra una publicación de cada orientación antes de repetir: izquierda, centro-izquierda, centro, centro-derecha y derecha, y después el contenido sin postura política.</dd></div>
      <div><dt>Más vistos</dt><dd>Por cantidad de vistas. Úsalo con cuidado: lo popular no siempre es lo confiable.</dd></div>
    </dl>
    <p>Además puedes filtrar por tipo, categoría, orientación, verificación, fecha, duración, creador y si tiene fuente, enlace de venta o subtítulos. Cada filtro muestra cuántos resultados quedan.</p>
  </section>

  <section id="orientacion" class="transparencia__seccion">
    <h2>Etiquetas de orientación</h2>
    <p>Cada publicación que toma postura política lleva una etiqueta en una escala de cinco posiciones. La escala usa un solo color para todas las posiciones: ninguna se ve como “buena” o “mala”.</p>
    <ul class="escala-demo">
      <?php foreach (ORIENTACIONES as $k => [$t, $pos]): if (!$pos) { continue; } ?>
        <li><?php vista('escala', ['orientacion' => $k]); ?><span class="escala-demo__n"><?= (int) ($eq['orientacion'][$k] ?? 0) ?> publicaciones</span></li>
      <?php endforeach; ?>
    </ul>
    <p>La etiqueta viene de la línea editorial que declara cada canal o medio, o la asigna la moderación explicando por qué. Cada publicación muestra ese motivo en “Por qué ves estas etiquetas”. Las noticias, guías y productos sin postura política llevan “Sin orientación política”.</p>
    <p>La etiqueta describe la postura, no la califica. Que un video sea de izquierda o de derecha no lo hace más o menos verdadero: para eso está la verificación.</p>
    <p>En la sección <a class="enlace" href="<?= e(url('videos.php', ['cat' => 'aciertos-errores', 'orden' => 'equilibrado'])) ?>">Aciertos y errores</a> la etiqueta indica el signo del gobierno evaluado, no la postura de quien publica. Buscamos que haya logros y errores de cada orientación para que ninguna quede solo con lo bueno o solo con lo malo.</p>
  </section>

  <section id="verificacion" class="transparencia__seccion">
    <h2>Verificación</h2>
    <dl class="definiciones">
      <?php foreach (VERIFICACIONES as $k => [$t, $ayuda]): ?>
        <div><dt><?php vista('sello', ['verificacion' => $k]); ?></dt><dd><?= e($ayuda) ?> <?= (int) ($eq['verificacion'][$k] ?? 0) ?> publicaciones.</dd></div>
      <?php endforeach; ?>
    </dl>
    <p>No borramos el contenido engañoso: lo dejamos visible, etiquetado y con la explicación, para que puedas compararlo con la verificación y reconocer el patrón la próxima vez. Puedes ocultarlo con el filtro de verificación.</p>
  </section>

  <section id="comentarios" class="transparencia__seccion">
    <h2>Comentarios sin censura de opiniones</h2>
    <p>Leer los comentarios es libre; para comentar hay que iniciar sesión. No ocultamos ni ordenamos comentarios según su postura: se muestran por fecha, sin «me gusta» ni ranking que premie lo más viral.</p>
    <p>Solo se eliminan comentarios con spam, amenazas, insultos personales o datos privados de otras personas, y cada eliminación queda registrada. Cada persona puede borrar sus propios comentarios, y al eliminar su cuenta se borran todos.</p>
  </section>

  <section id="lectura" class="transparencia__seccion">
    <h2>Lectura cómoda y en voz alta</h2>
    <p>Con el botón <strong>Aa</strong> de la cabecera puedes elegir un estilo visual (Sin Filtro, Frutiger Aero, Periódico, Neón, Escritorio 98 o Neobrutalismo), el tema, un color de acento, el tamaño del texto, más espacio entre líneas, alto contraste y menos animaciones. Todos los colores cumplen el contraste mínimo de accesibilidad (WCAG AA).</p>
    <p>El botón <strong>Escuchar</strong> lee en voz alta títulos, descripciones, noticias y comentarios con las voces de tu propio dispositivo, así el texto no sale de tu equipo. Puedes pausar, detener y elegir la velocidad y la voz.</p>
  </section>

  <section id="asistente" class="transparencia__seccion">
    <h2>Asistente de preguntas rápidas</h2>
    <p>El botón <strong>Pregúntame</strong> responde preguntas cortas según la página en la que estás: en una publicación, su URL de origen, la fecha, quién la subió, quién la creó, por qué tiene sus etiquetas u otras miradas sobre el tema; en una sección, qué hay en ella y lo más visto o reciente. También busca por ti y te lleva a una sección.</p>
    <p>No es una inteligencia artificial externa: responde con los datos de este sitio y con reglas simples, así que no inventa ni opina. Sigue las mismas reglas que el resto del sitio (sin sesión no entrega enlaces de fuentes, tiendas, redes ni YouTube) y no guarda tus preguntas. La conversación vive solo en la pestaña de tu navegador y desaparece al cerrarla.</p>
  </section>

  <section id="youtube" class="transparencia__seccion">
    <h2>Videos de YouTube</h2>
    <p>Algunos videos son de YouTube y se reproducen aquí mismo, con la misma miniatura que tienen en YouTube. Esa miniatura la descarga este servidor y se guarda en el sitio; solo si el servidor no lo logra, tu navegador la pide directo al servidor de imágenes de YouTube (sin cookies y sin decirle desde qué página vienes). Recién cuando pulsas <strong>Reproducir</strong> se carga el reproductor desde <code>youtube-nocookie.com</code>, el modo de privacidad mejorada de YouTube; desde ese momento aplican las reglas de privacidad de YouTube. Si prefieres no conectarte con YouTube, no pulses reproducir.</p>
    <p>Cada uno enlaza a su video original y queda <strong>sin verificar</strong> hasta que la moderación revise lo que afirma.</p>
  </section>

  <section id="prensa" class="transparencia__seccion">
    <h2>Noticias en la prensa</h2>
    <p>Muchas publicaciones se pueden ver también como <strong>Noticias en la prensa</strong>: enlaces a artículos de medios reales sobre el mismo tema, por si prefieres leer en vez de ver un video o quieres contrastar con otras fuentes.</p>
    <p>Los elige la moderación y se muestran con su medio, su titular y, si la tiene, la fecha. Sin sesión ves los titulares; para abrirlos necesitas una cuenta gratis, como el resto de los enlaces externos. Esos artículos están en sitios que no controlamos: la verificación y la orientación de la publicación no se aplican a ellos.</p>
  </section>

  <section id="privacidad" class="transparencia__seccion">
    <h2>Privacidad</h2>
    <ul class="lista-check">
      <li>Sin rastreadores, sin publicidad y sin servicios de terceros: las fuentes, las imágenes (también las miniaturas de YouTube) y los videos subidos se sirven desde este mismo sitio. Solo los videos de YouTube se cargan desde YouTube, y solo cuando pulsas reproducir (y su miniatura, únicamente si el servidor no pudo guardarla).</li>
      <li>Dos cookies propias y ninguna de seguimiento: la de sesión, que te mantiene conectado y protege los formularios, y la de preferencias de lectura (tema, colores, tamaño de texto), que solo existe si cambias algo y no incluye datos personales.</li>
      <li>Las búsquedas se guardan sin IP ni usuario, solo para mostrar “Lo más buscado”. El buscador en vivo y el asistente no guardan nada.</li>
      <li>Los registros de acceso guardan la IP recortada (la última parte en cero).</li>
      <li>El historial de lo que abres está apagado por defecto. Si lo activas, solo tú lo ves y puedes borrarlo cuando quieras.</li>
      <li>Puedes eliminar tu cuenta desde “Mi cuenta”, con todo su historial.</li>
      <li>Tu avatar es opcional. Si subes una foto de perfil, se guarda como una imagen nueva sin los datos ocultos del archivo original (como la ubicación) y la ven quienes lean tus comentarios; puedes borrarla del servidor cuando quieras.</li>
      <li>Las contraseñas se guardan con hash seguro (bcrypt), nunca en texto plano, y los enlaces externos se abren sin enviar desde qué página vienes.</li>
    </ul>
  </section>

  <section id="ligero" class="transparencia__seccion">
    <h2>Liviano a propósito</h2>
    <p>Menos código también es menos superficie de ataque. Sin frameworks ni librerías externas: el filtrado, el orden y la paginación ocurren dentro de la base de datos y el servidor solo carga la página que estás viendo. Los videos se entregan por partes y las imágenes en el tamaño justo para tu pantalla.</p>
    <p>Al pie de cada página verás cuánta memoria del servidor usó. Esta página: <strong><?= e(tamano_legible(memory_get_peak_usage())) ?></strong>.</p>
  </section>
</article>
<?php vista('pie', ['seccion' => 'transparencia']); ?>
