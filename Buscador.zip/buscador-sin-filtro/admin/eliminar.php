<?php
/** Elimina una publicación y sus archivos. Solo por POST con token. */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
require INC_DIR . '/admin.php';
requerir_admin();

if (!es_post() || !csrf_valido()) {
    flash('error', 'No se pudo eliminar: el formulario expiró. Vuelve a intentarlo.');
    redirigir(url('admin/publicaciones.php'));
}
$p = publicacion_por_id((int) entrada('id'));
if ($p && eliminar_publicacion((int) $p['id'])) {
    flash('exito', 'Eliminaste «' . $p['titulo'] . '».');
} else {
    flash('error', 'Esa publicación ya no existe.');
}
redirigir(volver_seguro(entrada('volver'), url('admin/publicaciones.php')));
