<?php
/** Cuentas y roles. Por privacidad, aquí no se ve el historial de nadie. */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
require INC_DIR . '/admin.php';
requerir_admin();

if (es_post()) {
    if (!csrf_valido()) {
        flash('error', 'El formulario expiró por seguridad. Vuelve a intentarlo.');
    } else {
        $r = cambiar_rol((int) entrada('id'), entrada('rol'));
        flash($r['ok'] ? 'exito' : 'error', $r['ok'] ? $r['mensaje'] : $r['error']);
    }
    redirigir(url('admin/usuarios.php', array_filter(['q' => entrada('q')])));
}

$q = mb_substr(trim(entrada('q')), 0, 80);
$pagina = max(1, (int) entrada('pagina', '1'));
$porPagina = 40;
$where = $q !== '' ? ' WHERE nombre LIKE ? OR email LIKE ?' : '';
$prm = $q !== '' ? ['%' . $q . '%', '%' . $q . '%'] : [];
$total = (int) valor('SELECT COUNT(*) FROM usuarios' . $where, $prm);
$paginas = max(1, (int) ceil($total / $porPagina));
$pagina = min($pagina, $paginas);
$lista = filas('SELECT id, nombre, email, rol, nombre_admin, creado_en, ultimo_acceso FROM usuarios' . $where
    . " ORDER BY CASE WHEN rol = 'admin' THEN 0 ELSE 1 END, creado_en DESC LIMIT {$porPagina} OFFSET " . (($pagina - 1) * $porPagina), $prm);
$yo = (int) usuario_actual()['id'];

vista('cabecera', ['titulo' => 'Usuarios', 'seccion' => 'admin', 'sin_indexar' => true]);
vista('admin-nav', ['activa' => 'usuarios', 'titulo' => 'Usuarios y roles']);
?>
<p class="caja__txt admin-intro">Nombra a otras personas como administradoras para que puedan subir, editar y eliminar publicaciones. Por privacidad, el panel no muestra lo que cada persona busca o abre.</p>
<form class="admin-filtros" method="get" role="search">
  <div class="campo campo--buscar">
    <label class="sr" for="u-q">Buscar cuentas</label>
    <?= icono('buscar') ?><input id="u-q" name="q" type="search" value="<?= e($q) ?>" placeholder="Buscar por nombre o correo">
  </div>
  <button class="boton boton--suave" type="submit">Buscar</button>
</form>
<p class="admin-total"><?= e(plural($total, 'cuenta', 'cuentas')) ?></p>
<div class="tabla-envoltura">
  <table class="tabla">
    <thead><tr><th scope="col">Persona</th><th scope="col">Rol</th><th scope="col">Se unió</th><th scope="col">Último acceso</th><th scope="col"><span class="sr">Acciones</span></th></tr></thead>
    <tbody>
      <?php foreach ($lista as $c): ?>
        <tr>
          <td><div class="tabla__pub"><span class="avatar-creador" style="--av: <?= e(color_avatar($c['nombre'])) ?>" aria-hidden="true"><?= e(iniciales($c['nombre'])) ?></span>
            <div><span class="tabla__titulo"><?= e($c['nombre']) ?><?= (int) $c['id'] === $yo ? ' (tú)' : '' ?></span><span class="tabla__sub"><?= e($c['email']) ?></span></div></div></td>
          <td data-col="Rol"><?php if ($c['rol'] === 'admin'): ?><span class="rol-chip"><?= icono('escudo') ?>Admin</span><?php if ($c['nombre_admin']): ?><span class="tabla__sub">Firma como <?= e($c['nombre_admin']) ?></span><?php endif; ?><?php else: ?>Usuario<?php endif; ?></td>
          <td data-col="Se unió"><?= e(fecha_larga($c['creado_en'])) ?></td>
          <td data-col="Último acceso"><?= $c['ultimo_acceso'] ? e(fecha_relativa($c['ultimo_acceso'])) : 'Nunca' ?></td>
          <td class="tabla__fin">
            <form method="post" data-confirmar="<?= $c['rol'] === 'admin' ? '¿Quitar el rol de admin a ' . e($c['nombre']) . '?' : '¿Dar rol de admin a ' . e($c['nombre']) . '? Podrá subir, editar y eliminar publicaciones.' ?>">
              <?= csrf_campo() ?><input type="hidden" name="id" value="<?= (int) $c['id'] ?>"><input type="hidden" name="q" value="<?= e($q) ?>">
              <?php if ($c['rol'] === 'admin'): ?>
                <input type="hidden" name="rol" value="usuario"><button class="boton boton--suave boton--chico" type="submit">Quitar admin<span class="sr"> a <?= e($c['nombre']) ?></span></button>
              <?php else: ?>
                <input type="hidden" name="rol" value="admin"><button class="boton boton--suave boton--chico" type="submit"><?= icono('escudo') ?>Hacer admin<span class="sr"> a <?= e($c['nombre']) ?></span></button>
              <?php endif; ?>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php vista('paginacion', ['pagina' => $pagina, 'paginas' => $paginas, 'ruta' => 'admin/usuarios.php', 'params' => array_filter(['q' => $q])]); ?>
</div></div>
<?php vista('pie', ['seccion' => 'admin']); ?>
