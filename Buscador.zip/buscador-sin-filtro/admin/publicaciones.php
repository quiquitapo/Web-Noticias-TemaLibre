<?php
/** Lista de publicaciones con búsqueda y filtros para administrar. */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
require INC_DIR . '/admin.php';
requerir_admin();

$f = filtros_desde_url($_GET);
$res = explorar($f, 30);
$volver = url_actual();

vista('cabecera', ['titulo' => 'Publicaciones', 'seccion' => 'admin', 'sin_indexar' => true]);
vista('admin-nav', [
    'activa' => 'publicaciones',
    'titulo' => 'Publicaciones',
    'accion' => '<a class="boton boton--primario" href="' . e(url('admin/publicar.php')) . '">' . icono('subir') . 'Subir publicación</a>',
]);
?>
<form class="admin-filtros" method="get" role="search">
  <div class="campo campo--buscar">
    <label class="sr" for="adm-q">Buscar publicaciones</label>
    <?= icono('buscar') ?><input id="adm-q" name="q" type="search" value="<?= e($f['q']) ?>" placeholder="Buscar por título, creador o etiqueta">
  </div>
  <label class="select"><span class="sr">Tipo</span>
    <select name="tipo" data-autoenviar-campo>
      <option value="">Todos los tipos</option>
      <?php foreach (TIPOS as $k => [, $pl]): ?><option value="<?= e($k) ?>"<?= in_array($k, $f['tipo'], true) ? ' selected' : '' ?>><?= e($pl) ?></option><?php endforeach; ?>
    </select>
  </label>
  <label class="select"><span class="sr">Categoría</span>
    <select name="cat">
      <option value="">Todas las categorías</option>
      <?php foreach (categorias_planas() as $c): ?><option value="<?= e($c['slug']) ?>"<?= $f['cat'] === $c['slug'] ? ' selected' : '' ?>><?= $c['nivel'] ? '— ' : '' ?><?= e($c['nombre']) ?></option><?php endforeach; ?>
    </select>
  </label>
  <label class="select"><span class="sr">Verificación</span>
    <select name="verificacion">
      <option value="">Cualquier verificación</option>
      <?php foreach (VERIFICACIONES as $k => [$t]): ?><option value="<?= e($k) ?>"<?= in_array($k, $f['verificacion'], true) ? ' selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?>
    </select>
  </label>
  <button class="boton boton--suave" type="submit">Filtrar</button>
</form>

<p class="admin-total"><?= e(plural($res['total'], 'publicación', 'publicaciones')) ?></p>
<div class="tabla-envoltura">
  <table class="tabla">
    <thead>
      <tr><th scope="col">Publicación</th><th scope="col">Categoría</th><th scope="col">Etiquetas</th><th scope="col" class="num">Vistas</th><th scope="col">Publicada</th><th scope="col"><span class="sr">Acciones</span></th></tr>
    </thead>
    <tbody>
      <?php foreach ($res['items'] as $p): ?>
        <tr>
          <td>
            <div class="tabla__pub">
              <?= img($p['miniatura'], [480], '96px', '', 480, 270, $p['miniatura_color']) ?>
              <div>
                <a class="tabla__titulo" href="<?= e(url('admin/publicar.php', ['id' => $p['id']])) ?>"><?= e($p['titulo']) ?></a>
                <span class="tabla__sub"><?= e(TIPOS[$p['tipo']][0]) ?><?= $p['tipo'] === 'video' ? ', ' . e(duracion((int) $p['duracion_seg'])) : '' ?>, <?= e($p['creador']) ?></span>
              </div>
            </div>
          </td>
          <td data-col="Categoría"><?= $p['padre_nombre'] ? e($p['padre_nombre']) . ' › ' : '' ?><?= e($p['categoria_nombre']) ?></td>
          <td data-col="Etiquetas"><div class="tabla__etiquetas"><?php vista('sello', ['verificacion' => $p['verificacion']]); ?><?php vista('escala', ['orientacion' => $p['orientacion'], 'compacta' => true]); ?></div></td>
          <td class="num" data-col="Vistas"><?= e(numero_corto((int) $p['vistas'])) ?></td>
          <td data-col="Publicada"><time datetime="<?= e(fecha_iso($p['publicado_en'])) ?>"><?= e(fecha_relativa($p['publicado_en'])) ?></time></td>
          <td class="tabla__fin">
            <div class="tabla__acciones">
              <a class="icono-btn" href="<?= e(url('video.php', ['v' => $p['slug']])) ?>" title="Ver en el sitio"><?= icono('ojo') ?><span class="sr">Ver «<?= e($p['titulo']) ?>» en el sitio</span></a>
              <a class="icono-btn" href="<?= e(url('admin/publicar.php', ['id' => $p['id']])) ?>" title="Editar"><?= icono('editar') ?><span class="sr">Editar «<?= e($p['titulo']) ?>»</span></a>
              <form method="post" action="<?= e(url('admin/eliminar.php')) ?>" data-confirmar="¿Eliminar «<?= e($p['titulo']) ?>»? Se borran también sus archivos. No se puede deshacer.">
                <?= csrf_campo() ?><input type="hidden" name="id" value="<?= (int) $p['id'] ?>"><input type="hidden" name="volver" value="<?= e($volver) ?>">
                <button class="icono-btn icono-btn--peligro" type="submit" title="Eliminar"><?= icono('eliminar') ?><span class="sr">Eliminar «<?= e($p['titulo']) ?>»</span></button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$res['items']): ?>
        <tr><td colspan="6" class="tabla__vacia">No hay publicaciones con estos filtros. <a href="<?= e(url('admin/publicar.php')) ?>">Sube la primera</a>.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php vista('paginacion', ['pagina' => $res['pagina'], 'paginas' => $res['paginas'], 'ruta' => 'admin/publicaciones.php', 'params' => filtros_a_url($f, ['pagina' => 1])]); ?>
</div></div>
<?php vista('pie', ['seccion' => 'admin']); ?>
