<?php
/** Datos públicos de un video de YouTube (título y canal) para completar el formulario del panel. */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
require INC_DIR . '/admin.php';

if (!es_admin()) {
    json_respuesta(['ok' => false, 'error' => 'Necesitas una cuenta de administración.'], 403);
}
$id = youtube_id_de((string) ($_GET['url'] ?? ''));
if (!$id) {
    json_respuesta(['ok' => false, 'error' => 'No reconocemos ese enlace de YouTube. Pega la dirección del video.'], 422);
}
$o = youtube_oembed($id);
if (!$o) {
    json_respuesta(['ok' => false, 'id' => $id, 'fuente' => youtube_url($id), 'error' => 'El servidor no pudo consultar YouTube (sin conexión o video privado). Completa título y canal a mano; la miniatura se descargará cuando haya conexión.'], 502);
}
json_respuesta(['ok' => true, 'id' => $id, 'fuente' => youtube_url($id)] + $o);
