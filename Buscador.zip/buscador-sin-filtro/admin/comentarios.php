<?php
/** Moderación de comentarios: buscar y eliminar spam, amenazas o datos personales. */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
require INC_DIR . '/admin.php';
requerir_admin();

$q = mb_substr(entrada('q'), 0, 100);
$pagina = max(1, (int) entrada('pagina', '1'));
if (es_post()) {
    if (!csrf_valido()) {
        flash('error', 'El formulario expiró por seguridad. Vuelve a intentarlo.');
    } else {
        $r = eliminar_comentario(usuario_actual(), (int) entrada('id'));
        flash($r['ok'] ? 'exito' : 'error', $r['ok'] ? 'Comentario eliminado.' : $r['error']);
    }
    redirigir(url('admin/comentarios.php', array_filter(['q' => $q, 'pagina' => $pagina > 1 ? $pagina : null])));
}
$res = comentarios_recientes($q, $pagina);

vista('cabecera', ['titulo' => 'Comentarios', 'seccion' => 'admin', 'sin_indexar' => true]);
vista('admin-nav', ['activa' => 'comentarios', 'titulo' => 'Comentarios']);
?>
<p class="admin-intro">Las opiniones no se eliminan por su postura. Borra solo spam, amenazas, insultos personales o datos privados de terceros. Cada eliminación queda registrada.</p>
<form class="admin-filtros" method="get" role="search">
  <div class="campo campo--buscar">
    <label class="sr" for="c-q">Buscar comentarios</label>
    <?= icono('buscar') ?><input id="c-q" name="q" type="search" value="<?= e($q) ?>" placeholder="Buscar por texto, persona o publicación">
  </div>
  <button class="boton boton--suave" type="submit">Buscar</button>
</form>
<p class="admin-total"><?= e(plural($res['total'], 'comentario', 'comentarios')) ?></p>
<div class="tabla-envoltura">
  <table class="tabla">
    <thead><tr><th scope="col">Comentario</th><th scope="col">Persona</th><th scope="col">Publicación</th><th scope="col">Fecha</th><th scope="col"><span class="sr">Acciones</span></th></tr></thead>
    <tbody>
      <?php foreach ($res['items'] as $c): ?>
        <tr>
          <td><p class="tabla__comentario"><?= e(recortar($c['texto'], 220)) ?></p></td>
          <td data-col="Persona"><span class="tabla__titulo"><?= e($c['nombre']) ?></span><span class="tabla__sub"><?= e($c['email']) ?></span></td>
          <td data-col="Publicación"><a class="enlace" href="<?= e(url('video.php', ['v' => $c['slug']])) ?>#comentario-<?= (int) $c['id'] ?>"><?= e(recortar($c['titulo'], 70)) ?></a></td>
          <td data-col="Fecha"><time datetime="<?= e(fecha_iso($c['creado_en'])) ?>"><?= e(fecha_relativa($c['creado_en'])) ?></time></td>
          <td class="tabla__fin">
            <form method="post" data-confirmar="¿Eliminar el comentario de <?= e($c['nombre']) ?>? Hazlo solo si es spam, una amenaza o expone datos personales.">
              <?= csrf_campo() ?><input type="hidden" name="id" value="<?= (int) $c['id'] ?>"><input type="hidden" name="q" value="<?= e($q) ?>"><input type="hidden" name="pagina" value="<?= (int) $res['pagina'] ?>">
              <button class="icono-btn icono-btn--peligro" type="submit" title="Eliminar"><?= icono('eliminar') ?><span class="sr">Eliminar el comentario de <?= e($c['nombre']) ?></span></button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$res['items']): ?><tr><td colspan="5" class="tabla__vacia">No hay comentarios<?= $q !== '' ? ' con esa búsqueda' : '' ?>.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php vista('paginacion', ['pagina' => $res['pagina'], 'paginas' => $res['paginas'], 'ruta' => 'admin/comentarios.php', 'params' => array_filter(['q' => $q])]); ?>
</div></div>
<?php vista('pie', ['seccion' => 'admin']); ?>
