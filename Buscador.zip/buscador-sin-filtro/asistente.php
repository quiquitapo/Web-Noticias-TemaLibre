<?php
/**
 * Asistente de preguntas rápidas.
 * - Con JavaScript: el panel flotante envía POST con Accept: application/json y recibe la respuesta en JSON.
 * - Sin JavaScript: esta misma dirección muestra una página con el formulario y la respuesta.
 * Las preguntas no se guardan en ningún lado (van por POST para que tampoco queden en los registros del servidor).
 */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require_once INC_DIR . '/asistente.php';

$usuario = usuario_actual();
$ctx = asistente_contexto([
    'tipo' => entrada('tipo'),
    'ref' => entrada('ref'),
    'q' => entrada('q'),
]);
$json = es_peticion_json();
$pregunta = trim(mb_substr(entrada('pregunta'), 0, ASISTENTE_MAX + 50));
$respuesta = null;
$error = '';

if (es_post()) {
    if (!csrf_valido()) {
        $error = 'La conversación expiró por seguridad. Vuelve a enviar tu pregunta.';
        if ($json) {
            json_respuesta(['ok' => false, 'error' => $error, 'csrf' => csrf_token()], 403);
        }
    } elseif (!asistente_permitido()) {
        $error = 'Estás preguntando muy rápido. Espera un momento y vuelve a intentarlo.';
        if ($json) {
            json_respuesta(['ok' => false, 'error' => $error], 429);
        }
    } elseif (mb_strlen($pregunta) > ASISTENTE_MAX) {
        $error = 'La pregunta puede tener hasta ' . ASISTENTE_MAX . ' caracteres.';
        if ($json) {
            json_respuesta(['ok' => false, 'error' => $error], 422);
        }
    } elseif (!empty($_POST['inicio'])) {
        $respuesta = ['mensajes' => [asistente_msj(asistente_bienvenida($ctx))], 'sugerencias' => asistente_sugerencias($ctx)];
    } else {
        $respuesta = asistente_responder($pregunta, $ctx, $usuario);
    }
    session_write_close();
    if ($json) {
        json_respuesta(['ok' => true, 'lugar' => asistente_etiqueta($ctx)] + $respuesta);
    }
} elseif ($json) {
    json_respuesta(['ok' => false, 'error' => 'Usa POST.'], 405);
}

$respuesta ??= ['mensajes' => [asistente_msj(asistente_bienvenida($ctx))], 'sugerencias' => asistente_sugerencias($ctx)];
$datos = asistente_ctx_datos($ctx);
$lugar = asistente_etiqueta($ctx);
vista('cabecera', ['titulo' => 'Asistente', 'seccion' => 'asistente', 'sin_indexar' => true]);
?>
<div class="contenedor contenedor--texto pagina-asis">
  <p class="pagina-asis__volver"><a class="enlace" href="<?= e(asistente_url_lugar($ctx)) ?>"><?= icono('izq') ?>Volver a <?= e(recortar($lugar, 70)) ?></a></p>
  <h1 class="pagina-asis__titulo"><?= icono('asistente') ?>Asistente</h1>
  <p class="pagina-asis__intro">Respuestas rápidas sobre <strong><?= e($lugar) ?></strong>, con los datos del sitio. No guardamos tus preguntas.</p>

  <div class="asis-log asis-log--pagina">
    <?php if ($pregunta !== '' && es_post()): ?>
      <div class="asis-msj asis-msj--yo"><p class="asis-msj__txt"><span class="sr">Tú: </span><?= e($pregunta) ?></p></div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="asis-msj asis-msj--error" role="alert"><p class="asis-msj__txt"><?= e($error) ?></p></div>
    <?php else: ?>
      <?php foreach ($respuesta['mensajes'] as $m): ?>
        <div class="asis-msj asis-msj--bot">
          <p class="asis-msj__txt"><span class="sr">Asistente: </span><?= e($m['texto']) ?></p>
          <?php if ($m['enlaces']): ?>
            <ul class="asis-msj__enlaces">
              <?php foreach ($m['enlaces'] as $l): ?>
                <li><a href="<?= e($l['url']) ?>"<?= !empty($l['externo']) ? ' target="_blank" rel="noopener nofollow"' : '' ?>><?= e($l['texto']) ?><?php if (!empty($l['externo'])): ?><?= icono('externo') ?><span class="sr"> (se abre en una pestaña nueva)</span><?php endif; ?></a></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <form class="asis-form asis-form--pagina" method="post" action="<?= e(url('asistente.php')) ?>">
    <?= csrf_campo() ?>
    <?php foreach ($datos as $k => $v): ?><input type="hidden" name="<?= e($k) ?>" value="<?= e($v) ?>"><?php endforeach; ?>
    <label class="asis-form__label" for="asis-pag-q">Tu pregunta</label>
    <div class="asis-form__fila">
      <input class="asis-form__input" id="asis-pag-q" name="pregunta" type="text" maxlength="<?= ASISTENTE_MAX ?>" autocomplete="off" required placeholder="Por ejemplo: ¿cuál es la fuente?">
      <button class="boton boton--primario" type="submit"><?= icono('enviar') ?>Preguntar</button>
    </div>
  </form>

  <?php if ($respuesta['sugerencias']): ?>
    <form class="asis-sug" method="post" action="<?= e(url('asistente.php')) ?>" aria-label="Preguntas sugeridas">
      <?= csrf_campo() ?>
      <?php foreach ($datos as $k => $v): ?><input type="hidden" name="<?= e($k) ?>" value="<?= e($v) ?>"><?php endforeach; ?>
      <?php foreach ($respuesta['sugerencias'] as $s): ?>
        <button class="chip" type="submit" name="pregunta" value="<?= e($s) ?>"><?= e($s) ?></button>
      <?php endforeach; ?>
    </form>
  <?php endif; ?>
</div>
<?php vista('pie', ['seccion' => 'asistente']); ?>
