<?php
/** Preferencias de lectura (versión de página completa: funciona sin JavaScript). */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

$volver = volver_seguro(entrada('volver'), url());
if (es_post()) {
    if (csrf_valido()) {
        guardar_preferencias(!empty($_POST['restablecer']) ? [] : $_POST);
        flash('exito', !empty($_POST['restablecer']) ? 'Preferencias restablecidas.' : 'Preferencias guardadas.');
    } else {
        flash('error', 'El formulario expiró por seguridad. Vuelve a intentarlo.');
    }
    redirigir($volver);
}
vista('cabecera', ['titulo' => 'Preferencias de lectura', 'seccion' => 'preferencias', 'sin_indexar' => true]);
?>
<div class="contenedor contenedor--texto pagina-prefs">
  <h1 class="pagina-prefs__titulo"><?= icono('texto') ?>Preferencias de lectura</h1>
  <p class="pagina-prefs__intro">Ajusta colores, tamaño del texto, contraste, animaciones y la voz para escuchar publicaciones y comentarios.</p>
  <?php vista('preferencias', ['prefijo' => 'pag', 'volver' => $volver]); ?>
</div>
<?php vista('pie', ['seccion' => 'preferencias']); ?>
