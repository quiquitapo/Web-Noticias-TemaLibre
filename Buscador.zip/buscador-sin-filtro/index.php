<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

$arbol = categorias_arbol();
$eq = equilibrio();
$tendencias = tendencias(6);
$conSesion = sesion_iniciada();
$recientes = explorar(filtros_desde_url([]), 8)['items'];
$miradas = explorar(filtros_desde_url(['orden' => 'equilibrado', 'orientacion' => 'izquierda,centro-izquierda,centro,centro-derecha,derecha']), 5)['items'];
$verif = explorar(filtros_desde_url(['cat' => 'verificacion']), 4)['items'];
$estante = static fn(string $cat, string $orden = 'recientes', int $n = 4) => categoria_por_slug($cat) ? explorar(filtros_desde_url(['cat' => $cat, 'orden' => $orden]), $n)['items'] : [];
$maxOrient = max(1, ...array_map(static fn($k) => $eq['orientacion'][$k] ?? 0, ['izquierda', 'centro-izquierda', 'centro', 'centro-derecha', 'derecha']));

vista('cabecera', [
    'seccion'     => 'inicio',
    'variante'    => 'hero',
    'descripcion' => config('app.descripcion'),
    'json_ld'     => [
        '@context' => 'https://schema.org',
        '@type' => 'WebSite',
        'name' => config('app.nombre'),
        'url' => url_absoluta(url()),
        'potentialAction' => ['@type' => 'SearchAction', 'target' => url_absoluta(url('videos.php')) . '?q={search_term_string}', 'query-input' => 'required name=search_term_string'],
    ],
]);
?>
<section class="hero">
  <div class="contenedor hero__in">
    <div class="hero__buscar">
      <h1 class="hero__lema"><?= e(config('app.lema')) ?></h1>
      <p class="hero__sub">Busca videos y noticias con la orientación política a la vista, el estado de verificación de cada publicación y sin rastreo. El orden lo eliges tú.</p>
      <?php vista('buscador', ['id' => 'q-hero', 'variante' => 'hero']); ?>

      <ul class="hero__tipos" aria-label="Categorías">
        <?php foreach ($arbol as $r): ?>
          <li><a class="tipo-chip" href="<?= e(url('videos.php', ['cat' => $r['slug']])) ?>"><?= icono(icono_seccion($r['slug'])) ?><?= e($r['nombre']) ?><span class="tipo-chip__n"><?= (int) $r['total'] ?></span></a></li>
        <?php endforeach; ?>
      </ul>

      <div class="hero__tendencias">
        <h2 id="tend-titulo">Lo más buscado</h2>
        <ul aria-labelledby="tend-titulo">
          <?php foreach ($tendencias as $t): ?><li><a href="<?= e(url('videos.php', ['q' => $t])) ?>"><?= e($t) ?></a></li><?php endforeach; ?>
        </ul>
      </div>
    </div>

    <aside class="hero__equilibrio" aria-labelledby="eq-titulo">
      <h2 id="eq-titulo" class="hero__panel-titulo">Equilibrio del catálogo</h2>
      <p class="hero__panel-desc">Publicaciones con postura política, según su orientación declarada.</p>
      <ul class="barras">
        <?php foreach (['izquierda', 'centro-izquierda', 'centro', 'centro-derecha', 'derecha'] as $k): $n = (int) ($eq['orientacion'][$k] ?? 0); ?>
          <li class="barras__fila">
            <a class="barras__enlace" href="<?= e(url('videos.php', ['orientacion' => $k])) ?>">
              <span class="barras__txt"><?= e(ORIENTACIONES[$k][0]) ?></span>
              <span class="barras__pista" aria-hidden="true"><span class="barras__barra" style="--v: <?= round($n / $maxOrient * 100) ?>%"></span></span>
              <span class="barras__n"><?= $n ?><span class="sr"> publicaciones</span></span>
            </a>
          </li>
        <?php endforeach; ?>
      </ul>
      <p class="hero__panel-nota"><?= (int) ($eq['orientacion']['no-aplica'] ?? 0) ?> publicaciones no tratan temas políticos.</p>
      <ul class="hero__verif" aria-label="Estado de verificación">
        <?php foreach (VERIFICACIONES as $k => [$t]): ?>
          <li><a href="<?= e(url('videos.php', ['verificacion' => $k])) ?>"><?php vista('sello', ['verificacion' => $k]); ?><strong><?= (int) ($eq['verificacion'][$k] ?? 0) ?></strong></a></li>
        <?php endforeach; ?>
      </ul>
      <a class="hero__panel-enlace" href="<?= e(url('transparencia.php')) ?>">Cómo funciona el algoritmo<?= icono('der') ?></a>
    </aside>
  </div>
</section>

<section class="seccion" aria-labelledby="sec-recientes">
  <div class="contenedor">
    <div class="seccion__cabeza">
      <h2 class="seccion__titulo" id="sec-recientes">Lo más reciente</h2>
      <a class="enlace-mas" href="<?= e(url('videos.php')) ?>">Ver todos los videos<?= icono('der') ?></a>
    </div>
    <ul class="rejilla-videos">
      <?php foreach ($recientes as $i => $p): ?><li><?php vista('tarjeta', ['p' => $p, 'prioridad' => $i < 4]); ?></li><?php endforeach; ?>
    </ul>
  </div>
</section>

<?php if ($miradas): ?>
<section class="seccion seccion--miradas" aria-labelledby="sec-miradas">
  <div class="contenedor">
    <div class="seccion__cabeza">
      <div>
        <h2 class="seccion__titulo" id="sec-miradas"><?= icono('balanza') ?>Todas las miradas, lado a lado</h2>
        <p class="seccion__desc">La vista equilibrada intercala una publicación de cada orientación antes de repetir. Compara cómo se cuenta un mismo tema y decide tú.</p>
      </div>
      <a class="enlace-mas" href="<?= e(url('videos.php', ['orden' => 'equilibrado'])) ?>">Abrir la vista equilibrada<?= icono('der') ?></a>
    </div>
    <ul class="rejilla-videos rejilla-videos--cinco">
      <?php foreach ($miradas as $p): ?><li><?php vista('tarjeta', ['p' => $p]); ?></li><?php endforeach; ?>
    </ul>
  </div>
</section>
<?php endif; ?>

<?php $logros = $estante('logros', 'equilibrado', 5); $errores = $estante('errores', 'equilibrado', 5); ?>
<?php if ($logros || $errores): ?>
<section class="seccion" aria-labelledby="sec-aciertos">
  <div class="contenedor">
    <div class="seccion__cabeza">
      <div>
        <h2 class="seccion__titulo" id="sec-aciertos"><?= icono('aciertos') ?>Aciertos y errores, de todas las orientaciones</h2>
        <p class="seccion__desc">Lo que salió bien y lo que salió mal en gobiernos de izquierda, centro y derecha. Una publicación de cada orientación por fila, para que ninguna quede solo con lo bueno o solo con lo malo.</p>
      </div>
      <a class="enlace-mas" href="<?= e(url('videos.php', ['cat' => 'aciertos-errores', 'orden' => 'equilibrado'])) ?>">Ver todos<?= icono('der') ?></a>
    </div>
    <?php foreach ([['Logros', 'logros', $logros, 'check-circulo'], ['Errores', 'errores', $errores, 'alerta']] as [$t, $slug, $items, $ico]): if (!$items) { continue; } ?>
      <h3 class="seccion__subtitulo"><?= icono($ico) ?><a href="<?= e(url('videos.php', ['cat' => $slug, 'orden' => 'equilibrado'])) ?>"><?= e($t) ?></a></h3>
      <ul class="rejilla-videos rejilla-videos--cinco">
        <?php foreach ($items as $p): ?><li><?php vista('tarjeta', ['p' => $p]); ?></li><?php endforeach; ?>
      </ul>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<section class="seccion seccion--sala" aria-labelledby="sec-verif">
  <div class="contenedor">
    <div class="seccion__cabeza">
      <div>
        <h2 class="seccion__titulo" id="sec-verif"><?= icono('escudo') ?>Verificación</h2>
        <p class="seccion__desc">Cómo detectar montajes, campañas de cuentas falsas y videos fuera de contexto. Lo engañoso queda visible y etiquetado, para que puedas compararlo.</p>
      </div>
      <a class="enlace-mas" href="<?= e(url('videos.php', ['cat' => 'verificacion'])) ?>">Ver verificaciones<?= icono('der') ?></a>
    </div>
    <ul class="rejilla-videos">
      <?php foreach ($verif as $p): ?><li><?php vista('tarjeta', ['p' => $p]); ?></li><?php endforeach; ?>
    </ul>
  </div>
</section>

<?php
vista('estante', ['id' => 'sec-deportes', 'titulo' => 'Deportes', 'icono' => 'balon', 'items' => $estante('deportes'), 'href' => url('videos.php', ['cat' => 'deportes']), 'enlace' => 'Ver deportes']);
vista('estante', ['id' => 'sec-tecnologia', 'titulo' => 'Tecnología', 'icono' => 'chip', 'desc' => 'Proyectos de GitHub, inteligencia artificial, cámaras y computación cuántica.',
    'items' => $estante('tecnologia'), 'href' => url('videos.php', ['cat' => 'tecnologia']), 'enlace' => 'Ver tecnología']);
vista('estante', ['id' => 'sec-conflictos', 'titulo' => 'Conflictos y seguridad', 'icono' => 'globo', 'desc' => 'Lo que pasa en el mundo y en tu zona, con datos y sin alarmismo.',
    'items' => $estante('conflictos-seguridad'), 'href' => url('videos.php', ['cat' => 'conflictos-seguridad']), 'enlace' => 'Ver conflictos y seguridad']);
vista('estante', ['id' => 'sec-curiosidades', 'titulo' => 'Curiosidades y diversión', 'icono' => 'chispa', 'clase' => 'seccion--curiosidades',
    'desc' => 'La sección que nos pidieron: ciencia ficción, biología especulativa, series, anime, ejercicio y mitos desmentidos.',
    'items' => $estante('curiosidades', 'vistas'), 'href' => url('videos.php', ['cat' => 'curiosidades']), 'enlace' => 'Ver curiosidades']);
vista('estante', ['id' => 'sec-productos', 'titulo' => 'Productos', 'icono' => 'etiqueta', 'items' => $estante('productos', 'vistas'), 'href' => url('videos.php', ['cat' => 'productos']), 'enlace' => 'Ver todos los productos']);
?>

<?php if (!$conSesion): ?>
<section class="seccion seccion--cuenta" aria-labelledby="sec-cuenta">
  <div class="contenedor cuenta-cta">
    <div class="cuenta-cta__txt">
      <h2 class="seccion__titulo" id="sec-cuenta">Explorar es libre. Con una cuenta gratis ves todo</h2>
      <p>Buscar, filtrar y leer no requiere cuenta. Para reproducir videos, abrir la fuente de una noticia, ver enlaces de venta o las redes de cada creador, inicia sesión. No usamos tu cuenta para perfilarte.</p>
      <div class="cuenta-cta__botones">
        <a class="boton boton--primario boton--grande" href="<?= e(url('registro.php', ['volver' => url_actual()])) ?>" data-acceso data-pestana="registro">Crear cuenta gratis</a>
        <a class="boton boton--suave boton--grande" href="<?= e(url_acceso()) ?>" data-acceso>Ya tengo cuenta</a>
      </div>
    </div>
    <?php vista('desbloquea'); ?>
  </div>
</section>
<?php endif; ?>

<?php vista('pie', ['seccion' => 'inicio']); ?>
