<?php
/**
 * Redirección protegida a enlaces externos (fuente, venta, red social, YouTube y noticias de prensa).
 * Las URL reales nunca se imprimen en la página para visitantes sin sesión.
 */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

$tipo = entrada('t');
$id = (int) entrada('id');

[$destino, $pubId] = match ($tipo) {
    'venta'   => [valor('SELECT venta_url FROM publicaciones WHERE id = ?', [$id]), $id],
    'fuente'  => [valor('SELECT fuente_url FROM publicaciones WHERE id = ?', [$id]), $id],
    'creador' => [valor('SELECT creador_url FROM publicaciones WHERE id = ?', [$id]), $id],
    'youtube' => [($yt = valor('SELECT youtube_id FROM publicaciones WHERE id = ?', [$id])) && youtube_id_de((string) $yt) ? youtube_url((string) $yt) : null, $id],
    'red'     => (static function () use ($id) { $r = red_por_id($id); return [$r['url'] ?? null, (int) ($r['publicacion_id'] ?? 0)]; })(),
    'prensa'  => (static function () use ($id) { $a = prensa_por_id($id); return [$a['url'] ?? null, (int) ($a['publicacion_id'] ?? 0)]; })(),
    default   => [null, 0],
};

if (!$destino || !preg_match('#^https?://#i', (string) $destino)) {
    no_encontrado();
}

if (!sesion_iniciada()) {
    $ref = (string) ($_SERVER['HTTP_REFERER'] ?? '');
    $volver = '';
    if ($ref !== '' && parse_url($ref, PHP_URL_HOST) === ($_SERVER['HTTP_HOST'] ?? '')) {
        $volver = (string) parse_url($ref, PHP_URL_PATH) . (($qs = parse_url($ref, PHP_URL_QUERY)) ? '?' . $qs : '');
    }
    redirigir(url('entrar.php', ['volver' => volver_seguro($volver), 'motivo' => ['creador' => 'red', 'youtube' => 'video'][$tipo] ?? $tipo]));
}

registrar_clic(usuario_actual(), $pubId, $tipo);
header('Cache-Control: no-store');
header('Referrer-Policy: no-referrer');
redirigir((string) $destino, 302);
