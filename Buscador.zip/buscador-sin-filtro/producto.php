<?php
/** Compatibilidad: busca la publicación de venta de un producto de la versión anterior. */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
$slug = preg_replace('/[^a-z0-9-]/', '', entrada('p'));
$destino = $slug !== '' ? valor('SELECT slug FROM publicaciones WHERE slug = ? OR venta_url LIKE ? ORDER BY tipo DESC LIMIT 1', [$slug . '-fotos', '%/producto/' . $slug]) : null;
redirigir($destino ? url('video.php', ['v' => $destino]) : url('videos.php', ['cat' => 'productos']), 301);
