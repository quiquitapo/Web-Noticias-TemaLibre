<?php
/** Compatibilidad: noticia.php?n=slug ahora es video.php?v=slug */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
redirigir(url('video.php', ['v' => entrada('n')]), 301);
