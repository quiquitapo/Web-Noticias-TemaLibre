<?php
/** Explorar: galería de videos, noticias y fotos con búsqueda, categorías y filtros. */
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$f = filtros_desde_url($_GET);
$catActual = $f['cat'] !== '' ? categoria_por_slug($f['cat']) : null;
if (!$catActual) {
    $f['cat'] = '';
}
$res = explorar($f);
$fac = facetas($f);
if ($f['q'] !== '' && $res['pagina'] === 1) {
    registrar_busqueda($f['q'], $res['total']);
}
$raiz = $catActual ? ($catActual['padre_slug'] ?: $catActual['slug']) : '';
$titulo = $f['q'] !== '' ? 'Resultados para “' . $f['q'] . '”'
    : ($catActual ? ($catActual['padre_nombre'] ? $catActual['padre_nombre'] . ': ' : '') . $catActual['nombre'] : 'Todos los videos');

vista('cabecera', [
    'titulo' => $titulo,
    'seccion' => $f['q'] !== '' ? 'buscar' : 'videos',
    'nav_activo' => in_array($raiz, ['noticias', 'verificacion', 'ventas'], true) ? $raiz : 'videos',
    'descripcion' => $catActual['descripcion'] ?? config('app.descripcion'),
    'sin_indexar' => $f['q'] !== '' || count(filtros_a_url($f, ['q' => '', 'cat' => ''])) > 0,
]);
vista('explorar', ['f' => $f, 'res' => $res, 'fac' => $fac, 'catActual' => $catActual, 'raiz' => $raiz, 'titulo' => $titulo]);
vista('pie', ['seccion' => $f['q'] !== '' ? 'buscar' : 'videos']);
