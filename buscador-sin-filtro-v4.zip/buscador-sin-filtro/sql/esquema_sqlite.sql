CREATE TABLE IF NOT EXISTS meta (
  clave VARCHAR(40) NOT NULL PRIMARY KEY,
  valor VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS categorias (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug VARCHAR(80) NOT NULL UNIQUE,
  nombre VARCHAR(80) NOT NULL,
  descripcion VARCHAR(255) NOT NULL DEFAULT '',
  padre_id INTEGER NULL,
  orden INT NOT NULL DEFAULT 0,
  FOREIGN KEY (padre_id) REFERENCES categorias(id)
);

CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre VARCHAR(80) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  clave_hash VARCHAR(255) NOT NULL,
  rol VARCHAR(10) NOT NULL DEFAULT 'usuario',
  nombre_admin VARCHAR(80) NULL,
  guardar_historial SMALLINT NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL,
  ultimo_acceso DATETIME NULL
);

CREATE TABLE IF NOT EXISTS publicaciones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug VARCHAR(160) NOT NULL UNIQUE,
  tipo VARCHAR(10) NOT NULL,
  titulo VARCHAR(200) NOT NULL,
  descripcion TEXT NOT NULL,
  cuerpo TEXT NULL,
  categoria_id INTEGER NOT NULL,
  orientacion VARCHAR(20) NOT NULL DEFAULT 'no-aplica',
  orientacion_nota VARCHAR(255) NULL,
  verificacion VARCHAR(20) NOT NULL DEFAULT 'sin-verificar',
  verificacion_nota VARCHAR(600) NULL,
  creador VARCHAR(120) NOT NULL DEFAULT '',
  creador_url VARCHAR(255) NULL,
  autor VARCHAR(120) NULL,
  fuente_url VARCHAR(255) NULL,
  venta_url VARCHAR(255) NULL,
  tienda VARCHAR(120) NULL,
  precio INT NULL,
  precio_antes INT NULL,
  ficha TEXT NULL,
  miniatura VARCHAR(200) NOT NULL,
  miniatura_color CHAR(7) NOT NULL DEFAULT '#e5e7ef',
  video_archivo VARCHAR(200) NULL,
  video_webm VARCHAR(200) NULL,
  subtitulos VARCHAR(200) NULL,
  duracion_seg INT NOT NULL DEFAULT 0,
  etiquetas VARCHAR(500) NOT NULL DEFAULT '',
  vistas INT NOT NULL DEFAULT 0,
  destacado SMALLINT NOT NULL DEFAULT 0,
  subido_por_id INTEGER NULL,
  subido_por VARCHAR(80) NOT NULL DEFAULT '',
  titulo_norm VARCHAR(400) NOT NULL DEFAULT '',
  busqueda TEXT NOT NULL,
  publicado_en DATETIME NOT NULL,
  actualizado_en DATETIME NULL,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id),
  FOREIGN KEY (subido_por_id) REFERENCES usuarios(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS imagenes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  publicacion_id INTEGER NOT NULL,
  base VARCHAR(200) NOT NULL,
  color CHAR(7) NOT NULL DEFAULT '#e5e7ef',
  alt VARCHAR(255) NOT NULL DEFAULT '',
  orden INT NOT NULL DEFAULT 0,
  FOREIGN KEY (publicacion_id) REFERENCES publicaciones(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS redes_sociales (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  publicacion_id INTEGER NOT NULL,
  red VARCHAR(20) NOT NULL,
  usuario VARCHAR(80) NOT NULL,
  url VARCHAR(255) NOT NULL,
  FOREIGN KEY (publicacion_id) REFERENCES publicaciones(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS intentos_acceso (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  clave CHAR(64) NOT NULL,
  creado_en DATETIME NOT NULL
);

CREATE TABLE IF NOT EXISTS clics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  publicacion_id INTEGER NOT NULL,
  tipo VARCHAR(12) NOT NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (publicacion_id) REFERENCES publicaciones(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS busquedas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  termino VARCHAR(120) NOT NULL,
  resultados INT NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL
);

CREATE INDEX idx_pub_categoria ON publicaciones (categoria_id);

CREATE INDEX idx_pub_fecha ON publicaciones (publicado_en);

CREATE INDEX idx_pub_orientacion ON publicaciones (orientacion);

CREATE INDEX idx_pub_verificacion ON publicaciones (verificacion);

CREATE INDEX idx_pub_tipo ON publicaciones (tipo);

CREATE INDEX idx_cat_padre ON categorias (padre_id);

CREATE INDEX idx_img_pub ON imagenes (publicacion_id);

CREATE INDEX idx_redes_pub ON redes_sociales (publicacion_id);

CREATE INDEX idx_intentos_clave ON intentos_acceso (clave, creado_en);

CREATE INDEX idx_clics_usuario ON clics (usuario_id, creado_en);

CREATE INDEX idx_busquedas_fecha ON busquedas (creado_en);
