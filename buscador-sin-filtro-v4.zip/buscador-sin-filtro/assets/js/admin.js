/* ==========================================================================
   Sin Filtro — panel de administración
   Todo funciona sin JavaScript (formularios normales); esto agrega vistas previas,
   arrastrar y soltar, captura de miniatura desde el video y progreso de subida.
   ========================================================================== */

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const peso = (b) => (b >= 1048576 ? (b / 1048576).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB');
const tiempo = (s) => { s = Math.round(s); const m = Math.floor(s / 60); return `${m}:${String(s % 60).padStart(2, '0')}`; };
const icono = (n) => `<svg class="ico" aria-hidden="true" focusable="false"><use href="#i-${n}"/></svg>`;

/* --- Confirmación accesible (reemplaza a confirm()) ---------------------------- */
function confirmar(mensaje, aceptar = 'Eliminar') {
  return new Promise((resolver) => {
    const dlg = document.createElement('dialog');
    dlg.className = 'dlg dlg-confirmar';
    dlg.setAttribute('aria-labelledby', 'conf-titulo');
    dlg.innerHTML = `<div class="confirmar">
      <span class="confirmar__ico">${icono('alerta')}</span>
      <h2 class="confirmar__titulo" id="conf-titulo">${esc(mensaje)}</h2>
      <div class="confirmar__botones">
        <button class="boton boton--suave" type="button" value="no">Cancelar</button>
        <button class="boton boton--peligro" type="button" value="si">${esc(aceptar)}</button>
      </div></div>`;
    document.body.append(dlg);
    const cerrar = (v) => { dlg.close(); dlg.remove(); resolver(v); };
    dlg.addEventListener('click', (e) => {
      const b = e.target.closest('button');
      if (b) cerrar(b.value === 'si');
      else if (e.target === dlg) cerrar(false);
    });
    dlg.addEventListener('cancel', (e) => { e.preventDefault(); cerrar(false); });
    dlg.showModal();
    $('button[value="no"]', dlg).focus();
  });
}

for (const f of $$('form[data-confirmar]')) {
  f.addEventListener('submit', async (e) => {
    if (f.dataset.confirmado) return;
    e.preventDefault();
    const boton = e.submitter;
    const txt = boton?.textContent.trim().split(' ')[0] || 'Confirmar';
    if (await confirmar(f.dataset.confirmar, /quitar|hacer/i.test(txt) ? 'Confirmar' : 'Eliminar')) {
      f.dataset.confirmado = '1';
      f.requestSubmit(boton);
    }
  });
}

for (const s of $$('select[data-autoenviar-campo]')) {
  if (s.closest('[data-filtros]')) continue;
  s.addEventListener('change', () => s.form.requestSubmit());
}

/* --- Formulario de publicación ---------------------------------------------------- */
const form = $('[data-publicar]');
if (form) publicar(form);

function publicar(form) {
  const maxVideo = Number(form.dataset.maxVideo) * 1048576;
  const maxImg = Number(form.dataset.maxImg) * 1048576;
  const resumen = $('[data-resumen-errores]', form);

  // Tipo: muestra solo los campos que aplican
  const tipoActual = () => $('input[name="tipo"]:checked', form)?.value || 'video';
  const aplicarTipo = () => {
    const t = tipoActual();
    for (const el of $$('[data-solo]', form)) el.hidden = el.dataset.solo !== t;
    for (const el of $$('[data-solo-no]', form)) el.hidden = el.dataset.soloNo === t;
  };
  for (const r of $$('input[name="tipo"]', form)) r.addEventListener('change', aplicarTipo);
  aplicarTipo();

  // Venta: visible para la categoría Ventas o si ya tiene datos
  const venta = $('[data-seccion-venta]', form);
  const cat = $('[data-categoria]', form);
  const tieneVenta = () => $$('input, textarea', venta).some((i) => i.value.trim() !== '');
  const btnVenta = document.createElement('button');
  btnVenta.type = 'button';
  btnVenta.className = 'boton boton--suave boton--ancho';
  btnVenta.innerHTML = `${icono('etiqueta')}Agregar datos de venta`;
  btnVenta.addEventListener('click', () => { venta.hidden = false; btnVenta.hidden = true; $('input', venta).focus(); });
  venta.after(btnVenta);
  const aplicarVenta = () => {
    const esVentas = cat.selectedOptions[0]?.dataset.raiz === 'ventas';
    venta.hidden = !(esVentas || tieneVenta());
    btnVenta.hidden = !venta.hidden;
  };
  cat.addEventListener('change', aplicarVenta);
  aplicarVenta();

  // Contadores de caracteres
  for (const c of $$('[data-contar]', form)) {
    const p = document.createElement('p');
    p.className = 'campo__contador';
    p.setAttribute('aria-live', 'polite');
    const pintar = () => { p.textContent = `${c.value.length} / ${c.maxLength}`; p.classList.toggle('cerca', c.value.length > c.maxLength * 0.9); };
    c.addEventListener('input', pintar);
    c.after(p);
    pintar();
  }

  // Arrastrar y soltar
  for (const zona of $$('[data-soltar]', form)) {
    const input = $('input[type="file"]', zona);
    const etiqueta = $('.soltar__zona', zona);
    ['dragenter', 'dragover'].forEach((ev) => etiqueta.addEventListener(ev, (e) => { e.preventDefault(); etiqueta.classList.add('encima'); }));
    ['dragleave', 'drop'].forEach((ev) => etiqueta.addEventListener(ev, () => etiqueta.classList.remove('encima')));
    etiqueta.addEventListener('drop', (e) => {
      e.preventDefault();
      if (!e.dataTransfer.files.length) return;
      const dt = new DataTransfer();
      for (const f of e.dataTransfer.files) dt.items.add(f);
      input.files = dt.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
    });
  }

  // Video: vista previa, duración y validación
  const inVideo = $('#video', form);
  const vista = inVideo && $('[data-vista]', inVideo.closest('[data-soltar]'));
  const previa = inVideo && $('[data-video-previa]', vista);
  const duracion = $('[data-duracion]', form);
  let urlVideo = null;
  inVideo?.addEventListener('change', () => {
    const f = inVideo.files[0];
    limpiarError(inVideo);
    if (urlVideo) URL.revokeObjectURL(urlVideo);
    if (!f) { vista.hidden = true; return; }
    if (!/^video\/(mp4|webm)$/.test(f.type)) return marcarError(inVideo, 'El video debe ser MP4 o WebM. Si es .mov, expórtalo como MP4.');
    if (f.size > maxVideo) return marcarError(inVideo, `El video pesa ${peso(f.size)}; el máximo es ${peso(maxVideo)}.`);
    urlVideo = URL.createObjectURL(f);
    previa.src = urlVideo;
    vista.hidden = false;
    $('[data-info]', vista).textContent = `${f.name}, ${peso(f.size)}`;
    previa.addEventListener('loadedmetadata', () => {
      duracion.value = Math.round(previa.duration || 0);
      $('[data-info]', vista).textContent = `${f.name}, ${peso(f.size)}, dura ${tiempo(previa.duration)}`;
      previa.currentTime = Math.min(1, previa.duration / 3);
    }, { once: true });
  });

  // Captura de un cuadro del video como miniatura PNG
  const inMini = $('#miniatura', form);
  $('[data-capturar]', form)?.addEventListener('click', () => {
    if (!previa?.videoWidth) return;
    const c = document.createElement('canvas');
    c.width = 1280;
    c.height = 720;
    const ctx = c.getContext('2d');
    const r = Math.max(1280 / previa.videoWidth, 720 / previa.videoHeight);
    const w = previa.videoWidth * r, h = previa.videoHeight * r;
    ctx.drawImage(previa, (1280 - w) / 2, (720 - h) / 2, w, h);
    c.toBlob((blob) => {
      const dt = new DataTransfer();
      dt.items.add(new File([blob], 'miniatura-del-video.png', { type: 'image/png' }));
      inMini.files = dt.files;
      inMini.dispatchEvent(new Event('change', { bubbles: true }));
      anunciar('Cuadro del video listo como miniatura.');
    }, 'image/png');
  });

  // Miniatura: vista previa recortada a 16:9
  inMini?.addEventListener('change', () => {
    const f = inMini.files[0];
    const caja = inMini.closest('[data-soltar]');
    const v = $('[data-vista]', caja);
    limpiarError(inMini);
    if (!f) { v.hidden = true; return; }
    if (!/^image\/(png|jpeg|webp)$/.test(f.type)) return marcarError(inMini, 'La miniatura debe ser PNG, JPG o WebP.');
    if (f.size > maxImg) return marcarError(inMini, `La miniatura pesa ${peso(f.size)}; el máximo es ${peso(maxImg)}.`);
    const img = $('[data-img-previa]', v);
    img.src = URL.createObjectURL(f);
    img.onload = () => {
      v.hidden = false;
      caja.classList.add('con-previa');
      if (img.naturalWidth < 960) anunciar(`La imagen mide ${img.naturalWidth} px de ancho. Se verá mejor con 1280 px o más.`, v);
    };
  });

  // Fotos: vista previa y texto alternativo de cada una
  const inFotos = $('#fotos-input', form);
  inFotos?.addEventListener('change', () => {
    const lista = $('[data-fotos-previa]', form);
    lista.innerHTML = '';
    limpiarError(inFotos);
    [...inFotos.files].forEach((f, i) => {
      if (!/^image\/(png|jpeg|webp)$/.test(f.type) || f.size > maxImg) {
        marcarError(inFotos, `«${f.name}» no es una imagen válida o supera ${peso(maxImg)}.`);
        return;
      }
      const li = document.createElement('li');
      li.innerHTML = `<img alt="" src="${URL.createObjectURL(f)}">
        <label for="alt-${i}">Describe la foto ${i + 1}</label>
        <input id="alt-${i}" name="fotos_alt[]" maxlength="255" placeholder="Texto para lectores de pantalla">`;
      lista.append(li);
    });
  });

  // Redes adjuntas: agregar y quitar filas
  const listaRedes = $('[data-redes]', form);
  const plantilla = $('#plantilla-red');
  let nRed = 100;
  $('[data-agregar-red]', form)?.addEventListener('click', () => {
    const fila = plantilla.content.firstElementChild.cloneNode(true);
    const [lSel, lUrl] = $$('label', fila);
    const sel = $('select', fila), url = $('input', fila);
    sel.id = `red-${nRed}`; url.id = `red-url-${nRed}`;
    lSel.htmlFor = sel.id; lUrl.htmlFor = url.id;
    nRed++;
    listaRedes.append(fila);
    sel.focus();
  });
  listaRedes?.addEventListener('click', (e) => {
    const b = e.target.closest('[data-quitar-red]');
    if (!b) return;
    const fila = b.closest('[data-red-fila]');
    if ($$('[data-red-fila]', listaRedes).length > 1) {
      fila.remove();
      $('[data-agregar-red]', form).focus();
    } else {
      $('input', fila).value = '';
      $('input', fila).focus();
    }
  });

  // Envío con barra de progreso (los videos pueden ser pesados)
  const progreso = $('[data-progreso]', form);
  const barra = $('[data-progreso-barra]', form);
  const txtProg = $('[data-progreso-txt]', form);
  const boton = $('[data-enviar]', form);
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const errores = validarLocal();
    if (errores.length) return mostrarResumen(Object.fromEntries(errores));
    const datos = new FormData(form);
    const xhr = new XMLHttpRequest();
    xhr.open('POST', form.action);
    xhr.setRequestHeader('Accept', 'application/json');
    xhr.setRequestHeader('X-Requested-With', 'fetch');
    xhr.upload.addEventListener('progress', (ev) => {
      if (!ev.lengthComputable) return;
      const p = Math.round((ev.loaded / ev.total) * 100);
      barra.style.width = p + '%';
      txtProg.textContent = p < 100 ? `Subiendo… ${p} % (${peso(ev.loaded)} de ${peso(ev.total)})` : 'Procesando imágenes…';
    });
    xhr.addEventListener('load', () => {
      let r = null;
      try { r = JSON.parse(xhr.responseText); } catch { /* respuesta no JSON */ }
      if (r?.ok) { txtProg.textContent = 'Listo. Abriendo la publicación…'; location.assign(r.redirigir); return; }
      terminar();
      if (r?.csrf) for (const c of $$('input[name="csrf"]')) c.value = r.csrf;
      mostrarResumen(r?.errores || { general: xhr.status === 413 ? 'El archivo es demasiado grande para el servidor.' : 'El servidor no respondió como esperábamos. Vuelve a intentarlo.' });
    });
    xhr.addEventListener('error', () => { terminar(); mostrarResumen({ general: 'Se cortó la conexión durante la subida. Revisa tu internet y vuelve a intentarlo.' }); });
    progreso.hidden = false;
    barra.style.width = '0%';
    boton.disabled = true;
    boton.setAttribute('aria-busy', 'true');
    xhr.send(datos);
  });
  function terminar() {
    progreso.hidden = true;
    boton.disabled = false;
    boton.removeAttribute('aria-busy');
  }

  function validarLocal() {
    const err = [];
    const t = tipoActual();
    const req = (sel, clave, msg) => { const el = $(sel, form); if (el && !el.value.trim()) { err.push([clave, msg]); marcarError(el, msg); } };
    req('#titulo', 'titulo', 'Escribe un título.');
    req('#descripcion', 'descripcion', 'Escribe una descripción.');
    req('#categoria', 'categoria_id', 'Elige una categoría.');
    req('#creador', 'creador', 'Escribe quién creó el contenido.');
    const esNueva = !/[?&]id=\d+/.test(form.action);
    if (esNueva && !inMini.files.length && !(t === 'imagen' && inFotos.files.length)) err.push(['miniatura', 'Sube una miniatura (PNG recomendado).']);
    if (esNueva && t === 'video' && !inVideo.files.length) err.push(['video', 'Sube el archivo de video.']);
    if (t === 'imagen' && esNueva && !inFotos.files.length) err.push(['fotos', 'Sube al menos una foto.']);
    if ($('#verificacion-enganoso', form)?.checked && $('#verificacion_nota', form).value.trim().length < 10) {
      err.push(['verificacion_nota', 'Explica por qué es engañoso.']);
      marcarError($('#verificacion_nota', form), 'Explica por qué es engañoso.');
    }
    for (const el of $$('[aria-invalid="true"]', form)) {
      const m = el.closest('[data-soltar], .campo')?.querySelector('.campo__error span')?.textContent;
      if (m && !err.some(([, x]) => x === m)) err.push([el.name || el.id, m]);
    }
    return err;
  }

  const nombres = { titulo: 'Título', descripcion: 'Descripción', categoria_id: 'Categoría', creador: 'Creador', miniatura: 'Miniatura', video: 'Video', fotos: 'Fotos',
    verificacion_nota: 'Nota de verificación', archivos: 'Archivos', general: 'Formulario', redes: 'Redes', creador_url: 'URL del creador', fuente_url: 'URL de la noticia',
    venta_url: 'URL de venta', precio_antes: 'Precio anterior', tipo: 'Tipo', orientacion: 'Orientación', verificacion: 'Verificación', publicado_en: 'Fecha' };
  const anclas = { categoria_id: 'categoria', archivos: 'miniatura', general: 'titulo', fotos: 'fotos-input', tipo: 'tipo-video', orientacion: 'orientacion-no-aplica', verificacion: 'verificacion-sin-verificar', redes: 'redes' };
  function mostrarResumen(errores) {
    const items = Object.entries(errores);
    resumen.innerHTML = `<h2>${icono('alerta')}Revisa ${items.length === 1 ? 'un campo' : items.length + ' campos'} antes de publicar</h2>
      <ul>${items.map(([k, m]) => `<li><a href="#${anclas[k] || k}">${esc((nombres[k] || k) + ': ' + m)}</a></li>`).join('')}</ul>`;
    resumen.hidden = false;
    for (const [k, m] of items) {
      const el = form.elements[k] instanceof RadioNodeList ? null : form.elements[k];
      if (el && el.tagName) marcarError(el, m);
    }
    resumen.focus();
    resumen.scrollIntoView({ block: 'start', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
  }

  form.addEventListener('input', (e) => { if (e.target.getAttribute('aria-invalid')) limpiarError(e.target); });
}

function marcarError(el, msg) {
  el.setAttribute('aria-invalid', 'true');
  const cont = el.closest('[data-soltar]') || el.closest('.campo') || el.parentElement;
  let p = cont.querySelector(':scope > .campo__error, :scope + .campo__error');
  if (!p) {
    p = document.createElement('p');
    p.className = 'campo__error';
    p.id = 'err-' + (el.name || el.id).replace(/\W/g, '');
    cont.append(p);
  }
  p.innerHTML = `${icono('alerta')}<span>${esc(msg)}</span>`;
  p.hidden = false;
  el.setAttribute('aria-describedby', p.id);
}

function limpiarError(el) {
  el.removeAttribute('aria-invalid');
  const cont = el.closest('[data-soltar]') || el.closest('.campo') || el.parentElement;
  const p = cont.querySelector(':scope > .campo__error');
  if (p) p.hidden = true;
}

function anunciar(msg, cerca) {
  let p = cerca ? cerca.querySelector('.soltar__aviso') : null;
  if (cerca && !p) { p = document.createElement('p'); p.className = 'soltar__aviso'; cerca.append(p); }
  const vivo = $('[data-avisos]');
  if (p) p.textContent = msg;
  if (vivo) {
    const a = document.createElement('div');
    a.className = 'aviso aviso--info';
    a.innerHTML = `${icono('check')}<p>${esc(msg)}</p>`;
    vivo.append(a);
    setTimeout(() => a.remove(), 4000);
  }
}
