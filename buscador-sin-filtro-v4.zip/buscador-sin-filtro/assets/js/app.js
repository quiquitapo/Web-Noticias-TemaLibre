/* ==========================================================================
   Sin Filtro — interacción
   Mejora progresiva: todo funciona sin JavaScript; esto agrega búsqueda en vivo,
   diálogos, animaciones y atajos de teclado.
   ========================================================================== */

const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
const BASE = document.body.dataset.base || '';
const menosMovimiento = matchMedia('(prefers-reduced-motion: reduce)');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const icono = (n, clase = '') => `<svg class="ico ${clase}" aria-hidden="true" focusable="false"><use href="#i-${n}"/></svg>`;

/* --- Imágenes: aparecen suavemente cuando terminan de cargar ---------------- */
function imagenes(raiz = document) {
  for (const img of $$('img.img[loading="lazy"]', raiz)) {
    const listo = () => img.classList.add('cargada');
    if (img.complete && img.naturalWidth) listo();
    else {
      img.addEventListener('load', listo, { once: true });
      img.addEventListener('error', listo, { once: true });
    }
  }
}

/* --- Tema claro / oscuro ------------------------------------------------------ */
function tema() {
  const btn = $('[data-tema]');
  if (!btn) return;
  const raiz = document.documentElement;
  const sistema = matchMedia('(prefers-color-scheme: dark)');
  const actual = () => raiz.dataset.theme || (sistema.matches ? 'dark' : 'light');
  const pintar = () => btn.setAttribute('aria-pressed', String(actual() === 'dark'));
  btn.addEventListener('click', () => {
    const nuevo = actual() === 'dark' ? 'light' : 'dark';
    const aplicar = () => {
      raiz.dataset.theme = nuevo;
      try { localStorage.setItem('sf-tema', nuevo === 'dark' ? 'oscuro' : 'claro'); } catch { /* sin almacenamiento */ }
      pintar();
    };
    if (document.startViewTransition && !menosMovimiento.matches) document.startViewTransition(aplicar);
    else aplicar();
  });
  sistema.addEventListener('change', pintar);
  pintar();
}

/* --- Cabecera: cambia de azul a sólida al pasar la portada ------------------ */
function cabecera() {
  const cab = $('.cabecera');
  if (!cab) return;
  const hero = $('.hero');
  const meta = $('meta[name="theme-color"][media*="light"]');
  if (hero && 'IntersectionObserver' in window) {
    const io = new IntersectionObserver(([e]) => {
      const solida = !e.isIntersecting;
      cab.classList.toggle('cabecera--solida', solida);
      if (meta) meta.content = solida ? '#ffffff' : '#2340F5';
    }, { rootMargin: `-${cab.offsetHeight}px 0px 0px 0px` });
    io.observe(hero);
  } else {
    let pendiente = false;
    const revisar = () => { cab.classList.toggle('cabecera--solida', scrollY > 4); pendiente = false; };
    addEventListener('scroll', () => { if (!pendiente) { pendiente = true; requestAnimationFrame(revisar); } }, { passive: true });
    revisar();
  }
}

/* --- Diálogos con animación de cierre ---------------------------------------- */
const anteriorFoco = new WeakMap();
function abrirDialogo(dlg, origen) {
  if (dlg.open) return;
  anteriorFoco.set(dlg, origen || document.activeElement);
  dlg.showModal();
  document.documentElement.style.overflow = 'hidden';
}
function cerrarDialogo(dlg) {
  if (!dlg.open || dlg.classList.contains('cerrando')) return;
  const fin = () => {
    dlg.classList.remove('cerrando');
    dlg.close();
  };
  if (menosMovimiento.matches) fin();
  else {
    dlg.classList.add('cerrando');
    dlg.addEventListener('animationend', fin, { once: true });
    setTimeout(() => dlg.open && fin(), 400);
  }
}
function prepararDialogo(dlg) {
  dlg.addEventListener('cancel', (e) => { e.preventDefault(); cerrarDialogo(dlg); });
  dlg.addEventListener('close', () => {
    document.documentElement.style.overflow = '';
    const f = anteriorFoco.get(dlg);
    if (f && document.contains(f)) f.focus({ preventScroll: true });
  });
  // Clic fuera del contenido (en el fondo) cierra
  dlg.addEventListener('pointerdown', (e) => { dlg._fondo = e.target === dlg; });
  dlg.addEventListener('click', (e) => { if (e.target === dlg && dlg._fondo) cerrarDialogo(dlg); });
  for (const b of $$('[data-cerrar]', dlg)) b.addEventListener('click', () => cerrarDialogo(dlg));
}

/* --- Buscador en vivo (patrón combobox de ARIA) ------------------------------ */
const cacheBusqueda = new Map();

class Buscador {
  constructor(form) {
    this.form = form;
    this.input = $('.buscador__input', form);
    this.panel = $('[data-panel]', form);
    this.lista = $('[role="listbox"]', form);
    this.estado = $('[data-estado]', form);
    this.limpiar = $('[data-limpiar]', form);
    this.enDialogo = form.classList.contains('buscador--dialogo');
    this.opciones = [];
    this.activo = -1;
    this.ctrl = null;
    this.temporizador = 0;
    if (this.enDialogo) this.panel.hidden = false;

    this.input.addEventListener('input', () => this.alEscribir());
    this.input.addEventListener('keydown', (e) => this.teclado(e));
    this.input.addEventListener('focus', () => { if (this.opciones.length && this.input.value.trim().length >= 2) this.abrir(); });
    this.limpiar?.addEventListener('click', () => {
      this.input.value = '';
      this.alEscribir();
      this.input.focus();
    });
    document.addEventListener('pointerdown', (e) => {
      if (!this.enDialogo && !this.form.contains(e.target)) this.cerrar();
    });
    this.form.addEventListener('focusout', (e) => {
      if (!this.enDialogo && e.relatedTarget && !this.form.contains(e.relatedTarget)) this.cerrar();
    });
    this.lista.addEventListener('pointermove', (e) => {
      const op = e.target.closest('[role="option"]');
      if (op) this.marcar(this.opciones.indexOf(op), false);
    });
  }

  alEscribir() {
    const q = this.input.value.trim();
    if (this.limpiar) this.limpiar.hidden = this.input.value === '';
    clearTimeout(this.temporizador);
    if (q.length < 2) {
      this.ctrl?.abort();
      this.pintar(null);
      return;
    }
    this.temporizador = setTimeout(() => this.buscar(q), 140);
  }

  async buscar(q) {
    if (cacheBusqueda.has(q)) return this.pintar(cacheBusqueda.get(q));
    this.ctrl?.abort();
    this.ctrl = new AbortController();
    const cargando = setTimeout(() => this.cargando(), 180);
    try {
      const r = await fetch(`${BASE}/api/buscar.php?q=${encodeURIComponent(q)}`, {
        signal: this.ctrl.signal,
        headers: { Accept: 'application/json' },
      });
      if (!r.ok) throw new Error(r.status);
      const datos = await r.json();
      cacheBusqueda.set(q, datos);
      if (q === this.input.value.trim()) this.pintar(datos);
    } catch (err) {
      if (err.name !== 'AbortError') {
        this.lista.innerHTML = `<p class="sug-vacio">No pudimos cargar sugerencias. Presiona Enter para buscar igual.</p>`;
        this.abrir();
      }
    } finally {
      clearTimeout(cargando);
    }
  }

  cargando() {
    this.lista.innerHTML = '<div class="sug-cargando" aria-hidden="true"><span></span><span></span><span></span></div>';
    this.opciones = [];
    this.abrir();
  }

  pintar(datos) {
    this.activo = -1;
    this.input.removeAttribute('aria-activedescendant');
    if (!datos) {
      this.lista.innerHTML = '';
      this.opciones = [];
      this.estado.textContent = '';
      this.cerrar();
      return;
    }
    const id = this.lista.id;
    let n = 0;
    let html = '';
    if (!datos.total) {
      html = `<p class="sug-vacio">No encontramos nada para <strong>“${esc(datos.q)}”</strong>. Prueba con otra palabra o presiona Enter para ver ideas.</p>`;
    } else {
      for (const g of datos.grupos) {
        const gid = `${id}-g-${g.tipo}`;
        html += `<div class="sug-grupo" role="group" aria-labelledby="${gid}">
          <div class="sug-grupo__titulo" id="${gid}"><span class="punto punto--${g.tipo}" aria-hidden="true"></span>${esc(g.etiqueta)} <span class="sr">, ${g.total} resultados</span>
          ${g.total > g.items.length ? `<a class="sug-grupo__mas" href="${esc(g.ver_mas)}" tabindex="-1">Ver ${g.total}</a>` : ''}</div>`;
        for (const it of g.items) {
          const extra = it.verificacion === 'enganoso'
            ? `<span class="sug__extra sug__extra--engano">${icono('alerta')}Engañoso</span>`
            : it.precio ? `<span class="sug__extra">${esc(it.precio)}</span>` : '<span></span>';
          const orient = it.orientacion ? ` <span aria-hidden="true">—</span> ${esc(it.orientacion)}` : '';
          html += `<a class="sug sug--${g.tipo}" role="option" id="${id}-o${n}" href="${esc(it.url)}" tabindex="-1" aria-selected="false" style="--i:${n}">
            <span class="sug__img" style="--ph:${esc(it.color)}"><img src="${esc(it.imagen)}" alt="" width="64" height="40" decoding="async"></span>
            <span><span class="sug__titulo">${it.titulo_html}</span><span class="sug__meta">${esc(it.etiqueta)}${it.detalle ? ` <span aria-hidden="true">—</span> ${esc(it.detalle)}` : ''}${orient}</span></span>
            ${extra}
          </a>`;
          n++;
        }
      }
      html += `<a class="sug sug--todo" role="option" id="${id}-o${n}" href="${esc(datos.ver_todo)}" tabindex="-1" aria-selected="false" style="--i:${n}">
        <span>Ver los ${datos.total} resultados para “${esc(datos.q)}”</span>${icono('flecha')}</a>`;
    }
    this.lista.innerHTML = html;
    this.opciones = $$('[role="option"]', this.lista);
    this.estado.textContent = datos.total
      ? `${datos.total} resultados. Usa las flechas para recorrerlos.`
      : `Sin resultados para ${datos.q}.`;
    this.abrir();
  }

  abrir() {
    if (this.enDialogo) {
      this.input.setAttribute('aria-expanded', String(this.opciones.length > 0));
      return;
    }
    if (this.panel.hidden) {
      this.panel.hidden = false;
      if (!menosMovimiento.matches) {
        this.panel.classList.add('abriendo');
        this.panel.addEventListener('animationend', () => this.panel.classList.remove('abriendo'), { once: true });
      }
    }
    this.input.setAttribute('aria-expanded', 'true');
  }

  cerrar() {
    if (!this.enDialogo) this.panel.hidden = true;
    this.input.setAttribute('aria-expanded', 'false');
    this.marcar(-1);
  }

  marcar(i, desplazar = true) {
    this.opciones[this.activo]?.setAttribute('aria-selected', 'false');
    this.activo = i;
    const op = this.opciones[i];
    if (op) {
      op.setAttribute('aria-selected', 'true');
      this.input.setAttribute('aria-activedescendant', op.id);
      if (desplazar) op.scrollIntoView({ block: 'nearest' });
    } else {
      this.input.removeAttribute('aria-activedescendant');
    }
  }

  teclado(e) {
    const total = this.opciones.length;
    const abierto = this.enDialogo || !this.panel.hidden;
    switch (e.key) {
      case 'ArrowDown':
        if (!total) return;
        e.preventDefault();
        if (!abierto) this.abrir();
        this.marcar(this.activo + 1 >= total ? 0 : this.activo + 1);
        break;
      case 'ArrowUp':
        if (!total) return;
        e.preventDefault();
        if (!abierto) this.abrir();
        this.marcar(this.activo - 1 < 0 ? total - 1 : this.activo - 1);
        break;
      case 'Home':
      case 'End':
        if (!total || this.activo < 0) return;
        e.preventDefault();
        this.marcar(e.key === 'Home' ? 0 : total - 1);
        break;
      case 'Enter':
        if (this.activo >= 0 && this.opciones[this.activo]) {
          e.preventDefault();
          location.assign(this.opciones[this.activo].href);
        }
        break;
      case 'Escape':
        if (this.enDialogo) {
          e.preventDefault();
          cerrarDialogo(this.form.closest('dialog'));
        } else if (abierto) {
          e.preventDefault();
          this.cerrar();
        } else if (!this.enDialogo && this.input.value) {
          e.preventDefault();
          this.input.value = '';
          this.alEscribir();
        }
        break;
    }
  }
}

/* Texto de ejemplo que se escribe solo en la portada */
function placeholderAnimado(input) {
  const ejemplos = ['video falso de la inundación', 'licitación pública', 'transporte gratuito', 'campaña de cuentas falsas', 'impuesto al patrimonio', 'cómo detectar un deepfake'];
  if (menosMovimiento.matches) return;
  let i = 0, j = 0, borrando = false, visible = true, t = 0;
  const original = input.placeholder;
  const paso = () => {
    if (!visible || document.activeElement === input || input.value) {
      input.placeholder = document.activeElement === input ? 'Escribe lo que buscas' : original;
      t = setTimeout(paso, 600);
      return;
    }
    const txt = ejemplos[i];
    j += borrando ? -1 : 1;
    input.placeholder = txt.slice(0, j) || ' ';
    let espera = borrando ? 28 : 62;
    if (!borrando && j >= txt.length) { borrando = true; espera = 1700; }
    else if (borrando && j <= 0) { borrando = false; i = (i + 1) % ejemplos.length; espera = 350; }
    t = setTimeout(paso, espera);
  };
  new IntersectionObserver(([e]) => { visible = e.isIntersecting; }).observe(input);
  document.addEventListener('visibilitychange', () => { clearTimeout(t); if (!document.hidden) t = setTimeout(paso, 400); });
  t = setTimeout(paso, 900);
}

function buscadores() {
  for (const form of $$('[data-buscador]')) new Buscador(form);
  const hero = $('[data-placeholder-animado]');
  if (hero) placeholderAnimado(hero);

  const dlg = $('#dlg-buscador');
  if (!dlg) return;
  prepararDialogo(dlg);
  const input = $('.buscador__input', dlg);
  const abrir = (origen) => {
    abrirDialogo(dlg, origen);
    requestAnimationFrame(() => { input.focus(); input.select(); });
  };
  for (const a of $$('[data-abrir-buscador]')) {
    a.addEventListener('click', (e) => {
      if (e.metaKey || e.ctrlKey || e.shiftKey) return;
      e.preventDefault();
      abrir(a);
    });
  }
  document.addEventListener('keydown', (e) => {
    const t = e.target;
    const escribiendo = t.isContentEditable || /^(input|textarea|select)$/i.test(t.tagName);
    if ((e.key === '/' && !escribiendo && !e.metaKey && !e.ctrlKey) || ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k')) {
      if ($('dialog[open]') && !dlg.open) return;
      e.preventDefault();
      const heroInput = $('#q-hero');
      if (heroInput && heroInput.getBoundingClientRect().bottom > 0 && !dlg.open) heroInput.focus();
      else abrir(document.activeElement);
    }
  });
}

/* --- Acceso: diálogo, pestañas y formularios ---------------------------------- */
function pestanas(raiz) {
  const tabs = $$('[role="tab"]', raiz);
  const activar = (tab, foco = true) => {
    for (const t of tabs) {
      const sel = t === tab;
      t.setAttribute('aria-selected', String(sel));
      t.tabIndex = sel ? 0 : -1;
      const panel = document.getElementById(t.getAttribute('aria-controls'));
      if (panel.hidden === sel) {
        panel.hidden = !sel;
        if (sel && !menosMovimiento.matches) {
          panel.classList.add('entrando');
          panel.addEventListener('animationend', () => panel.classList.remove('entrando'), { once: true });
        }
      }
    }
    raiz.dataset.activa = tab.dataset.tab;
    if (foco) tab.focus();
  };
  for (const t of tabs) {
    t.addEventListener('click', () => activar(t));
    t.addEventListener('keydown', (e) => {
      const i = tabs.indexOf(t);
      const sig = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: tabs.length - 1 }[e.key];
      if (sig === undefined) return;
      e.preventDefault();
      activar(tabs[(sig + tabs.length) % tabs.length]);
    });
  }
  const sel = tabs.find((t) => t.getAttribute('aria-selected') === 'true') || tabs[0];
  raiz.dataset.activa = sel.dataset.tab;
  return { activar: (nombre) => activar(tabs.find((t) => t.dataset.tab === nombre) || tabs[0], false) };
}

function errorCampo(input, msg) {
  const campo = input.closest('.campo');
  const p = $('.campo__error', campo);
  if (msg) {
    input.setAttribute('aria-invalid', 'true');
    if (p) { $('span', p).textContent = msg; p.hidden = false; }
  } else {
    input.removeAttribute('aria-invalid');
    if (p) p.hidden = true;
  }
}

function validar(form) {
  const errores = [];
  for (const input of $$('input[required]', form)) {
    const v = input.value.trim();
    let msg = '';
    if (!v) {
      msg = { email: 'Escribe tu correo.', clave: 'Escribe tu contraseña.', nombre: 'Escribe tu nombre.' }[input.name] || 'Completa este campo.';
    } else if (input.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) {
      msg = 'Escribe un correo válido, por ejemplo nombre@correo.cl.';
    } else if (input.minLength > 0 && input.value.length < input.minLength) {
      msg = `La contraseña debe tener al menos ${input.minLength} caracteres.`;
    }
    errorCampo(input, msg);
    if (msg) errores.push(input);
  }
  return errores;
}

function formulariosAcceso() {
  for (const raiz of $$('[data-pestanas]')) raiz._pestanas = pestanas(raiz);

  for (const form of $$('[data-form-acceso]')) {
    const general = $('[data-error-general]', form);
    const boton = $('[data-enviar]', form);
    for (const input of $$('input', form)) {
      input.addEventListener('input', () => { if (input.getAttribute('aria-invalid')) errorCampo(input, ''); });
    }
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      general.hidden = true;
      const invalidos = validar(form);
      if (invalidos.length) { invalidos[0].focus(); return; }
      boton.setAttribute('aria-busy', 'true');
      boton.disabled = true;
      try {
        const r = await fetch(form.action, {
          method: 'POST',
          body: new FormData(form),
          headers: { Accept: 'application/json', 'X-Requested-With': 'fetch' },
          credentials: 'same-origin',
        });
        const datos = await r.json();
        if (datos.ok) {
          irA(datos.redirigir);
          return;
        }
        if (datos.csrf) for (const c of $$('input[name="csrf"]')) c.value = datos.csrf;
        let primero = null;
        for (const [campo, msg] of Object.entries(datos.errores || {})) {
          const input = form.elements[campo];
          if (input) { errorCampo(input, msg); primero ||= input; }
        }
        if (datos.error && !primero) {
          $('span', general).textContent = datos.error;
          general.hidden = false;
          general.classList.remove('sacudir');
          void general.offsetWidth;
          general.classList.add('sacudir');
          const clave = form.elements.clave;
          if (clave) { clave.value = ''; clave.focus(); }
        } else primero?.focus();
      } catch {
        $('span', general).textContent = 'No hay conexión con el servidor. Revisa tu internet y vuelve a intentarlo.';
        general.hidden = false;
      } finally {
        boton.removeAttribute('aria-busy');
        boton.disabled = false;
      }
    });
  }

  // Mostrar u ocultar contraseña
  for (const b of $$('[data-ver-clave]')) {
    b.addEventListener('click', () => {
      const input = $('input', b.parentElement);
      const ver = input.type === 'password';
      input.type = ver ? 'text' : 'password';
      b.setAttribute('aria-pressed', String(ver));
      input.focus();
    });
  }

  // Cuenta de prueba
  for (const b of $$('[data-usar-demo]')) {
    b.addEventListener('click', () => {
      const form = b.closest('form');
      form.elements.email.value = b.dataset.email;
      form.elements.clave.value = b.dataset.clave;
      form.requestSubmit();
    });
  }

  // Medidor de contraseña
  for (const input of $$('[data-medidor]')) {
    const m = $('.medidor', input.closest('.campo'));
    input.addEventListener('input', () => {
      const v = input.value;
      let nivel = 0;
      if (v.length >= 8) nivel = 1;
      if (nivel && /[a-z]/i.test(v) && /\d/.test(v)) nivel = 2;
      if (nivel === 2 && v.length >= 12 && (/[^a-z0-9]/i.test(v) || /[A-Z]/.test(v))) nivel = 3;
      m.dataset.nivel = v ? Math.max(1, nivel) : 0;
    });
  }

  // Diálogo de acceso
  const dlg = $('#dlg-acceso');
  if (!dlg) return;
  prepararDialogo(dlg);
  const motivo = $('[data-motivo-texto]', dlg);
  const motivoBase = motivo.textContent;
  const pest = $('[data-pestanas]', dlg)._pestanas;
  for (const a of $$('[data-acceso]')) {
    a.addEventListener('click', (e) => {
      if (e.metaKey || e.ctrlKey || e.shiftKey) return;
      e.preventDefault();
      motivo.textContent = a.dataset.motivo ? `${a.dataset.motivo} Con una cuenta gratis también ves:` : motivoBase;
      const volver = new URL(a.href, location.href).searchParams.get('volver') || location.pathname + location.search;
      for (const v of $$('[data-volver]', dlg)) v.value = volver;
      for (const err of $$('[data-error-general]', dlg)) err.hidden = true;
      pest.activar(a.dataset.pestana || 'entrar');
      abrirDialogo(dlg, a);
      requestAnimationFrame(() => {
        const panel = $('[role="tabpanel"]:not([hidden])', dlg);
        $('input:not([type="hidden"])', panel)?.focus();
      });
    });
  }
}

/** Navega al destino; si es la misma página, recarga para mostrar el contenido desbloqueado. */
function irA(destino) {
  const url = new URL(destino || location.href, location.href);
  const mismaPagina = url.pathname === location.pathname && url.search === location.search;
  if (mismaPagina) {
    if (url.hash) history.replaceState(null, '', url.hash);
    location.reload();
  } else {
    location.assign(url.href);
  }
}

/* --- Galería de producto ---------------------------------------------------- */
function galerias() {
  for (const g of $$('[data-galeria]')) {
    const imgs = $$('.galeria__img', g);
    const minis = $$('.galeria__mini', g);
    imgs.forEach((im, i) => {
      im.hidden = false;
      if (i) im.setAttribute('aria-hidden', 'true');
    });
    const mostrar = (i) => {
      imgs.forEach((im, k) => {
        const activa = k === i;
        im.toggleAttribute('data-activa', activa);
        if (activa) im.removeAttribute('aria-hidden'); else im.setAttribute('aria-hidden', 'true');
        const img = $('img', im);
        if (activa && img.loading === 'lazy') img.loading = 'eager';
      });
      minis.forEach((m, k) => m.setAttribute('aria-pressed', String(k === i)));
      const c = $('[data-contador]', g);
      if (c) c.textContent = `${i + 1} / ${imgs.length}`;
    };
    minis.forEach((m, i) => {
      m.addEventListener('click', () => mostrar(i));
      m.addEventListener('keydown', (e) => {
        const d = { ArrowRight: 1, ArrowLeft: -1 }[e.key];
        if (!d) return;
        e.preventDefault();
        const sig = (i + d + minis.length) % minis.length;
        minis[sig].focus();
        mostrar(sig);
      });
    });
  }
}

/* --- Carrusel de videos ----------------------------------------------------- */
function carruseles() {
  for (const ctrl of $$('[data-carrusel-controles]')) {
    const rail = document.getElementById(ctrl.dataset.carruselControles);
    if (!rail) continue;
    const [prev, next] = $$('button', ctrl);
    const estado = () => {
      prev.disabled = rail.scrollLeft < 8;
      next.disabled = rail.scrollLeft + rail.clientWidth >= rail.scrollWidth - 8;
    };
    for (const b of [prev, next]) {
      b.addEventListener('click', () => rail.scrollBy({
        left: Number(b.dataset.dir) * rail.clientWidth * 0.8,
        behavior: menosMovimiento.matches ? 'auto' : 'smooth',
      }));
    }
    let pendiente = false;
    rail.addEventListener('scroll', () => {
      if (pendiente) return;
      pendiente = true;
      requestAnimationFrame(() => { estado(); pendiente = false; });
    }, { passive: true });
    addEventListener('resize', estado, { passive: true });
    estado();
  }
}

/* --- Avisos ------------------------------------------------------------------ */
function avisos() {
  const cont = $('[data-avisos]');
  if (!cont) return;
  for (const [i, a] of $$('.aviso', cont).entries()) {
    const quitar = () => {
      a.classList.add('saliendo');
      a.addEventListener('animationend', () => a.remove(), { once: true });
      setTimeout(() => a.remove(), 500);
    };
    a.addEventListener('click', quitar);
    setTimeout(quitar, 5200 + i * 600);
  }
}

/* --- Formularios que se envían solos (ordenar) -------------------------------- */
function autoenviar() {
  for (const f of $$('[data-autoenviar]')) {
    f.addEventListener('change', () => f.requestSubmit());
  }
}

/* --- Filtros de la galería ------------------------------------------------------ */
function filtros() {
  const form = $('[data-filtros]');
  if (!form) return;
  const boton = $('[data-filtros-toggle]', form);
  const panel = $('[data-filtros-panel]', form);
  const estado = $('[data-panel-estado]', form);
  const abrir = (si) => {
    boton.setAttribute('aria-expanded', String(si));
    panel.toggleAttribute('data-cerrado', !si);
    estado.disabled = !si;
  };
  abrir(boton.getAttribute('aria-expanded') === 'true');
  boton.addEventListener('click', () => {
    const si = boton.getAttribute('aria-expanded') !== 'true';
    abrir(si);
    if (si) $('input', panel)?.focus();
  });
  // Cada cambio aplica el filtro al instante (sin JavaScript, se usa el botón "Aplicar filtros").
  let t = 0;
  form.addEventListener('change', (e) => {
    if (!e.target.matches('input, select')) return;
    clearTimeout(t);
    t = setTimeout(() => form.requestSubmit(), e.target.type === 'checkbox' ? 350 : 0);
  });
  panel.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { abrir(false); boton.focus(); }
  });
}

/* --- Descripción plegable (como en las plataformas de video) --------------------- */
function descripciones() {
  for (const d of $$('[data-plegable]')) {
    if (d.scrollHeight < 120) continue;
    d.setAttribute('data-plegado', '');
    d.id ||= 'desc-' + Math.random().toString(36).slice(2, 8);
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'descripcion__mas';
    b.setAttribute('aria-expanded', 'false');
    b.setAttribute('aria-controls', d.id);
    b.textContent = 'Mostrar más';
    b.addEventListener('click', () => {
      const abierto = d.toggleAttribute('data-plegado') === false;
      b.setAttribute('aria-expanded', String(abierto));
      b.textContent = abierto ? 'Mostrar menos' : 'Mostrar más';
    });
    d.after(b);
  }
}

/* --- Compartir: copia el enlace (o usa el menú del sistema en móviles) ------------- */
function compartir() {
  for (const b of $$('[data-compartir]')) {
    const txt = $('[data-compartir-txt]', b);
    b.addEventListener('click', async () => {
      const url = location.href.split('#')[0];
      if (navigator.share && matchMedia('(pointer: coarse)').matches) {
        try { await navigator.share({ title: b.dataset.titulo, url }); return; } catch { /* cancelado */ }
      }
      try {
        await navigator.clipboard.writeText(url);
        txt.textContent = 'Enlace copiado';
      } catch {
        txt.textContent = 'Copia la dirección del navegador';
      }
      setTimeout(() => { txt.textContent = 'Copiar enlace'; }, 2200);
    });
  }
}

/* --- Animación de desbloqueo después de iniciar sesión ----------------------- */
function desbloqueo() {
  if (!document.body.hasAttribute('data-desbloqueo')) return;
  setTimeout(() => document.body.removeAttribute('data-desbloqueo'), 2600);
}

/* --- Precarga de páginas internas al pasar el cursor ------------------------- */
function precarga() {
  if (navigator.connection?.saveData) return;
  const hechas = new Set();
  let t = 0;
  const precargar = (a) => {
    const url = new URL(a.href, location.href);
    if (url.origin !== location.origin || hechas.has(url.href) || /(ir|salir|stream)\.php/.test(url.pathname) || url.href === location.href) return;
    hechas.add(url.href);
    const l = document.createElement('link');
    l.rel = 'prefetch';
    l.href = url.href;
    document.head.append(l);
  };
  document.addEventListener('pointerover', (e) => {
    const a = e.target.closest('a[href]');
    if (!a) return;
    clearTimeout(t);
    t = setTimeout(() => precargar(a), 70);
  }, { passive: true });
  document.addEventListener('touchstart', (e) => {
    const a = e.target.closest('a[href]');
    if (a) precargar(a);
  }, { passive: true });
}

/* --- Inicio ------------------------------------------------------------------- */
imagenes();
tema();
cabecera();
buscadores();
formulariosAcceso();
galerias();
carruseles();
avisos();
autoenviar();
filtros();
descripciones();
compartir();
desbloqueo();
precarga();
