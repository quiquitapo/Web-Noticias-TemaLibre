<?php
/** Categorías y subcategorías: crear, renombrar, mover, ordenar y eliminar. */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
require INC_DIR . '/admin.php';
requerir_admin();

$error = '';
$errorId = 0;
if (es_post()) {
    if (!csrf_valido()) {
        $error = 'El formulario expiró por seguridad. Vuelve a intentarlo.';
    } else {
        $accion = entrada('accion');
        $id = (int) entrada('id');
        $r = match ($accion) {
            'crear' => guardar_categoria($_POST, null),
            'editar' => ($c = categoria_por_id($id)) ? guardar_categoria($_POST, $c) : ['ok' => false, 'error' => 'La categoría no existe.'],
            'eliminar' => eliminar_categoria($id, (int) entrada('mover_a')),
            default => ['ok' => false, 'error' => 'Acción desconocida.'],
        };
        if ($r['ok']) {
            flash('exito', $r['mensaje']);
            redirigir(url('admin/categorias.php'));
        }
        $error = $r['error'];
        $errorId = $accion === 'crear' ? -1 : $id;
    }
    http_response_code(422);
}
$arbol = categorias_arbol();
$planas = categorias_planas();

$formEditar = static function (array $c, array $arbol) use ($errorId, $error): void { ?>
  <details class="plegable plegable--inline"<?= $errorId === (int) $c['id'] ? ' open' : '' ?>>
    <summary class="boton boton--suave boton--chico"><?= icono('editar') ?>Editar<span class="sr"> <?= e($c['nombre']) ?></span></summary>
    <form class="form form--compacto" method="post">
      <?= csrf_campo() ?><input type="hidden" name="accion" value="editar"><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
      <div class="campo"><label for="nom-<?= (int) $c['id'] ?>">Nombre</label><input id="nom-<?= (int) $c['id'] ?>" name="nombre" maxlength="80" required value="<?= e($c['nombre']) ?>"></div>
      <div class="campo"><label for="desc-<?= (int) $c['id'] ?>">Descripción</label><input id="desc-<?= (int) $c['id'] ?>" name="descripcion" maxlength="255" value="<?= e($c['descripcion']) ?>"></div>
      <div class="campos-dos">
        <div class="campo"><label for="padre-<?= (int) $c['id'] ?>">Ubicación</label>
          <select id="padre-<?= (int) $c['id'] ?>" name="padre_id">
            <option value="">Categoría principal</option>
            <?php foreach ($arbol as $r): if ((int) $r['id'] === (int) $c['id']) { continue; } ?>
              <option value="<?= (int) $r['id'] ?>"<?= (int) $c['padre_id'] === (int) $r['id'] ? ' selected' : '' ?>>Dentro de <?= e($r['nombre']) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="campo"><label for="ord-<?= (int) $c['id'] ?>">Orden</label><input id="ord-<?= (int) $c['id'] ?>" name="orden" type="number" min="0" max="999" value="<?= (int) $c['orden'] ?>"></div>
      </div>
      <p class="campo__ayuda">Dirección: <code>videos.php?cat=<?= e($c['slug']) ?></code> (no cambia al renombrar).</p>
      <button class="boton boton--primario" type="submit">Guardar</button>
    </form>
  </details>
<?php };

$formEliminar = static function (array $c, array $planas) use ($errorId, $error): void { ?>
  <form method="post" class="form-eliminar" data-confirmar="¿Eliminar la categoría «<?= e($c['nombre']) ?>»?">
    <?= csrf_campo() ?><input type="hidden" name="accion" value="eliminar"><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
    <?php if ((int) $c['propias'] > 0): ?>
      <label class="sr" for="mover-<?= (int) $c['id'] ?>">Mover sus publicaciones a</label>
      <select id="mover-<?= (int) $c['id'] ?>" name="mover_a" class="select-chico" title="Mover sus publicaciones a">
        <option value="">Mover publicaciones a…</option>
        <?php foreach ($planas as $p): if ((int) $p['id'] === (int) $c['id']) { continue; } ?>
          <option value="<?= (int) $p['id'] ?>"><?= $p['nivel'] ? '— ' : '' ?><?= e($p['nombre']) ?></option>
        <?php endforeach; ?>
      </select>
    <?php endif; ?>
    <button class="boton boton--suave boton--chico" type="submit"><?= icono('eliminar') ?>Eliminar<span class="sr"> <?= e($c['nombre']) ?></span></button>
  </form>
<?php };

// Publicaciones propias (sin contar subcategorías), para saber si hay que moverlas al eliminar
$propias = array_column(filas('SELECT categoria_id, COUNT(*) AS n FROM publicaciones GROUP BY categoria_id'), 'n', 'categoria_id');

vista('cabecera', ['titulo' => 'Categorías', 'seccion' => 'admin', 'sin_indexar' => true]);
vista('admin-nav', ['activa' => 'categorias', 'titulo' => 'Categorías y subcategorías']);
?>
<?php if ($error): ?><p class="form__error admin-alerta" role="alert"><?= icono('alerta') ?><span><?= e($error) ?></span></p><?php endif; ?>
<div class="admin-grid admin-grid--lado">
  <div class="arbol">
    <?php foreach ($arbol as $r): $r['propias'] = (int) ($propias[$r['id']] ?? 0); ?>
      <section class="arbol__raiz" aria-labelledby="cat-<?= (int) $r['id'] ?>">
        <div class="arbol__fila arbol__fila--raiz">
          <div class="arbol__txt">
            <h2 class="arbol__nombre" id="cat-<?= (int) $r['id'] ?>"><?= icono('carpeta') ?><?= e($r['nombre']) ?></h2>
            <span class="arbol__meta"><?= e(plural((int) $r['total'], 'publicación', 'publicaciones')) ?>, <?= e(plural(count($r['subs']), 'subcategoría', 'subcategorías')) ?></span>
            <?php if ($r['descripcion']): ?><p class="arbol__desc"><?= e($r['descripcion']) ?></p><?php endif; ?>
          </div>
          <div class="arbol__acciones"><?php $formEditar($r, $arbol); $formEliminar($r, $planas); ?></div>
        </div>
        <?php if ($r['subs']): ?>
          <ul class="arbol__subs">
            <?php foreach ($r['subs'] as $s): $s['propias'] = (int) ($propias[$s['id']] ?? 0); ?>
              <li class="arbol__fila">
                <div class="arbol__txt">
                  <h3 class="arbol__nombre arbol__nombre--sub"><?= e($s['nombre']) ?></h3>
                  <span class="arbol__meta"><?= e(plural((int) $s['total'], 'publicación', 'publicaciones')) ?></span>
                </div>
                <div class="arbol__acciones"><?php $formEditar($s, $arbol); $formEliminar($s, $planas); ?></div>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </section>
    <?php endforeach; ?>
  </div>

  <aside>
    <section class="caja caja--fija" aria-labelledby="nueva-titulo">
      <h2 class="caja__titulo" id="nueva-titulo"><?= icono('mas') ?>Nueva categoría</h2>
      <form class="form" method="post">
        <?= csrf_campo() ?><input type="hidden" name="accion" value="crear">
        <div class="campo"><label for="nueva-nombre">Nombre</label><input id="nueva-nombre" name="nombre" maxlength="80" required placeholder="Ej.: Medio ambiente"></div>
        <div class="campo"><label for="nueva-padre">Ubicación</label>
          <select id="nueva-padre" name="padre_id">
            <option value="">Categoría principal</option>
            <?php foreach ($arbol as $r): ?><option value="<?= (int) $r['id'] ?>">Subcategoría de <?= e($r['nombre']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="campo"><label for="nueva-desc">Descripción (opcional)</label><input id="nueva-desc" name="descripcion" maxlength="255"></div>
        <div class="campo"><label for="nueva-orden">Orden</label><input id="nueva-orden" name="orden" type="number" min="0" max="999" value="0"><p class="campo__ayuda">Los números menores aparecen primero.</p></div>
        <button class="boton boton--primario boton--ancho" type="submit">Crear</button>
      </form>
    </section>
  </aside>
</div>
</div></div>
<?php vista('pie', ['seccion' => 'admin']); ?>
