<?php
/** Resumen del panel: totales, equilibrio de orientaciones y pendientes. */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
require INC_DIR . '/admin.php';
requerir_admin();

$eq = equilibrio();
$u = usuario_actual();
$vistas = (int) valor('SELECT COALESCE(SUM(vistas), 0) FROM publicaciones');
$usuarios = (int) valor('SELECT COUNT(*) FROM usuarios');
$admins = (int) valor("SELECT COUNT(*) FROM usuarios WHERE rol = 'admin'");
$ultimas = explorar(filtros_desde_url([]), 6)['items'];
$pendientes = explorar(filtros_desde_url(['verificacion' => 'sin-verificar']), 6)['items'];
$posturas = ['izquierda', 'centro-izquierda', 'centro', 'centro-derecha', 'derecha'];
$conteos = array_map(static fn($k) => (int) ($eq['orientacion'][$k] ?? 0), $posturas);
$maxO = max(1, ...$conteos);
$izq = $conteos[0] + $conteos[1];
$der = $conteos[3] + $conteos[4];
$aviso = abs($izq - $der) >= 2
    ? 'Hay ' . plural($izq, 'publicación', 'publicaciones') . ' hacia la izquierda y ' . plural($der, 'publicación', 'publicaciones') . ' hacia la derecha. Considera sumar la otra mirada para mantener el equilibrio.'
    : '';

vista('cabecera', ['titulo' => 'Panel', 'seccion' => 'admin', 'sin_indexar' => true]);
vista('admin-nav', [
    'activa' => 'resumen',
    'titulo' => 'Hola, ' . ($u['nombre_admin'] ?: $u['nombre']),
    'accion' => '<a class="boton boton--primario" href="' . e(url('admin/publicar.php')) . '">' . icono('subir') . 'Subir publicación</a>',
]);
?>
<ul class="cifras">
  <li class="cifra"><span class="cifra__n"><?= (int) $eq['total'] ?></span><span class="cifra__txt">publicaciones</span>
    <span class="cifra__det"><?= (int) ($eq['tipo']['video'] ?? 0) ?> videos, <?= (int) ($eq['tipo']['imagen'] ?? 0) ?> de fotos, <?= (int) ($eq['tipo']['noticia'] ?? 0) ?> noticias</span></li>
  <li class="cifra"><span class="cifra__n"><?= e(numero_corto($vistas)) ?></span><span class="cifra__txt">vistas en total</span></li>
  <li class="cifra"><span class="cifra__n"><?= $usuarios ?></span><span class="cifra__txt">cuentas</span><span class="cifra__det"><?= $admins ?> con rol de admin</span></li>
  <li class="cifra"><span class="cifra__n"><?= (int) ($eq['verificacion']['sin-verificar'] ?? 0) ?></span><span class="cifra__txt">sin verificar</span><span class="cifra__det"><?= e(plural((int) ($eq['verificacion']['enganoso'] ?? 0), 'marcada como engañosa', 'marcadas como engañosas')) ?></span></li>
</ul>

<div class="admin-grid">
  <section class="caja" aria-labelledby="eq-titulo">
    <h2 class="caja__titulo" id="eq-titulo"><?= icono('balanza') ?>Equilibrio de orientaciones</h2>
    <p class="caja__txt">Publicaciones con postura política. La portada y la vista equilibrada funcionan mejor si todas las posturas tienen contenido.</p>
    <ul class="barras barras--claro">
      <?php foreach ($posturas as $i => $k): ?>
        <li class="barras__fila"><a class="barras__enlace" href="<?= e(url('admin/publicaciones.php', ['orientacion' => $k])) ?>">
          <span class="barras__txt"><?= e(ORIENTACIONES[$k][0]) ?></span>
          <span class="barras__pista" aria-hidden="true"><span class="barras__barra" style="--v: <?= round($conteos[$i] / $maxO * 100) ?>%"></span></span>
          <span class="barras__n"><?= $conteos[$i] ?></span></a></li>
      <?php endforeach; ?>
    </ul>
    <p class="caja__nota"><?= (int) ($eq['orientacion']['no-aplica'] ?? 0) ?> publicaciones sin orientación política.</p>
    <?php if ($aviso): ?><p class="aviso-parcial"><?= icono('alerta') ?><?= e($aviso) ?></p><?php endif; ?>
  </section>

  <section class="caja" aria-labelledby="pend-titulo">
    <h2 class="caja__titulo" id="pend-titulo"><?= icono('pendiente') ?>Pendientes de verificar</h2>
    <?php if ($pendientes): ?>
      <ul class="lista-admin">
        <?php foreach ($pendientes as $p): ?>
          <li><a href="<?= e(url('admin/publicar.php', ['id' => $p['id']])) ?>"><?= e($p['titulo']) ?></a><span><?= e($p['creador']) ?></span></li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <p class="vacio-mini">Todo verificado.</p>
    <?php endif; ?>
  </section>
</div>

<section class="admin-seccion" aria-labelledby="ult-titulo">
  <div class="seccion__cabeza">
    <h2 class="seccion__titulo seccion__titulo--chico" id="ult-titulo">Últimas publicaciones</h2>
    <a class="enlace-mas" href="<?= e(url('admin/publicaciones.php')) ?>">Ver todas<?= icono('der') ?></a>
  </div>
  <ul class="rejilla-videos">
    <?php foreach ($ultimas as $p): ?><li><?php vista('tarjeta', ['p' => $p]); ?></li><?php endforeach; ?>
  </ul>
</section>
</div></div>
<?php vista('pie', ['seccion' => 'admin']); ?>
