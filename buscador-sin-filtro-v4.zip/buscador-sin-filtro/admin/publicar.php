<?php
/** Subir o editar una publicación (video, fotos o noticia). */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
require INC_DIR . '/admin.php';
requerir_admin();

$id = (int) entrada('id');
$actual = $id ? publicacion_por_id($id) : null;
if ($id && !$actual) {
    no_encontrado();
}
$u = usuario_actual();
$errores = [];

$v = $actual ? [
    'tipo' => $actual['tipo'], 'titulo' => $actual['titulo'], 'descripcion' => $actual['descripcion'], 'cuerpo' => (string) $actual['cuerpo'],
    'categoria_id' => (int) $actual['categoria_id'], 'orientacion' => $actual['orientacion'], 'orientacion_nota' => (string) $actual['orientacion_nota'],
    'verificacion' => $actual['verificacion'], 'verificacion_nota' => (string) $actual['verificacion_nota'],
    'creador' => $actual['creador'], 'creador_url' => (string) $actual['creador_url'], 'autor' => (string) $actual['autor'],
    'fuente_url' => (string) $actual['fuente_url'], 'venta_url' => (string) $actual['venta_url'], 'tienda' => (string) $actual['tienda'],
    'precio' => $actual['precio'] !== null ? (string) $actual['precio'] : '', 'precio_antes' => $actual['precio_antes'] !== null ? (string) $actual['precio_antes'] : '',
    'ficha' => ficha_a_texto($actual['ficha']), 'etiquetas' => $actual['etiquetas'], 'subido_por' => $actual['subido_por'],
    'destacado' => (int) $actual['destacado'], 'publicado_en' => date('Y-m-d\TH:i', strtotime($actual['publicado_en'])),
    'redes' => array_map(static fn($r) => [$r['red'], $r['url']], redes_de((int) $actual['id'])), 'duracion_seg' => (int) $actual['duracion_seg'],
] : [
    'tipo' => 'video', 'titulo' => '', 'descripcion' => '', 'cuerpo' => '', 'categoria_id' => 0, 'orientacion' => 'no-aplica', 'orientacion_nota' => '',
    'verificacion' => 'sin-verificar', 'verificacion_nota' => '', 'creador' => '', 'creador_url' => '', 'autor' => '', 'fuente_url' => '',
    'venta_url' => '', 'tienda' => '', 'precio' => '', 'precio_antes' => '', 'ficha' => '', 'etiquetas' => '',
    'subido_por' => $u['nombre_admin'] ?: $u['nombre'], 'destacado' => 0, 'publicado_en' => date('Y-m-d\TH:i'), 'redes' => [], 'duracion_seg' => 0,
];

if (es_post()) {
    if (empty($_POST) && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
        // PHP descarta todo el formulario si se supera post_max_size
        $errores['archivos'] = 'Lo que subiste pesa más de lo que acepta el servidor (post_max_size = ' . ini_get('post_max_size') . '). Sube un archivo más liviano o aumenta ese límite.';
    } elseif (!csrf_valido()) {
        $errores['general'] = 'El formulario expiró por seguridad. Vuelve a intentarlo.';
    } else {
        $r = guardar_publicacion($_POST, $_FILES, $actual);
        if ($r['ok']) {
            flash('exito', $actual ? 'Cambios guardados.' : 'Publicación subida. Ya es visible en el sitio.');
            $destino = url('video.php', ['v' => $r['slug']]);
            if (es_peticion_json()) {
                json_respuesta(['ok' => true, 'redirigir' => $destino]);
            }
            redirigir($destino);
        }
        $errores = $r['errores'];
    }
    foreach (array_keys($v) as $k) {
        if (isset($_POST[$k]) && is_string($_POST[$k])) {
            $v[$k] = $_POST[$k];
        }
    }
    $v['destacado'] = !empty($_POST['destacado']) ? 1 : 0;
    $v['redes'] = [];
    foreach ((array) ($_POST['red'] ?? []) as $i => $red) {
        $v['redes'][] = [(string) $red, (string) (($_POST['red_url'] ?? [])[$i] ?? '')];
    }
    if (es_peticion_json()) {
        json_respuesta(['ok' => false, 'errores' => $errores, 'csrf' => csrf_token()], 422);
    }
    http_response_code(422);
}

$cats = categorias_planas();
$fotos = $actual ? imagenes_de((int) $actual['id']) : [];
$maxVideo = (int) config('subidas.video_max_mb', 512);
$maxImg = (int) config('subidas.imagen_max_mb', 8);
$limiteServidor = ini_get('upload_max_filesize');
$err = static fn(string $k) => isset($errores[$k]) ? '<p class="campo__error" id="err-' . e($k) . '">' . icono('alerta') . '<span>' . e($errores[$k]) . '</span></p>' : '';
$inv = static fn(string $k) => isset($errores[$k]) ? ' aria-invalid="true" aria-describedby="err-' . e($k) . '"' : '';
$etiquetasCampo = [
    'tipo' => 'Tipo', 'titulo' => 'Título', 'descripcion' => 'Descripción', 'categoria_id' => 'Categoría', 'orientacion' => 'Orientación',
    'verificacion' => 'Verificación', 'verificacion_nota' => 'Nota de verificación', 'creador' => 'Creador', 'creador_url' => 'URL del creador',
    'fuente_url' => 'URL de la noticia', 'venta_url' => 'URL de venta', 'precio_antes' => 'Precio anterior', 'publicado_en' => 'Fecha',
    'miniatura' => 'Miniatura', 'video' => 'Video', 'fotos' => 'Fotos', 'redes' => 'Redes', 'archivos' => 'Archivos', 'general' => 'Formulario',
];
$ancla = static fn(string $k) => ['tipo' => 'tipo-video', 'categoria_id' => 'categoria', 'orientacion' => 'orientacion-no-aplica', 'verificacion' => 'verificacion-sin-verificar',
    'miniatura' => 'miniatura', 'video' => 'video', 'fotos' => 'fotos', 'redes' => 'redes', 'archivos' => 'miniatura', 'general' => 'titulo'][$k] ?? $k;

vista('cabecera', ['titulo' => $actual ? 'Editar publicación' : 'Subir publicación', 'seccion' => 'admin', 'sin_indexar' => true]);
vista('admin-nav', [
    'activa' => $actual ? 'publicaciones' : 'publicar',
    'titulo' => $actual ? 'Editar: ' . $actual['titulo'] : 'Subir publicación',
    'accion' => $actual ? '<a class="boton boton--suave" href="' . e(url('video.php', ['v' => $actual['slug']])) . '">' . icono('ojo') . 'Ver en el sitio</a>' : '',
]);
?>
<form class="publicar" method="post" enctype="multipart/form-data" action="<?= e(url('admin/publicar.php', ['id' => $actual['id'] ?? null])) ?>" novalidate data-publicar
      data-max-video="<?= $maxVideo ?>" data-max-img="<?= $maxImg ?>">
  <?= csrf_campo() ?>
  <input type="hidden" name="duracion_seg" value="<?= (int) $v['duracion_seg'] ?>" data-duracion>

  <?php if ($errores): ?>
    <div class="resumen-errores" role="alert" tabindex="-1" data-resumen-errores>
      <h2><?= icono('alerta') ?>Revisa <?= count($errores) === 1 ? 'un campo' : count($errores) . ' campos' ?> antes de publicar</h2>
      <ul>
        <?php foreach ($errores as $k => $m): ?><li><a href="#<?= e($ancla($k)) ?>"><?= e(($etiquetasCampo[$k] ?? $k) . ': ' . $m) ?></a></li><?php endforeach; ?>
      </ul>
    </div>
  <?php else: ?>
    <div class="resumen-errores" role="alert" tabindex="-1" data-resumen-errores hidden></div>
  <?php endif; ?>

  <div class="publicar__grid">
    <div class="publicar__principal">
      <fieldset class="tarjeta-form">
        <legend class="tarjeta-form__titulo">¿Qué vas a publicar?</legend>
        <div class="segmentado" role="radiogroup" aria-label="Tipo de publicación">
          <?php foreach (['video' => ['Video', 'video', 'Archivo MP4 o WebM'], 'imagen' => ['Fotos', 'fotos', 'Una o más imágenes'], 'noticia' => ['Noticia', 'noticia', 'Texto con portada']] as $k => [$t, $ico, $ayuda]): ?>
            <label class="segmentado__op">
              <input type="radio" name="tipo" value="<?= e($k) ?>" id="tipo-<?= e($k) ?>"<?= $v['tipo'] === $k ? ' checked' : '' ?> data-tipo>
              <span class="segmentado__caja"><?= icono($ico) ?><strong><?= e($t) ?></strong><span><?= e($ayuda) ?></span></span>
            </label>
          <?php endforeach; ?>
        </div>
        <?= $err('tipo') ?>
      </fieldset>

      <section class="tarjeta-form" data-solo="video" aria-labelledby="sec-video">
        <h2 class="tarjeta-form__titulo" id="sec-video">Archivo de video</h2>
        <div class="soltar" data-soltar>
          <input class="soltar__input" type="file" id="video" name="video" accept="video/mp4,video/webm" data-archivo="video"<?= $inv('video') ?>>
          <label class="soltar__zona" for="video">
            <?= icono('subir') ?>
            <strong><?= $actual && $actual['video_archivo'] ? 'Reemplazar el video' : 'Arrastra el video aquí o elige un archivo' ?></strong>
            <span>MP4 (H.264) o WebM, hasta <?= $maxVideo ?> MB. Límite actual del servidor: <?= e((string) $limiteServidor) ?>.</span>
          </label>
          <div class="soltar__vista" data-vista hidden>
            <video class="soltar__video" controls muted playsinline preload="metadata" data-video-previa></video>
            <p class="soltar__info" data-info></p>
            <button class="boton boton--suave" type="button" data-capturar><?= icono('fotos') ?>Usar este cuadro como miniatura</button>
          </div>
          <?php if ($actual && $actual['video_archivo']): ?>
            <p class="soltar__actual"><?= icono('check-circulo') ?>Video actual: <?= e(duracion((int) $actual['duracion_seg'])) ?><?= $actual['subtitulos'] ? ', con subtítulos' : '' ?>. Si no eliges otro, se mantiene.</p>
          <?php endif; ?>
        </div>
        <?= $err('video') ?>
        <div class="campo campo--archivo">
          <label for="subtitulos">Subtítulos (opcional)</label>
          <input type="file" id="subtitulos" name="subtitulos" accept=".vtt,.srt,text/vtt">
          <p class="campo__ayuda">WebVTT (.vtt) o SRT (.srt). Hacen el video accesible y mejoran la búsqueda.</p>
        </div>
      </section>

      <section class="tarjeta-form" aria-labelledby="sec-mini">
        <h2 class="tarjeta-form__titulo" id="sec-mini">Miniatura<?php if (!$actual): ?> <span class="opcional" data-solo="imagen">(opcional: si no subes una, usamos la primera foto)</span><?php endif; ?></h2>
        <div class="soltar soltar--mini" data-soltar>
          <input class="soltar__input" type="file" id="miniatura" name="miniatura" accept="image/png,image/jpeg,image/webp" data-archivo="imagen"<?= $inv('miniatura') ?>>
          <label class="soltar__zona" for="miniatura">
            <?php if ($actual): ?>
              <?= img($actual['miniatura'], [480, 960], '360px', '', 1600, 900, $actual['miniatura_color'], ['clase' => 'soltar__actual-img', 'lazy' => false]) ?>
            <?php endif; ?>
            <?= icono('fotos') ?>
            <strong><?= $actual ? 'Reemplazar la miniatura' : 'Sube una imagen PNG' ?></strong>
            <span>PNG recomendado (también JPG o WebP), 1280×720 o más, hasta <?= $maxImg ?> MB. Se recorta al centro en 16:9.</span>
          </label>
          <div class="soltar__vista soltar__vista--mini" data-vista hidden><img alt="Vista previa de la miniatura" data-img-previa></div>
        </div>
        <?= $err('miniatura') ?>
      </section>

      <section class="tarjeta-form" aria-labelledby="sec-fotos" id="fotos">
        <h2 class="tarjeta-form__titulo" id="sec-fotos">Fotos <span class="opcional" data-solo-no="imagen">(opcional)</span></h2>
        <?php if ($fotos): ?>
          <ul class="fotos-actuales">
            <?php foreach ($fotos as $f): ?>
              <li>
                <?= img($f['base'], [400], '120px', $f['alt'], 400, 400, $f['color']) ?>
                <label class="opcion"><input type="checkbox" name="quitar_fotos[]" value="<?= (int) $f['id'] ?>"><span>Quitar</span></label>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
        <div class="soltar" data-soltar>
          <input class="soltar__input" type="file" id="fotos-input" name="fotos[]" accept="image/png,image/jpeg,image/webp" multiple data-archivo="fotos">
          <label class="soltar__zona soltar__zona--chica" for="fotos-input"><?= icono('subir') ?><strong>Agrega fotos</strong><span>Hasta <?= (int) config('subidas.max_fotos', 12) ?> fotos. Se mantiene su proporción.</span></label>
          <ul class="soltar__fotos" data-fotos-previa></ul>
        </div>
        <?= $err('fotos') ?>
      </section>

      <section class="tarjeta-form" aria-labelledby="sec-texto">
        <h2 class="tarjeta-form__titulo" id="sec-texto">Título y descripción</h2>
        <div class="campo">
          <label for="titulo">Título</label>
          <input id="titulo" name="titulo" maxlength="200" required value="<?= e($v['titulo']) ?>" data-contar<?= $inv('titulo') ?>>
          <?= $err('titulo') ?>
        </div>
        <div class="campo">
          <label for="descripcion">Descripción</label>
          <textarea id="descripcion" name="descripcion" rows="5" maxlength="5000" required data-contar<?= $inv('descripcion') ?>><?= e($v['descripcion']) ?></textarea>
          <p class="campo__ayuda">Las primeras líneas se ven en la galería. Separa párrafos con una línea en blanco.</p>
          <?= $err('descripcion') ?>
        </div>
        <div class="campo" data-solo="noticia">
          <label for="cuerpo">Texto completo de la noticia</label>
          <textarea id="cuerpo" name="cuerpo" rows="12" maxlength="30000"><?= e($v['cuerpo']) ?></textarea>
        </div>
        <div class="campo">
          <label for="etiquetas">Etiquetas</label>
          <input id="etiquetas" name="etiquetas" value="<?= e($v['etiquetas']) ?>" aria-describedby="etiquetas-ayuda">
          <p class="campo__ayuda" id="etiquetas-ayuda">Separadas por comas. Se usan para buscar y para mostrar otras miradas sobre el mismo tema.</p>
        </div>
      </section>
    </div>

    <aside class="publicar__lado">
      <section class="tarjeta-form" aria-labelledby="sec-donde">
        <h2 class="tarjeta-form__titulo" id="sec-donde">Dónde se publica</h2>
        <div class="campo">
          <label for="categoria">Categoría</label>
          <select id="categoria" name="categoria_id" required data-categoria<?= $inv('categoria_id') ?>>
            <option value="">Elige una categoría</option>
            <?php foreach (categorias_arbol() as $r): ?>
              <optgroup label="<?= e($r['nombre']) ?>">
                <option value="<?= (int) $r['id'] ?>" data-raiz="<?= e($r['slug']) ?>"<?= (int) $v['categoria_id'] === (int) $r['id'] ? ' selected' : '' ?>><?= e($r['nombre']) ?> (general)</option>
                <?php foreach ($r['subs'] as $s): ?>
                  <option value="<?= (int) $s['id'] ?>" data-raiz="<?= e($r['slug']) ?>"<?= (int) $v['categoria_id'] === (int) $s['id'] ? ' selected' : '' ?>><?= e($s['nombre']) ?></option>
                <?php endforeach; ?>
              </optgroup>
            <?php endforeach; ?>
          </select>
          <?= $err('categoria_id') ?>
          <p class="campo__ayuda"><a href="<?= e(url('admin/categorias.php')) ?>">Crear o editar categorías</a></p>
        </div>
        <div class="campo">
          <label for="publicado_en">Fecha de publicación</label>
          <input id="publicado_en" name="publicado_en" type="datetime-local" value="<?= e($v['publicado_en']) ?>"<?= $inv('publicado_en') ?>>
          <?= $err('publicado_en') ?>
        </div>
        <label class="opcion"><input type="checkbox" name="destacado" value="1"<?= $v['destacado'] ? ' checked' : '' ?>><span>Destacar en la portada</span></label>
      </section>

      <section class="tarjeta-form" aria-labelledby="sec-quien">
        <h2 class="tarjeta-form__titulo" id="sec-quien">Creador y subida</h2>
        <div class="campo">
          <label for="creador">Creador original</label>
          <input id="creador" name="creador" maxlength="120" required list="lista-creadores" value="<?= e($v['creador']) ?>" placeholder="Canal, medio o persona"<?= $inv('creador') ?>>
          <datalist id="lista-creadores"><?php foreach (creadores() as $c): ?><option value="<?= e($c) ?>"><?php endforeach; ?></datalist>
          <?= $err('creador') ?>
        </div>
        <div class="campo">
          <label for="creador_url">Sitio del creador (opcional)</label>
          <input id="creador_url" name="creador_url" type="url" inputmode="url" placeholder="https://" value="<?= e($v['creador_url']) ?>"<?= $inv('creador_url') ?>>
          <?= $err('creador_url') ?>
        </div>
        <div class="campo" data-solo="noticia">
          <label for="autor">Autor de la noticia (opcional)</label>
          <input id="autor" name="autor" maxlength="120" value="<?= e($v['autor']) ?>">
        </div>
        <div class="campo">
          <label for="subido_por">Subido por (tu nombre de admin)</label>
          <input id="subido_por" name="subido_por" maxlength="80" value="<?= e($v['subido_por']) ?>" aria-describedby="subido-ayuda">
          <p class="campo__ayuda" id="subido-ayuda">Se muestra en la publicación como “Subido por”.</p>
          <label class="opcion"><input type="checkbox" name="recordar_nombre" value="1"><span>Usar siempre este nombre</span></label>
        </div>
      </section>

      <section class="tarjeta-form" aria-labelledby="sec-orient">
        <h2 class="tarjeta-form__titulo" id="sec-orient">Orientación</h2>
        <div class="radios" role="radiogroup" aria-labelledby="sec-orient">
          <?php foreach (ORIENTACIONES as $k => [$t, $pos]): ?>
            <label class="opcion"><input type="radio" name="orientacion" value="<?= e($k) ?>" id="orientacion-<?= e($k) ?>"<?= $v['orientacion'] === $k ? ' checked' : '' ?>>
              <span class="opcion__escala" aria-hidden="true"><?php for ($i = 1; $i <= 5; $i++): ?><i<?= $i === $pos ? ' class="on"' : '' ?>></i><?php endfor; ?></span><span><?= e($t) ?></span></label>
          <?php endforeach; ?>
        </div>
        <?= $err('orientacion') ?>
        <div class="campo">
          <label for="orientacion_nota">Por qué esta etiqueta (opcional)</label>
          <input id="orientacion_nota" name="orientacion_nota" maxlength="255" value="<?= e($v['orientacion_nota']) ?>" placeholder="Ej.: línea editorial declarada por el canal">
        </div>
      </section>

      <section class="tarjeta-form" aria-labelledby="sec-verif">
        <h2 class="tarjeta-form__titulo" id="sec-verif">Verificación</h2>
        <div class="radios" role="radiogroup" aria-labelledby="sec-verif">
          <?php foreach (VERIFICACIONES as $k => [$t, $ayuda]): ?>
            <label class="opcion opcion--<?= e($k) ?>"><input type="radio" name="verificacion" value="<?= e($k) ?>" id="verificacion-<?= e($k) ?>"<?= $v['verificacion'] === $k ? ' checked' : '' ?>>
              <?= icono(['verificado' => 'check-circulo', 'sin-verificar' => 'pendiente', 'enganoso' => 'alerta'][$k]) ?><span><?= e($t) ?></span></label>
          <?php endforeach; ?>
        </div>
        <?= $err('verificacion') ?>
        <div class="campo">
          <label for="verificacion_nota">Nota de verificación</label>
          <textarea id="verificacion_nota" name="verificacion_nota" rows="3" maxlength="600" placeholder="Qué se revisó, o por qué es engañoso"<?= $inv('verificacion_nota') ?>><?= e($v['verificacion_nota']) ?></textarea>
          <?= $err('verificacion_nota') ?>
        </div>
      </section>

      <section class="tarjeta-form" aria-labelledby="sec-enlaces" id="redes">
        <h2 class="tarjeta-form__titulo" id="sec-enlaces">Enlaces</h2>
        <div class="campo">
          <label for="fuente_url">URL de la noticia o fuente original</label>
          <input id="fuente_url" name="fuente_url" type="url" inputmode="url" placeholder="https://" value="<?= e($v['fuente_url']) ?>"<?= $inv('fuente_url') ?>>
          <p class="campo__ayuda">Solo la ven las personas con sesión iniciada.</p>
          <?= $err('fuente_url') ?>
        </div>
        <fieldset class="redes-form">
          <legend>Redes sociales adjuntas</legend>
          <ul class="redes-form__lista" data-redes>
            <?php $filas = $v['redes'] ?: [['youtube', '']]; ?>
            <?php foreach ($filas as $i => [$red, $url]): ?>
              <li class="redes-form__fila" data-red-fila>
                <label class="sr" for="red-<?= $i ?>">Plataforma</label>
                <select id="red-<?= $i ?>" name="red[]"><?php foreach (REDES_PERMITIDAS as $rp): ?><option value="<?= e($rp) ?>"<?= $red === $rp ? ' selected' : '' ?>><?= e(red_info($rp)[0]) ?></option><?php endforeach; ?></select>
                <label class="sr" for="red-url-<?= $i ?>">URL del perfil</label>
                <input id="red-url-<?= $i ?>" name="red_url[]" type="url" inputmode="url" placeholder="https://" value="<?= e($url) ?>">
                <button class="icono-btn" type="button" data-quitar-red><?= icono('cerrar') ?><span class="sr">Quitar esta red</span></button>
              </li>
            <?php endforeach; ?>
          </ul>
          <button class="boton boton--suave" type="button" data-agregar-red><?= icono('mas') ?>Agregar red</button>
          <?= $err('redes') ?>
        </fieldset>
      </section>

      <section class="tarjeta-form" aria-labelledby="sec-venta" data-seccion-venta>
        <h2 class="tarjeta-form__titulo" id="sec-venta">Venta <span class="opcional">(para la categoría Ventas)</span></h2>
        <div class="campo">
          <label for="venta_url">URL de venta</label>
          <input id="venta_url" name="venta_url" type="url" inputmode="url" placeholder="https://" value="<?= e($v['venta_url']) ?>"<?= $inv('venta_url') ?>>
          <?= $err('venta_url') ?>
        </div>
        <div class="campo"><label for="tienda">Tienda</label><input id="tienda" name="tienda" maxlength="120" value="<?= e($v['tienda']) ?>"></div>
        <div class="campos-dos">
          <div class="campo"><label for="precio">Precio (CLP)</label><input id="precio" name="precio" inputmode="numeric" value="<?= e($v['precio']) ?>"></div>
          <div class="campo"><label for="precio_antes">Precio anterior</label><input id="precio_antes" name="precio_antes" inputmode="numeric" value="<?= e($v['precio_antes']) ?>"<?= $inv('precio_antes') ?>></div>
        </div>
        <?= $err('precio_antes') ?>
        <div class="campo">
          <label for="ficha">Ficha técnica (opcional)</label>
          <textarea id="ficha" name="ficha" rows="4" placeholder="Batería: 40 h&#10;Peso: 254 g"><?= e($v['ficha']) ?></textarea>
          <p class="campo__ayuda">Una característica por línea, con el formato “Nombre: valor”.</p>
        </div>
      </section>
    </aside>
  </div>

  <div class="publicar__barra">
    <div class="progreso" data-progreso hidden>
      <div class="progreso__pista"><span class="progreso__barra" data-progreso-barra></span></div>
      <p class="progreso__txt" aria-live="polite" data-progreso-txt>Subiendo…</p>
    </div>
    <a class="boton boton--suave" href="<?= e(url('admin/publicaciones.php')) ?>">Cancelar</a>
    <button class="boton boton--primario boton--grande" type="submit" data-enviar>
      <span class="boton__txt"><?= $actual ? 'Guardar cambios' : 'Publicar' ?></span><span class="boton__cargando" aria-hidden="true"></span>
    </button>
  </div>
</form>

<template id="plantilla-red">
  <li class="redes-form__fila" data-red-fila>
    <label class="sr">Plataforma</label>
    <select name="red[]"><?php foreach (REDES_PERMITIDAS as $rp): ?><option value="<?= e($rp) ?>"><?= e(red_info($rp)[0]) ?></option><?php endforeach; ?></select>
    <label class="sr">URL del perfil</label>
    <input name="red_url[]" type="url" inputmode="url" placeholder="https://">
    <button class="icono-btn" type="button" data-quitar-red><?= icono('cerrar') ?><span class="sr">Quitar esta red</span></button>
  </li>
</template>

<?php if ($actual): ?>
  <section class="zona-peligro" aria-labelledby="zp-titulo">
    <h2 class="caja__titulo" id="zp-titulo">Eliminar esta publicación</h2>
    <p class="caja__txt">Se borran la publicación, sus fotos, su video y sus redes adjuntas. No se puede deshacer.</p>
    <form method="post" action="<?= e(url('admin/eliminar.php')) ?>" data-confirmar="¿Eliminar «<?= e($actual['titulo']) ?>»? No se puede deshacer.">
      <?= csrf_campo() ?><input type="hidden" name="id" value="<?= (int) $actual['id'] ?>">
      <button class="boton boton--peligro" type="submit"><?= icono('eliminar') ?>Eliminar publicación</button>
    </form>
  </section>
<?php endif; ?>
</div></div>
<?php vista('pie', ['seccion' => 'admin']); ?>
