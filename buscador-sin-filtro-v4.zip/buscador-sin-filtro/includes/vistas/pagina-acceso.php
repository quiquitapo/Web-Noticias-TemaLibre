<?php
/** Página completa de acceso (sin JavaScript o al entrar directo). Variables: las de formularios-acceso + $motivo_txt */
?>
<div class="acceso-pagina">
  <div class="contenedor">
    <div class="acceso acceso--pagina">
      <aside class="acceso__lado">
        <svg class="acceso__logo" aria-hidden="true" focusable="false"><use href="#i-logo"/></svg>
        <h1 class="acceso__titulo"><?= $activa === 'registro' ? 'Crea tu cuenta gratis' : 'Entra para ver el contenido completo' ?></h1>
        <p class="acceso__motivo"><?= e($motivo_txt ?: 'Puedes explorar noticias, videos y ventas sin cuenta. Con una cuenta gratis también ves:') ?></p>
        <?php vista('desbloquea'); ?>
      </aside>
      <div class="acceso__formularios">
        <?php vista('formularios-acceso', get_defined_vars()); ?>
      </div>
    </div>
  </div>
</div>
