<?php
/**
 * Galería con barra lateral de categorías, chips, panel de filtros y resultados.
 * Variables: $f (filtros), $res (resultado de explorar), $fac (facetas), $catActual, $raiz, $titulo
 */
$arbol = categorias_arbol();
$total = array_sum(array_column($arbol, 'total'));
$base = filtros_a_url($f, ['pagina' => 1]);
$enlace = static fn(array $cambios) => url('videos.php', filtros_a_url($f, $cambios + ['pagina' => 1]));
$panelFiltros = count($f['tipo']) + count($f['orientacion']) + count($f['verificacion']) + count($f['con']) + ($f['fecha'] ? 1 : 0) + ($f['duracion'] ? 1 : 0) + ($f['creador'] ? 1 : 0);
$panelAbierto = !empty($_GET['panel']);
$explicacion = [
    'recientes'   => 'Lo más nuevo primero, por fecha de publicación. Nadie paga por aparecer más arriba.',
    'relevancia'  => 'Primero lo que coincide con tu búsqueda en el título, luego en la descripción. Desempata la fecha.',
    'equilibrado' => 'Una publicación de cada orientación antes de repetir. Así comparas posturas en vez de quedarte en una burbuja.',
    'vistas'      => 'Lo más visto primero. Ojo: lo popular no siempre es lo más confiable.',
    'antiguos'    => 'Lo más antiguo primero, por fecha de publicación.',
][$f['orden']];

// Filtros activos como chips que se pueden quitar
$activos = [];
foreach ($f['tipo'] as $v) {
    $activos[] = [TIPOS[$v][1], $enlace(['tipo' => array_values(array_diff($f['tipo'], [$v]))])];
}
foreach ($f['orientacion'] as $v) {
    $activos[] = [ORIENTACIONES[$v][0], $enlace(['orientacion' => array_values(array_diff($f['orientacion'], [$v]))])];
}
foreach ($f['verificacion'] as $v) {
    $activos[] = [VERIFICACIONES[$v][0], $enlace(['verificacion' => array_values(array_diff($f['verificacion'], [$v]))])];
}
foreach ($f['con'] as $v) {
    $activos[] = [CARACTERISTICAS[$v][0], $enlace(['con' => array_values(array_diff($f['con'], [$v]))])];
}
if ($f['fecha']) {
    $activos[] = [FECHAS[$f['fecha']][0], $enlace(['fecha' => ''])];
}
if ($f['duracion']) {
    $activos[] = [DURACIONES[$f['duracion']][0], $enlace(['duracion' => ''])];
}
if ($f['creador']) {
    $activos[] = ['Creador: ' . $f['creador'], $enlace(['creador' => ''])];
}
$subsRaiz = [];
foreach ($arbol as $r) {
    if ($r['slug'] === $raiz) {
        $subsRaiz = $r['subs'];
    }
}
$ocultos = array_filter(['cat' => $f['cat'], 'orden' => $f['orden'] !== 'relevancia' && $f['orden'] !== 'recientes' ? $f['orden'] : '']);
?>
<div class="explorar">
  <aside class="guia" aria-label="Categorías y algoritmo">
    <nav aria-label="Categorías">
      <ul class="guia__lista">
        <li><a class="guia__item" href="<?= e(url('videos.php', array_filter(['q' => $f['q']]))) ?>"<?= $f['cat'] === '' ? ' aria-current="page"' : '' ?>><?= icono('video') ?><span>Todo</span><span class="guia__n"><?= (int) $total ?></span></a></li>
        <?php foreach ($arbol as $r): ?>
          <li>
            <a class="guia__item" href="<?= e($enlace(['cat' => $r['slug']])) ?>"<?= $f['cat'] === $r['slug'] ? ' aria-current="page"' : '' ?>><?= icono('carpeta') ?><span><?= e($r['nombre']) ?></span><span class="guia__n"><?= (int) $r['total'] ?></span></a>
            <?php if ($r['subs']): ?>
              <ul class="guia__subs">
                <?php foreach ($r['subs'] as $s): ?>
                  <li><a class="guia__sub" href="<?= e($enlace(['cat' => $s['slug']])) ?>"<?= $f['cat'] === $s['slug'] ? ' aria-current="page"' : '' ?>><span><?= e($s['nombre']) ?></span><span class="guia__n"><?= (int) $s['total'] ?></span></a></li>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
    </nav>
    <section class="algoritmo" aria-labelledby="algoritmo-titulo">
      <h2 class="algoritmo__titulo" id="algoritmo-titulo"><?= icono('balanza') ?>Tu algoritmo</h2>
      <p><strong><?= e(ORDENES[$f['orden']]) ?>.</strong> <?= e($explicacion) ?></p>
      <p>Sin personalización: con los mismos filtros, todas las personas ven el mismo orden.</p>
      <a class="enlace" href="<?= e(url('transparencia.php')) ?>">Cómo funciona</a>
    </section>
  </aside>

  <div class="explorar__principal">
    <header class="explorar__cabeza">
      <?php vista('buscador', ['id' => 'q-pagina', 'variante' => 'pagina', 'valor' => $f['q'], 'ocultos' => $ocultos]); ?>
      <h1 class="explorar__titulo"><?php if ($f['q'] !== ''): ?>Resultados para <q><?= e($f['q']) ?></q><?php else: ?><?= e($titulo) ?><?php endif; ?></h1>
      <?php if ($catActual && $catActual['descripcion'] && $f['q'] === ''): ?><p class="explorar__desc"><?= e($catActual['descripcion']) ?></p><?php endif; ?>
    </header>

    <nav class="chips-barra" aria-label="Categorías principales">
      <ul class="chips chips--barra">
        <li><a class="chip" href="<?= e($enlace(['cat' => ''])) ?>"<?= $f['cat'] === '' ? ' aria-current="page"' : '' ?>>Todo</a></li>
        <?php foreach ($arbol as $r): ?>
          <li><a class="chip" href="<?= e($enlace(['cat' => $r['slug']])) ?>"<?= $raiz === $r['slug'] ? ' aria-current="' . ($f['cat'] === $r['slug'] ? 'page' : 'true') . '"' : '' ?>><?= e($r['nombre']) ?></a></li>
        <?php endforeach; ?>
      </ul>
      <?php if ($subsRaiz): ?>
        <ul class="chips chips--subs" aria-label="Subcategorías">
          <?php foreach ($subsRaiz as $s): ?>
            <li><a class="chip chip--sub" href="<?= e($enlace(['cat' => $s['slug']])) ?>"<?= $f['cat'] === $s['slug'] ? ' aria-current="page"' : '' ?>><?= e($s['nombre']) ?><span class="chip__n"><?= (int) $s['total'] ?></span></a></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </nav>

    <form class="filtros" method="get" action="<?= e(url('videos.php')) ?>" data-filtros>
      <?php if ($f['q'] !== ''): ?><input type="hidden" name="q" value="<?= e($f['q']) ?>"><?php endif; ?>
      <?php if ($f['cat'] !== ''): ?><input type="hidden" name="cat" value="<?= e($f['cat']) ?>"><?php endif; ?>
      <?php if ($f['creador'] !== ''): ?><input type="hidden" name="creador" value="<?= e($f['creador']) ?>"><?php endif; ?>
      <input type="hidden" name="panel" value="1" data-panel-estado disabled>
      <div class="filtros__barra">
        <button class="boton boton--suave filtros__boton" type="button" aria-expanded="<?= $panelAbierto ? 'true' : 'false' ?>" aria-controls="filtros-panel" data-filtros-toggle>
          <?= icono('filtro') ?>Filtros<?php if ($panelFiltros): ?><span class="filtros__n"><span class="sr">, </span><?= $panelFiltros ?><span class="sr"> activos</span></span><?php endif; ?>
        </button>
        <a class="boton filtros__equilibrio<?= $f['orden'] === 'equilibrado' ? ' activo' : '' ?>" href="<?= e($enlace(['orden' => $f['orden'] === 'equilibrado' ? ($f['q'] !== '' ? 'relevancia' : 'recientes') : 'equilibrado'])) ?>"<?= $f['orden'] === 'equilibrado' ? ' aria-current="true"' : '' ?>>
          <?= icono('balanza') ?>Vista equilibrada<span class="sr"><?= $f['orden'] === 'equilibrado' ? ' (activada; toca para desactivar)' : '' ?></span>
        </a>
        <label class="select filtros__orden">
          <span class="select__label">Ordenar por</span>
          <select name="orden" data-autoenviar-campo>
            <?php foreach (ORDENES as $k => $t): if ($k === 'relevancia' && $f['q'] === '') { continue; } ?>
              <option value="<?= e($k) ?>"<?= $f['orden'] === $k ? ' selected' : '' ?>><?= e($t) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <p class="filtros__total" aria-live="polite"><?= e(plural($res['total'], 'resultado', 'resultados')) ?></p>
      </div>

      <div class="filtros__panel" id="filtros-panel" data-filtros-panel<?= $panelAbierto ? '' : ' data-cerrado' ?>>
        <fieldset class="filtro">
          <legend>Tipo</legend>
          <?php foreach (TIPOS as $k => [$t, $tp]): $n = (int) ($fac['tipo'][$k] ?? 0); ?>
            <label class="opcion<?= !$n && !in_array($k, $f['tipo'], true) ? ' opcion--vacia' : '' ?>"><input type="checkbox" name="tipo[]" value="<?= e($k) ?>"<?= in_array($k, $f['tipo'], true) ? ' checked' : '' ?>><span><?= e($tp) ?></span><span class="opcion__n"><?= $n ?></span></label>
          <?php endforeach; ?>
        </fieldset>
        <fieldset class="filtro">
          <legend>Orientación</legend>
          <?php foreach (ORIENTACIONES as $k => [$t, $pos]): $n = (int) ($fac['orientacion'][$k] ?? 0); ?>
            <label class="opcion<?= !$n && !in_array($k, $f['orientacion'], true) ? ' opcion--vacia' : '' ?>"><input type="checkbox" name="orientacion[]" value="<?= e($k) ?>"<?= in_array($k, $f['orientacion'], true) ? ' checked' : '' ?>>
              <span class="opcion__escala" aria-hidden="true"><?php for ($i = 1; $i <= 5; $i++): ?><i<?= $i === $pos ? ' class="on"' : '' ?>></i><?php endfor; ?></span><span><?= e($pos ? $t : 'Sin orientación') ?></span><span class="opcion__n"><?= $n ?></span></label>
          <?php endforeach; ?>
        </fieldset>
        <fieldset class="filtro">
          <legend>Verificación</legend>
          <?php foreach (VERIFICACIONES as $k => [$t]): $n = (int) ($fac['verificacion'][$k] ?? 0); ?>
            <label class="opcion opcion--<?= e($k) ?><?= !$n && !in_array($k, $f['verificacion'], true) ? ' opcion--vacia' : '' ?>"><input type="checkbox" name="verificacion[]" value="<?= e($k) ?>"<?= in_array($k, $f['verificacion'], true) ? ' checked' : '' ?>><?= icono(['verificado' => 'check-circulo', 'sin-verificar' => 'pendiente', 'enganoso' => 'alerta'][$k]) ?><span><?= e($t) ?></span><span class="opcion__n"><?= $n ?></span></label>
          <?php endforeach; ?>
        </fieldset>
        <fieldset class="filtro">
          <legend>Fecha de publicación</legend>
          <label class="opcion"><input type="radio" name="fecha" value=""<?= $f['fecha'] === '' ? ' checked' : '' ?>><span>Cualquier fecha</span></label>
          <?php foreach (FECHAS as $k => [$t]): ?>
            <label class="opcion"><input type="radio" name="fecha" value="<?= e($k) ?>"<?= $f['fecha'] === $k ? ' checked' : '' ?>><span><?= e($t) ?></span></label>
          <?php endforeach; ?>
        </fieldset>
        <fieldset class="filtro">
          <legend>Duración del video</legend>
          <label class="opcion"><input type="radio" name="duracion" value=""<?= $f['duracion'] === '' ? ' checked' : '' ?>><span>Cualquiera</span></label>
          <?php foreach (DURACIONES as $k => [$t]): ?>
            <label class="opcion"><input type="radio" name="duracion" value="<?= e($k) ?>"<?= $f['duracion'] === $k ? ' checked' : '' ?>><span><?= e($t) ?></span></label>
          <?php endforeach; ?>
        </fieldset>
        <fieldset class="filtro">
          <legend>Características</legend>
          <?php foreach (CARACTERISTICAS as $k => [$t]): ?>
            <label class="opcion"><input type="checkbox" name="con[]" value="<?= e($k) ?>"<?= in_array($k, $f['con'], true) ? ' checked' : '' ?>><span><?= e($t) ?></span></label>
          <?php endforeach; ?>
        </fieldset>
        <div class="filtros__acciones">
          <button class="boton boton--primario" type="submit">Aplicar filtros</button>
          <?php if ($panelFiltros): ?><a class="boton boton--suave" href="<?= e(url('videos.php', array_filter(['q' => $f['q'], 'cat' => $f['cat']]))) ?>">Quitar filtros</a><?php endif; ?>
        </div>
      </div>
    </form>

    <?php if ($activos): ?>
      <ul class="activos" aria-label="Filtros aplicados">
        <?php foreach ($activos as [$t, $href]): ?>
          <li><a class="activo-chip" href="<?= e($href) ?>"><?= e($t) ?><?= icono('cerrar') ?><span class="sr"> (quitar filtro)</span></a></li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <?php if ($res['total'] > 0 && !$res['exacto']): ?>
      <p class="aviso-parcial"><?= icono('alerta') ?>Ninguna publicación contiene todas las palabras. Te mostramos las que coinciden con alguna.</p>
    <?php endif; ?>

    <?php if ($res['items']): ?>
      <ul class="rejilla-videos">
        <?php foreach ($res['items'] as $i => $p): ?>
          <li><?php vista('tarjeta', ['p' => $p, 'terminos' => $res['terminos'], 'prioridad' => $i < 4, 'h' => 'h2']); ?></li>
        <?php endforeach; ?>
      </ul>
      <?php vista('paginacion', ['pagina' => $res['pagina'], 'paginas' => $res['paginas'], 'ruta' => 'videos.php', 'params' => filtros_a_url($f, ['pagina' => 1])]); ?>
    <?php else: ?>
      <section class="vacio" aria-labelledby="vacio-titulo">
        <h2 class="vacio__titulo" id="vacio-titulo">No hay publicaciones con estos filtros</h2>
        <ul class="vacio__tips">
          <?php if ($activos): ?><li><a href="<?= e(url('videos.php', array_filter(['q' => $f['q'], 'cat' => $f['cat']]))) ?>">Quita los filtros</a> para ver más resultados.</li><?php endif; ?>
          <?php if ($f['q'] !== ''): ?><li>Usa menos palabras o términos más generales, como “corrupción” o “video falso”.</li><?php endif; ?>
          <?php if ($f['cat'] !== ''): ?><li><a href="<?= e(url('videos.php', array_filter(['q' => $f['q']]))) ?>">Busca en todas las categorías</a>.</li><?php endif; ?>
        </ul>
        <h3 class="vacio__sub">Lo más buscado</h3>
        <ul class="chips">
          <?php foreach (tendencias(8) as $t): ?><li><a class="chip" href="<?= e(url('videos.php', ['q' => $t])) ?>"><?= e($t) ?></a></li><?php endforeach; ?>
        </ul>
      </section>
    <?php endif; ?>
  </div>
</div>
