<?php
/**
 * Punto de arranque común: configuración, errores, sesión, cabeceras de seguridad y base de datos.
 * Cada página pública empieza con: require __DIR__ . '/includes/bootstrap.php';
 */
declare(strict_types=1);

define('APP_DIR', dirname(__DIR__));
define('INC_DIR', __DIR__);

$GLOBALS['config'] = require INC_DIR . '/config.php';

function config(string $ruta, $defecto = null)
{
    $valor = $GLOBALS['config'];
    foreach (explode('.', $ruta) as $parte) {
        if (!is_array($valor) || !array_key_exists($parte, $valor)) {
            return $defecto;
        }
        $valor = $valor[$parte];
    }
    return $valor;
}

date_default_timezone_set(config('app.zona_horaria', 'America/Santiago'));
mb_internal_encoding('UTF-8');

// --- Errores -----------------------------------------------------------------
$produccion = config('app.entorno') === 'produccion';
error_reporting(E_ALL);
ini_set('display_errors', $produccion ? '0' : '1');
ini_set('log_errors', '1');
ini_set('error_log', APP_DIR . '/logs/php-errores.log');

require INC_DIR . '/helpers.php';
require INC_DIR . '/db.php';
require INC_DIR . '/auth.php';
require INC_DIR . '/repositorio.php';

set_exception_handler(static function (Throwable $e) use ($produccion): void {
    registrar_log('errores', get_class($e) . ': ' . $e->getMessage() . ' en ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
    }
    if (es_peticion_json()) {
        json_respuesta(['ok' => false, 'error' => 'Ocurrió un error en el servidor. Inténtalo de nuevo.'], 500);
    }
    if (!$produccion) {
        echo '<pre style="padding:2rem;white-space:pre-wrap">' . e((string) $e) . '</pre>';
        return;
    }
    $GLOBALS['error_500'] = true;
    require APP_DIR . '/404.php';
});

// --- Sesión segura -----------------------------------------------------------
if (PHP_SAPI !== 'cli' && session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_name('sf_sesion');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => url_base() . '/',
        'secure'   => es_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// --- Cabeceras de seguridad ----------------------------------------------------
if (PHP_SAPI !== 'cli' && !headers_sent()) {
    $nonce = csp_nonce();
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header('X-Frame-Options: DENY');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'nonce-{$nonce}'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'");
    if (es_https()) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}
