<?php
/**
 * Conexión PDO. SQLite por defecto (sin configuración); MySQL/MariaDB con SF_DB_DRIVER=mysql.
 * Con SQLite, la base se crea y se llena con datos de ejemplo la primera vez.
 */
declare(strict_types=1);

/** Versión del esquema. Si la base SQLite tiene otra, se reinstala sola (solo datos de ejemplo). */
const ESQUEMA_VERSION = '2';

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $driver = config('db.driver', 'sqlite');
    $opciones = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    if ($driver === 'mysql') {
        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', config('db.host'), config('db.puerto'), config('db.nombre'));
        $pdo = new PDO($dsn, (string) config('db.usuario'), (string) config('db.clave'), $opciones);
        $pdo->exec("SET time_zone = '" . date('P') . "'");
        return $pdo;
    }

    $ruta = (string) config('db.sqlite_ruta');
    $pdo = new PDO('sqlite:' . $ruta, null, null, $opciones);
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('PRAGMA journal_mode = WAL');
    $pdo->exec('PRAGMA busy_timeout = 3000');
    // Memoria acotada: caché de páginas pequeña y temporales en disco.
    $pdo->exec('PRAGMA cache_size = -2000');
    $pdo->exec('PRAGMA temp_store = FILE');
    try {
        $version = $pdo->query("SELECT valor FROM meta WHERE clave = 'esquema'")->fetchColumn();
    } catch (Throwable) {
        $version = null;
    }
    // Base nueva o de la versión 1 (sin tabla meta): se instala con datos de ejemplo.
    // Una base con otra versión nunca se borra sola: hay que migrarla a mano.
    if ($version === false || $version === null) {
        require_once INC_DIR . '/instalar.php';
        instalar($pdo, 'sqlite');
    } elseif ($version !== ESQUEMA_VERSION) {
        throw new RuntimeException("La base de datos usa el esquema v{$version} y esta versión del sitio necesita v" . ESQUEMA_VERSION . '.');
    }
    return $pdo;
}

function db_driver(): string
{
    return config('db.driver', 'sqlite') === 'mysql' ? 'mysql' : 'sqlite';
}

function consulta(string $sql, array $params = []): PDOStatement
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

function fila(string $sql, array $params = []): ?array
{
    $r = consulta($sql, $params)->fetch();
    return $r === false ? null : $r;
}

function filas(string $sql, array $params = []): array
{
    return consulta($sql, $params)->fetchAll();
}

function valor(string $sql, array $params = [])
{
    $v = consulta($sql, $params)->fetchColumn();
    return $v === false ? null : $v;
}

function ahora(): string
{
    return date('Y-m-d H:i:s');
}
