<?php
/**
 * Esquema de base de datos (versión 2) y datos de ejemplo.
 *
 * Uso por consola (desde la carpeta del proyecto):
 *   php includes/instalar.php              Crea las tablas y carga los datos de ejemplo si están vacías
 *   php includes/instalar.php --reiniciar  Borra todo y vuelve a instalar
 *   php includes/instalar.php --exportar   Regenera sql/buscador_mysql.sql (para importar en phpMyAdmin)
 *
 * Con SQLite no necesitas ejecutar nada: la base se crea (o se actualiza) sola.
 */
declare(strict_types=1);

const TABLAS = ['busquedas', 'clics', 'intentos_acceso', 'redes_sociales', 'imagenes', 'publicaciones', 'usuarios', 'categorias', 'meta'];
// Tablas de la versión 1, se eliminan al actualizar.
const TABLAS_V1 = ['videos', 'noticias', 'productos', 'perfiles'];

function esquema(string $driver): array
{
    $mysql = $driver === 'mysql';
    $pk = $mysql ? 'INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
    $fk = $mysql ? 'INT UNSIGNED' : 'INTEGER';
    $fin = $mysql ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';
    $ix = static fn(string $n, string $t, string $c) => "CREATE INDEX {$n} ON {$t} ({$c})";

    return [
        "CREATE TABLE IF NOT EXISTS meta (
  clave VARCHAR(40) NOT NULL PRIMARY KEY,
  valor VARCHAR(255) NOT NULL
){$fin}",
        "CREATE TABLE IF NOT EXISTS categorias (
  id {$pk},
  slug VARCHAR(80) NOT NULL UNIQUE,
  nombre VARCHAR(80) NOT NULL,
  descripcion VARCHAR(255) NOT NULL DEFAULT '',
  padre_id {$fk} NULL,
  orden INT NOT NULL DEFAULT 0,
  FOREIGN KEY (padre_id) REFERENCES categorias(id)
){$fin}",
        "CREATE TABLE IF NOT EXISTS usuarios (
  id {$pk},
  nombre VARCHAR(80) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  clave_hash VARCHAR(255) NOT NULL,
  rol VARCHAR(10) NOT NULL DEFAULT 'usuario',
  nombre_admin VARCHAR(80) NULL,
  guardar_historial SMALLINT NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL,
  ultimo_acceso DATETIME NULL
){$fin}",
        "CREATE TABLE IF NOT EXISTS publicaciones (
  id {$pk},
  slug VARCHAR(160) NOT NULL UNIQUE,
  tipo VARCHAR(10) NOT NULL,
  titulo VARCHAR(200) NOT NULL,
  descripcion TEXT NOT NULL,
  cuerpo TEXT NULL,
  categoria_id {$fk} NOT NULL,
  orientacion VARCHAR(20) NOT NULL DEFAULT 'no-aplica',
  orientacion_nota VARCHAR(255) NULL,
  verificacion VARCHAR(20) NOT NULL DEFAULT 'sin-verificar',
  verificacion_nota VARCHAR(600) NULL,
  creador VARCHAR(120) NOT NULL DEFAULT '',
  creador_url VARCHAR(255) NULL,
  autor VARCHAR(120) NULL,
  fuente_url VARCHAR(255) NULL,
  venta_url VARCHAR(255) NULL,
  tienda VARCHAR(120) NULL,
  precio INT NULL,
  precio_antes INT NULL,
  ficha TEXT NULL,
  miniatura VARCHAR(200) NOT NULL,
  miniatura_color CHAR(7) NOT NULL DEFAULT '#e5e7ef',
  video_archivo VARCHAR(200) NULL,
  video_webm VARCHAR(200) NULL,
  subtitulos VARCHAR(200) NULL,
  duracion_seg INT NOT NULL DEFAULT 0,
  etiquetas VARCHAR(500) NOT NULL DEFAULT '',
  vistas INT NOT NULL DEFAULT 0,
  destacado SMALLINT NOT NULL DEFAULT 0,
  subido_por_id {$fk} NULL,
  subido_por VARCHAR(80) NOT NULL DEFAULT '',
  titulo_norm VARCHAR(400) NOT NULL DEFAULT '',
  busqueda TEXT NOT NULL,
  publicado_en DATETIME NOT NULL,
  actualizado_en DATETIME NULL,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id),
  FOREIGN KEY (subido_por_id) REFERENCES usuarios(id) ON DELETE SET NULL
){$fin}",
        "CREATE TABLE IF NOT EXISTS imagenes (
  id {$pk},
  publicacion_id {$fk} NOT NULL,
  base VARCHAR(200) NOT NULL,
  color CHAR(7) NOT NULL DEFAULT '#e5e7ef',
  alt VARCHAR(255) NOT NULL DEFAULT '',
  orden INT NOT NULL DEFAULT 0,
  FOREIGN KEY (publicacion_id) REFERENCES publicaciones(id) ON DELETE CASCADE
){$fin}",
        "CREATE TABLE IF NOT EXISTS redes_sociales (
  id {$pk},
  publicacion_id {$fk} NOT NULL,
  red VARCHAR(20) NOT NULL,
  usuario VARCHAR(80) NOT NULL,
  url VARCHAR(255) NOT NULL,
  FOREIGN KEY (publicacion_id) REFERENCES publicaciones(id) ON DELETE CASCADE
){$fin}",
        "CREATE TABLE IF NOT EXISTS intentos_acceso (
  id {$pk},
  clave CHAR(64) NOT NULL,
  creado_en DATETIME NOT NULL
){$fin}",
        "CREATE TABLE IF NOT EXISTS clics (
  id {$pk},
  usuario_id {$fk} NOT NULL,
  publicacion_id {$fk} NOT NULL,
  tipo VARCHAR(12) NOT NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (publicacion_id) REFERENCES publicaciones(id) ON DELETE CASCADE
){$fin}",
        "CREATE TABLE IF NOT EXISTS busquedas (
  id {$pk},
  termino VARCHAR(120) NOT NULL,
  resultados INT NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL
){$fin}",
        $ix('idx_pub_categoria', 'publicaciones', 'categoria_id'),
        $ix('idx_pub_fecha', 'publicaciones', 'publicado_en'),
        $ix('idx_pub_orientacion', 'publicaciones', 'orientacion'),
        $ix('idx_pub_verificacion', 'publicaciones', 'verificacion'),
        $ix('idx_pub_tipo', 'publicaciones', 'tipo'),
        $ix('idx_cat_padre', 'categorias', 'padre_id'),
        $ix('idx_img_pub', 'imagenes', 'publicacion_id'),
        $ix('idx_redes_pub', 'redes_sociales', 'publicacion_id'),
        $ix('idx_intentos_clave', 'intentos_acceso', 'clave, creado_en'),
        $ix('idx_clics_usuario', 'clics', 'usuario_id, creado_en'),
        $ix('idx_busquedas_fecha', 'busquedas', 'creado_en'),
    ];
}

function borrar_tablas(PDO $pdo, string $driver): void
{
    if ($driver === 'mysql') {
        $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
    } else {
        $pdo->exec('PRAGMA foreign_keys = OFF');
    }
    foreach (array_merge(TABLAS, TABLAS_V1) as $t) {
        $pdo->exec("DROP TABLE IF EXISTS {$t}");
    }
    if ($driver === 'mysql') {
        $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
    } else {
        $pdo->exec('PRAGMA foreign_keys = ON');
    }
}

function version_esquema(PDO $pdo): ?string
{
    try {
        $v = $pdo->query("SELECT valor FROM meta WHERE clave = 'esquema'")->fetchColumn();
        return $v === false ? null : (string) $v;
    } catch (Throwable) {
        return null;
    }
}

function instalar(PDO $pdo, string $driver): void
{
    $version = version_esquema($pdo);
    if ($version !== null && $version !== ESQUEMA_VERSION) {
        throw new RuntimeException("La base usa el esquema v{$version}. Usa --reiniciar para reemplazarla (se borran los datos).");
    }
    if ($version === null) {
        borrar_tablas($pdo, $driver); // elimina tablas de la versión 1 si existen
        foreach (esquema($driver) as $sql) {
            $pdo->exec($sql);
        }
        $pdo->prepare('INSERT INTO meta (clave, valor) VALUES (?, ?)')->execute(['esquema', ESQUEMA_VERSION]);
    }
    if ((int) $pdo->query('SELECT COUNT(*) FROM categorias')->fetchColumn() === 0) {
        $pdo->beginTransaction();
        foreach (filas_semilla() as [$tabla, $datos]) {
            $cols = array_keys($datos);
            $st = $pdo->prepare("INSERT INTO {$tabla} (" . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')');
            $st->execute(array_values($datos));
        }
        $pdo->commit();
    }
}

/** Convierte sql/datos_demo.json en filas listas para insertar, con IDs explícitos. */
function filas_semilla(): array
{
    $d = json_decode((string) file_get_contents(APP_DIR . '/sql/datos_demo.json'), true, 512, JSON_THROW_ON_ERROR);
    $out = [];
    $demo = config('cuenta_demo');
    $admin = config('cuenta_admin');
    $out[] = ['usuarios', ['id' => 1, 'nombre' => $admin['nombre'], 'email' => $admin['email'], 'clave_hash' => password_hash($admin['clave'], PASSWORD_DEFAULT),
        'rol' => 'admin', 'nombre_admin' => $admin['nombre_admin'], 'guardar_historial' => 0, 'creado_en' => '2026-09-01 09:00:00', 'ultimo_acceso' => null]];
    $out[] = ['usuarios', ['id' => 2, 'nombre' => $demo['nombre'], 'email' => $demo['email'], 'clave_hash' => password_hash($demo['clave'], PASSWORD_DEFAULT),
        'rol' => 'usuario', 'nombre_admin' => null, 'guardar_historial' => 0, 'creado_en' => '2026-09-01 10:00:00', 'ultimo_acceso' => null]];

    $catId = [];
    $catNombre = [];
    $padreDe = [];
    $id = 0;
    foreach ($d['categorias'] as $i => $c) {
        $pid = ++$id;
        $catId[$c['slug']] = $pid;
        $catNombre[$c['slug']] = $c['nombre'];
        $out[] = ['categorias', ['id' => $pid, 'slug' => $c['slug'], 'nombre' => $c['nombre'], 'descripcion' => $c['descripcion'], 'padre_id' => null, 'orden' => $i]];
        foreach ($c['subcategorias'] as $k => $s) {
            $sid = ++$id;
            $catId[$s['slug']] = $sid;
            $catNombre[$s['slug']] = $s['nombre'];
            $padreDe[$s['slug']] = $c['nombre'];
            $out[] = ['categorias', ['id' => $sid, 'slug' => $s['slug'], 'nombre' => $s['nombre'], 'descripcion' => '', 'padre_id' => $pid, 'orden' => $k]];
        }
    }

    $img = 0;
    $red = 0;
    // Orden cronológico: los IDs crecen con la fecha, igual que si se hubieran subido de a uno.
    usort($d['publicaciones'], static fn($a, $b) => strcmp($a['publicado_en'], $b['publicado_en']));
    foreach ($d['publicaciones'] as $i => $p) {
        $pubId = $i + 1;
        $fila = [
            'id' => $pubId, 'slug' => $p['slug'], 'tipo' => $p['tipo'], 'titulo' => $p['titulo'], 'descripcion' => $p['descripcion'],
            'cuerpo' => $p['cuerpo'] ?? null, 'categoria_id' => $catId[$p['categoria']],
            'orientacion' => $p['orientacion'], 'orientacion_nota' => $p['orientacion_nota'] ?? null,
            'verificacion' => $p['verificacion'], 'verificacion_nota' => $p['verificacion_nota'] ?? null,
            'creador' => $p['creador'] ?? '', 'creador_url' => $p['creador_url'] ?? null, 'autor' => $p['autor'] ?? null,
            'fuente_url' => $p['fuente_url'] ?? null,
            'venta_url' => $p['venta']['url'] ?? null, 'tienda' => $p['venta']['tienda'] ?? null,
            'precio' => $p['venta']['precio'] ?? null, 'precio_antes' => $p['venta']['antes'] ?? null,
            'ficha' => !empty($p['ficha']) ? json_encode($p['ficha'], JSON_UNESCAPED_UNICODE) : null,
            'miniatura' => $p['miniatura'], 'miniatura_color' => $p['miniatura_color'],
            'video_archivo' => $p['video']['archivo'] ?? null, 'video_webm' => $p['video']['webm'] ?? null,
            'subtitulos' => $p['video']['vtt'] ?? null, 'duracion_seg' => $p['video']['duracion'] ?? 0,
            'etiquetas' => implode(', ', $p['etiquetas'] ?? []), 'vistas' => $p['vistas'] ?? 0, 'destacado' => $p['destacado'] ?? 0,
            'subido_por_id' => 1, 'subido_por' => $p['subido_por'] ?? $admin['nombre_admin'],
            'publicado_en' => $p['publicado_en'], 'actualizado_en' => null,
        ];
        $fila += campos_busqueda($fila, $catNombre[$p['categoria']], $padreDe[$p['categoria']] ?? '');
        $out[] = ['publicaciones', $fila];
        foreach ($p['imagenes'] ?? [] as $k => $im) {
            $out[] = ['imagenes', ['id' => ++$img, 'publicacion_id' => $pubId, 'base' => $im['base'], 'color' => $im['color'], 'alt' => $im['alt'], 'orden' => $k]];
        }
        foreach ($p['redes'] ?? [] as $r) {
            $out[] = ['redes_sociales', ['id' => ++$red, 'publicacion_id' => $pubId, 'red' => $r['red'], 'usuario' => $r['usuario'], 'url' => $r['url']]];
        }
    }
    return $out;
}

function exportar_sql_mysql(): string
{
    $q = static function ($v): string {
        if ($v === null) {
            return 'NULL';
        }
        if (is_int($v) || is_float($v)) {
            return (string) $v;
        }
        return "'" . str_replace(['\\', "'", "\0"], ['\\\\', "''", ''], (string) $v) . "'";
    };
    $sql = "-- Sin Filtro: esquema v" . ESQUEMA_VERSION . " y datos de ejemplo para MySQL 8+ / MariaDB 10.3+\n"
        . "-- Generado con: php includes/instalar.php --exportar\n"
        . '-- Admin: ' . config('cuenta_admin.email') . ' / ' . config('cuenta_admin.clave') . "\n"
        . '-- Usuario: ' . config('cuenta_demo.email') . ' / ' . config('cuenta_demo.clave') . "\n\n"
        . "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n";
    foreach (array_merge(TABLAS, TABLAS_V1) as $t) {
        $sql .= "DROP TABLE IF EXISTS {$t};\n";
    }
    $sql .= "SET FOREIGN_KEY_CHECKS = 1;\n\n" . implode(";\n\n", esquema('mysql')) . ";\n\n";
    $sql .= "INSERT INTO meta (clave, valor) VALUES ('esquema', '" . ESQUEMA_VERSION . "');\n";
    foreach (filas_semilla() as [$tabla, $datos]) {
        $sql .= "INSERT INTO {$tabla} (" . implode(', ', array_keys($datos)) . ') VALUES (' . implode(', ', array_map($q, $datos)) . ");\n";
    }
    return $sql;
}

// --- Ejecución por consola ------------------------------------------------------
if (PHP_SAPI === 'cli' && realpath($argv[0] ?? '') === realpath(__FILE__)) {
    require __DIR__ . '/bootstrap.php';
    $args = array_slice($argv, 1);
    if (in_array('--exportar', $args, true)) {
        file_put_contents(APP_DIR . '/sql/buscador_mysql.sql', exportar_sql_mysql());
        file_put_contents(APP_DIR . '/sql/esquema_sqlite.sql', implode(";\n\n", esquema('sqlite')) . ";\n");
        echo "Listo: sql/buscador_mysql.sql y sql/esquema_sqlite.sql\n";
        exit(0);
    }
    $pdo = db();
    if (in_array('--reiniciar', $args, true)) {
        borrar_tablas($pdo, db_driver());
    }
    instalar($pdo, db_driver());
    echo 'Base de datos lista (' . db_driver() . ', esquema v' . ESQUEMA_VERSION . ').' . PHP_EOL;
    echo 'Admin: ' . config('cuenta_admin.email') . ' / ' . config('cuenta_admin.clave') . PHP_EOL;
    echo 'Usuario: ' . config('cuenta_demo.email') . ' / ' . config('cuenta_demo.clave') . PHP_EOL;
    exit(0);
}
