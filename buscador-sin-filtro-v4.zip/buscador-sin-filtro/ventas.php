<?php
/** Compatibilidad con la versión anterior: Ventas ahora es una categoría de Videos. */
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
redirigir(url('videos.php', ['cat' => 'ventas']), 301);
