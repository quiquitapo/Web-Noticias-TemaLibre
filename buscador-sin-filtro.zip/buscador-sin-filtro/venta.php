<?php
declare(strict_types=1);

/**
 * venta.php — ficha del aviso.
 * El aviso es público; el contacto del vendedor solo con sesión iniciada, para
 * que un robot no coseche correos y teléfonos del catálogo completo.
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/buscador.php';
require_once __DIR__ . '/includes/ventas.php';
require_once __DIR__ . '/includes/asistente.php';
require_once __DIR__ . '/includes/funciones.php';

iniciarSesionSegura();

$modoActual = 'ventas';
$id = enteroOpcional($_GET['id'] ?? null, 1, 99999999);
$venta = $id !== null ? ventaPorId($id, estaLogueado()) : null;

if ($venta === null) {
    http_response_code(404);
    $tituloPagina = 'Aviso no encontrado · ' . APP_NOMBRE;
    require __DIR__ . '/includes/header.php';
    echo '<div class="articulo"><h1>Aviso no encontrado</h1>'
       . '<p class="bajada">Puede que el enlace esté mal copiado o que el aviso ya se haya vendido.</p>'
       . '<p><a href="ventas.php">Volver a ventas</a></p></div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

contarVistaVenta($id);
$similares    = similaresVenta($id, (int) $venta['categoria_id'], 3);
$ctxAsistente = ['tipo' => 'venta', 'id' => $id];
$tituloPagina = $venta['titulo'] . ' · Ventas · ' . APP_NOMBRE;
$parrafos     = preg_split('/\R{2,}/u', (string) $venta['descripcion']) ?: [(string) $venta['descripcion']];

require __DIR__ . '/includes/header.php';
?>

<article class="articulo" id="contenido">
  <p class="migas">
    <a href="ventas.php">Ventas</a> /
    <a href="ventas.php?cat=<?= eu((string) $venta['categoria_slug']) ?>"><?= e($venta['categoria']) ?></a>
  </p>

  <h1><?= e($venta['titulo']) ?></h1>

  <p class="precio-ficha"><?= e(precioFormateado((int) $venta['precio'], (string) $venta['moneda'])) ?></p>

  <div class="ficha-origen">
    <span class="etiqueta-estado estado-<?= e((string) $venta['condicion']) ?>"><?= e(ucfirst((string) $venta['condicion'])) ?></span>
    <span class="meta-origen"><?= e($venta['comuna']) ?>, <?= e($venta['region']) ?></span>
    <span class="separador">·</span>
    <span><?= $venta['envio'] ? 'El vendedor despacha' : 'Retiro en el lugar' ?></span>
    <span class="separador">·</span>
    <span><?= (int) $venta['stock'] ?> <?= (int) $venta['stock'] === 1 ? 'unidad disponible' : 'unidades disponibles' ?></span>
    <span class="separador">·</span>
    <span>Publicado <?= e(fechaRelativa((string) $venta['publicada_en'])) ?></span>
  </div>

  <figure class="reproductor">
    <?= miniaturaSvg($id + 100, (string) $venta['categoria'], false) ?>
    <figcaption class="reproductor-pie">
      Imagen ilustrativa generada por el servidor. Este catálogo es una demostración:
      no se cargan fotos de terceros, para no abrir la política de seguridad ni rastrear al visitante.
    </figcaption>
  </figure>

  <div class="texto-articulo">
    <?php foreach ($parrafos as $p): ?>
      <?php $p = trim($p); if ($p === '') { continue; } ?>
      <p><?= e($p) ?></p>
    <?php endforeach; ?>
  </div>

  <section class="bloque-vendedor">
    <h2>Vendedor</h2>
    <p class="vendedor-nombre"><?= e($venta['vendedor']) ?></p>
    <?php if (estaLogueado()): ?>
      <p class="contacto"><?= e((string) ($venta['contacto'] ?? '')) ?></p>
      <p class="pista">Trata directo con el vendedor. El sitio no participa en el pago ni en la entrega.</p>
    <?php else: ?>
      <div class="muro">
        <h2>El contacto se muestra con sesión iniciada</h2>
        <p>Es la única forma de evitar que un robot recolecte los correos y teléfonos de todos los avisos.
           Ver el precio, la ubicación y la descripción no pide nada.</p>
        <div class="acciones">
          <a class="boton-oscuro" href="login.php">Iniciar sesión</a>
          <a class="boton-oscuro" href="registro.php">Crear cuenta</a>
        </div>
      </div>
    <?php endif; ?>
  </section>

  <?php if ($similares): ?>
    <section class="otras-versiones">
      <h2>Otros avisos de <?= e($venta['categoria']) ?></h2>
      <ul>
        <?php foreach ($similares as $s): ?>
          <li>
            <a href="venta.php?id=<?= (int) $s['id'] ?>"><?= e($s['titulo']) ?></a>
            <div class="meta">
              <span class="meta-origen"><?= e(precioFormateado((int) $s['precio'])) ?></span>
              <span class="separador">·</span>
              <span><?= e($s['comuna']) ?></span>
              <span class="separador">·</span>
              <span><?= e((string) $s['condicion']) ?></span>
            </div>
          </li>
        <?php endforeach; ?>
      </ul>
    </section>
  <?php endif; ?>

  <p class="pie-acceso"><a href="ventas.php">← Volver a ventas</a></p>
</article>

<?php require __DIR__ . '/includes/footer.php'; ?>
