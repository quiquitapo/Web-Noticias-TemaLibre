<?php
declare(strict_types=1);

/**
 * index.php — buscador público.
 * Cualquiera puede buscar y ver titular, bajada y procedencia.
 * El texto completo vive en noticia.php, que exige sesión.
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/buscador.php';
require_once __DIR__ . '/includes/funciones.php';

iniciarSesionSegura();
purgarIntentos();

$filtros   = filtrosDesdeGet($_GET);
$resultado = buscarNoticias($filtros);
$conteos   = conteoPorCategoria();
$subcats   = subcategoriasDe($filtros['categoria_id']);

$modoActual   = 'noticias';
$tituloPagina = ($filtros['q'] !== '' ? '“' . $filtros['q'] . '” · ' : '')
              . ($filtros['categoria_nombre'] !== '' ? $filtros['categoria_nombre'] . ' · ' : '')
              . APP_NOMBRE;

require __DIR__ . '/includes/header.php';
?>

<div class="lienzo">

  <!-- ── Categorías ─────────────────────────────────────────────────── -->
  <nav class="categorias" aria-label="Categorías">
    <ul>
      <li>
        <a href="<?= e(urlBuscador($filtros, ['cat' => '', 'sub' => '', 'p' => 1])) ?>"
           class="<?= $filtros['categoria_slug'] === '' ? 'actual' : '' ?>"
           <?= $filtros['categoria_slug'] === '' ? 'aria-current="page"' : '' ?>>Todas</a>
      </li>
      <?php foreach (categorias() as $cat): ?>
        <?php $activa = $filtros['categoria_slug'] === $cat['slug']; ?>
        <li>
          <a href="<?= e(urlBuscador($filtros, ['cat' => $cat['slug'], 'sub' => '', 'p' => 1])) ?>"
             class="<?= $activa ? 'actual' : '' ?>" <?= $activa ? 'aria-current="page"' : '' ?>>
            <?= e($cat['nombre']) ?>
            <span class="conteo"><?= (int) ($conteos[$cat['id']] ?? 0) ?></span>
          </a>
        </li>
      <?php endforeach; ?>
    </ul>
  </nav>

  <!-- ── Panel principal ────────────────────────────────────────────── -->
  <main class="panel" id="contenido">
    <form method="get" action="index.php" id="forma-buscador" role="search">
      <input type="hidden" name="cat" value="<?= e($filtros['categoria_slug']) ?>">

      <div class="fila-busqueda">
        <?php if ($filtros['q'] !== ''): ?>
          <a class="limpiar-busqueda" href="<?= e(urlBuscador($filtros, ['q' => '', 'p' => 1])) ?>">Borrar búsqueda</a>
        <?php endif; ?>
        <div class="buscador">
          <label class="oculto-visual" for="q">Buscar noticias por texto o palabra clave</label>
          <input type="search" id="q" name="q" placeholder="Search"
                 value="<?= e($filtros['q']) ?>" maxlength="<?= MAX_LARGO_BUSQUEDA ?>"
                 autocomplete="off" spellcheck="false">
          <button type="submit" class="boton-lupa" aria-label="Buscar">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                 stroke-width="2" aria-hidden="true">
              <circle cx="11" cy="11" r="7"></circle><path d="M20 20l-3.6-3.6"></path>
            </svg>
          </button>
        </div>
      </div>

      <div class="resumen">
        <span>
          <strong><?= number_format($resultado['total'], 0, ',', '.') ?></strong>
          <?= $resultado['total'] === 1 ? 'noticia' : 'noticias' ?>
          <?php if ($filtros['q'] !== ''): ?>
            para <strong><?= e($filtros['q']) ?></strong>
          <?php endif; ?>
          <?php if ($filtros['categoria_nombre'] !== ''): ?>
            en <strong><?= e($filtros['categoria_nombre']) ?></strong>
          <?php endif; ?>
        </span>
        <span class="orden">
          <label for="orden">Ordenar</label>
          <span class="orden-caja">
          <select name="orden" id="orden">
            <?php foreach (ordenesDisponibles() as $clave => $op): ?>
              <?php if ($clave === 'relevancia' && $filtros['q'] === '') { continue; } ?>
              <option value="<?= e($clave) ?>" <?= $filtros['orden'] === $clave ? 'selected' : '' ?>>
                <?= e($op['etiqueta']) ?>
              </option>
            <?php endforeach; ?>
          </select>
          </span>
        </span>
      </div>

      <?php if ($resultado['items']): ?>
        <div class="lista-noticias">
          <?php foreach ($resultado['items'] as $n): ?>
            <?php $enlace = 'noticia.php?id=' . (int) $n['id']; ?>
            <article class="noticia">
              <a class="miniatura" href="<?= e($enlace) ?>"
                 aria-label="Abrir: <?= e($n['titulo']) ?>">
                <?= miniaturaSvg((int) $n['id'], (string) $n['categoria'], $n['tipo'] === 'video') ?>
                <?php if ($n['tipo'] === 'video' && $n['duracion_min']): ?>
                  <span class="sello-duracion"><?= (int) $n['duracion_min'] ?> min</span>
                <?php endif; ?>
              </a>

              <div class="noticia-cuerpo">
                <h2><a href="<?= e($enlace) ?>"><?= resaltar((string) $n['titulo'], $filtros['terminos']) ?></a></h2>
                <p><?= resaltar(extracto((string) $n['bajada']), $filtros['terminos']) ?></p>
                <div class="meta">
                  <span class="meta-origen"><?= e($n['origen']) ?></span>
                  <span class="sesgo" title="Declarado por el propio medio"><?= e(etiquetaSesgo((string) $n['sesgo'])) ?></span>
                  <span class="separador">·</span>
                  <span><?= e($n['categoria']) ?><?= $n['subcategoria'] ? ' / ' . e($n['subcategoria']) : '' ?></span>
                  <span class="separador">·</span>
                  <time datetime="<?= e(date('c', (int) strtotime((string) $n['publicada_en']))) ?>">
                    <?= e(fechaRelativa((string) $n['publicada_en'])) ?>
                  </time>
                  <?php if (!estaLogueado()): ?>
                    <span class="candado">
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                           stroke-width="2.4" aria-hidden="true">
                        <rect x="4" y="11" width="16" height="10" rx="2"></rect>
                        <path d="M8 11V7a4 4 0 0 1 8 0v4"></path>
                      </svg>
                      Requiere cuenta
                    </span>
                  <?php endif; ?>
                </div>
              </div>
            </article>
          <?php endforeach; ?>
        </div>

        <?php if ($resultado['paginas'] > 1): ?>
          <nav class="paginacion" aria-label="Paginación">
            <?php if ($resultado['pagina'] > 1): ?>
              <a href="<?= e(urlBuscador($filtros, ['p' => $resultado['pagina'] - 1])) ?>" rel="prev">Anterior</a>
            <?php else: ?>
              <span class="inactivo">Anterior</span>
            <?php endif; ?>

            <span class="posicion">Página <?= (int) $resultado['pagina'] ?> de <?= (int) $resultado['paginas'] ?></span>

            <?php if ($resultado['pagina'] < $resultado['paginas']): ?>
              <a href="<?= e(urlBuscador($filtros, ['p' => $resultado['pagina'] + 1])) ?>" rel="next">Siguiente</a>
            <?php else: ?>
              <span class="inactivo">Siguiente</span>
            <?php endif; ?>
          </nav>
        <?php endif; ?>

      <?php else: ?>
        <div class="vacio">
          <h2>Sin resultados</h2>
          <p>No hay noticias que cumplan a la vez todos los filtros aplicados.<br>
             Prueba con menos palabras, amplía el rango de tiempo o cambia de categoría.</p>
          <ul>
            <li><a href="<?= e(urlBuscador($filtros, ['tiempo' => '', 'p' => 1])) ?>">Quitar el filtro de tiempo</a></li>
            <li><a href="<?= e(urlBuscador($filtros, ['origen' => '', 'p' => 1])) ?>">Ver todos los orígenes</a></li>
            <li><a href="index.php">Empezar de nuevo</a></li>
          </ul>
        </div>
      <?php endif; ?>

      <!-- ── Filtros ──────────────────────────────────────────────────── -->
      <div class="filtros">
        <div class="filtro <?= $filtros['tiempo'] !== '' ? 'filtro-activo' : '' ?>">
          <label for="tiempo">Filtro tiempo</label>
          <select name="tiempo" id="tiempo">
            <option value="">Cualquier fecha</option>
            <?php foreach (rangosTiempo() as $clave => $rango): ?>
              <option value="<?= e($clave) ?>" <?= $filtros['tiempo'] === $clave ? 'selected' : '' ?>>
                <?= e($rango['etiqueta']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="filtro <?= $filtros['origen_id'] !== null ? 'filtro-activo' : '' ?>">
          <label for="origen">Filtro origen</label>
          <select name="origen" id="origen">
            <option value="">Todos los medios</option>
            <?php foreach (origenes() as $o): ?>
              <option value="<?= (int) $o['id'] ?>" <?= $filtros['origen_id'] === (int) $o['id'] ? 'selected' : '' ?>>
                <?= e($o['nombre']) ?> · <?= e($o['pais']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="filtro <?= $filtros['subcategoria_id'] !== null ? 'filtro-activo' : '' ?>">
          <label for="sub">Subcategoría</label>
          <select name="sub" id="sub" <?= $subcats ? '' : 'disabled' ?>>
            <option value=""><?= $subcats ? 'Todas las subcategorías' : 'Elige una categoría' ?></option>
            <?php foreach ($subcats as $s): ?>
              <option value="<?= (int) $s['id'] ?>" <?= $filtros['subcategoria_id'] === (int) $s['id'] ? 'selected' : '' ?>>
                <?= e($s['nombre']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <button type="submit" class="boton-aplicar">Aplicar</button>
      </div>
    </form>
  </main>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
