<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/funciones.php';

iniciarSesionSegura();
noCachear();

if (estaLogueado()) {
    irA('index.php');
}

$errores = [];
$datos   = ['usuario' => '', 'correo' => ''];

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    exigirPostSeguro();

    $datos['usuario'] = limpiarTexto($_POST['usuario'] ?? '', 24);
    $datos['correo']  = limpiarTexto($_POST['correo'] ?? '', 120);
    $clave            = (string) ($_POST['password'] ?? '');
    $clave2           = (string) ($_POST['password2'] ?? '');

    // Trampa para bots: campo invisible que una persona nunca rellena.
    $trampa = trim((string) ($_POST['sitio_web'] ?? ''));

    // Un formulario enviado en menos de dos segundos no lo llenó una persona.
    $abierto  = (int) ($_SESSION['registro_abierto'] ?? 0);
    $demasiadoRapido = $abierto > 0 && (time() - $abierto) < 2;

    if ($trampa !== '' || $demasiadoRapido) {
        registrarLog('REGISTRO_BOT trampa=' . ($trampa !== '' ? 'si' : 'no') . ' rapido=' . ($demasiadoRapido ? 'si' : 'no'));
        $errores[] = 'No pudimos validar el formulario. Recarga la página e inténtalo otra vez.';
    } else {
        $alta = crearCuenta($datos['usuario'], $datos['correo'], $clave, $clave2);

        if ($alta['ok']) {
            $stmt = bd()->prepare('SELECT id, usuario, correo, rol, estado FROM usuarios WHERE id = ?');
            $stmt->execute([$alta['id']]);
            iniciarSesionDe($stmt->fetch());

            $destino = destinoSeguro($_SESSION['destino'] ?? null, 'index.php');
            unset($_SESSION['destino'], $_SESSION['registro_abierto']);
            $_SESSION['aviso_ok'] = 'Cuenta creada y sesión iniciada. Ya puedes leer las noticias completas.';
            irA($destino);
        }
        $errores = array_merge($errores, $alta['errores']);
    }
}

$_SESSION['registro_abierto'] = time();
$tituloPagina = 'Crear cuenta · ' . APP_NOMBRE;

require __DIR__ . '/includes/header.php';
?>

<main class="acceso" id="contenido">
  <h1>Crear cuenta</h1>
  <p class="intro">Solo pedimos usuario, correo y contraseña. No hay perfilado ni publicidad:
     la cuenta existe para abrir las noticias, nada más.</p>

  <?php if ($errores): ?>
    <div class="aviso" role="alert">
      <ul class="errores">
        <?php foreach ($errores as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="post" action="registro.php" autocomplete="on" novalidate>
    <?= campoCsrf() ?>

    <!-- Campo trampa: oculto para las personas, tentador para los robots -->
    <div class="trampa" aria-hidden="true">
      <label for="sitio_web">No rellenar</label>
      <input type="text" id="sitio_web" name="sitio_web" tabindex="-1" autocomplete="off">
    </div>

    <div class="campo">
      <label for="usuario">Usuario</label>
      <input type="text" id="usuario" name="usuario" required autofocus
             minlength="3" maxlength="24" pattern="[A-Za-z0-9._]{3,24}"
             autocomplete="username" value="<?= e($datos['usuario']) ?>">
      <span class="pista">Entre 3 y 24 caracteres: letras, números, punto o guion bajo.</span>
    </div>

    <div class="campo">
      <label for="correo">Correo</label>
      <input type="email" id="correo" name="correo" required maxlength="120"
             autocomplete="email" value="<?= e($datos['correo']) ?>">
    </div>

    <div class="campo">
      <label for="password">Contraseña</label>
      <input type="password" id="password" name="password" required
             minlength="<?= PASS_LARGO_MIN ?>" maxlength="200" autocomplete="new-password"
             data-medidor="fuerza">
      <span class="pista">Mínimo <?= PASS_LARGO_MIN ?> caracteres y tres tipos distintos
            (minúsculas, mayúsculas, números o símbolos). Una frase larga funciona mejor
            que una palabra con símbolos raros.</span>
      <div class="medidor" id="fuerza" hidden>
        <span class="medidor-texto">Seguridad de la contraseña</span>
        <div class="medidor-barra"><div class="medidor-relleno"></div></div>
      </div>
    </div>

    <div class="campo">
      <label for="password2">Repite la contraseña</label>
      <input type="password" id="password2" name="password2" required
             minlength="<?= PASS_LARGO_MIN ?>" maxlength="200" autocomplete="new-password">
    </div>

    <button type="submit" class="boton-ancho">Crear cuenta</button>
  </form>

  <p class="pie-acceso">¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a></p>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
