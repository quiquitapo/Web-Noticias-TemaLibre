<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

/**
 * validacion.php — toda entrada del usuario pasa por aquí antes de tocar la BD.
 * Criterio: lista blanca (defino lo que SÍ acepto), nunca lista negra.
 */

/** Normaliza texto libre: recorta, quita control chars y limita el largo. */
function limpiarTexto(?string $valor, int $maximo = 255): string
{
    $valor = (string) $valor;
    $valor = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $valor) ?? '';
    $valor = trim($valor);
    if (function_exists('mb_substr')) {
        return mb_substr($valor, 0, $maximo, 'UTF-8');
    }
    return substr($valor, 0, $maximo);
}

/** Entero dentro de un rango; devuelve null si no encaja. */
function enteroOpcional($valor, int $min = 1, int $max = PHP_INT_MAX): ?int
{
    if ($valor === null || $valor === '' || !is_scalar($valor)) {
        return null;
    }
    $n = filter_var((string) $valor, FILTER_VALIDATE_INT);
    if ($n === false || $n < $min || $n > $max) {
        return null;
    }
    return $n;
}

/** Solo letras, números, guion bajo y punto. 3–24 caracteres. */
function validarNombreUsuario(string $usuario): ?string
{
    if (!preg_match('/^[a-zA-Z0-9._]{3,24}$/', $usuario)) {
        return 'El usuario debe tener entre 3 y 24 caracteres: letras, números, punto o guion bajo.';
    }
    if (preg_match('/^[._]|[._]$|[._]{2}/', $usuario)) {
        return 'El usuario no puede empezar, terminar ni repetir punto o guion bajo.';
    }
    return null;
}

function validarCorreo(string $correo): ?string
{
    if (strlen($correo) > 120 || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        return 'Escribe un correo válido, por ejemplo nombre@dominio.cl';
    }
    return null;
}

/**
 * Política de contraseña: largo mínimo real + variedad + nada de claves
 * conocidas. El largo pesa más que los símbolos raros (NIST SP 800-63B).
 */
function validarPassword(string $clave, string $usuario = '', string $correo = ''): ?string
{
    $largo = function_exists('mb_strlen') ? mb_strlen($clave, 'UTF-8') : strlen($clave);

    if ($largo < PASS_LARGO_MIN) {
        return 'La contraseña necesita al menos ' . PASS_LARGO_MIN . ' caracteres.';
    }
    if ($largo > 200) {
        return 'La contraseña es demasiado larga (máximo 200 caracteres).';
    }
    $clases = 0;
    $clases += preg_match('/[a-záéíóúñ]/u', $clave) ? 1 : 0;
    $clases += preg_match('/[A-ZÁÉÍÓÚÑ]/u', $clave) ? 1 : 0;
    $clases += preg_match('/[0-9]/', $clave) ? 1 : 0;
    $clases += preg_match('/[^\p{L}\p{N}]/u', $clave) ? 1 : 0;
    if ($clases < 3) {
        return 'Combina al menos tres de: minúsculas, mayúsculas, números y símbolos.';
    }
    if ($usuario !== '' && stripos($clave, $usuario) !== false) {
        return 'La contraseña no puede contener tu nombre de usuario.';
    }
    if ($correo !== '') {
        $local = strstr($correo, '@', true);
        if (is_string($local) && strlen($local) > 2 && stripos($clave, $local) !== false) {
            return 'La contraseña no puede contener tu correo.';
        }
    }
    if (esPasswordComun($clave)) {
        return 'Esa contraseña aparece en las listas de claves filtradas. Elige otra.';
    }
    return null;
}

/** Lista corta de claves reventadas en segundos por cualquier diccionario. */
function esPasswordComun(string $clave): bool
{
    $normal = strtolower(preg_replace('/[^a-z0-9]/i', '', $clave) ?? '');
    $malas = [
        'password', 'contrasena', 'contraseña', '123456', '12345678', '123456789', '1234567890',
        'qwerty', 'qwertyuiop', 'admin', 'administrador', 'iloveyou', 'welcome', 'bienvenido',
        'passw0rd', 'password1', 'abc123', 'letmein', 'monkey', 'dragon', 'futbol', 'chile123',
        'buscadorsinfiltro', 'noticias123', 'usuario', 'temporal', 'cambiame',
    ];
    foreach ($malas as $mala) {
        if ($normal === $mala || str_contains($normal, $mala)) {
            return true;
        }
    }
    // "aaaaaaaaaaaa", "abcdabcdabcd" y similares
    if (preg_match('/^(.{1,3})\1+$/u', $clave)) {
        return true;
    }
    return false;
}

/** Escapa los comodines de LIKE para que "100%" no busque cualquier cosa. */
function escaparLike(string $texto): string
{
    return str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $texto);
}

/**
 * Parte la búsqueda en términos. Respeta "frases entre comillas" y descarta
 * palabras de una letra. Devuelve como máximo MAX_TERMINOS_BUSQUEDA términos.
 */
function separarTerminos(string $consulta): array
{
    $consulta = limpiarTexto($consulta, MAX_LARGO_BUSQUEDA);
    if ($consulta === '') {
        return [];
    }

    $terminos = [];
    if (preg_match_all('/"([^"]{2,60})"/u', $consulta, $frases)) {
        foreach ($frases[1] as $frase) {
            $terminos[] = trim($frase);
        }
        $consulta = preg_replace('/"[^"]*"/u', ' ', $consulta) ?? '';
    }

    foreach (preg_split('/[\s,;]+/u', $consulta) ?: [] as $palabra) {
        $palabra = trim($palabra, ".:!¡¿?()[]{}'-");
        if (mb_strlen($palabra, 'UTF-8') >= 2) {
            $terminos[] = $palabra;
        }
    }

    $terminos = array_values(array_unique(array_filter($terminos)));
    return array_slice($terminos, 0, MAX_TERMINOS_BUSQUEDA);
}
