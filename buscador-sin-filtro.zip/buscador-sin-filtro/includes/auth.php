<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/seguridad.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/limitador.php';
require_once __DIR__ . '/validacion.php';

/**
 * auth.php — cuentas de lectura.
 *
 * Reglas del producto: buscar es libre; abrir una noticia exige sesión.
 * Reglas de seguridad: hash moderno, mensajes que no revelan si la cuenta
 * existe, bloqueo temporal por fuerza bruta y auditoría de cada acceso.
 */

/** Algoritmo de hash: Argon2id si está disponible; si no, bcrypt coste 12. */
function algoritmoHash(): array
{
    if (defined('PASSWORD_ARGON2ID')) {
        return [PASSWORD_ARGON2ID, ['memory_cost' => 65536, 'time_cost' => 4, 'threads' => 2]];
    }
    return [PASSWORD_BCRYPT, ['cost' => 12]];
}

function hashPassword(string $clave): string
{
    [$algo, $opciones] = algoritmoHash();
    return password_hash($clave, $algo, $opciones);
}

function estaLogueado(): bool
{
    return !empty($_SESSION['usuario_id']);
}

/**
 * Datos del usuario en curso, leídos de la BD (no de la sesión) para que un
 * bloqueo administrativo surta efecto de inmediato.
 */
function usuarioActual(): ?array
{
    static $cache = null;
    static $resuelto = false;

    if ($resuelto) {
        return $cache;
    }
    $resuelto = true;

    if (!estaLogueado()) {
        return $cache = null;
    }

    $stmt = bd()->prepare('SELECT id, usuario, correo, rol, estado FROM usuarios WHERE id = ? LIMIT 1');
    $stmt->execute([(int) $_SESSION['usuario_id']]);
    $fila = $stmt->fetch();

    if (!$fila || $fila['estado'] !== 'activo') {
        cerrarSesion();
        return $cache = null;
    }

    return $cache = $fila;
}

/** Puerta de acceso: si no hay sesión, manda al login y vuelve luego. */
function requiereLogin(string $motivo = ''): array
{
    $usuario = usuarioActual();
    if ($usuario !== null) {
        return $usuario;
    }

    $_SESSION['destino'] = destinoSeguro(($_SERVER['REQUEST_URI'] ?? '') !== ''
        ? basename((string) $_SERVER['REQUEST_URI'])
        : 'index.php');
    if ($motivo !== '') {
        $_SESSION['aviso'] = $motivo;
    }
    irA('login.php');
}

/**
 * Verifica credenciales. Devuelve ['ok'=>bool,'error'=>string,'usuario'=>?array].
 * El mensaje de error es SIEMPRE el mismo: no decimos si el usuario existe.
 */
function autenticar(string $identificador, string $clave): array
{
    $generico = 'Usuario o contraseña incorrectos.';
    $claves   = ['usuario' => $identificador, 'ip' => ipCliente()];

    $espera = segundosBloqueado('login', $claves, LOGIN_MAX_INTENTOS, LOGIN_VENTANA, LOGIN_BLOQUEO);
    if ($espera > 0) {
        return ['ok' => false, 'usuario' => null,
                'error' => 'Demasiados intentos fallidos. Espera ' . esperaLegible($espera) . ' antes de reintentar.'];
    }

    $stmt = bd()->prepare(
        'SELECT id, usuario, correo, clave_hash, rol, estado
           FROM usuarios
          WHERE usuario = ? OR correo = ?
          LIMIT 1'
    );
    $stmt->execute([$identificador, $identificador]);
    $fila = $stmt->fetch();

    // Hash señuelo: si el usuario no existe gastamos el mismo tiempo de CPU,
    // así nadie deduce cuentas válidas midiendo la respuesta (timing attack).
    $hash = $fila['clave_hash'] ?? '$2y$12$c2VndXJpZGFkZGVjb3lzZeR6q4rZ0k1eYb0tGkQb0pXKQ2m8W1nAu';
    $correcta = password_verify($clave, $hash);

    if (!$fila || !$correcta || $fila['estado'] !== 'activo') {
        registrarIntento('login', $claves, false);
        registrarLog('LOGIN_FALLIDO identificador=' . substr(hash('sha256', $identificador), 0, 12));
        return ['ok' => false, 'usuario' => null, 'error' => $generico];
    }

    // Si cambian los parámetros del algoritmo, se re-hashea al vuelo.
    [$algo, $opciones] = algoritmoHash();
    if (password_needs_rehash($fila['clave_hash'], $algo, $opciones)) {
        $up = bd()->prepare('UPDATE usuarios SET clave_hash = ? WHERE id = ?');
        $up->execute([hashPassword($clave), (int) $fila['id']]);
    }

    registrarIntento('login', $claves, true);
    limpiarIntentos('login', $claves);
    unset($fila['clave_hash']);

    return ['ok' => true, 'error' => '', 'usuario' => $fila];
}

/** Abre la sesión del usuario ya verificado. */
function iniciarSesionDe(array $usuario): void
{
    session_regenerate_id(true);            // ID nuevo: corta el session fixation
    $_SESSION['usuario_id'] = (int) $usuario['id'];
    $_SESSION['_creada']    = time();
    $_SESSION['_visto']     = time();
    $_SESSION['_rotada']    = time();
    $_SESSION['_huella']    = huellaNavegador();
    rotarTokenCsrf();

    $stmt = bd()->prepare('UPDATE usuarios SET ultimo_acceso = NOW() WHERE id = ?');
    $stmt->execute([(int) $usuario['id']]);

    auditar('login', 'Inicio de sesión correcto', (int) $usuario['id']);
}

function cerrarSesion(): void
{
    if (estaLogueado()) {
        auditar('logout', 'Cierre de sesión', (int) $_SESSION['usuario_id']);
    }
    destruirSesion();
}

/**
 * Crea una cuenta de lectura.
 * Devuelve ['ok'=>bool,'errores'=>array<string>,'id'=>?int].
 */
function crearCuenta(string $usuario, string $correo, string $clave, string $clave2): array
{
    $errores = [];

    if ($e = validarNombreUsuario($usuario)) { $errores[] = $e; }
    if ($e = validarCorreo($correo))         { $errores[] = $e; }
    if ($e = validarPassword($clave, $usuario, $correo)) { $errores[] = $e; }
    if (!hash_equals($clave, $clave2))       { $errores[] = 'Las dos contraseñas no coinciden.'; }

    if ($errores) {
        return ['ok' => false, 'errores' => $errores, 'id' => null];
    }

    if (accionesPorIp('registro', REGISTRO_VENTANA) >= REGISTRO_MAX_POR_IP) {
        return ['ok' => false, 'id' => null,
                'errores' => ['Se alcanzó el máximo de cuentas nuevas desde esta conexión. Inténtalo más tarde.']];
    }

    try {
        $stmt = bd()->prepare(
            'INSERT INTO usuarios (usuario, correo, clave_hash, rol, estado) VALUES (?, ?, ?, "lector", "activo")'
        );
        $stmt->execute([$usuario, mb_strtolower($correo, 'UTF-8'), hashPassword($clave)]);
        $id = (int) bd()->lastInsertId();
    } catch (PDOException $e) {
        registrarIntento('registro', ['ip' => ipCliente()], false);
        if (($e->errorInfo[1] ?? 0) === 1062) {   // UNIQUE duplicado
            // Mensaje deliberadamente ambiguo: no confirmamos qué dato ya existe.
            return ['ok' => false, 'id' => null,
                    'errores' => ['No se pudo crear la cuenta con esos datos. Prueba con otro usuario o correo.']];
        }
        registrarLog('ERROR_REGISTRO: ' . $e->getMessage());
        return ['ok' => false, 'id' => null, 'errores' => ['No se pudo crear la cuenta. Inténtalo de nuevo.']];
    }

    registrarIntento('registro', ['ip' => ipCliente()], true);
    auditar('registro', 'Cuenta creada', $id);

    return ['ok' => true, 'errores' => [], 'id' => $id];
}

/** Deja rastro de lo relevante: quién, qué, desde dónde y cuándo. */
function auditar(string $accion, string $detalle = '', ?int $usuarioId = null): void
{
    try {
        $stmt = bd()->prepare(
            'INSERT INTO auditoria (usuario_id, accion, detalle, ip, agente) VALUES (?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $usuarioId ?? ($_SESSION['usuario_id'] ?? null),
            mb_substr($accion, 0, 40, 'UTF-8'),
            mb_substr($detalle, 0, 255, 'UTF-8'),
            ipCliente(),
            mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 200, 'UTF-8'),
        ]);
    } catch (PDOException $e) {
        registrarLog('ERROR_AUDITORIA: ' . $e->getMessage());
    }
}
