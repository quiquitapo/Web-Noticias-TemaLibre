<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

/**
 * limitador.php — freno para fuerza bruta y abuso.
 *
 * Cuenta los intentos fallidos guardados en `intentos_acceso` dentro de una
 * ventana de tiempo. Se cuenta por DOS claves a la vez:
 *   - "usuario:pedro"  → protege una cuenta concreta.
 *   - "ip:1.2.3.4"     → frena el rociado de claves contra muchas cuentas.
 * Guardamos un hash de la clave, no el dato en claro (minimiza el daño si
 * alguien lee la tabla).
 */

function claveLimite(string $tipo, string $valor): string
{
    return hash('sha256', $tipo . ':' . mb_strtolower(trim($valor), 'UTF-8'));
}

/** Registra un intento (exitoso o no) para una acción. */
function registrarIntento(string $accion, array $claves, bool $exito): void
{
    $sql = 'INSERT INTO intentos_acceso (accion, clave_hash, ip, exito) VALUES (?, ?, ?, ?)';
    $stmt = bd()->prepare($sql);
    foreach ($claves as $tipo => $valor) {
        $stmt->execute([$accion, claveLimite($tipo, (string) $valor), ipCliente(), $exito ? 1 : 0]);
    }
}

/** Fallos acumulados para una clave dentro de la ventana. */
function fallosRecientes(string $accion, string $tipo, string $valor, int $ventana): int
{
    $stmt = bd()->prepare(
        'SELECT COUNT(*) FROM intentos_acceso
          WHERE accion = ? AND clave_hash = ? AND exito = 0
            AND creado_en > (NOW() - INTERVAL ? SECOND)'
    );
    $stmt->execute([$accion, claveLimite($tipo, $valor), $ventana]);
    return (int) $stmt->fetchColumn();
}

/** Cuántos segundos falta para poder reintentar. 0 = puedes intentar. */
function segundosBloqueado(string $accion, array $claves, int $maximo, int $ventana, int $bloqueo): int
{
    $restante = 0;

    foreach ($claves as $tipo => $valor) {
        if (fallosRecientes($accion, $tipo, (string) $valor, $ventana) < $maximo) {
            continue;
        }
        $stmt = bd()->prepare(
            'SELECT TIMESTAMPDIFF(SECOND, NOW(), creado_en + INTERVAL ? SECOND)
               FROM intentos_acceso
              WHERE accion = ? AND clave_hash = ? AND exito = 0
              ORDER BY creado_en DESC LIMIT 1'
        );
        $stmt->execute([$bloqueo, $accion, claveLimite($tipo, (string) $valor)]);
        $falta = (int) $stmt->fetchColumn();
        $restante = max($restante, $falta);
    }

    return max(0, $restante);
}

/** Cuenta acciones (con o sin éxito) por IP: sirve para limitar registros. */
function accionesPorIp(string $accion, int $ventana): int
{
    $stmt = bd()->prepare(
        'SELECT COUNT(*) FROM intentos_acceso
          WHERE accion = ? AND ip = ? AND creado_en > (NOW() - INTERVAL ? SECOND)'
    );
    $stmt->execute([$accion, ipCliente(), $ventana]);
    return (int) $stmt->fetchColumn();
}

/** Al entrar bien, se limpian los fallos previos de esa cuenta. */
function limpiarIntentos(string $accion, array $claves): void
{
    $stmt = bd()->prepare('DELETE FROM intentos_acceso WHERE accion = ? AND clave_hash = ? AND exito = 0');
    foreach ($claves as $tipo => $valor) {
        $stmt->execute([$accion, claveLimite($tipo, (string) $valor)]);
    }
}

/** Borra registros viejos: la tabla no crece para siempre. */
function purgarIntentos(): void
{
    if (random_int(1, 50) !== 1) {   // ~2 % de las peticiones
        return;
    }
    bd()->exec('DELETE FROM intentos_acceso WHERE creado_en < (NOW() - INTERVAL 7 DAY)');
}

/** Espera legible: "3 minutos", "45 segundos". */
function esperaLegible(int $segundos): string
{
    if ($segundos >= 60) {
        $min = (int) ceil($segundos / 60);
        return $min . ($min === 1 ? ' minuto' : ' minutos');
    }
    return max(1, $segundos) . ' segundos';
}
