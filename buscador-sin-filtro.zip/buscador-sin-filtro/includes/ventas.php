<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/validacion.php';

/**
 * ventas.php (includes) — consultas del catálogo de avisos.
 *
 * Mismas reglas que el buscador de noticias: cada dato del usuario entra como
 * parámetro preparado o pasa por una lista blanca. Nada se concatena.
 */

/** Tramos de precio permitidos, en pesos. Lista blanca cerrada. */
function tramosPrecio(): array
{
    return [
        '0-50'    => ['etiqueta' => 'Hasta $50.000',        'min' => 0,       'max' => 50000],
        '50-150'  => ['etiqueta' => '$50.000 a $150.000',   'min' => 50000,   'max' => 150000],
        '150-400' => ['etiqueta' => '$150.000 a $400.000',  'min' => 150000,  'max' => 400000],
        '400-1m'  => ['etiqueta' => '$400.000 a $1.000.000','min' => 400000,  'max' => 1000000],
        '1m+'     => ['etiqueta' => 'Más de $1.000.000',    'min' => 1000000, 'max' => null],
    ];
}

function ordenesVenta(): array
{
    return [
        'reciente'    => ['etiqueta' => 'Más recientes',   'sql' => 'v.publicada_en DESC, v.id DESC'],
        'precio_asc'  => ['etiqueta' => 'Precio: menor',   'sql' => 'v.precio ASC, v.publicada_en DESC'],
        'precio_desc' => ['etiqueta' => 'Precio: mayor',   'sql' => 'v.precio DESC, v.publicada_en DESC'],
        'vistos'      => ['etiqueta' => 'Más vistos',      'sql' => 'v.vistas DESC, v.publicada_en DESC'],
        'relevancia'  => ['etiqueta' => 'Más relevantes',  'sql' => 'relevancia DESC, v.publicada_en DESC'],
    ];
}

function categoriasVenta(): array
{
    static $cache = null;
    return $cache ??= bd()->query(
        'SELECT id, slug, nombre FROM categorias_venta WHERE activa = 1 ORDER BY orden, nombre'
    )->fetchAll();
}

function categoriaVentaPorSlug(?string $slug): ?array
{
    if ($slug === null || $slug === '') {
        return null;
    }
    foreach (categoriasVenta() as $c) {
        if ($c['slug'] === $slug) {
            return $c;
        }
    }
    return null;
}

/** Regiones que realmente tienen avisos publicados. */
function regionesVenta(): array
{
    static $cache = null;
    return $cache ??= array_column(bd()->query(
        'SELECT DISTINCT region FROM ventas WHERE estado = "publicada" ORDER BY region'
    )->fetchAll(), 'region');
}

function filtrosVentaDesdeGet(array $get): array
{
    $categoria = categoriaVentaPorSlug(isset($get['cat']) ? limpiarTexto((string) $get['cat'], 40) : null);
    $tiempo    = isset($get['tiempo']) && isset(rangosTiempo()[$get['tiempo']]) ? (string) $get['tiempo'] : '';
    $precio    = isset($get['precio']) && isset(tramosPrecio()[$get['precio']]) ? (string) $get['precio'] : '';
    $orden     = isset($get['orden'])  && isset(ordenesVenta()[$get['orden']])  ? (string) $get['orden']  : '';
    $q         = limpiarTexto((string) ($get['q'] ?? ''), MAX_LARGO_BUSQUEDA);
    $pagina    = enteroOpcional($get['p'] ?? null, 1, 500) ?? 1;

    $region = limpiarTexto((string) ($get['region'] ?? ''), 60);
    if ($region !== '' && !in_array($region, regionesVenta(), true)) {
        $region = '';                          // solo valores del propio catálogo
    }

    if ($orden === '') {
        $orden = $q !== '' ? 'relevancia' : 'reciente';
    }

    return [
        'q'                => $q,
        'terminos'         => separarTerminos($q),
        'categoria_id'     => $categoria['id']     ?? null,
        'categoria_slug'   => $categoria['slug']   ?? '',
        'categoria_nombre' => $categoria['nombre'] ?? '',
        'tiempo'           => $tiempo,
        'precio'           => $precio,
        'region'           => $region,
        'orden'            => $orden,
        'pagina'           => $pagina,
    ];
}

/** Busca avisos. Nunca selecciona `contacto`: ese dato exige sesión. */
function buscarVentas(array $f): array
{
    $where  = ['v.estado = "publicada"'];
    $wParam = [];

    if ($f['categoria_id'] !== null) {
        $where[] = 'v.categoria_id = ?';
        $wParam[] = $f['categoria_id'];
    }
    if ($f['region'] !== '') {
        $where[] = 'v.region = ?';
        $wParam[] = $f['region'];
    }
    if ($f['tiempo'] !== '') {
        $where[] = 'v.publicada_en >= (NOW() - INTERVAL ? DAY)';
        $wParam[] = rangosTiempo()[$f['tiempo']]['dias'];
    }
    if ($f['precio'] !== '') {
        $tramo = tramosPrecio()[$f['precio']];
        $where[] = 'v.precio >= ?';
        $wParam[] = $tramo['min'];
        if ($tramo['max'] !== null) {
            $where[] = 'v.precio < ?';
            $wParam[] = $tramo['max'];
        }
    }

    $sParam = [];
    $relevancia = '0';

    if ($f['terminos']) {
        $piezas = [];
        foreach ($f['terminos'] as $t) {
            $like = '%' . escaparLike($t) . '%';
            $piezas[] = '(CASE WHEN v.titulo      LIKE ? ESCAPE \'\\\\\' THEN 5 ELSE 0 END)';
            $sParam[] = $like;
            $piezas[] = '(CASE WHEN v.resumen     LIKE ? ESCAPE \'\\\\\' THEN 3 ELSE 0 END)';
            $sParam[] = $like;
            $piezas[] = '(CASE WHEN v.descripcion LIKE ? ESCAPE \'\\\\\' THEN 1 ELSE 0 END)';
            $sParam[] = $like;

            $where[] = '(v.titulo LIKE ? ESCAPE \'\\\\\'
                      OR v.resumen LIKE ? ESCAPE \'\\\\\'
                      OR v.descripcion LIKE ? ESCAPE \'\\\\\'
                      OR v.comuna LIKE ? ESCAPE \'\\\\\')';
            array_push($wParam, $like, $like, $like, $like);
        }
        $relevancia = implode(' + ', $piezas);
    }

    $sqlWhere = implode(' AND ', $where);

    $stmt = bd()->prepare("SELECT COUNT(*) FROM ventas v WHERE $sqlWhere");
    $stmt->execute($wParam);
    $total = (int) $stmt->fetchColumn();

    $porPagina = RESULTADOS_POR_PAGINA;
    $paginas   = max(1, (int) ceil($total / $porPagina));
    $pagina    = min(max(1, (int) $f['pagina']), $paginas);
    $offset    = ($pagina - 1) * $porPagina;    // enteros validados

    $orden = ordenesVenta()[$f['orden']]['sql'];
    if ($f['orden'] === 'relevancia' && !$f['terminos']) {
        $orden = ordenesVenta()['reciente']['sql'];
    }

    $sql = "SELECT v.id, v.titulo, v.resumen, v.precio, v.moneda, v.condicion,
                   v.region, v.comuna, v.vendedor, v.stock, v.envio,
                   v.publicada_en, v.vistas,
                   c.nombre AS categoria, c.slug AS categoria_slug,
                   ($relevancia) AS relevancia
              FROM ventas v
              JOIN categorias_venta c ON c.id = v.categoria_id
             WHERE $sqlWhere
          ORDER BY $orden
             LIMIT $porPagina OFFSET $offset";

    $stmt = bd()->prepare($sql);
    $stmt->execute(array_merge($sParam, $wParam));

    return ['items' => $stmt->fetchAll(), 'total' => $total, 'paginas' => $paginas, 'pagina' => $pagina];
}

/** Ficha del aviso. $conContacto solo debe ser true con sesión iniciada. */
function ventaPorId(int $id, bool $conContacto = false): ?array
{
    $campos = 'v.id, v.categoria_id, v.titulo, v.resumen, v.descripcion, v.precio, v.moneda, v.condicion,
               v.region, v.comuna, v.vendedor, v.stock, v.envio, v.publicada_en, v.vistas,
               c.nombre AS categoria, c.slug AS categoria_slug';
    if ($conContacto) {
        $campos .= ', v.contacto';
    }

    $stmt = bd()->prepare(
        "SELECT $campos
           FROM ventas v
           JOIN categorias_venta c ON c.id = v.categoria_id
          WHERE v.id = ? AND v.estado = 'publicada'
          LIMIT 1"
    );
    $stmt->execute([$id]);
    return $stmt->fetch() ?: null;
}

function similaresVenta(int $id, int $categoriaId, int $limite = 3): array
{
    $limite = max(1, min(6, $limite));
    $stmt = bd()->prepare(
        "SELECT v.id, v.titulo, v.precio, v.comuna, v.condicion
           FROM ventas v
          WHERE v.categoria_id = ? AND v.id <> ? AND v.estado = 'publicada'
       ORDER BY v.publicada_en DESC
          LIMIT $limite"
    );
    $stmt->execute([$categoriaId, $id]);
    return $stmt->fetchAll();
}

function contarVistaVenta(int $id): void
{
    $vistas = $_SESSION['_vistas_venta'] ?? [];
    if (isset($vistas[$id])) {
        return;
    }
    $vistas[$id] = time();
    $_SESSION['_vistas_venta'] = array_slice($vistas, -200, 200, true);

    $stmt = bd()->prepare('UPDATE ventas SET vistas = vistas + 1 WHERE id = ?');
    $stmt->execute([$id]);
}

function conteoPorCategoriaVenta(): array
{
    $filas = bd()->query(
        'SELECT categoria_id, COUNT(*) AS total FROM ventas WHERE estado = "publicada" GROUP BY categoria_id'
    )->fetchAll();
    return array_column($filas, 'total', 'categoria_id');
}
