<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/funciones.php';

/**
 * asistente.php (includes) — asistente de respuestas rápidas.
 *
 * NO es inteligencia artificial y el proyecto no finge que lo sea: es un
 * clasificador de intención por palabras clave que consulta la base de datos y
 * devuelve un dato exacto. Si no entiende algo, lo dice y ofrece lo que sí sabe
 * responder, en vez de inventar.
 *
 * Seguridad: solo lee. Nunca escribe, nunca ejecuta lo que llega en el mensaje
 * y nunca devuelve el cuerpo de una noticia ni el contacto de un vendedor sin
 * sesión iniciada; eso se decide aquí, en el servidor.
 */

/** minúsculas y sin tildes, para comparar sin sorpresas */
function normalizar(string $texto): string
{
    $texto = mb_strtolower($texto, 'UTF-8');
    $texto = strtr($texto, [
        'á'=>'a','é'=>'e','í'=>'i','ó'=>'o','ú'=>'u','ü'=>'u','ñ'=>'n',
        'à'=>'a','è'=>'e','ì'=>'i','ò'=>'o','ù'=>'u',
    ]);
    return trim(preg_replace('/\s+/u', ' ', $texto) ?? '');
}

/** Diccionario de intenciones: la primera que coincide, gana. */
function intenciones(): array
{
    return [
        'ayuda'     => ['ayuda','que puedes','que sabes','como funciona','opciones','para que sirve','quien eres'],
        'cuenta'    => ['cuenta','registrarme','registro','iniciar sesion','por que necesito','crear usuario','login'],
        'contacto'  => ['contacto','telefono','correo del vendedor','whatsapp','como contacto','llamar','escribirle'],
        'vendedor'  => ['vendedor','quien vende','quien lo vende'],
        'precio'    => ['precio','cuanto cuesta','cuanto vale','cuanto sale','valor','cuesta','vale','cobran'],
        'envio'     => ['envio','envia','despacho','despacha','mandan','enviar'],
        'stock'     => ['stock','disponible','quedan','hay unidades','cuantos hay'],
        'condicion' => ['condicion','es nuevo','esta usado','usado','nuevo','en que estado','estado del'],
        'ubicacion' => ['ubicacion','donde','de donde','comuna','region','retiro','se retira','ciudad'],
        'autor'     => ['autor','quien escribio','quien la escribio','firma','periodista','quien redacto'],
        'medio'     => ['medio','fuente','origen','quien publico','diario','sesgo','linea editorial','confiable'],
        'fecha'     => ['fecha','cuando','publicada','publicacion','publico','es reciente','antigua'],
        'duracion'  => ['duracion','cuanto dura','minutos','es video'],
        'vistas'    => ['vistas','lecturas','leida','popular','visitas'],
        'categoria' => ['categoria','seccion','subcategoria','de que seccion'],
        'resumen'   => ['de que trata','resumen','sobre que','de que habla','que dice'],
    ];
}

function detectarIntencion(string $texto): ?string
{
    foreach (intenciones() as $clave => $frases) {
        foreach ($frases as $frase) {
            if (str_contains($texto, $frase)) {
                return $clave;
            }
        }
    }
    return null;
}

/** Palabras útiles del mensaje (descarta las vacías de significado). */
function palabrasClave(string $texto): array
{
    $vacias = ['que','cual','cuales','como','donde','cuando','cuanto','cuanta','para','por','del','las','los',
               'una','uno','este','esta','esa','ese','con','sin','sobre','tiene','esta','estan','hay','the',
               'noticia','aviso','producto','articulo','publicacion','dime','sabes','puedes','favor','quien',
               'precio','valor','vale','cuesta','ubicacion','autor','fecha','medio','envio','stock'];
    $palabras = [];
    foreach (preg_split('/[^a-z0-9ñ]+/u', $texto) ?: [] as $p) {
        if (mb_strlen($p, 'UTF-8') >= 4 && !in_array($p, $vacias, true)) {
            $palabras[] = $p;
        }
    }
    return array_slice(array_unique($palabras), 0, 6);
}

/** Busca el aviso o la noticia de la que habla el mensaje. */
function resolverItem(string $texto, string $preferido = 'venta'): ?array
{
    $palabras = palabrasClave($texto);
    if (!$palabras) {
        return null;
    }

    $mejor = null;

    foreach ([['venta', 'ventas v', 'v.titulo', 'v.resumen'],
              ['noticia', 'noticias n', 'n.titulo', 'n.bajada']] as [$tipo, $tabla, $col1, $col2]) {
        $piezas = [];
        $params = [];
        foreach ($palabras as $p) {
            $like = '%' . escaparLike($p) . '%';
            $piezas[] = "(CASE WHEN $col1 LIKE ? ESCAPE '\\\\' THEN 2 ELSE 0 END)";
            $params[] = $like;
            $piezas[] = "(CASE WHEN $col2 LIKE ? ESCAPE '\\\\' THEN 1 ELSE 0 END)";
            $params[] = $like;
        }
        $puntaje = implode(' + ', $piezas);
        $alias   = $tipo === 'venta' ? 'v' : 'n';

        $sql = "SELECT $alias.id, $alias.titulo, ($puntaje) AS puntaje
                  FROM $tabla
                 WHERE $alias.estado = 'publicada'
              ORDER BY puntaje DESC, $alias.publicada_en DESC
                 LIMIT 1";
        $stmt = bd()->prepare($sql);
        $stmt->execute($params);
        $fila = $stmt->fetch();

        if ($fila && (int) $fila['puntaje'] > 0) {
            $fila['tipo'] = $tipo;
            $bonus = $tipo === $preferido ? 1 : 0;   // desempata a favor del modo actual
            if ($mejor === null || ((int) $fila['puntaje'] + $bonus) > (int) $mejor['puntaje']) {
                $mejor = $fila;
            }
        }
    }

    return $mejor;
}

/** Respuesta del asistente: ['texto' => string, 'sugerencias' => array, 'enlace' => ?array] */
function responderAsistente(string $mensaje, string $modo, ?string $ctxTipo, ?int $ctxId, bool $logueado): array
{
    $texto     = normalizar(limpiarTexto($mensaje, 200));
    $intencion = detectarIntencion($texto);

    if ($texto === '') {
        return respuesta('Escríbeme una pregunta corta. Por ejemplo: "precio de la bicicleta" o "quién escribió la noticia de las farmacias".', $modo);
    }

    // Preguntas generales, sin objeto
    if ($intencion === 'ayuda' || $intencion === null && mb_strlen($texto, 'UTF-8') < 6) {
        return respuesta(
            'Respondo datos concretos del catálogo, sin que tengas que buscarlos. '
            . 'En ventas: precio, ubicación, condición, envío, stock y vendedor. '
            . 'En noticias: autor, medio, fecha, sección y de qué trata. '
            . 'Nómbrame el aviso o la noticia, por ejemplo: "precio del notebook".',
            $modo
        );
    }

    if ($intencion === 'cuenta') {
        return respuesta(
            $logueado
                ? 'Ya tienes la sesión iniciada: puedes leer las noticias completas y ver el contacto de los vendedores.'
                : 'Buscar y filtrar es libre y no pide datos. Necesitas cuenta solo para dos cosas: leer una noticia completa y ver el contacto de un vendedor. El registro pide usuario, correo y contraseña, nada más.',
            $modo
        );
    }

    // ¿De qué item habla?
    $item = null;
    if ($ctxTipo !== null && $ctxId !== null && in_array($ctxTipo, ['venta', 'noticia'], true)) {
        $item = ['tipo' => $ctxTipo, 'id' => $ctxId];
    }
    $delTexto = resolverItem($texto, $modo === 'ventas' ? 'venta' : 'noticia');
    if ($delTexto !== null) {
        $item = ['tipo' => $delTexto['tipo'], 'id' => (int) $delTexto['id']];
    }

    if ($item === null) {
        return respuesta(
            'No identifiqué de qué aviso o noticia me hablas. Nómbralo con una palabra de su título, '
            . 'por ejemplo "precio del kayak" o "autor de la noticia del puente".',
            $modo
        );
    }

    return $item['tipo'] === 'venta'
        ? responderVenta((int) $item['id'], $intencion, $logueado)
        : responderNoticia((int) $item['id'], $intencion, $logueado);
}

function responderVenta(int $id, ?string $intencion, bool $logueado): array
{
    require_once __DIR__ . '/ventas.php';
    $v = ventaPorId($id, $logueado);
    if ($v === null) {
        return respuesta('Ese aviso ya no está publicado.', 'ventas');
    }

    $titulo  = $v['titulo'];
    $enlace  = ['url' => 'venta.php?id=' . $id, 'texto' => 'Ver el aviso'];
    $sugeridas = ['Precio', 'Ubicación', 'Condición', '¿Hace envío?'];

    $texto = match ($intencion) {
        'precio'    => sprintf('%s cuesta %s. %s',
                        $titulo, precioFormateado((int) $v['precio'], (string) $v['moneda']),
                        $v['envio'] ? 'El vendedor despacha, el costo lo acuerdan entre ustedes.' : 'No ofrece envío: se retira en el lugar.'),
        'ubicacion' => sprintf('Está en %s, Región %s. %s',
                        $v['comuna'], $v['region'],
                        $v['envio'] ? 'También despacha a otras ciudades.' : 'Se retira en el lugar, sin envío.'),
        'envio'     => $v['envio']
                        ? sprintf('Sí, "%s" se puede enviar. El costo del despacho lo acuerdas con el vendedor.', $titulo)
                        : sprintf('No. "%s" se retira en %s, %s.', $titulo, $v['comuna'], $v['region']),
        'stock'     => sprintf('Quedan %d %s de "%s".', (int) $v['stock'],
                        (int) $v['stock'] === 1 ? 'unidad' : 'unidades', $titulo),
        'condicion' => sprintf('Está en condición: %s. Precio %s, en %s.',
                        $v['condicion'], precioFormateado((int) $v['precio'], (string) $v['moneda']), $v['comuna']),
        'vendedor'  => sprintf('Lo vende %s, desde %s.', $v['vendedor'], $v['comuna']),
        'fecha'     => sprintf('El aviso se publicó %s (%s).',
                        fechaRelativa((string) $v['publicada_en']), fechaLarga((string) $v['publicada_en'])),
        'vistas'    => sprintf('"%s" lleva %s visitas.', $titulo, number_format((int) $v['vistas'], 0, ',', '.')),
        'categoria' => sprintf('Está en la categoría %s del modo ventas.', $v['categoria']),
        'resumen'   => sprintf('%s %s', $titulo . ':', $v['resumen']),
        'contacto'  => $logueado
                        ? sprintf('Contacto de %s: %s', $v['vendedor'], $v['contacto'] ?? '')
                        : 'El contacto del vendedor se muestra solo con sesión iniciada, para que nadie recolecte correos y teléfonos con un robot. Crea una cuenta o inicia sesión y te lo muestro.',
        default     => sprintf('%s · %s · %s, %s · condición %s.',
                        $titulo, precioFormateado((int) $v['precio'], (string) $v['moneda']),
                        $v['comuna'], $v['region'], $v['condicion']),
    };

    return ['texto' => $texto, 'sugerencias' => $sugeridas, 'enlace' => $enlace];
}

function responderNoticia(int $id, ?string $intencion, bool $logueado): array
{
    $stmt = bd()->prepare(
        'SELECT n.id, n.titulo, n.autor, n.bajada, n.tipo, n.duracion_min, n.publicada_en, n.vistas,
                c.nombre AS categoria, s.nombre AS subcategoria,
                o.nombre AS origen, o.pais, o.sesgo
           FROM noticias n
           JOIN categorias c ON c.id = n.categoria_id
      LEFT JOIN subcategorias s ON s.id = n.subcategoria_id
           JOIN origenes o ON o.id = n.origen_id
          WHERE n.id = ? AND n.estado = "publicada" LIMIT 1'
    );
    $stmt->execute([$id]);
    $n = $stmt->fetch();

    if (!$n) {
        return respuesta('Esa noticia ya no está publicada.', 'noticias');
    }

    $enlace = ['url' => 'noticia.php?id=' . $id, 'texto' => 'Abrir la noticia'];
    $sugeridas = ['¿Quién la escribió?', '¿Qué medio la publicó?', '¿Cuándo se publicó?', '¿De qué trata?'];

    $texto = match ($intencion) {
        'autor'     => sprintf('La firma %s, en %s, publicada %s.',
                        $n['autor'], $n['origen'], fechaRelativa((string) $n['publicada_en'])),
        'medio'     => sprintf('La publicó %s (%s). %s. Sin filtro no significa sin fuente: el sesgo lo declara el propio medio y te lo mostramos para que compares.',
                        $n['origen'], $n['pais'], etiquetaSesgo((string) $n['sesgo'])),
        'fecha'     => sprintf('Se publicó %s, es decir %s.',
                        fechaLarga((string) $n['publicada_en']), fechaRelativa((string) $n['publicada_en'])),
        'categoria' => sprintf('Está en %s%s.', $n['categoria'],
                        $n['subcategoria'] ? ' / ' . $n['subcategoria'] : ''),
        'vistas'    => sprintf('"%s" lleva %s lecturas.', $n['titulo'], number_format((int) $n['vistas'], 0, ',', '.')),
        'duracion'  => $n['tipo'] === 'video'
                        ? sprintf('Es un video de %d minutos, de %s.', (int) $n['duracion_min'], $n['origen'])
                        : sprintf('No es video: "%s" es una nota de texto.', $n['titulo']),
        'ubicacion' => sprintf('Es una noticia, no un aviso. La publicó %s desde %s.', $n['origen'], $n['pais']),
        'precio'    => 'Esa es una noticia, no un producto. Cambia al modo Ventas arriba si buscas precios.',
        'resumen'   => sprintf('%s %s', $n['titulo'] . ':', $n['bajada'])
                        . ($logueado ? '' : ' El texto completo se abre con sesión iniciada.'),
        default     => sprintf('%s · %s · %s · %s.',
                        $n['titulo'], $n['autor'], $n['origen'], fechaRelativa((string) $n['publicada_en'])),
    };

    return ['texto' => $texto, 'sugerencias' => $sugeridas, 'enlace' => $enlace];
}

function respuesta(string $texto, string $modo): array
{
    $sug = $modo === 'ventas'
        ? ['Precio del notebook', 'Ubicación de la bicicleta', '¿El kayak tiene envío?']
        : ['¿Quién escribió la noticia del puente?', 'Fecha de la noticia de las farmacias', '¿Qué medio publicó el fallo de IA?'];
    return ['texto' => $texto, 'sugerencias' => $sug, 'enlace' => null];
}

/** Preguntas de ejemplo que se muestran como botones al abrir el asistente. */
function sugerenciasIniciales(string $modo, ?string $ctxTipo): array
{
    if ($ctxTipo === 'venta') {
        return ['¿Cuál es el precio?', '¿Dónde está?', '¿Hace envío?', '¿En qué condición está?'];
    }
    if ($ctxTipo === 'noticia') {
        return ['¿Quién la escribió?', '¿Cuándo se publicó?', '¿Qué medio la publicó?', '¿De qué trata?'];
    }
    return $modo === 'ventas'
        ? ['Precio del notebook', '¿Dónde está la bicicleta?', '¿El kayak tiene envío?', '¿Necesito cuenta?']
        : ['¿Quién escribió la noticia del puente?', '¿Cuándo se publicó lo de las farmacias?', '¿Qué medio publicó el fallo de IA?', '¿Necesito cuenta?'];
}
