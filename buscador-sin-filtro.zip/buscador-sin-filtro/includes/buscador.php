<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/validacion.php';

/**
 * buscador.php — consultas del catálogo de noticias.
 *
 * Principio: cada dato que viene del usuario entra como parámetro preparado
 * (`?`) o pasa por una lista blanca. En este archivo NO se concatena nunca
 * texto del visitante dentro del SQL; los únicos trozos dinámicos son los
 * fragmentos fijos que decide el servidor (orden, límite ya casteado a int).
 */

/** Rangos de tiempo permitidos → días. Lista blanca cerrada. */
function rangosTiempo(): array
{
    return [
        '24h' => ['etiqueta' => 'Últimas 24 horas', 'dias' => 1],
        '7d'  => ['etiqueta' => 'Última semana',    'dias' => 7],
        '30d' => ['etiqueta' => 'Último mes',       'dias' => 30],
        '6m'  => ['etiqueta' => 'Últimos 6 meses',  'dias' => 180],
        '1a'  => ['etiqueta' => 'Último año',       'dias' => 365],
    ];
}

/** Criterios de orden permitidos → fragmento SQL fijo. */
function ordenesDisponibles(): array
{
    return [
        'reciente'   => ['etiqueta' => 'Más recientes', 'sql' => 'n.publicada_en DESC, n.id DESC'],
        'antiguo'    => ['etiqueta' => 'Más antiguas',  'sql' => 'n.publicada_en ASC, n.id ASC'],
        'relevancia' => ['etiqueta' => 'Más relevantes','sql' => 'relevancia DESC, n.publicada_en DESC'],
        'leidas'     => ['etiqueta' => 'Más leídas',    'sql' => 'n.vistas DESC, n.publicada_en DESC'],
    ];
}

function categorias(): array
{
    static $cache = null;
    return $cache ??= bd()->query(
        'SELECT id, slug, nombre FROM categorias WHERE activa = 1 ORDER BY orden, nombre'
    )->fetchAll();
}

function categoriaPorSlug(?string $slug): ?array
{
    if ($slug === null || $slug === '') {
        return null;
    }
    foreach (categorias() as $cat) {           // ya está en memoria: sin consulta extra
        if ($cat['slug'] === $slug) {
            return $cat;
        }
    }
    return null;
}

function subcategoriasDe(?int $categoriaId): array
{
    if ($categoriaId === null) {
        return [];
    }
    $stmt = bd()->prepare('SELECT id, nombre FROM subcategorias WHERE categoria_id = ? ORDER BY nombre');
    $stmt->execute([$categoriaId]);
    return $stmt->fetchAll();
}

function origenes(): array
{
    static $cache = null;
    return $cache ??= bd()->query(
        'SELECT id, nombre, pais, sesgo FROM origenes WHERE activo = 1 ORDER BY nombre'
    )->fetchAll();
}

/** Normaliza lo que llega por GET a un arreglo de filtros de confianza. */
function filtrosDesdeGet(array $get): array
{
    $categoria = categoriaPorSlug(isset($get['cat']) ? limpiarTexto((string) $get['cat'], 40) : null);
    $tiempo    = isset($get['tiempo']) && isset(rangosTiempo()[$get['tiempo']]) ? (string) $get['tiempo'] : '';
    $orden     = isset($get['orden'])  && isset(ordenesDisponibles()[$get['orden']]) ? (string) $get['orden'] : '';
    $q         = limpiarTexto((string) ($get['q'] ?? ''), MAX_LARGO_BUSQUEDA);

    $origenId  = enteroOpcional($get['origen'] ?? null, 1, 999999);
    $subId     = enteroOpcional($get['sub'] ?? null, 1, 999999);
    $pagina    = enteroOpcional($get['p'] ?? null, 1, 500) ?? 1;

    // La subcategoría solo vale si pertenece a la categoría elegida.
    if ($subId !== null) {
        $valida = false;
        foreach (subcategoriasDe($categoria['id'] ?? null) as $sub) {
            if ((int) $sub['id'] === $subId) { $valida = true; break; }
        }
        if (!$valida) { $subId = null; }
    }
    // Y el origen debe existir y estar activo.
    if ($origenId !== null) {
        $existe = false;
        foreach (origenes() as $o) {
            if ((int) $o['id'] === $origenId) { $existe = true; break; }
        }
        if (!$existe) { $origenId = null; }
    }

    if ($orden === '') {
        $orden = $q !== '' ? 'relevancia' : 'reciente';
    }

    return [
        'q'               => $q,
        'terminos'        => separarTerminos($q),
        'categoria_id'    => $categoria['id']   ?? null,
        'categoria_slug'  => $categoria['slug'] ?? '',
        'categoria_nombre'=> $categoria['nombre'] ?? '',
        'subcategoria_id' => $subId,
        'origen_id'       => $origenId,
        'tiempo'          => $tiempo,
        'orden'           => $orden,
        'pagina'          => $pagina,
    ];
}

/**
 * Busca noticias. Devuelve ['items' => array, 'total' => int, 'paginas' => int].
 * OJO: nunca se selecciona `n.cuerpo`. El texto completo no sale del servidor
 * salvo en noticia.php, que exige sesión iniciada.
 */
function buscarNoticias(array $f): array
{
    $where  = ['n.estado = "publicada"', 'n.publicada_en <= NOW()'];
    $wParam = [];

    if ($f['categoria_id'] !== null) {
        $where[] = 'n.categoria_id = ?';
        $wParam[] = $f['categoria_id'];
    }
    if ($f['subcategoria_id'] !== null) {
        $where[] = 'n.subcategoria_id = ?';
        $wParam[] = $f['subcategoria_id'];
    }
    if ($f['origen_id'] !== null) {
        $where[] = 'n.origen_id = ?';
        $wParam[] = $f['origen_id'];
    }
    if ($f['tiempo'] !== '') {
        $where[] = 'n.publicada_en >= (NOW() - INTERVAL ? DAY)';
        $wParam[] = rangosTiempo()[$f['tiempo']]['dias'];
    }

    // ── Texto libre / palabras clave ────────────────────────────────────────
    $sParam = [];                       // parámetros del cálculo de relevancia
    $relevancia = '0';

    if ($f['terminos']) {
        $piezas = [];
        foreach ($f['terminos'] as $t) {
            $like = '%' . escaparLike($t) . '%';

            // Peso: título 5, bajada 3, etiquetas 3, cuerpo 1.
            $piezas[] = '(CASE WHEN n.titulo  LIKE ? ESCAPE \'\\\\\' THEN 5 ELSE 0 END)';
            $sParam[] = $like;
            $piezas[] = '(CASE WHEN n.bajada  LIKE ? ESCAPE \'\\\\\' THEN 3 ELSE 0 END)';
            $sParam[] = $like;
            $piezas[] = '(CASE WHEN n.cuerpo  LIKE ? ESCAPE \'\\\\\' THEN 1 ELSE 0 END)';
            $sParam[] = $like;
            $piezas[] = '(CASE WHEN EXISTS (SELECT 1 FROM noticia_etiqueta ne
                                              JOIN etiquetas et ON et.id = ne.etiqueta_id
                                             WHERE ne.noticia_id = n.id AND et.nombre LIKE ? ESCAPE \'\\\\\')
                              THEN 3 ELSE 0 END)';
            $sParam[] = $like;

            $where[] = '(n.titulo LIKE ? ESCAPE \'\\\\\'
                       OR n.bajada LIKE ? ESCAPE \'\\\\\'
                       OR n.cuerpo LIKE ? ESCAPE \'\\\\\'
                       OR EXISTS (SELECT 1 FROM noticia_etiqueta ne2
                                    JOIN etiquetas et2 ON et2.id = ne2.etiqueta_id
                                   WHERE ne2.noticia_id = n.id AND et2.nombre LIKE ? ESCAPE \'\\\\\'))';
            array_push($wParam, $like, $like, $like, $like);
        }
        $relevancia = implode(' + ', $piezas);
    }

    $sqlWhere = implode(' AND ', $where);

    // ── Total (para la paginación) ──────────────────────────────────────────
    $stmt = bd()->prepare("SELECT COUNT(*) FROM noticias n WHERE $sqlWhere");
    $stmt->execute($wParam);
    $total = (int) $stmt->fetchColumn();

    $porPagina = RESULTADOS_POR_PAGINA;
    $paginas   = max(1, (int) ceil($total / $porPagina));
    $pagina    = min(max(1, (int) $f['pagina']), $paginas);
    $offset    = ($pagina - 1) * $porPagina;   // enteros ya validados: seguros de interpolar

    $orden = ordenesDisponibles()[$f['orden']]['sql'];
    if ($f['orden'] === 'relevancia' && !$f['terminos']) {
        $orden = ordenesDisponibles()['reciente']['sql'];
    }

    $sql = "SELECT n.id, n.titulo, n.bajada, n.tipo, n.publicada_en, n.vistas,
                   n.duracion_min, n.url_original,
                   c.nombre AS categoria, c.slug AS categoria_slug,
                   s.nombre AS subcategoria,
                   o.id AS origen_id, o.nombre AS origen, o.pais, o.sesgo, o.dominio,
                   ($relevancia) AS relevancia
              FROM noticias n
              JOIN categorias   c ON c.id = n.categoria_id
         LEFT JOIN subcategorias s ON s.id = n.subcategoria_id
              JOIN origenes     o ON o.id = n.origen_id
             WHERE $sqlWhere
          ORDER BY $orden
             LIMIT $porPagina OFFSET $offset";

    $stmt = bd()->prepare($sql);
    $stmt->execute(array_merge($sParam, $wParam));

    return [
        'items'   => $stmt->fetchAll(),
        'total'   => $total,
        'paginas' => $paginas,
        'pagina'  => $pagina,
    ];
}

/** Ficha completa. Solo se llama desde una página protegida por login. */
function noticiaPorId(int $id): ?array
{
    $stmt = bd()->prepare(
        'SELECT n.*, c.nombre AS categoria, c.slug AS categoria_slug,
                s.nombre AS subcategoria, s.id AS subcategoria_id,
                o.nombre AS origen, o.pais, o.sesgo, o.dominio, o.descripcion AS origen_desc
           FROM noticias n
           JOIN categorias   c ON c.id = n.categoria_id
      LEFT JOIN subcategorias s ON s.id = n.subcategoria_id
           JOIN origenes     o ON o.id = n.origen_id
          WHERE n.id = ? AND n.estado = "publicada"
          LIMIT 1'
    );
    $stmt->execute([$id]);
    return $stmt->fetch() ?: null;
}

function etiquetasDe(int $noticiaId): array
{
    $stmt = bd()->prepare(
        'SELECT et.nombre FROM etiquetas et
           JOIN noticia_etiqueta ne ON ne.etiqueta_id = et.id
          WHERE ne.noticia_id = ? ORDER BY et.nombre'
    );
    $stmt->execute([$noticiaId]);
    return array_column($stmt->fetchAll(), 'nombre');
}

/** Misma historia contada por otros medios: el corazón del "sin sesgo". */
function otrasVersiones(int $noticiaId, ?int $historiaId, int $limite = 4): array
{
    if ($historiaId === null) {
        return [];
    }
    $limite = max(1, min(10, $limite));
    $stmt = bd()->prepare(
        "SELECT n.id, n.titulo, n.publicada_en, o.nombre AS origen, o.sesgo, o.pais
           FROM noticias n
           JOIN origenes o ON o.id = n.origen_id
          WHERE n.historia_id = ? AND n.id <> ? AND n.estado = 'publicada'
       ORDER BY n.publicada_en DESC
          LIMIT $limite"
    );
    $stmt->execute([$historiaId, $noticiaId]);
    return $stmt->fetchAll();
}

/** Suma una lectura como mucho una vez por sesión y noticia. */
function contarLectura(int $noticiaId): void
{
    $vistas = $_SESSION['_vistas'] ?? [];
    if (isset($vistas[$noticiaId])) {
        return;
    }
    $vistas[$noticiaId] = time();
    $_SESSION['_vistas'] = array_slice($vistas, -200, 200, true);

    $stmt = bd()->prepare('UPDATE noticias SET vistas = vistas + 1 WHERE id = ?');
    $stmt->execute([$noticiaId]);
}

/** Cuántas noticias hay por categoría (para el contador del menú lateral). */
function conteoPorCategoria(): array
{
    $filas = bd()->query(
        'SELECT categoria_id, COUNT(*) AS total
           FROM noticias WHERE estado = "publicada" AND publicada_en <= NOW()
          GROUP BY categoria_id'
    )->fetchAll();
    return array_column($filas, 'total', 'categoria_id');
}
