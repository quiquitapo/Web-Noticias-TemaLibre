<?php
declare(strict_types=1);

require_once __DIR__ . '/compat.php';

/**
 * config.php — parámetros de la aplicación.
 * Único archivo que normalmente necesitas editar.
 *
 * Regla de seguridad: este archivo no imprime nada y vive dentro de
 * /includes, que está bloqueado por .htaccess para accesos directos.
 */

// ── Identidad ────────────────────────────────────────────────────────────────
const APP_NOMBRE  = 'Buscador Sin Filtro';
const APP_LEMA    = 'Descubre la realidad, no lo que quieren que sepas';

/**
 * 'local'      → XAMPP en tu máquina (errores visibles en el log, no en pantalla).
 * 'produccion' → servidor real (fuerza HTTPS y cookies Secure).
 */
const APP_ENTORNO = 'local';

// ── Base de datos (valores por defecto de XAMPP) ─────────────────────────────
const DB_HOST = '127.0.0.1';
const DB_PORT = 3306;
const DB_NAME = 'buscador_sin_filtro';
const DB_USER = 'root';
const DB_PASS = '';

// ── Sesión ───────────────────────────────────────────────────────────────────
const SESION_NOMBRE       = 'bsf_sid';   // nombre neutro: no revela la tecnología
const SESION_INACTIVIDAD  = 1800;        // 30 min sin actividad → se cierra
const SESION_DURACION_MAX = 28800;       // 8 h de vida máxima, aunque estés activo
const SESION_ROTAR_CADA   = 300;         // regenera el ID cada 5 min

// ── Contraseñas y control de acceso ──────────────────────────────────────────
const PASS_LARGO_MIN      = 12;
const LOGIN_MAX_INTENTOS  = 5;    // fallos permitidos…
const LOGIN_VENTANA       = 900;  // …dentro de esta ventana (segundos)
const LOGIN_BLOQUEO       = 900;  // duración del bloqueo (segundos)
const REGISTRO_MAX_POR_IP = 3;    // cuentas nuevas por IP…
const REGISTRO_VENTANA    = 3600; // …por hora

// ── Buscador ─────────────────────────────────────────────────────────────────
const RESULTADOS_POR_PAGINA = 8;
const MAX_TERMINOS_BUSQUEDA = 8;    // corta consultas absurdamente largas
const MAX_LARGO_BUSQUEDA    = 120;  // caracteres
const LARGO_EXTRACTO        = 340;  // lo máximo que ve un visitante sin sesión

// ── Rutas ────────────────────────────────────────────────────────────────────
define('RUTA_BASE', dirname(__DIR__));
define('RUTA_LOGS', RUTA_BASE . '/logs');

// ── Errores: nunca en pantalla, siempre al log ───────────────────────────────
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('log_errors', '1');
if (is_dir(RUTA_LOGS) && is_writable(RUTA_LOGS)) {
    ini_set('error_log', RUTA_LOGS . '/php-error.log');
}

/** Registra un evento propio en el log de la aplicación. */
function registrarLog(string $mensaje): void
{
    if (!is_dir(RUTA_LOGS) || !is_writable(RUTA_LOGS)) {
        return;
    }
    $linea = sprintf("[%s] %s | ip=%s\n", date('Y-m-d H:i:s'), $mensaje, ipCliente());
    @file_put_contents(RUTA_LOGS . '/app.log', $linea, FILE_APPEND | LOCK_EX);
}

/** IP del visitante. No confía en cabeceras de proxy por defecto. */
function ipCliente(): string
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
}
