<?php
declare(strict_types=1);

/**
 * header.php — cabecera común: marca, cambio de modo y estado de sesión.
 * Se incluye DESPUÉS de auth.php y antes de cualquier salida.
 * Variables opcionales: $tituloPagina, $descripcionPagina, $modoActual.
 */

if (!function_exists('e')) {
    require_once __DIR__ . '/funciones.php';
}

enviarCabecerasSeguridad();
if (estaLogueado()) {
    noCachear();
}

$tituloPagina      = $tituloPagina      ?? APP_NOMBRE;
$descripcionPagina = $descripcionPagina ?? 'Buscador de noticias y avisos con la fuente siempre a la vista.';
$modoActual        = ($modoActual ?? 'noticias') === 'ventas' ? 'ventas' : 'noticias';
$usuarioSesion     = usuarioActual();

$avisoTexto = $_SESSION['aviso'] ?? '';
$avisoOk    = $_SESSION['aviso_ok'] ?? '';
unset($_SESSION['aviso'], $_SESSION['aviso_ok']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="<?= e($descripcionPagina) ?>">
<meta name="referrer" content="strict-origin-when-cross-origin">
<title><?= e($tituloPagina) ?></title>
<link rel="stylesheet" href="assets/css/estilos.css">
<script src="assets/js/app.js" defer nonce="<?= e(nonceCsp()) ?>"></script>
</head>
<body>
<a class="saltar" href="#contenido">Saltar al contenido</a>

<header class="cinta">
  <a class="marca" href="<?= $modoActual === 'ventas' ? 'ventas.php' : 'index.php' ?>">
    <h1 class="marca-titulo"><?= e(APP_NOMBRE) ?></h1>
    <p class="marca-lema"><?= e(APP_LEMA) ?></p>
  </a>

  <div class="cinta-derecha">
    <nav class="modos" aria-label="Modo del buscador">
      <a href="index.php" class="<?= $modoActual === 'noticias' ? 'modo-activo' : '' ?>"
         <?= $modoActual === 'noticias' ? 'aria-current="page"' : '' ?>>Noticias</a>
      <a href="ventas.php" class="<?= $modoActual === 'ventas' ? 'modo-activo' : '' ?>"
         <?= $modoActual === 'ventas' ? 'aria-current="page"' : '' ?>>Ventas</a>
    </nav>

    <div class="acciones-cuenta">
      <?php if ($usuarioSesion): ?>
        <span class="identidad">Sesión de <strong><?= e($usuarioSesion['usuario']) ?></strong></span>
        <form method="post" action="logout.php">
          <?= campoCsrf() ?>
          <button type="submit" class="enlace-secundario">Cerrar sesión</button>
        </form>
      <?php else: ?>
        <a class="boton-oscuro" href="login.php">Iniciar sesión</a>
        <a class="enlace-secundario" href="registro.php">Registrarse</a>
      <?php endif; ?>
    </div>
  </div>
</header>

<?php if ($avisoOk !== ''): ?>
  <p class="aviso aviso-ok" role="status"><?= e($avisoOk) ?></p>
<?php endif; ?>
<?php if ($avisoTexto !== ''): ?>
  <p class="aviso" role="status"><?= e($avisoTexto) ?></p>
<?php endif; ?>
