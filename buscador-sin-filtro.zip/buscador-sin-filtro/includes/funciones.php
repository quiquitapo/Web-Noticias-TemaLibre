<?php
declare(strict_types=1);

require_once __DIR__ . '/validacion.php';

/**
 * funciones.php — utilidades de presentación.
 * Todo lo que se imprime pasa por e() o por resaltar(): no hay excepciones.
 */

/** Escapa para HTML. Es la última barrera contra XSS. */
function e(?string $valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8');
}

/** Escapa para usar dentro de un atributo de URL. */
function eu(string $valor): string
{
    return e(rawurlencode($valor));
}

/**
 * Escapa el texto y luego marca las coincidencias de la búsqueda.
 * Importante: primero se escapa TODO y después se inserta <mark>; nunca al
 * revés. Se hace en una sola pasada para que un término no pueda encajar
 * dentro de una etiqueta ya insertada.
 */
function resaltar(string $texto, array $terminos): string
{
    $seguro = e($texto);
    $terminos = array_filter($terminos, static fn($t) => mb_strlen((string) $t, 'UTF-8') >= 2);

    if (!$terminos) {
        return $seguro;
    }

    $partes = array_map(static fn($t) => preg_quote(e((string) $t), '/'), $terminos);
    $patron = '/(?<![&#\w])(' . implode('|', $partes) . ')/iu';

    return preg_replace($patron, '<mark>$1</mark>', $seguro) ?? $seguro;
}

/** Recorta sin cortar palabras a la mitad. */
function extracto(string $texto, int $largo = LARGO_EXTRACTO): string
{
    $texto = trim(preg_replace('/\s+/u', ' ', $texto) ?? '');
    if (mb_strlen($texto, 'UTF-8') <= $largo) {
        return $texto;
    }
    $corte = mb_substr($texto, 0, $largo, 'UTF-8');
    $espacio = mb_strrpos($corte, ' ', 0, 'UTF-8');
    if ($espacio !== false && $espacio > $largo * 0.6) {
        $corte = mb_substr($corte, 0, $espacio, 'UTF-8');
    }
    return rtrim($corte, " ,.;:-") . '…';
}

/** "hace 20 minutos", "hace 3 días", o la fecha si es muy antigua. */
function fechaRelativa(string $fechaSql): string
{
    $ts = strtotime($fechaSql);
    if ($ts === false) {
        return '';
    }
    $delta = time() - $ts;

    if ($delta < 60)      { return 'hace un momento'; }
    if ($delta < 3600)    { $n = (int) floor($delta / 60);    return 'hace ' . $n . ($n === 1 ? ' minuto' : ' minutos'); }
    if ($delta < 86400)   { $n = (int) floor($delta / 3600);  return 'hace ' . $n . ($n === 1 ? ' hora' : ' horas'); }
    if ($delta < 604800)  { $n = (int) floor($delta / 86400); return 'hace ' . $n . ($n === 1 ? ' día' : ' días'); }
    if ($delta < 2592000) { $n = (int) floor($delta / 604800); return 'hace ' . $n . ($n === 1 ? ' semana' : ' semanas'); }

    return 'el ' . date('d/m/Y', $ts);
}

/** Fecha larga para la ficha de la noticia. */
function fechaLarga(string $fechaSql): string
{
    $ts = strtotime($fechaSql);
    if ($ts === false) {
        return '';
    }
    $meses = ['enero','febrero','marzo','abril','mayo','junio','julio',
              'agosto','septiembre','octubre','noviembre','diciembre'];
    return date('j', $ts) . ' de ' . $meses[(int) date('n', $ts) - 1] . ' de ' . date('Y, H:i', $ts);
}

/** Construye la URL del buscador conservando los filtros activos. */
function urlBuscador(array $filtros, array $cambios = []): string
{
    $params = array_merge([
        'cat'    => $filtros['categoria_slug'] ?? '',
        'q'      => $filtros['q'] ?? '',
        'tiempo' => $filtros['tiempo'] ?? '',
        'origen' => $filtros['origen_id'] ?? '',
        'sub'    => $filtros['subcategoria_id'] ?? '',
        'orden'  => $filtros['orden'] ?? '',
        'p'      => $filtros['pagina'] ?? 1,
    ], $cambios);

    $params = array_filter($params, static fn($v) => $v !== '' && $v !== null && $v !== 0);
    if (($params['p'] ?? 1) == 1) {
        unset($params['p']);
    }

    return 'index.php' . ($params ? '?' . http_build_query($params) : '');
}

/** Precio en pesos, con separador de miles. */
function precioFormateado(int $precio, string $moneda = 'CLP'): string
{
    return '$' . number_format($precio, 0, ',', '.') . ($moneda !== 'CLP' ? ' ' . $moneda : '');
}

/**
 * Construye una URL conservando los filtros activos, sirve para los dos modos.
 * Solo se copian claves conocidas: nada que venga del usuario llega crudo aquí.
 */
function urlModo(string $pagina, array $filtros, array $cambios = []): string
{
    $params = [
        'cat'    => $filtros['categoria_slug']   ?? '',
        'q'      => $filtros['q']                ?? '',
        'tiempo' => $filtros['tiempo']           ?? '',
        'origen' => $filtros['origen_id']        ?? '',
        'sub'    => $filtros['subcategoria_id']  ?? '',
        'precio' => $filtros['precio']           ?? '',
        'region' => $filtros['region']           ?? '',
        'orden'  => $filtros['orden']            ?? '',
        'p'      => $filtros['pagina']           ?? 1,
    ];
    $params = array_merge($params, $cambios);
    $params = array_filter($params, static fn($v) => $v !== '' && $v !== null && $v !== 0);
    if ((int) ($params['p'] ?? 1) === 1) {
        unset($params['p']);
    }
    return $pagina . ($params ? '?' . http_build_query($params) : '');
}

/**
 * Miniatura generada en el propio servidor: un SVG determinista a partir del
 * id de la noticia. Evita pedir imágenes a terceros, así que la CSP puede
 * quedarse en img-src 'self' y nadie rastrea al lector desde fuera.
 */
function miniaturaSvg(int $semilla, string $categoria, bool $conVideo): string
{
    $tonos = [
        ['#2b2b30', '#6f6f78', '#b9b9c0'],
        ['#1f2a30', '#4d6b74', '#a9c2c7'],
        ['#2e2521', '#7a5f4d', '#c4ab97'],
        ['#26212e', '#5f5273', '#b3a6c4'],
        ['#202a22', '#4f6b56', '#a8c1ad'],
    ];
    $p = $tonos[$semilla % count($tonos)];
    $a = 20 + ($semilla * 37) % 60;
    $b = 30 + ($semilla * 53) % 80;
    $c = 40 + ($semilla * 71) % 90;
    $id = 'g' . $semilla;

    $svg  = '<svg class="miniatura-svg" viewBox="0 0 320 190" role="img" aria-label="Imagen de la sección ' . e($categoria) . '" xmlns="http://www.w3.org/2000/svg">';
    $svg .= '<defs><linearGradient id="' . $id . '" x1="0" y1="0" x2="1" y2="1">'
          . '<stop offset="0" stop-color="' . $p[0] . '"/><stop offset="1" stop-color="' . $p[1] . '"/></linearGradient></defs>';
    $svg .= '<rect width="320" height="190" fill="url(#' . $id . ')"/>';
    $svg .= '<path d="M0 ' . (120 + $a % 40) . ' L' . (80 + $b) . ' ' . (60 + $a) . ' L' . (180 + $c) . ' ' . (150 - $a % 50) . ' L320 ' . (70 + $b % 60) . ' V190 H0 Z" fill="' . $p[2] . '" opacity="0.35"/>';
    $svg .= '<circle cx="' . (60 + $c) . '" cy="' . (40 + $a % 50) . '" r="' . (18 + $a % 22) . '" fill="' . $p[2] . '" opacity="0.28"/>';
    $svg .= '<rect x="0" y="0" width="320" height="190" fill="none" stroke="rgba(0,0,0,.25)" stroke-width="2"/>';

    if ($conVideo) {
        $svg .= '<circle cx="160" cy="95" r="34" fill="rgba(0,0,0,.72)"/>';
        $svg .= '<path d="M150 78 L150 112 L178 95 Z" fill="#fff"/>';
    }

    return $svg . '</svg>';
}

/** Texto neutro para la línea editorial declarada del medio. */
function etiquetaSesgo(string $sesgo): string
{
    return match ($sesgo) {
        'izquierda'        => 'Línea editorial: izquierda',
        'centro-izquierda' => 'Línea editorial: centro-izquierda',
        'centro'           => 'Línea editorial: centro',
        'centro-derecha'   => 'Línea editorial: centro-derecha',
        'derecha'          => 'Línea editorial: derecha',
        'estatal'          => 'Medio estatal',
        'independiente'    => 'Medio independiente',
        default            => 'Línea editorial no declarada',
    };
}
