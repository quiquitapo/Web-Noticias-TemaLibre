<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

/**
 * db.php — conexión única a MySQL/MariaDB mediante PDO.
 *
 * Decisiones de seguridad:
 *  - ATTR_EMULATE_PREPARES = false → las consultas preparadas las arma el motor,
 *    no PHP. Es lo que hace que una inyección SQL sea imposible aunque el
 *    parámetro venga con comillas.
 *  - ERRMODE_EXCEPTION → ningún error pasa desapercibido.
 *  - El detalle técnico del fallo va al log; el visitante solo ve un aviso
 *    genérico (no filtramos usuario de BD, rutas ni versiones).
 */
function bd(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', DB_HOST, DB_PORT, DB_NAME);

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_STRINGIFY_FETCHES  => false,
        ]);
    } catch (PDOException $e) {
        registrarLog('FALLO_BD: ' . $e->getMessage());
        http_response_code(503);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html lang="es"><meta charset="utf-8">'
           . '<title>Servicio no disponible</title>'
           . '<body><h1>No se pudo conectar a la base de datos</h1>'
           . '<p>Revisa que MySQL esté iniciado en XAMPP y que hayas importado '
           . '<code>sql/buscador.sql</code>.</p></body></html>';
        exit;
    }

    return $pdo;
}
