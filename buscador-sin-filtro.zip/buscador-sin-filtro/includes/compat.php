<?php
declare(strict_types=1);

/**
 * compat.php — red de seguridad por si el servidor no trae mbstring.
 *
 * XAMPP lo incluye activado, pero un hosting recortado puede no tenerlo y una
 * página en blanco por función inexistente es una caída evitable. Las
 * sustituciones respetan UTF-8 usando expresiones regulares con el modificador
 * /u, así que los acentos y la ñ siguen contando como un carácter.
 */

if (!function_exists('mb_strlen')) {
    function mb_strlen(string $texto, ?string $enc = null): int
    {
        return (int) preg_match_all('/./us', $texto);
    }
}

if (!function_exists('mb_substr')) {
    function mb_substr(string $texto, int $inicio, ?int $largo = null, ?string $enc = null): string
    {
        preg_match_all('/./us', $texto, $c);
        $trozo = array_slice($c[0], $inicio, $largo);
        return implode('', $trozo);
    }
}

if (!function_exists('mb_strtolower')) {
    function mb_strtolower(string $texto, ?string $enc = null): string
    {
        return strtr(strtolower($texto), [
            'Á' => 'á', 'É' => 'é', 'Í' => 'í', 'Ó' => 'ó', 'Ú' => 'ú',
            'Ñ' => 'ñ', 'Ü' => 'ü',
        ]);
    }
}

if (!function_exists('mb_strrpos')) {
    function mb_strrpos(string $texto, string $aguja, int $desde = 0, ?string $enc = null)
    {
        $pos = strrpos($texto, $aguja, $desde);
        if ($pos === false) {
            return false;
        }
        return mb_strlen(substr($texto, 0, $pos));
    }
}

if (!function_exists('mb_strtoupper')) {
    function mb_strtoupper(string $texto, ?string $enc = null): string
    {
        return strtr(strtoupper($texto), [
            'á' => 'Á', 'é' => 'É', 'í' => 'Í', 'ó' => 'Ó', 'ú' => 'Ú',
            'ñ' => 'Ñ', 'ü' => 'Ü',
        ]);
    }
}
