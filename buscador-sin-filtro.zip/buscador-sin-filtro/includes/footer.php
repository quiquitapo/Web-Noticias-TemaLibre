<?php
/**
 * footer.php — pie común + asistente flotante.
 * El asistente se arma con <details>: se abre y se cierra sin JavaScript,
 * y si hay JavaScript el formulario responde sin recargar la página.
 */
require_once __DIR__ . '/asistente.php';

$modoActual   = ($modoActual ?? 'noticias') === 'ventas' ? 'ventas' : 'noticias';
$ctxAsistente = $ctxAsistente ?? null;     // ['tipo' => 'venta'|'noticia', 'id' => int]
$sinAsistente = $sinAsistente ?? false;
?>

<?php if (!$sinAsistente): ?>
<details class="asistente" id="asistente">
  <summary class="asistente-boton">
    <span class="asistente-punto" aria-hidden="true"></span>
    Asistente
  </summary>

  <div class="asistente-panel">
    <div class="asistente-cabeza">
      <strong>Respuestas rápidas</strong>
      <span>Precio, ubicación, autor, fecha… sin buscar.</span>
    </div>

    <div class="asistente-log" id="asistente-log" aria-live="polite">
      <p class="asistente-mensaje asistente-bot">
        Pregúntame por un aviso o una noticia y te doy el dato al tiro.
        No soy una IA: reconozco preguntas frecuentes y consulto la base de datos.
      </p>
    </div>

    <ul class="chips" id="asistente-chips">
      <?php foreach (sugerenciasIniciales($modoActual, $ctxAsistente['tipo'] ?? null) as $s): ?>
        <li><button type="button" class="chip" data-pregunta="<?= e($s) ?>"><?= e($s) ?></button></li>
      <?php endforeach; ?>
    </ul>

    <form class="asistente-forma" id="asistente-forma" method="get" action="asistente.php"
          data-csrf="<?= e(tokenCsrf()) ?>">
      <input type="hidden" name="modo" value="<?= e($modoActual) ?>">
      <?php if ($ctxAsistente): ?>
        <input type="hidden" name="ctx" value="<?= e((string) $ctxAsistente['tipo']) ?>">
        <input type="hidden" name="ctx_id" value="<?= (int) $ctxAsistente['id'] ?>">
      <?php endif; ?>
      <label class="oculto-visual" for="asistente-pregunta">Escribe tu pregunta</label>
      <input type="text" id="asistente-pregunta" name="pregunta" maxlength="200"
             autocomplete="off" placeholder="precio del notebook">
      <button type="submit" class="boton-oscuro">Preguntar</button>
    </form>
  </div>
</details>
<?php endif; ?>

<footer class="pie">
  <span>Contenido de demostración: los medios, las noticias y los avisos son ficticios.</span>
  <span>Buscar es libre. Leer completo y contactar vendedores requiere cuenta.</span>
</footer>
</body>
</html>
