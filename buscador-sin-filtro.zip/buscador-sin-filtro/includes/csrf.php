<?php
declare(strict_types=1);

require_once __DIR__ . '/seguridad.php';

/**
 * csrf.php — evita que otra web envíe formularios en nombre del usuario.
 *
 * Defensa en dos capas:
 *   1. Cookie de sesión con SameSite=Strict (bloquea el envío cruzado).
 *   2. Token secreto en cada formulario, comparado con hash_equals()
 *      (comparación de tiempo constante) y verificando el Origin.
 */

function tokenCsrf(): string
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

/** Token nuevo. Se llama al iniciar y al cerrar sesión. */
function rotarTokenCsrf(): void
{
    $_SESSION['_csrf'] = bin2hex(random_bytes(32));
}

/** Campo oculto listo para pegar dentro de un <form>. */
function campoCsrf(): string
{
    return '<input type="hidden" name="_csrf" value="' . htmlspecialchars(tokenCsrf(), ENT_QUOTES, 'UTF-8') . '">';
}

/** ¿El token recibido es válido? */
function tokenValido(?string $recibido): bool
{
    $guardado = $_SESSION['_csrf'] ?? '';
    return is_string($recibido)
        && $guardado !== ''
        && strlen($recibido) === strlen($guardado)
        && hash_equals($guardado, $recibido);
}

/** ¿La petición nació en nuestro propio sitio? */
function origenValido(): bool
{
    $origen = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origen === '') {
        $ref = $_SERVER['HTTP_REFERER'] ?? '';
        if ($ref === '') {
            return true; // algunos navegadores/proxys no mandan ninguno de los dos
        }
        $origen = (string) parse_url($ref, PHP_URL_SCHEME) . '://' . (string) parse_url($ref, PHP_URL_HOST)
                . (parse_url($ref, PHP_URL_PORT) ? ':' . parse_url($ref, PHP_URL_PORT) : '');
    }
    $esperado = (esHttps() ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? '');
    return hash_equals($esperado, $origen);
}

/**
 * Exige POST + token + origen. Si algo falla, corta con 403.
 * Se llama al inicio de cada acción que modifica estado.
 */
function exigirPostSeguro(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        http_response_code(405);
        header('Allow: POST');
        exit('Método no permitido.');
    }
    if (!origenValido() || !tokenValido($_POST['_csrf'] ?? null)) {
        registrarLog('CSRF_RECHAZADO ruta=' . ($_SERVER['SCRIPT_NAME'] ?? '?'));
        http_response_code(403);
        exit('Petición rechazada: falta la verificación de seguridad. Recarga la página e inténtalo de nuevo.');
    }
}
