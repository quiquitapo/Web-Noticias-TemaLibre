<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

/**
 * seguridad.php — se incluye SIEMPRE antes de imprimir una sola letra de HTML.
 *
 * Hace tres cosas:
 *   1. Cabeceras HTTP defensivas (CSP, anti-clickjacking, anti-sniffing…).
 *   2. Sesión endurecida (cookie HttpOnly + SameSite, caducidad, huella).
 *   3. Utilidades de redirección sin "open redirect".
 */

/** ¿La petición llegó por HTTPS (directo o tras un proxy TLS)? */
function esHttps(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    return (int) ($_SERVER['SERVER_PORT'] ?? 80) === 443;
}

/**
 * Nonce aleatorio por respuesta. Va en cada <script>/<style> propio y en la
 * CSP; así, aunque alguien logre inyectar HTML, su <script> no se ejecuta
 * porque no conoce el nonce de ESTA carga de página.
 */
function nonceCsp(): string
{
    static $nonce = null;
    if ($nonce === null) {
        $nonce = base64_encode(random_bytes(18));
    }
    return $nonce;
}

/** Cabeceras de seguridad. Llamar antes de cualquier salida. */
function enviarCabecerasSeguridad(): void
{
    if (headers_sent()) {
        return;
    }

    $nonce = nonceCsp();

    $csp = [
        "default-src 'self'",
        "base-uri 'self'",
        "form-action 'self'",
        "frame-ancestors 'none'",          // nadie puede meternos en un <iframe>
        "object-src 'none'",               // sin Flash/applets
        "script-src 'self' 'nonce-$nonce'",// sin 'unsafe-inline': mata el XSS clásico
        "style-src 'self' 'nonce-$nonce'",
        "img-src 'self' data:",
        "media-src 'self'",
        "font-src 'self'",
        "connect-src 'self'",
        "manifest-src 'self'",
        "require-trusted-types-for 'script'",
    ];
    if (esHttps()) {
        $csp[] = 'upgrade-insecure-requests';
    }

    header('Content-Security-Policy: ' . implode('; ', $csp));
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()');
    header('Cross-Origin-Opener-Policy: same-origin');
    header('Cross-Origin-Resource-Policy: same-origin');
    header('X-Permitted-Cross-Domain-Policies: none');
    header_remove('X-Powered-By');           // no anunciamos versión de PHP
    header('Content-Type: text/html; charset=utf-8');

    if (esHttps()) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

/** Las páginas con datos de usuario no deben quedar en caché del navegador. */
function noCachear(): void
{
    if (headers_sent()) {
        return;
    }
    header('Cache-Control: no-store, no-cache, must-revalidate, private');
    header('Pragma: no-cache');
}

/** Sesión con cookie blindada + caducidad + huella de navegador. */
function iniciarSesionSegura(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    ini_set('session.use_strict_mode', '1');  // rechaza IDs de sesión inventados
    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_trans_sid', '0');
    ini_set('session.sid_length', '48');
    ini_set('session.sid_bits_per_character', '6');
    ini_set('session.cookie_httponly', '1');  // JavaScript no puede leer la cookie
    ini_set('session.gc_maxlifetime', (string) SESION_DURACION_MAX);

    session_name(SESION_NOMBRE);
    session_set_cookie_params([
        'lifetime' => 0,                       // cookie de sesión, muere al cerrar
        'path'     => rutaBase(),
        'domain'   => '',
        'secure'   => esHttps() || APP_ENTORNO === 'produccion',
        'httponly' => true,
        'samesite' => 'Strict',                // corta el CSRF por navegación
    ]);

    session_start();

    $ahora  = time();
    $huella = huellaNavegador();

    // Sesión nueva
    if (empty($_SESSION['_creada'])) {
        $_SESSION['_creada']  = $ahora;
        $_SESSION['_visto']   = $ahora;
        $_SESSION['_rotada']  = $ahora;
        $_SESSION['_huella']  = $huella;
        return;
    }

    // Robo de cookie desde otro navegador → fuera
    if (!hash_equals((string) ($_SESSION['_huella'] ?? ''), $huella)) {
        registrarLog('SESION_HUELLA_DISTINTA usuario_id=' . (string) ($_SESSION['usuario_id'] ?? '-'));
        destruirSesion();
        session_start();
        $_SESSION['_creada'] = $_SESSION['_visto'] = $_SESSION['_rotada'] = $ahora;
        $_SESSION['_huella'] = $huella;
        return;
    }

    // Caducidad por inactividad o por vida máxima
    $inactiva = ($ahora - (int) $_SESSION['_visto']) > SESION_INACTIVIDAD;
    $vencida  = ($ahora - (int) $_SESSION['_creada']) > SESION_DURACION_MAX;
    if ($inactiva || $vencida) {
        destruirSesion();
        session_start();
        $_SESSION['_creada'] = $_SESSION['_visto'] = $_SESSION['_rotada'] = $ahora;
        $_SESSION['_huella'] = $huella;
        $_SESSION['aviso']   = 'Tu sesión caducó por seguridad. Vuelve a entrar.';
        return;
    }

    $_SESSION['_visto'] = $ahora;

    // Rotación periódica del identificador (limita el "session fixation")
    if (($ahora - (int) $_SESSION['_rotada']) > SESION_ROTAR_CADA) {
        session_regenerate_id(true);
        $_SESSION['_rotada'] = $ahora;
    }
}

/** Huella estable del cliente: navegador + idioma. No usamos la IP (cambia en móvil). */
function huellaNavegador(): string
{
    return hash('sha256', ($_SERVER['HTTP_USER_AGENT'] ?? '') . '|' . ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? ''));
}

/** Borra la sesión por completo: datos, cookie y archivo. */
function destruirSesion(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires'  => time() - 42000,
            'path'     => $p['path'],
            'domain'   => $p['domain'],
            'secure'   => $p['secure'],
            'httponly' => $p['httponly'],
            'samesite' => $p['samesite'],
        ]);
    }
    session_destroy();
}

/** Carpeta donde vive la app, p. ej. "/buscador-sin-filtro/". */
function rutaBase(): string
{
    $dir = str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/')));
    return rtrim($dir, '/') . '/';
}

/**
 * Redirección segura: solo acepta rutas internas.
 * Bloquea "//evil.com", "https://evil.com" y "\\evil.com" (open redirect).
 */
function destinoSeguro(?string $destino, string $porDefecto = 'index.php'): string
{
    if ($destino === null || $destino === '') {
        return $porDefecto;
    }
    $destino = str_replace('\\', '/', trim($destino));

    if (str_starts_with($destino, '//') || preg_match('#^[a-z][a-z0-9+.\-]*:#i', $destino)) {
        return $porDefecto;                     // absoluta o con esquema → no
    }
    if (str_contains($destino, "\n") || str_contains($destino, "\r")) {
        return $porDefecto;                     // intento de "header injection"
    }
    if (str_starts_with($destino, '/')) {
        $destino = ltrim($destino, '/');
    }
    if (str_contains($destino, '..')) {
        return $porDefecto;
    }
    // Solo páginas de esta app
    if (!preg_match('#^[a-z_]+\.php(\?[A-Za-z0-9_\-=&%.,+]*)?$#', $destino)) {
        return $porDefecto;
    }
    return $destino;
}

/** Redirige y corta la ejecución. */
function irA(string $ruta): never
{
    header('Location: ' . $ruta, true, 303);
    exit;
}
