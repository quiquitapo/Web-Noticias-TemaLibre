<?php
declare(strict_types=1);

/**
 * asistente.php — punto de entrada del asistente de respuestas rápidas.
 *
 *  POST + token CSRF  → responde JSON (lo usa el panel flotante).
 *  GET                → página normal con el mismo asistente, para que funcione
 *                       igual sin JavaScript.
 *
 * Límite de uso: 40 preguntas cada 5 minutos por IP. Sin eso, el asistente
 * sería una forma cómoda de raspar el catálogo entero a máquina.
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/asistente.php';
require_once __DIR__ . '/includes/funciones.php';

iniciarSesionSegura();

$esJson    = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
$logueado  = estaLogueado();

$modo      = (($_REQUEST['modo'] ?? 'noticias') === 'ventas') ? 'ventas' : 'noticias';
$ctxTipo   = in_array($_REQUEST['ctx'] ?? '', ['venta', 'noticia'], true) ? (string) $_REQUEST['ctx'] : null;
$ctxId     = enteroOpcional($_REQUEST['ctx_id'] ?? null, 1, 99999999);
$pregunta  = limpiarTexto((string) ($_REQUEST['pregunta'] ?? ''), 200);

if ($esJson) {
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');

    if (!origenValido() || !tokenValido($_POST['_csrf'] ?? null)) {
        http_response_code(403);
        echo json_encode(['texto' => 'La sesión caducó. Recarga la página e inténtalo otra vez.',
                          'sugerencias' => [], 'enlace' => null], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (accionesPorIp('asistente', 300) >= 40) {
        http_response_code(429);
        echo json_encode(['texto' => 'Demasiadas preguntas seguidas. Espera un momento y sigue.',
                          'sugerencias' => [], 'enlace' => null], JSON_UNESCAPED_UNICODE);
        exit;
    }
    registrarIntento('asistente', ['ip' => ipCliente()], true);

    echo json_encode(
        responderAsistente($pregunta, $modo, $ctxTipo, $ctxId, $logueado),
        JSON_UNESCAPED_UNICODE
    );
    exit;
}

// ── Versión sin JavaScript ──────────────────────────────────────────────────
$resultado = $pregunta !== ''
    ? responderAsistente($pregunta, $modo, $ctxTipo, $ctxId, $logueado)
    : null;

$tituloPagina = 'Asistente · ' . APP_NOMBRE;
$modoActual   = $modo;
require __DIR__ . '/includes/header.php';
?>

<main class="acceso acceso-ancho" id="contenido">
  <h1>Asistente</h1>
  <p class="intro">Respondo datos puntuales del catálogo sin que tengas que buscarlos.
     No es inteligencia artificial: reconozco preguntas frecuentes y consulto la base de datos.</p>

  <?php if ($resultado !== null): ?>
    <div class="burbuja-respuesta">
      <p class="pregunta-eco"><?= e($pregunta) ?></p>
      <p><?= e($resultado['texto']) ?></p>
      <?php if ($resultado['enlace']): ?>
        <p><a class="enlace-fuerte" href="<?= e($resultado['enlace']['url']) ?>"><?= e($resultado['enlace']['texto']) ?> →</a></p>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <form method="get" action="asistente.php">
    <input type="hidden" name="modo" value="<?= e($modo) ?>">
    <?php if ($ctxTipo !== null && $ctxId !== null): ?>
      <input type="hidden" name="ctx" value="<?= e($ctxTipo) ?>">
      <input type="hidden" name="ctx_id" value="<?= (int) $ctxId ?>">
    <?php endif; ?>
    <div class="campo">
      <label for="pregunta">Tu pregunta</label>
      <input type="text" id="pregunta" name="pregunta" maxlength="200" autofocus
             placeholder="precio del notebook" value="<?= e($pregunta) ?>">
    </div>
    <button type="submit" class="boton-ancho">Preguntar</button>
  </form>

  <ul class="chips">
    <?php foreach (sugerenciasIniciales($modo, $ctxTipo) as $s): ?>
      <li><a href="asistente.php?modo=<?= e($modo) ?>&amp;pregunta=<?= eu($s) ?>"><?= e($s) ?></a></li>
    <?php endforeach; ?>
  </ul>

  <p class="pie-acceso"><a href="<?= $modo === 'ventas' ? 'ventas.php' : 'index.php' ?>">← Volver al buscador</a></p>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
