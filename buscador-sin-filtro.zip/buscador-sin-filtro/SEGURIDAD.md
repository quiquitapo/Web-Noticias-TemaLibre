# Seguridad — Buscador Sin Filtro

Cada control de este documento está implementado en el código, no es una lista
de intenciones. Debajo de la tabla están las pruebas que se corrieron contra la
aplicación en marcha.

## 1. Control de acceso al contenido

La regla del producto es que el texto completo exige sesión. La forma **incorrecta**
de hacerlo es mandar el artículo entero al navegador y taparlo con CSS o con un
`if` en JavaScript: cualquiera lo lee con Ctrl+U o con `curl`.

Aquí, cuando no hay sesión, `noticia.php` **ni siquiera consulta la columna
`cuerpo`**. Solo pide título, bajada y origen, que ya son públicos en el listado.
El listado de `index.php` tampoco selecciona nunca `n.cuerpo`. Lo que no sale del
servidor no se puede filtrar.

La respuesta al muro es un `401`, no un `200`, para que quede correcto también
para cachés y buscadores.

## 2. Inyección SQL

- **PDO con `ATTR_EMULATE_PREPARES = false`.** La consulta la arma el motor, no
  PHP concatenando texto. Es la diferencia entre una defensa real y una que se
  cae con un juego de caracteres raro.
- Todo dato del usuario entra como parámetro `?`. Lo único dinámico que se
  concatena son fragmentos que decide el servidor: el `ORDER BY` viene de una
  lista blanca cerrada y el `LIMIT/OFFSET` son enteros ya validados con rango.
- Los comodines de `LIKE` se escapan (`escaparLike`), para que buscar `100%` no
  se convierta en "cualquier cosa".
- La búsqueda se parte en un máximo de 8 términos de 120 caracteres: nadie
  fabrica una consulta de coste ilimitado.

## 3. XSS

- Todo lo que se imprime pasa por `e()` (`htmlspecialchars` con `ENT_QUOTES`).
- El resaltado de coincidencias **escapa primero y marca después**, en una sola
  pasada, para que un término no pueda encajar dentro de una etiqueta ya
  insertada.
- **Content-Security-Policy con nonce por respuesta** y sin `'unsafe-inline'`.
  Aunque alguien lograra inyectar HTML, su `<script>` no se ejecuta porque no
  conoce el nonce de esa carga. Se añade `require-trusted-types-for 'script'`;
  por eso `app.js` no usa `innerHTML` en ningún punto.
- No hay atributos `style=` en el HTML: todo el diseño vive en el CSS externo,
  que es lo que permite mantener la CSP estricta.

## 4. CSRF

Doble capa:

1. Cookie de sesión con **`SameSite=Strict`**, que corta el envío desde otro sitio.
2. **Token por sesión** en cada formulario, comparado con `hash_equals()`
   (tiempo constante) y verificando la cabecera `Origin`/`Referer`.

`exigirPostSeguro()` exige método POST + token + origen, y responde `403` si algo
falla. Se aplica a login, registro y cierre de sesión. **`logout.php` es POST**:
si se cerrara sesión con un GET, bastaría un `<img src=".../logout.php">` en
cualquier página para echar al usuario.

## 5. Sesiones

| Medida | Dónde |
|---|---|
| Cookie `HttpOnly` (JavaScript no la lee) | `seguridad.php` |
| `SameSite=Strict` + `Secure` en HTTPS o entorno producción | `seguridad.php` |
| `session.use_strict_mode = 1` (rechaza IDs inventados) | `seguridad.php` |
| ID regenerado al iniciar sesión (anti *session fixation*) | `auth.php` |
| Rotación del ID cada 5 minutos | `seguridad.php` |
| Cierre por inactividad (30 min) y vida máxima (8 h) | `seguridad.php` |
| Huella de navegador: si la cookie se usa desde otro agente, se destruye la sesión | `seguridad.php` |
| Nombre de cookie neutro (`bsf_sid`), no delata la tecnología | `config.php` |
| `Cache-Control: no-store` en páginas con sesión | `header.php` |

El estado del usuario se relee de la base en cada petición: si una cuenta se
bloquea, deja de funcionar en el acto y no al caducar la sesión.

## 6. Contraseñas y cuentas

- **Argon2id** si el servidor lo soporta, con caída a **bcrypt coste 12**.
  Nunca texto plano, nunca MD5/SHA1.
- `password_needs_rehash()`: si algún día se suben los parámetros, las claves se
  re-hashean solas en el siguiente login correcto.
- Política siguiendo NIST SP 800-63B: **mínimo 12 caracteres**, tres tipos de
  carácter, sin el usuario ni el correo dentro, y rechazo de claves conocidas y
  de patrones repetidos (`abcabcabcabc`).
- **Sin enumeración de usuarios**: el error de login es siempre el mismo y el de
  registro no confirma si el correo ya existía.
- **Sin fuga por tiempo**: si el usuario no existe se verifica igual contra un
  hash señuelo, para que la respuesta tarde lo mismo.

## 7. Fuerza bruta y abuso

`intentos_acceso` cuenta los fallos por dos claves a la vez:

- `usuario:x` → protege una cuenta concreta.
- `ip:y` → frena el rociado de una misma clave contra muchas cuentas.

A los **5 fallos en 15 minutos**, bloqueo de 15 minutos con mensaje que dice
cuánto falta. Al entrar bien, los fallos de esa cuenta se limpian. Se guarda un
**hash** de la clave de conteo, no el dato legible, y se purgan los registros de
más de 7 días.

El registro añade: máximo 3 cuentas por IP y hora, campo trampa invisible
(*honeypot*) y rechazo de formularios enviados en menos de 2 segundos.

## 8. Cabeceras HTTP

```
Content-Security-Policy: default-src 'self'; base-uri 'self'; form-action 'self';
  frame-ancestors 'none'; object-src 'none'; script-src 'self' 'nonce-…';
  style-src 'self' 'nonce-…'; img-src 'self' data:; require-trusted-types-for 'script'
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=()
Cross-Origin-Opener-Policy: same-origin
Cross-Origin-Resource-Policy: same-origin
Strict-Transport-Security: …           (solo cuando hay HTTPS)
```

Se envían desde PHP **y** desde `.htaccess`, para que sigan puestas si un archivo
se sirve sin pasar por PHP.

## 9. Fugas de información

- `display_errors` apagado siempre; los errores van a `logs/php-error.log`.
- El fallo de conexión a la base muestra un aviso genérico, sin usuario de BD,
  rutas ni versiones.
- `X-Powered-By` eliminado.
- `.htaccess` devuelve 404 en `/includes`, `/logs` y `/sql`, y niega `.sql`,
  `.log`, `.md`, `.bak` y los dotfiles. Además cada una de esas carpetas lleva su
  propio `.htaccess` con `Require all denied`.
- `robots.txt` mantiene fuera de los índices las rutas de cuenta.

## 10. Otros

- **Sin *open redirect***: `destinoSeguro()` solo acepta rutas internas con forma
  `pagina.php?params`; rechaza `//evil.com`, esquemas, `..` y saltos de línea
  (que serían inyección de cabeceras).
- **Sin recursos de terceros**: las miniaturas son SVG generados por el servidor.
  No hay CDN, tipografías remotas ni reproductores externos, así que la CSP puede
  quedarse en `'self'` y ningún tercero rastrea al lector.
- **Auditoría**: `auditoria` guarda inicio y cierre de sesión, altas y lecturas,
  con IP y agente. `logs/app.log` recoge CSRF rechazados, logins fallidos,
  sesiones con huella distinta y sospechas de bots.
- Solo se aceptan métodos `GET`, `POST` y `HEAD`.

---

## Pruebas ejecutadas contra la aplicación en marcha

| Prueba | Resultado |
|---|---|
| `?q=100% ' OR 1=1 -- ` | 0 resultados: entra como texto literal, no como SQL |
| `?q=<script>alert(1)</script>` | Se imprime escapado; 0 etiquetas `<script>` en la salida |
| `POST /login.php` sin token CSRF | `403` y registro en el log |
| `GET /noticia.php?id=1` sin sesión | `401` + muro; el cuerpo **no** aparece en el HTML |
| Login correcto → vuelve a la noticia pedida | `303` a `noticia.php?id=1` |
| 6 intentos con clave incorrecta | Bloqueo al sexto: "Espera 15 minutos" |
| Filtros con `sub=999`, `origen=abc`, `cat=noexiste`, `p=-5` | Se descartan y se vuelve al estado válido, sin error |
| Cabeceras de respuesta | CSP, `X-Frame-Options`, `nosniff`, cookie `HttpOnly; SameSite=Strict` presentes |

## Lo que este proyecto **no** cubre

Para ser honestos sobre el alcance:

- No hay verificación de correo ni recuperación de contraseña.
- No hay segundo factor (2FA).
- No hay WAF ni límite de peticiones global: eso corresponde al servidor o a un
  proxy delante.
- El panel de administración de noticias no existe; el contenido se carga por SQL.
- Sobre XAMPP con la configuración por defecto, MySQL corre como `root` sin
  contraseña. Eso es aceptable en local y **no** lo es en un servidor público
  (ver punto 6 del README).

---

## Anexo: modo Ventas y asistente

**Modo Ventas.** Misma arquitectura que el buscador de noticias: filtros por
lista blanca (tramo de precio, región validada contra el propio catálogo) y
consultas preparadas. La regla de acceso es paralela a la de las noticias: el
aviso, su precio y su ubicación son públicos, pero **`ventaPorId()` no
selecciona la columna `contacto` si no hay sesión**. El correo y el teléfono del
vendedor no se envían al navegador de un visitante anónimo, así que un robot no
puede cosechar la agenda completa del sitio.

**Asistente de respuestas rápidas.** No es inteligencia artificial y el proyecto
no lo insinúa: es un clasificador de intención por palabras clave que consulta
la base y devuelve un dato exacto. Cuando no entiende, lo dice y ofrece lo que
sí sabe responder, en vez de inventar.

Lo que se cuidó:

- **Solo lee.** No tiene ninguna ruta de escritura y nada de lo que llega en el
  mensaje se ejecuta ni se concatena en SQL: los términos entran como parámetros.
- **No es una puerta trasera.** Decide en el servidor qué puede contar: sin
  sesión no entrega el contacto de un vendedor ni el cuerpo de una noticia,
  exactamente igual que las páginas.
- **Límite de uso**: 40 preguntas cada 5 minutos por IP. Sin ese freno, el
  asistente sería la forma más cómoda de raspar el catálogo a máquina.
- **CSRF**: la vía rápida (JSON) exige token y origen válido.
- **Sin `innerHTML`**: las burbujas se arman con `createElement` y `textContent`,
  como exige `require-trusted-types-for 'script'`.
- **Funciona sin JavaScript**: `asistente.php` responde también como página
  normal, y el panel se abre con `<details>`, no con scripts.
