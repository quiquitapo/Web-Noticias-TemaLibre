# Buscador Sin Filtro

Un sitio con **dos modos**: buscar **noticias** y buscar **ventas** (avisos
clasificados). Se cambia de modo con el botón de arriba a la derecha.

Buscar es libre. Solo se pide cuenta para dos cosas: **leer una noticia completa**
y **ver el contacto de un vendedor**.

Hecho con PHP y MySQL, sin frameworks ni librerías externas. Funciona igual en
Windows, Linux y macOS sobre XAMPP.

---

## 1. Instalar (5 minutos)

**Paso 1.** Instala [XAMPP](https://www.apachefriends.org/) y ábrelo. Inicia
**Apache** y **MySQL**: los dos tienen que quedar en verde.

**Paso 2.** Copia la carpeta `buscador-sin-filtro` dentro de `htdocs`:

| Sistema | Carpeta |
|---------|---------|
| Windows | `C:\xampp\htdocs\` |
| Linux   | `/opt/lampp/htdocs/` |
| macOS   | `/Applications/XAMPP/htdocs/` |

**Paso 3.** Crea la base de datos. Abre `http://localhost/phpmyadmin`, entra a la
pestaña **Importar**, pulsa **Seleccionar archivo**, elige
`buscador-sin-filtro/sql/buscador.sql` y dale a **Continuar**.

Eso crea todo de una vez: las tablas, 30 noticias, 20 avisos de venta, 10 medios
y la cuenta de prueba.

**Paso 4.** Abre en el navegador:

```
http://localhost/buscador-sin-filtro/
```

Listo.

### Para entrar

```
usuario:    demo
contraseña: LectorLibre2026*
```

También puedes crear tu propia cuenta desde **Registrarse**.

### Si algo falla

| Síntoma | Causa y arreglo |
|---|---|
| "No se pudo conectar a la base de datos" | MySQL no está iniciado en XAMPP, o falta importar `buscador.sql` |
| Los acentos se ven rotos (`filtraciÃ³n`) | Se importó por consola sin UTF-8. Reimporta desde phpMyAdmin, o usa `mysql -u root --default-character-set=utf8mb4 < sql/buscador.sql` |
| Tu MySQL tiene contraseña | Edita `includes/config.php` y ponla en `DB_PASS` |

---

## 2. Cómo funciona

### Modo Noticias

- **Columna izquierda:** las categorías (IA, Series, Conflictos, Política,
  Tecnología, Videojuegos, Deporte, Educación, Nacional, Internacional). El
  número indica cuántas noticias tiene cada una.
- **Buscador (arriba):** busca en el título, la bajada, el texto y las palabras
  clave. Acepta varias palabras, o una frase exacta entre comillas:
  `"corredor humanitario"`. Lo que coincide se resalta en rojo.
- **Filtros (abajo):** *Tiempo* (24 h, semana, mes, 6 meses, año), *Origen* (el
  medio) y *Subcategoría*.
- **Cada resultado** muestra el medio, el país y la línea editorial que ese medio
  declara. La idea del sitio no es esconder el sesgo, sino mostrarlo.
- **Al abrir una noticia** se pide iniciar sesión, y al entrar el sitio te
  devuelve justo a la noticia que querías leer. Si varios medios cubrieron el
  mismo hecho, abajo aparecen las otras versiones para que compares.

### Modo Ventas

- Mismo diseño, otro catálogo: **categorías** a la izquierda, **buscador** arriba
  y **filtros** abajo, que aquí son *Tiempo*, *Precio* y *Ubicación*.
- Cada aviso muestra precio, condición (nuevo, usado o reacondicionado), comuna,
  región y si el vendedor hace envío.
- La ficha del aviso es pública: descripción completa, stock y precio. **Solo el
  correo y el teléfono del vendedor** piden sesión, para que nadie recolecte los
  contactos con un robot.

### Asistente (botón flotante, abajo a la derecha)

Responde datos puntuales al instante, sin que tengas que buscarlos:

> "precio del notebook" · "dónde está la bicicleta" · "¿el kayak tiene envío?"
> · "quién escribió la noticia del puente" · "cuándo se publicó lo de las farmacias"

**No es inteligencia artificial**, y el sitio no finge que lo sea: reconoce
preguntas frecuentes por sus palabras clave y consulta la base de datos. Si no
entiende, lo dice y propone preguntas que sí sabe responder. Responde sobre:

| En ventas | En noticias |
|---|---|
| Precio | Autor |
| Ubicación (comuna y región) | Medio y su línea editorial |
| Condición (nuevo / usado) | Fecha de publicación |
| Envío y stock | Sección y subcategoría |
| Vendedor y contacto\* | De qué trata · duración del video |

\* El contacto, solo con sesión iniciada.

Todo el sitio funciona **sin JavaScript**: el asistente tiene su propia página
(`asistente.php`) y los filtros traen un botón **Aplicar**.

---

## 3. Qué hay en cada archivo

```
buscador-sin-filtro/
├── index.php        → buscador de noticias
├── noticia.php      → noticia completa (pide sesión)
├── ventas.php       → buscador de ventas
├── venta.php        → ficha del aviso (el contacto pide sesión)
├── asistente.php    → asistente de respuestas rápidas
├── login.php · registro.php · logout.php
├── assets/          → estilos (CSS) y el poco JavaScript que hay
├── includes/        → el motor: conexión, seguridad y consultas
├── sql/buscador.sql → la base de datos completa
└── logs/            → registros de la aplicación
```

---

## 4. Dos advertencias

**El contenido es ficticio a propósito.** Las noticias, los medios y los avisos
son inventados para la demostración. Un catálogo de prueba con noticias reales
mezcladas sería desinformación aunque nadie lo dijera en voz alta.

**Antes de subirlo a internet** hay cuatro cosas obligatorias: cambiar la
contraseña de `demo`, poner HTTPS, cambiar `APP_ENTORNO` a `'produccion'` en
`includes/config.php` y crear un usuario de MySQL propio en vez de usar `root`
sin contraseña. Está todo detallado en [`SEGURIDAD.md`](SEGURIDAD.md), que además
explica cada defensa del sitio y qué cosas **no** cubre.
