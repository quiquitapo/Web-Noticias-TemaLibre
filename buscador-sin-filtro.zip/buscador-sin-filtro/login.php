<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/funciones.php';

iniciarSesionSegura();
noCachear();

if (estaLogueado()) {
    irA('index.php');
}

$errores    = [];
$usuarioIn  = '';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    exigirPostSeguro();

    $usuarioIn = limpiarTexto($_POST['usuario'] ?? '', 120);
    $clave     = (string) ($_POST['password'] ?? '');

    if ($usuarioIn === '' || $clave === '') {
        $errores[] = 'Escribe tu usuario (o correo) y tu contraseña.';
    } else {
        $intento = autenticar($usuarioIn, $clave);

        if ($intento['ok']) {
            iniciarSesionDe($intento['usuario']);
            $destino = destinoSeguro($_SESSION['destino'] ?? null, 'index.php');
            unset($_SESSION['destino']);
            $_SESSION['aviso_ok'] = 'Sesión iniciada. Ya puedes leer las noticias completas.';
            irA($destino);
        }
        $errores[] = $intento['error'];
    }
}

$destinoPendiente = isset($_SESSION['destino']);
$tituloPagina     = 'Iniciar sesión · ' . APP_NOMBRE;

require __DIR__ . '/includes/header.php';
?>

<main class="acceso" id="contenido">
  <h1>Iniciar sesión</h1>
  <p class="intro">
    <?= $destinoPendiente
        ? 'Entra con tu cuenta y te llevamos directo a la noticia que querías abrir.'
        : 'Buscar es libre. Para leer el texto completo necesitas una cuenta.' ?>
  </p>

  <?php if ($errores): ?>
    <div class="aviso" role="alert">
      <ul class="errores">
        <?php foreach ($errores as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="post" action="login.php" autocomplete="on" novalidate>
    <?= campoCsrf() ?>

    <div class="campo">
      <label for="usuario">Usuario o correo</label>
      <input type="text" id="usuario" name="usuario" required autofocus
             maxlength="120" autocomplete="username"
             value="<?= e($usuarioIn) ?>">
    </div>

    <div class="campo">
      <label for="password">Contraseña</label>
      <input type="password" id="password" name="password" required
             maxlength="200" autocomplete="current-password">
    </div>

    <button type="submit" class="boton-ancho">Entrar</button>
  </form>

  <p class="pie-acceso">
    ¿No tienes cuenta? <a href="registro.php">Regístrate</a><br>
    <span class="pista">Cuenta de prueba: <code>demo</code> · <code>LectorLibre2026*</code></span>
  </p>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
