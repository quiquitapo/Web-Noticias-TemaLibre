/* ===========================================================================
   app.js — mejoras opcionales. La página funciona completa sin JavaScript:
   los filtros llevan botón "Aplicar" y todo se resuelve en el servidor.

   Nota de seguridad: no se usa innerHTML en ningún punto (la política de
   seguridad de contenido exige Trusted Types). Solo textContent y clases.
   =========================================================================== */
(function () {
  'use strict';

  document.documentElement.classList.add('js');

  /* ── Filtros: aplicar al cambiar, sin pulsar botón ────────────────────── */
  var forma = document.getElementById('forma-buscador');
  if (forma) {
    var selects = forma.querySelectorAll('select');
    for (var i = 0; i < selects.length; i++) {
      selects[i].addEventListener('change', function () {
        forma.submit();
      });
    }
  }

  /* ── Medidor de contraseña ────────────────────────────────────────────── */
  var campo = document.querySelector('[data-medidor]');
  if (!campo) { return; }

  var caja = document.getElementById(campo.getAttribute('data-medidor'));
  if (!caja) { return; }

  var texto   = caja.querySelector('.medidor-texto');
  var relleno = caja.querySelector('.medidor-relleno');
  var niveles = ['Muy débil', 'Débil', 'Aceptable', 'Buena', 'Muy buena'];

  function evaluar(valor) {
    if (!valor) { return 0; }
    var clases = 0;
    if (/[a-záéíóúñ]/.test(valor)) { clases++; }
    if (/[A-ZÁÉÍÓÚÑ]/.test(valor)) { clases++; }
    if (/[0-9]/.test(valor))       { clases++; }
    if (/[^\wáéíóúñÁÉÍÓÚÑ]/.test(valor)) { clases++; }

    var puntos = 0;
    if (valor.length >= 12) { puntos++; }
    if (valor.length >= 16) { puntos++; }
    if (clases >= 3) { puntos++; }
    if (clases >= 4) { puntos++; }
    if (valor.length < 12 || clases < 3) { puntos = Math.min(puntos, 1); }
    return puntos;
  }

  campo.addEventListener('input', function () {
    var nivel = evaluar(campo.value);
    caja.hidden = campo.value.length === 0;
    texto.textContent = 'Seguridad de la contraseña: ' + niveles[nivel];
    relleno.className = 'medidor-relleno' + (nivel > 0 ? ' n' + nivel : '');
  });

  /* Aviso inmediato si la repetición no coincide (el servidor lo revisa igual) */
  var repite = document.getElementById('password2');
  if (repite) {
    repite.addEventListener('input', function () {
      repite.setCustomValidity(repite.value && repite.value !== campo.value
        ? 'Las dos contraseñas no coinciden.' : '');
    });
  }
})();

/* ===========================================================================
   Asistente de respuestas rápidas.
   Sin JavaScript el formulario funciona igual: envía por GET a asistente.php
   y la respuesta se ve en una página normal. Con JavaScript, responde aquí.

   Nada se construye con innerHTML: la política de seguridad exige Trusted
   Types, así que todo se arma con createElement y textContent.
   =========================================================================== */
(function () {
  'use strict';

  var forma = document.getElementById('asistente-forma');
  if (!forma) { return; }

  var caja   = document.getElementById('asistente-pregunta');
  var log    = document.getElementById('asistente-log');
  var chips  = document.getElementById('asistente-chips');
  var csrf   = forma.getAttribute('data-csrf');
  var ocupado = false;

  function burbuja(texto, mia) {
    var p = document.createElement('p');
    p.className = 'asistente-mensaje ' + (mia ? 'asistente-yo' : 'asistente-bot');
    p.textContent = texto;
    log.appendChild(p);
    log.scrollTop = log.scrollHeight;
    return p;
  }

  function pintarSugerencias(lista) {
    if (!chips || !lista || !lista.length) { return; }
    while (chips.firstChild) { chips.removeChild(chips.firstChild); }
    lista.slice(0, 4).forEach(function (texto) {
      var li = document.createElement('li');
      var b  = document.createElement('button');
      b.type = 'button';
      b.className = 'chip';
      b.textContent = texto;
      b.setAttribute('data-pregunta', texto);
      li.appendChild(b);
      chips.appendChild(li);
    });
  }

  function preguntar(texto) {
    if (ocupado || !texto) { return; }
    ocupado = true;

    burbuja(texto, true);
    var espera = burbuja('Buscando el dato…', false);
    caja.value = '';

    var datos = new URLSearchParams();
    datos.append('_csrf', csrf);
    datos.append('pregunta', texto);
    ['modo', 'ctx', 'ctx_id'].forEach(function (nombre) {
      var campo = forma.querySelector('[name="' + nombre + '"]');
      if (campo) { datos.append(nombre, campo.value); }
    });

    fetch('asistente.php', {
      method: 'POST',
      body: datos,
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'fetch' }
    })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        espera.textContent = d.texto || 'No pude responder eso.';
        if (d.enlace && d.enlace.url) {
          espera.appendChild(document.createTextNode(' '));
          var a = document.createElement('a');
          a.href = d.enlace.url;
          a.textContent = d.enlace.texto + ' →';
          espera.appendChild(a);
        }
        pintarSugerencias(d.sugerencias);
        log.scrollTop = log.scrollHeight;
      })
      .catch(function () {
        espera.textContent = 'No se pudo conectar. Revisa tu conexión e inténtalo otra vez.';
      })
      .then(function () { ocupado = false; });
  }

  forma.addEventListener('submit', function (ev) {
    ev.preventDefault();
    preguntar(caja.value.trim());
  });

  if (chips) {
    chips.addEventListener('click', function (ev) {
      var boton = ev.target.closest('.chip');
      if (boton) { preguntar(boton.getAttribute('data-pregunta')); }
    });
  }

  var panel = document.getElementById('asistente');
  if (panel) {
    panel.addEventListener('toggle', function () {
      if (panel.open) { caja.focus(); }
    });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape' && panel.open) { panel.open = false; }
    });
  }
})();
