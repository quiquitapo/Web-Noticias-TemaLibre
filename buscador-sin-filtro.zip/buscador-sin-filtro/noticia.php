<?php
declare(strict_types=1);

/**
 * noticia.php — texto completo. Puerta cerrada: sin sesión no se lee.
 *
 * Detalle importante: cuando no hay sesión, el cuerpo NI SIQUIERA se consulta.
 * No se manda al navegador y se esconde con CSS; simplemente no sale del
 * servidor. Ocultar con CSS o con JavaScript no es un control de acceso.
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/buscador.php';
require_once __DIR__ . '/includes/funciones.php';

iniciarSesionSegura();
$modoActual = 'noticias';

$id = enteroOpcional($_GET['id'] ?? null, 1, 99999999);
if ($id === null) {
    http_response_code(400);
    $tituloPagina = 'Noticia no encontrada · ' . APP_NOMBRE;
    require __DIR__ . '/includes/header.php';
    echo '<div class="articulo"><h1>Enlace no válido</h1>'
       . '<p class="bajada">El identificador de la noticia no tiene un formato correcto.</p>'
       . '<p><a href="index.php">Volver al buscador</a></p></div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

// ── Muro de acceso ───────────────────────────────────────────────────────────
if (!estaLogueado()) {
    // Solo se consultan los campos que ya son públicos en el listado.
    $stmt = bd()->prepare(
        'SELECT n.titulo, n.bajada, n.tipo, n.publicada_en,
                c.nombre AS categoria, o.nombre AS origen, o.sesgo
           FROM noticias n
           JOIN categorias c ON c.id = n.categoria_id
           JOIN origenes   o ON o.id = n.origen_id
          WHERE n.id = ? AND n.estado = "publicada" LIMIT 1'
    );
    $stmt->execute([$id]);
    $vista = $stmt->fetch();

    $_SESSION['destino'] = 'noticia.php?id=' . $id;
    $ctxAsistente = $vista ? ['tipo' => 'noticia', 'id' => $id] : null;

    http_response_code($vista ? 401 : 404);
    $tituloPagina = ($vista['titulo'] ?? 'Noticia') . ' · ' . APP_NOMBRE;
    require __DIR__ . '/includes/header.php';
    ?>
    <article class="articulo">
      <p class="migas"><a href="index.php">Buscador</a> / <?= e($vista['categoria'] ?? 'Noticia') ?></p>
      <h1><?= e($vista['titulo'] ?? 'Esta noticia no está disponible') ?></h1>
      <?php if ($vista): ?>
        <p class="bajada"><?= e($vista['bajada']) ?></p>
        <div class="ficha-origen">
          <span class="meta-origen"><?= e($vista['origen']) ?></span>
          <span class="sesgo"><?= e(etiquetaSesgo((string) $vista['sesgo'])) ?></span>
          <span><?= e(fechaLarga((string) $vista['publicada_en'])) ?></span>
        </div>

        <section class="muro">
          <h2>Para leer la noticia completa necesitas una cuenta</h2>
          <p>Buscar, filtrar y ver de dónde viene cada noticia es libre y no pide datos.
             El texto completo, el video y las otras versiones de la misma historia se abren al iniciar sesión.</p>
          <div class="acciones">
            <a class="boton-oscuro" href="login.php">Iniciar sesión</a>
            <a class="boton-oscuro" href="registro.php">Crear cuenta</a>
            <a class="enlace-secundario" href="index.php">Volver al buscador</a>
          </div>
        </section>
      <?php else: ?>
        <p class="bajada">Puede que el enlace esté mal copiado o que la noticia haya sido retirada.</p>
        <p><a href="index.php">Volver al buscador</a></p>
      <?php endif; ?>
    </article>
    <?php
    require __DIR__ . '/includes/footer.php';
    exit;
}

// ── Con sesión iniciada ──────────────────────────────────────────────────────
$usuario = usuarioActual();
$noticia = noticiaPorId($id);

if ($noticia === null) {
    http_response_code(404);
    $tituloPagina = 'Noticia no encontrada · ' . APP_NOMBRE;
    require __DIR__ . '/includes/header.php';
    echo '<div class="articulo"><h1>Noticia no encontrada</h1>'
       . '<p class="bajada">El enlace puede estar mal copiado o la noticia fue retirada.</p>'
       . '<p><a href="index.php">Volver al buscador</a></p></div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

contarLectura($id);
auditar('lectura', 'Noticia ' . $id, (int) $usuario['id']);

$etiquetas = etiquetasDe($id);
$versiones = otrasVersiones($id, $noticia['historia_id'] !== null ? (int) $noticia['historia_id'] : null);
$parrafos  = preg_split('/\R{2,}/u', (string) $noticia['cuerpo']) ?: [];

$ctxAsistente      = ['tipo' => 'noticia', 'id' => $id];
$tituloPagina      = $noticia['titulo'] . ' · ' . APP_NOMBRE;
$descripcionPagina = extracto((string) $noticia['bajada'], 150);

require __DIR__ . '/includes/header.php';
?>

<article class="articulo" id="contenido">
  <p class="migas">
    <a href="index.php">Buscador</a> /
    <a href="index.php?cat=<?= eu((string) $noticia['categoria_slug']) ?>"><?= e($noticia['categoria']) ?></a>
    <?php if ($noticia['subcategoria']): ?>
      / <a href="index.php?cat=<?= eu((string) $noticia['categoria_slug']) ?>&amp;sub=<?= (int) $noticia['subcategoria_id'] ?>"><?= e($noticia['subcategoria']) ?></a>
    <?php endif; ?>
  </p>

  <h1><?= e($noticia['titulo']) ?></h1>
  <p class="bajada"><?= e($noticia['bajada']) ?></p>

  <div class="ficha-origen">
    <span class="meta-origen"><?= e($noticia['origen']) ?></span>
    <span class="sesgo"><?= e(etiquetaSesgo((string) $noticia['sesgo'])) ?></span>
    <span><?= e($noticia['pais']) ?></span>
    <span class="separador">·</span>
    <span><?= e(fechaLarga((string) $noticia['publicada_en'])) ?></span>
    <span class="separador">·</span>
    <span><?= number_format((int) $noticia['vistas'], 0, ',', '.') ?> lecturas</span>
  </div>

  <?php if ($noticia['tipo'] === 'video'): ?>
    <figure class="reproductor">
      <?= miniaturaSvg((int) $noticia['id'], (string) $noticia['categoria'], true) ?>
      <figcaption class="reproductor-pie">
        Video de <?= e($noticia['origen']) ?><?= $noticia['duracion_min'] ? ' · ' . (int) $noticia['duracion_min'] . ' min' : '' ?>.
        En esta demostración no se incrusta reproductor externo: cargar video de terceros
        abriría la política de seguridad de contenido y permitiría rastrear al lector.
      </figcaption>
    </figure>
  <?php endif; ?>

  <div class="texto-articulo">
    <?php foreach ($parrafos as $p): ?>
      <?php $p = trim($p); if ($p === '') { continue; } ?>
      <p><?= e($p) ?></p>
    <?php endforeach; ?>
  </div>

  <?php if ($etiquetas): ?>
    <ul class="etiquetas">
      <?php foreach ($etiquetas as $etq): ?>
        <li><a href="index.php?q=<?= eu($etq) ?>"><?= e($etq) ?></a></li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>

  <?php if ($versiones): ?>
    <section class="otras-versiones">
      <h2>La misma historia en otros medios</h2>
      <p class="explica">Sin filtro no significa sin fuente: aquí está el mismo hecho contado por
         redacciones con líneas editoriales distintas. Compara y decide tú.</p>
      <ul>
        <?php foreach ($versiones as $v): ?>
          <li>
            <a href="noticia.php?id=<?= (int) $v['id'] ?>"><?= e($v['titulo']) ?></a>
            <div class="meta">
              <span class="meta-origen"><?= e($v['origen']) ?></span>
              <span class="sesgo"><?= e(etiquetaSesgo((string) $v['sesgo'])) ?></span>
              <span class="separador">·</span>
              <span><?= e(fechaRelativa((string) $v['publicada_en'])) ?></span>
            </div>
          </li>
        <?php endforeach; ?>
      </ul>
    </section>
  <?php endif; ?>

  <p class="pie-acceso"><a href="index.php">← Volver al buscador</a></p>
</article>

<?php require __DIR__ . '/includes/footer.php'; ?>
