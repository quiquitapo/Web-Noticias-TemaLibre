-- ============================================================================
--  buscador.sql — Buscador Sin Filtro
--  Ejecutar UNA vez en phpMyAdmin (pestaña SQL) o con:
--      mysql -u root -p < sql/buscador.sql
--
--  Reinicia la base completa: borra y vuelve a crear tablas y datos demo.
--  Todos los medios y noticias de ejemplo son FICTICIOS.
-- ============================================================================

CREATE DATABASE IF NOT EXISTS buscador_sin_filtro
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE buscador_sin_filtro;

-- Fuerza UTF-8 en la importación (evita acentos rotos al usar la consola)
SET NAMES utf8mb4;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS noticia_etiqueta, etiquetas, noticias, historias,
                     subcategorias, categorias, origenes,
                     ventas, categorias_venta,
                     auditoria, intentos_acceso, usuarios;
SET FOREIGN_KEY_CHECKS = 1;

-- ── Catálogo editorial ──────────────────────────────────────────────────────

CREATE TABLE categorias (
    id     INT AUTO_INCREMENT PRIMARY KEY,
    slug   VARCHAR(40)  NOT NULL UNIQUE,
    nombre VARCHAR(60)  NOT NULL,
    orden  SMALLINT     NOT NULL DEFAULT 0,
    activa TINYINT(1)   NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE subcategorias (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    categoria_id INT NOT NULL,
    nombre       VARCHAR(60) NOT NULL,
    UNIQUE KEY uq_sub (categoria_id, nombre),
    CONSTRAINT fk_sub_cat FOREIGN KEY (categoria_id) REFERENCES categorias(id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- El sesgo se DECLARA, no se oculta: el lector ve de dónde viene cada versión.
CREATE TABLE origenes (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(80) NOT NULL UNIQUE,
    dominio     VARCHAR(120) NOT NULL,
    pais        VARCHAR(40)  NOT NULL,
    sesgo       ENUM('izquierda','centro-izquierda','centro','centro-derecha',
                     'derecha','estatal','independiente','sin-declarar') NOT NULL DEFAULT 'sin-declarar',
    descripcion VARCHAR(255) NOT NULL DEFAULT '',
    activo      TINYINT(1)   NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- Una "historia" agrupa la misma noticia contada por varios medios.
CREATE TABLE historias (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    resumen VARCHAR(200) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE noticias (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    titulo          VARCHAR(200) NOT NULL,
    autor           VARCHAR(120) NOT NULL DEFAULT 'Redacción',
    bajada          VARCHAR(400) NOT NULL,          -- lo único visible sin sesión
    cuerpo          MEDIUMTEXT   NOT NULL,          -- exige iniciar sesión
    categoria_id    INT NOT NULL,
    subcategoria_id INT NULL,
    origen_id       INT NOT NULL,
    historia_id     INT NULL,
    tipo            ENUM('texto','video') NOT NULL DEFAULT 'texto',
    duracion_min    SMALLINT NULL,
    url_original    VARCHAR(255) NOT NULL DEFAULT '',
    publicada_en    DATETIME NOT NULL,
    estado          ENUM('borrador','publicada','retirada') NOT NULL DEFAULT 'publicada',
    vistas          INT UNSIGNED NOT NULL DEFAULT 0,
    creado_en       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    KEY idx_orden   (estado, publicada_en),
    KEY idx_cat     (categoria_id, publicada_en),
    KEY idx_sub     (subcategoria_id),
    KEY idx_origen  (origen_id),
    KEY idx_historia(historia_id),
    FULLTEXT KEY ft_texto (titulo, bajada, cuerpo),

    CONSTRAINT fk_not_cat FOREIGN KEY (categoria_id)    REFERENCES categorias(id)    ON UPDATE CASCADE,
    CONSTRAINT fk_not_sub FOREIGN KEY (subcategoria_id) REFERENCES subcategorias(id) ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_not_ori FOREIGN KEY (origen_id)       REFERENCES origenes(id)      ON UPDATE CASCADE,
    CONSTRAINT fk_not_his FOREIGN KEY (historia_id)     REFERENCES historias(id)     ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE etiquetas (
    id     INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE noticia_etiqueta (
    noticia_id  INT NOT NULL,
    etiqueta_id INT NOT NULL,
    PRIMARY KEY (noticia_id, etiqueta_id),
    CONSTRAINT fk_ne_not FOREIGN KEY (noticia_id)  REFERENCES noticias(id)  ON DELETE CASCADE,
    CONSTRAINT fk_ne_eti FOREIGN KEY (etiqueta_id) REFERENCES etiquetas(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── Cuentas y seguridad ─────────────────────────────────────────────────────

CREATE TABLE usuarios (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    usuario       VARCHAR(24)  NOT NULL UNIQUE,
    correo        VARCHAR(120) NOT NULL UNIQUE,
    clave_hash    VARCHAR(255) NOT NULL,          -- Argon2id o bcrypt: jamás texto plano
    rol           ENUM('lector','editor','admin') NOT NULL DEFAULT 'lector',
    estado        ENUM('activo','bloqueado')      NOT NULL DEFAULT 'activo',
    creado_en     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ultimo_acceso DATETIME NULL
) ENGINE=InnoDB;

-- Intentos de login/registro para frenar fuerza bruta. Guarda un hash de la
-- clave de conteo (usuario o IP), no el valor legible.
CREATE TABLE intentos_acceso (
    id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    accion     VARCHAR(20) NOT NULL,
    clave_hash CHAR(64)    NOT NULL,
    ip         VARCHAR(45) NOT NULL,
    exito      TINYINT(1)  NOT NULL DEFAULT 0,
    creado_en  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_busqueda (accion, clave_hash, exito, creado_en),
    KEY idx_ip (accion, ip, creado_en)
) ENGINE=InnoDB;

CREATE TABLE auditoria (
    id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NULL,
    accion     VARCHAR(40)  NOT NULL,
    detalle    VARCHAR(255) NOT NULL DEFAULT '',
    ip         VARCHAR(45)  NOT NULL,
    agente     VARCHAR(200) NOT NULL DEFAULT '',
    creado_en  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_aud (usuario_id, creado_en),
    CONSTRAINT fk_aud_usr FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ── Datos de demostración ───────────────────────────────────────────────────

INSERT INTO categorias (id, slug, nombre, orden) VALUES
(1,'ia','IA',1),
(2,'series','Series',2),
(3,'conflictos','Conflictos',3),
(4,'politica','Política',4),
(5,'tecnologia','Tecnología',5),
(6,'videojuegos','Videojuegos',6),
(7,'deporte','Deporte',7),
(8,'educacion','Educación',8),
(9,'nacional','Nacional',9),
(10,'internacional','Internacional',10);

INSERT INTO subcategorias (id, categoria_id, nombre) VALUES
(1,1,'Modelos y algoritmos'),(2,1,'Regulación'),(3,1,'Trabajo y empleo'),
(4,2,'Estrenos'),(5,2,'Plataformas'),(6,2,'Industria'),
(7,3,'Diplomacia'),(8,3,'Crisis humanitaria'),(9,3,'Fuerzas armadas'),
(10,4,'Congreso'),(11,4,'Elecciones'),(12,4,'Gobierno'),
(13,5,'Ciberseguridad'),(14,5,'Hardware'),(15,5,'Privacidad'),
(16,6,'Lanzamientos'),(17,6,'Esports'),(18,6,'Industria'),
(19,7,'Fútbol'),(20,7,'Selecciones'),(21,7,'Otros deportes'),
(22,8,'Escuelas'),(23,8,'Universidades'),(24,8,'Financiamiento'),
(25,9,'Regiones'),(26,9,'Economía local'),(27,9,'Seguridad'),
(28,10,'América'),(29,10,'Europa'),(30,10,'Asia');

INSERT INTO origenes (id, nombre, dominio, pais, sesgo, descripcion) VALUES
(1,'Agencia Meridiano','meridiano.example','Chile','centro','Agencia de cables. Publica despachos breves sin editorializar.'),
(2,'Diario del Sur','diariodelsur.example','Chile','centro-derecha','Diario generalista con línea editorial declarada de centro-derecha.'),
(3,'La Voz Obrera','vozobrera.example','Chile','izquierda','Medio sindical, cubre trabajo y movimientos sociales.'),
(4,'Canal Once Noticias','canalonce.example','Chile','centro-izquierda','Televisión abierta. Fuerte en video y reportajes.'),
(5,'Radio Cordillera','cordillera.example','Chile','independiente','Radio regional financiada por sus oyentes.'),
(6,'Boletín RTN','rtn.example','Chile','estatal','Servicio informativo de titularidad pública.'),
(7,'Global Wire','globalwire.example','Reino Unido','centro','Agencia internacional en español e inglés.'),
(8,'Pacífico Press','pacificopress.example','Perú','centro-izquierda','Cobertura andina y de integración regional.'),
(9,'Atlas Report','atlasreport.example','Estados Unidos','centro-derecha','Análisis económico y geopolítico.'),
(10,'Red Andina','redandina.example','Argentina','independiente','Cooperativa de periodistas, verificación de datos.');

INSERT INTO historias (id, resumen) VALUES
(1,'Fallo del regulador europeo sobre modelos de IA de uso general'),
(2,'Filtración de datos en una cadena de farmacias'),
(3,'Debate por el nuevo financiamiento escolar');

-- Noticias de ejemplo (ficticias). Las fechas son relativas a la importación,
-- así los filtros de tiempo funcionan siempre.
INSERT INTO noticias
(id, titulo, bajada, cuerpo, categoria_id, subcategoria_id, origen_id, historia_id, tipo, duracion_min, url_original, publicada_en, vistas) VALUES

-- ── Historia 1: regulación europea de IA (tres coberturas distintas) ────────
(1,'El regulador europeo publica su primer fallo sobre modelos de IA de uso general',
 'La resolución obliga a documentar los datos de entrenamiento y a permitir auditorías externas. Las empresas tienen nueve meses para adaptarse.',
 'La autoridad europea de inteligencia artificial publicó este martes su primera resolución vinculante sobre modelos de uso general. El texto exige a los proveedores documentar el origen de los datos de entrenamiento, mantener un registro de incidentes y abrir sus sistemas a auditorías independientes cuando superen un umbral de usuarios.\n\nEl plazo de adaptación es de nueve meses. Pasado ese tiempo, las sanciones pueden llegar al tres por ciento de la facturación global anual. La resolución no prohíbe ningún modelo en particular: se centra en la trazabilidad y en la capacidad de un tercero para comprobar lo que la empresa afirma.\n\nCuatro compañías afectadas anunciaron que estudian recurrir. Las organizaciones de consumidores, en cambio, celebraron el fallo y pidieron que el registro de incidentes sea público. El regulador aclaró que publicará una guía técnica antes de que empiece a correr el plazo.',
 1,2,7,1,'texto',NULL,'https://globalwire.example/ia/fallo-regulador', DATE_SUB(NOW(), INTERVAL 5 HOUR), 1840),

(2,'Las auditorías de IA llegan tarde para quienes ya perdieron el empleo',
 'El fallo europeo no dice nada sobre despidos por automatización. Sindicatos del sector servicios piden una mesa de negociación antes de fin de año.',
 'La resolución del regulador europeo se centra en la documentación técnica de los modelos, pero deja fuera el efecto que la automatización ya tuvo en el empleo. Federaciones de trabajadores del sector servicios calculan que las áreas de atención al cliente redujeron su dotación de forma sostenida en los últimos dos años.\n\nDesde la federación sostienen que la transparencia sobre los datos de entrenamiento es un avance, pero que no repone puestos ni obliga a reconversión laboral. La demanda central es una mesa tripartita antes de fin de año, con presencia del Estado, las empresas y los sindicatos.\n\nLas cámaras empresariales responden que la productividad creció y que los despidos responden a cambios de demanda, no solo a la tecnología. Ninguna de las dos partes discute el diagnóstico de fondo: las tareas repetitivas de texto y voz son las primeras en desaparecer.',
 1,3,3,1,'texto',NULL,'https://vozobrera.example/ia/empleo-fallo', DATE_SUB(NOW(), INTERVAL 9 HOUR), 640),

(3,'El costo de cumplir: qué significa el fallo europeo para las empresas medianas',
 'Las grandes tecnológicas tienen equipos legales para absorber la norma. Las medianas, según el análisis, enfrentan un gasto fijo que puede frenar su expansión.',
 'El nuevo marco europeo impone obligaciones que se cumplen con personal especializado: documentación de datos, registro de incidentes y auditoría externa. Para una empresa con miles de empleados es un costo marginal. Para una de doscientos, según estimaciones del sector, puede equivaler al presupuesto anual de investigación.\n\nEl análisis advierte un efecto no buscado: la norma podría consolidar a los actores dominantes, que ya cuentan con estructuras de cumplimiento. Varias firmas medianas evalúan trasladar el desarrollo fuera del bloque o directamente licenciar modelos de terceros.\n\nLos defensores de la regulación replican que el umbral de usuarios deja fuera a la mayoría de las empresas pequeñas y que el costo de no auditar nada es mayor. El debate seguirá abierto mientras se publica la guía técnica.',
 1,2,9,1,'texto',NULL,'https://atlasreport.example/ia/costo-cumplimiento', DATE_SUB(NOW(), INTERVAL 14 HOUR), 910),

-- ── Historia 2: filtración de datos en farmacias ───────────────────────────
(4,'Una cadena de farmacias confirma la filtración de datos de 1,2 millones de clientes',
 'La empresa detectó el acceso indebido hace once días y avisó al organismo de protección de datos. No hay evidencia de que se hayan expuesto recetas médicas.',
 'La cadena informó mediante un comunicado que un tercero accedió sin autorización a una base con nombres, correos, teléfonos y números de documento de 1,2 millones de clientes del programa de puntos. El acceso se produjo a través de una cuenta de un proveedor externo cuyas credenciales fueron reutilizadas.\n\nLa compañía afirma que las recetas médicas y los medios de pago están en sistemas separados y que no muestran señales de intrusión. El organismo de protección de datos abrió un expediente y pidió el informe forense completo en un plazo de diez días hábiles.\n\nLos especialistas recomiendan a los clientes cambiar la contraseña del programa de puntos, activar verificación en dos pasos donde exista y desconfiar de correos que pidan confirmar datos con urgencia. La empresa habilitó un canal de consultas y dice que notificará de forma individual a los afectados.',
 5,13,1,2,'texto',NULL,'https://meridiano.example/tec/filtracion-farmacias', DATE_SUB(NOW(), INTERVAL 20 HOUR), 3120),

(5,'Filtración en farmacias: la empresa responde y el mercado castiga la acción',
 'La compañía perdió un 4,1% en la jornada. Sus ejecutivos defienden que la respuesta fue rápida y que el fallo estuvo en un proveedor externo.',
 'La acción de la cadena cerró con una caída del 4,1 por ciento tras confirmarse el acceso indebido a la base de datos del programa de fidelización. En la conferencia con analistas, la gerencia insistió en que la detección y la contención ocurrieron dentro de las primeras horas.\n\nDesde la empresa señalan que la puerta de entrada fue una credencial de un proveedor de servicios y que ya se revocaron todos los accesos de terceros. También anunciaron una auditoría externa y la contratación de un responsable de seguridad de la información con reporte directo al directorio.\n\nAnalistas del sector consideran que el impacto financiero será acotado si no aparecen datos clínicos comprometidos, pero advierten que la reincidencia sería mucho más cara: la ley contempla multas por incumplimiento del deber de resguardo.',
 5,13,2,2,'texto',NULL,'https://diariodelsur.example/economia/farmacias-accion', DATE_SUB(NOW(), INTERVAL 16 HOUR), 1470),

(6,'Verificamos: qué datos se filtraron realmente en el caso de las farmacias',
 'Circulan capturas que hablan de historiales médicos completos. Contrastamos la muestra publicada en foros con lo declarado por la empresa.',
 'En las últimas horas circularon capturas de pantalla que aseguraban incluir historiales clínicos completos de pacientes. Revisamos la muestra publicada en dos foros y la comparamos con la estructura declarada por la empresa ante el organismo de protección de datos.\n\nLa muestra contiene nombre, correo, teléfono, número de documento y fecha de inscripción al programa de puntos. No aparecen diagnósticos, recetas ni datos de tarjetas. Tres registros que revisamos con sus titulares coincidían en el correo y el teléfono, lo que confirma que la filtración es real aunque más acotada de lo que afirman esas publicaciones.\n\nEl riesgo principal no es clínico sino de suplantación: con el documento y el teléfono es posible intentar recuperar cuentas de terceros. Recomendamos activar verificación en dos pasos y no confirmar datos por teléfono a quien llame diciendo ser de la empresa.',
 5,13,10,2,'texto',NULL,'https://redandina.example/verificacion/farmacias', DATE_SUB(NOW(), INTERVAL 11 HOUR), 2260),

-- ── Historia 3: financiamiento escolar ─────────────────────────────────────
(7,'El Ejecutivo presenta la nueva fórmula de financiamiento escolar',
 'El proyecto redistribuye recursos según matrícula, ruralidad y asistencia. El Ministerio calcula que 1.400 establecimientos recibirán más fondos.',
 'El Ejecutivo ingresó el proyecto que cambia la fórmula de financiamiento de los establecimientos escolares. El cálculo incorpora tres variables: matrícula efectiva, condición de ruralidad y asistencia promedio de los últimos dos años.\n\nSegún las proyecciones del Ministerio, unos 1.400 establecimientos aumentarían sus recursos, la mayoría en zonas rurales y en comunas con menor recaudación local. Otros 300 mantendrían el monto actual mediante un mecanismo de transición de tres años.\n\nEl texto ingresa ahora a comisión y el Gobierno espera despacharlo antes del receso legislativo. La cartera anunció que publicará el simulador de cálculo para que cada sostenedor pueda revisar su caso.',
 8,24,6,3,'texto',NULL,'https://rtn.example/educacion/financiamiento', DATE_SUB(NOW(), INTERVAL 30 HOUR), 780),

(8,'Profesores advierten que la nueva fórmula escolar deja fuera la deuda histórica',
 'El gremio valora el foco rural pero exige que el proyecto incluya el pago pendiente y una glosa para infraestructura deteriorada.',
 'El gremio docente recibió con reparos la nueva fórmula de financiamiento escolar. Reconoce que el criterio de ruralidad corrige una distorsión antigua, pero sostiene que el proyecto evita el asunto de fondo: la deuda pendiente con profesores de arrastre y el estado material de las escuelas.\n\nEn asambleas regionales se acordó pedir una glosa específica para infraestructura, con inventario público de los establecimientos con problemas estructurales. La dirigencia advierte que sin ese punto no acompañará la tramitación.\n\nDesde el Ministerio responden que la infraestructura se financia por otra vía y que mezclar ambos temas retrasaría el despacho del proyecto. La comisión recibirá a las partes la próxima semana.',
 8,24,3,3,'texto',NULL,'https://vozobrera.example/educacion/deuda-historica', DATE_SUB(NOW(), INTERVAL 26 HOUR), 520),

(9,'Sostenedores piden reglas claras antes de aprobar el cambio de financiamiento',
 'Las asociaciones de colegios particulares subvencionados advierten que la transición de tres años es insuficiente para los establecimientos urbanos que pierden recursos.',
 'Las asociaciones de sostenedores plantearon que el mecanismo de transición de tres años no alcanza para los establecimientos urbanos que verían reducidos sus ingresos. Piden extenderlo a cinco años y fijar por ley el momento en que se recalcula la asistencia promedio.\n\nEl argumento central es de previsibilidad: los contratos de personal y arriendo se firman a plazos largos y un ajuste brusco obliga a recortar horas docentes. También solicitan que el simulador anunciado por el Ministerio se publique antes de la votación en comisión.\n\nEl Ejecutivo se abrió a discutir el plazo de transición, pero descartó cambiar las tres variables del cálculo. La discusión en particular comienza la próxima semana.',
 8,24,2,3,'texto',NULL,'https://diariodelsur.example/educacion/sostenedores', DATE_SUB(NOW(), INTERVAL 22 HOUR), 430),

-- ── IA ──────────────────────────────────────────────────────────────────────
(10,'Un modelo abierto iguala a los comerciales en tareas de traducción médica',
 'El equipo publicó pesos, datos y método de evaluación. En pruebas ciegas con 40 traductores, el sistema empató con dos servicios de pago.',
 'Un consorcio universitario publicó un modelo de traducción especializado en textos clínicos con licencia abierta. A diferencia de otros anuncios, el equipo liberó los pesos, el conjunto de evaluación y el protocolo completo, de modo que cualquiera puede reproducir las mediciones.\n\nEn una prueba ciega con cuarenta traductores profesionales, el modelo obtuvo puntajes equivalentes a dos servicios comerciales de pago en informes de alta y peores resultados en textos con abreviaturas locales. Los autores lo señalan explícitamente en el artículo.\n\nLa relevancia práctica es el costo: hospitales públicos podrían ejecutarlo en su propia infraestructura sin enviar datos de pacientes a terceros. El consorcio advierte que el modelo no está certificado para uso clínico directo y que requiere revisión humana.',
 1,1,7,NULL,'texto',NULL,'https://globalwire.example/ia/traduccion-medica', DATE_SUB(NOW(), INTERVAL 40 HOUR), 1130),

(11,'Cómo detectar contenido generado por IA sin caer en falsos positivos',
 'Los detectores automáticos fallan con textos traducidos y con escritura no nativa. Explicamos qué señales sirven y cuáles no.',
 'Los detectores de texto generado por IA se popularizaron en universidades y redacciones, pero su tasa de error es alta en dos casos concretos: textos traducidos automáticamente y textos escritos por personas que no dominan el idioma. En ambos, la estructura resulta más regular y el detector la interpreta como sintética.\n\nLas señales que sí sirven son contextuales: citas a estudios que no existen, cifras sin fuente, referencias a hechos posteriores a lo que el texto dice conocer, y una uniformidad extraña en la longitud de los párrafos. Ninguna es concluyente por sí sola.\n\nLa recomendación práctica es no usar el resultado de un detector como prueba, sino como motivo para pedir el proceso de trabajo: borradores, fuentes y notas. En video, la verificación pasa por el archivo original y sus metadatos.',
 1,1,10,NULL,'video',7,'https://redandina.example/ia/detectores', DATE_SUB(NOW(), INTERVAL 60 HOUR), 2890),

-- ── Series ──────────────────────────────────────────────────────────────────
(12,'La serie chilena Cordillera Negra se estrena con récord de audiencia regional',
 'El thriller ambientado en el norte grande alcanzó 1,8 millones de reproducciones en su primer fin de semana en la región.',
 'La producción nacional Cordillera Negra, un thriller de ocho capítulos ambientado en una faena minera del norte, registró 1,8 millones de reproducciones en su primer fin de semana según los datos entregados por la plataforma que la distribuye.\n\nLa serie se rodó íntegramente en locaciones reales y empleó a un equipo técnico mayoritariamente regional. Su directora explicó que la decisión de filmar en altura encareció el rodaje pero permitió prescindir de efectos digitales en los exteriores.\n\nLa segunda temporada ya está confirmada y comenzaría a rodarse el próximo verano. La productora negocia además su distribución en el mercado de habla hispana de Norteamérica.',
 2,4,4,NULL,'video',4,'https://canalonce.example/series/cordillera-negra', DATE_SUB(NOW(), INTERVAL 50 HOUR), 4210),

(13,'Las plataformas de streaming suben precios y pierden suscriptores en la región',
 'Tres servicios ajustaron tarifas en el trimestre. El churn subió al 9%, el nivel más alto desde que se mide en el mercado local.',
 'Tres de los principales servicios de streaming aplicaron alzas de precio en el último trimestre, en un rango de entre el 8 y el 15 por ciento. En el mismo periodo, la tasa de cancelación mensual promedio del mercado local llegó al 9 por ciento, el registro más alto desde que se lleva la serie.\n\nEl comportamiento predominante no es el abandono definitivo sino la rotación: el usuario se suscribe para ver un título concreto y cancela al terminarlo. Las plataformas responden con planes con publicidad más baratos y con estrenos semanales en lugar de temporadas completas.\n\nEl efecto sobre la producción local todavía no es claro. Dos productoras consultadas señalan que los encargos siguen firmados, aunque con presupuestos más ajustados y plazos de rodaje más cortos.',
 2,5,9,NULL,'texto',NULL,'https://atlasreport.example/medios/streaming-precios', DATE_SUB(NOW(), INTERVAL 80 HOUR), 1670),

-- ── Conflictos ──────────────────────────────────────────────────────────────
(14,'Se reanuda la ronda de conversaciones por el corredor humanitario',
 'Las delegaciones acordaron un cese de hostilidades de 72 horas para permitir el ingreso de convoyes con medicamentos y agua potable.',
 'Las delegaciones retomaron las conversaciones tras dos semanas de suspensión y acordaron un cese de hostilidades de 72 horas en el sector norte del corredor. El acuerdo permite el ingreso de convoyes con medicamentos, agua potable y equipos de reparación eléctrica.\n\nLa organización mediadora informó que 34 camiones ya cruzaron el primer punto de control y que el objetivo es llegar a un centenar antes de que expire el plazo. Los equipos técnicos deben además restablecer una planta de bombeo que quedó fuera de servicio.\n\nNinguna de las partes se comprometió a extender la tregua. La próxima reunión está prevista para el jueves y su punto central será el intercambio de personas detenidas.',
 3,7,7,NULL,'texto',NULL,'https://globalwire.example/conflictos/corredor', DATE_SUB(NOW(), INTERVAL 7 HOUR), 2050),

(15,'Informe: la crisis alimentaria afecta a 2,3 millones de personas en la zona fronteriza',
 'El organismo internacional advierte que las reservas alcanzan para seis semanas y pide desbloquear el financiamiento comprometido.',
 'Un informe del organismo internacional de asistencia estima que 2,3 millones de personas de la zona fronteriza dependen hoy de la ayuda alimentaria directa. Las reservas disponibles en los centros de acopio alcanzan para unas seis semanas al ritmo actual de distribución.\n\nEl documento señala que el problema no es solo logístico: el 40 por ciento del financiamiento comprometido por los países donantes no se ha desembolsado. Sin ese dinero, la operación deberá reducir las raciones a partir del próximo mes.\n\nLos equipos en terreno describen además un aumento de casos de desnutrición aguda en menores de cinco años. El organismo pide un corredor estable y previsible, no autorizaciones caso a caso.',
 3,8,8,NULL,'texto',NULL,'https://pacificopress.example/mundo/informe-alimentario', DATE_SUB(NOW(), INTERVAL 34 HOUR), 890),

-- ── Política ────────────────────────────────────────────────────────────────
(16,'La comisión aprueba en general el proyecto de datos personales',
 'El texto crea una agencia con facultades sancionatorias. La votación en particular comienza la próxima semana.',
 'La comisión aprobó en general el proyecto que actualiza la ley de datos personales y crea una agencia con facultades para investigar y sancionar. El texto establece obligaciones de notificación de brechas en un plazo máximo de 72 horas y multas escalonadas según la gravedad.\n\nDurante la sesión se escuchó a especialistas y a representantes de empresas. El punto más discutido fue el estándar de consentimiento para el tratamiento de datos con fines publicitarios, donde hay dos redacciones alternativas sobre la mesa.\n\nLa votación en particular comienza la próxima semana. Los plazos de entrada en vigencia y el presupuesto de la nueva agencia quedaron pendientes para esa etapa.',
 4,10,1,NULL,'texto',NULL,'https://meridiano.example/politica/datos-personales', DATE_SUB(NOW(), INTERVAL 28 HOUR), 760),

(17,'Encuesta: el 62% considera que los medios no informan de forma equilibrada',
 'El estudio muestra desconfianza transversal y un aumento del consumo de noticias por redes sociales entre menores de 30 años.',
 'Una encuesta nacional aplicada a 2.400 personas muestra que el 62 por ciento considera que los medios no informan de forma equilibrada. La desconfianza es transversal a los grupos socioeconómicos y a la identificación política declarada.\n\nEl estudio también registra un cambio en el canal: entre los menores de 30 años, el 71 por ciento dice informarse principalmente por redes sociales, aunque solo el 24 por ciento afirma verificar la fuente original antes de compartir una noticia.\n\nLos autores advierten que la desconfianza no se traduce en menor consumo, sino en consumo fragmentado: las personas leen más fuentes, pero con menor profundidad en cada una.',
 4,12,5,NULL,'texto',NULL,'https://cordillera.example/politica/encuesta-medios', DATE_SUB(NOW(), INTERVAL 44 HOUR), 3340),

-- ── Tecnología ──────────────────────────────────────────────────────────────
(18,'Una vulnerabilidad crítica en un gestor de contraseñas obliga a actualizar de urgencia',
 'El fallo permite leer la bóveda si el equipo queda desbloqueado. Ya existe parche y no hay evidencia de explotación masiva.',
 'Los responsables de un gestor de contraseñas de uso extendido publicaron una actualización de urgencia tras detectarse un fallo que permite leer el contenido de la bóveda en un equipo que quedó desbloqueado y con la extensión activa. La condición requiere acceso local o una extensión maliciosa ya instalada.\n\nLa empresa afirma que no hay evidencia de explotación masiva y que el reporte llegó por su programa de recompensas. La recomendación oficial es actualizar de inmediato, cerrar sesión en los navegadores y revisar los dispositivos autorizados.\n\nLos especialistas aprovechan de recordar la medida que más reduce el daño en estos casos: activar la verificación en dos pasos en las cuentas críticas, de modo que la contraseña por sí sola no baste para entrar.',
 5,13,1,NULL,'texto',NULL,'https://meridiano.example/tec/gestor-contrasenas', DATE_SUB(NOW(), INTERVAL 3 HOUR), 5120),

(19,'Chips nacionales: el plan para ensamblar módulos de memoria en la región',
 'La inversión contempla una planta de encapsulado y pruebas. No fabricará obleas, pero podría capturar parte de la cadena de valor.',
 'El plan anunciado contempla una planta de encapsulado y pruebas de módulos de memoria, la etapa final de la cadena de fabricación de semiconductores. No incluye producción de obleas, que exige inversiones de otro orden de magnitud y consumo eléctrico y de agua muy superior.\n\nLos promotores estiman 600 empleos directos y la formación de técnicos especializados en convenio con centros de formación técnica. El proyecto depende de que se resuelva la conexión eléctrica de la zona industrial elegida.\n\nEspecialistas consultados coinciden en que la etapa de encapsulado es la puerta de entrada razonable para un país sin industria previa, aunque advierten que el margen es estrecho y que la competencia asiática opera con escalas mucho mayores.',
 5,14,9,NULL,'texto',NULL,'https://atlasreport.example/tec/semiconductores', DATE_SUB(NOW(), INTERVAL 96 HOUR), 1240),

-- ── Videojuegos ─────────────────────────────────────────────────────────────
(20,'Un estudio independiente chileno gana el premio a mejor narrativa en el festival de Colonia',
 'El juego, desarrollado por seis personas en cuatro años, mezcla mitología del sur con mecánicas de exploración.',
 'El estudio independiente, formado por seis personas, obtuvo el premio a mejor narrativa en el festival de Colonia por un juego de exploración basado en relatos del sur del país. El desarrollo tomó cuatro años y se financió con una mezcla de fondos concursables y venta anticipada.\n\nEl jurado destacó la integración entre la mecánica y el relato: el jugador avanza reconstruyendo testimonios y las decisiones cambian qué versión de los hechos queda registrada. El equipo trabajó con hablantes de la zona para el guion y el doblaje.\n\nEl juego saldrá primero en computadores y después en consolas. El estudio anunció que destinará parte de los ingresos a un fondo para nuevos desarrolladores de la región.',
 6,18,4,NULL,'video',6,'https://canalonce.example/videojuegos/premio-colonia', DATE_SUB(NOW(), INTERVAL 55 HOUR), 2740),

(21,'La final del torneo de esports se jugará con público en el estadio techado',
 'Se esperan 12 mil asistentes. Los organizadores anunciaron entradas a precio reducido para colegios técnicos.',
 'La final del torneo regional de esports se disputará con público en el estadio techado, con una capacidad habilitada de 12 mil asistentes. Es la primera vez que la competencia se realiza fuera de un estudio cerrado.\n\nLos organizadores anunciaron un bloque de entradas a precio reducido para estudiantes de colegios técnicos y una zona de charlas sobre desarrollo, producción y transmisión. La final se emitirá además por señal abierta.\n\nLos cuatro equipos clasificados vienen de tres países. El premio total del torneo aumentó respecto del año pasado gracias a nuevos auspiciadores del rubro tecnológico.',
 6,17,5,NULL,'texto',NULL,'https://cordillera.example/esports/final', DATE_SUB(NOW(), INTERVAL 18 HOUR), 1580),

-- ── Deporte ─────────────────────────────────────────────────────────────────
(22,'Debut con victoria: el arquero formado en cadetes ataja un penal en su primer partido',
 'El equipo ganó 2-1 en el cierre de la fase de grupos. El portero, de 20 años, entró por lesión del titular en el minuto 12.',
 'El arquero formado en las divisiones inferiores debutó en el primer equipo tras la lesión del titular a los doce minutos y terminó siendo figura: atajó un penal a los 78 y sostuvo el 2-1 en el cierre de la fase de grupos.\n\nEl técnico explicó en conferencia que la decisión de mantenerlo el próximo partido depende de la evolución del titular, pero valoró la personalidad del juvenil. En el vestuario, los capitanes destacaron que el arquero venía entrenando penales con el preparador desde la pretemporada.\n\nEl equipo clasificó a la siguiente fase como líder de su zona y jugará el cruce a mediados del próximo mes, con localía definida por sorteo.',
 7,19,4,NULL,'video',3,'https://canalonce.example/deporte/debut-arquero', DATE_SUB(NOW(), INTERVAL 2 HOUR), 6420),

(23,'La selección femenina cierra la gira con dos triunfos y una nómina renovada',
 'Ocho jugadoras debutaron en la gira. El cuerpo técnico probó una línea de tres defensoras con buenos resultados.',
 'La selección femenina terminó su gira internacional con dos triunfos y un empate, y con ocho jugadoras que debutaron en el proceso. El cuerpo técnico aprovechó los partidos para probar una línea de tres defensoras que hasta ahora solo se había ensayado en entrenamientos.\n\nEl balance deportivo es positivo en generación de ocasiones, aunque persiste la dificultad para cerrar los partidos: los tres goles recibidos llegaron en los últimos quince minutos. El cuerpo técnico apunta a la carga física acumulada.\n\nLa próxima convocatoria será en dos meses y considera un amistoso de local. La federación informó que el partido se jugará en regiones.',
 7,20,6,NULL,'texto',NULL,'https://rtn.example/deporte/seleccion-femenina', DATE_SUB(NOW(), INTERVAL 38 HOUR), 1890),

-- ── Educación ───────────────────────────────────────────────────────────────
(24,'Las universidades regionales piden un piso mínimo de investigación en el presupuesto',
 'Los rectores plantean que el fondo actual concentra el 70% de los recursos en tres instituciones.',
 'Los rectores de universidades regionales presentaron una propuesta para establecer un piso mínimo de financiamiento a la investigación en el presupuesto del próximo año. Sostienen que el fondo concursable actual concentra cerca del 70 por ciento de los recursos en tres instituciones.\n\nLa propuesta no plantea eliminar la competencia por proyectos, sino reservar una fracción para capacidades instaladas en regiones: laboratorios, personal técnico permanente y equipamiento compartido entre planteles.\n\nDesde el Ministerio señalan que la discusión se dará en la tramitación presupuestaria y que ya existe un instrumento con foco regional, aunque reconocen que su monto es marginal frente al fondo principal.',
 8,23,8,NULL,'texto',NULL,'https://pacificopress.example/educacion/universidades', DATE_SUB(NOW(), INTERVAL 70 HOUR), 640),

-- ── Nacional ────────────────────────────────────────────────────────────────
(25,'Comienza la reconstrucción del puente que dejó aisladas a seis localidades',
 'La obra durará ocho meses. Mientras tanto funcionará una balsa con horario ampliado y turnos de emergencia.',
 'Comenzaron los trabajos de reconstrucción del puente que colapsó durante el temporal y dejó aisladas a seis localidades. El plazo comprometido es de ocho meses y contempla fundaciones más profundas y una rasante más alta que la anterior.\n\nMientras dure la obra funcionará una balsa con horario ampliado, de seis de la mañana a diez de la noche, además de turnos de emergencia coordinados con el servicio de salud para traslados urgentes. Los vecinos habían pedido esa garantía como condición para aceptar el cronograma.\n\nLa autoridad regional informó que el financiamiento está aprobado en su totalidad y que habrá informes mensuales de avance en la sede comunal y en el sitio del municipio.',
 9,25,5,NULL,'texto',NULL,'https://cordillera.example/nacional/puente', DATE_SUB(NOW(), INTERVAL 12 HOUR), 1320),

(26,'El comercio local cierra el trimestre con ventas planas y menos empleo formal',
 'La cámara reporta caídas en vestuario y ferretería, y crecimiento en alimentos. El empleo formal del sector bajó 1,9%.',
 'El comercio local cerró el trimestre con ventas prácticamente planas respecto del mismo periodo del año anterior. El detalle muestra caídas en vestuario y ferretería, y un leve crecimiento en alimentos y farmacia.\n\nEl dato que más preocupa a la cámara es el empleo: la dotación formal del sector cayó un 1,9 por ciento, con mayor incidencia en locales de menos de diez trabajadores. La entidad atribuye el ajuste al costo de arriendo y al aumento de la venta por canales digitales de grandes operadores.\n\nLas proyecciones para el próximo trimestre son moderadas y dependen del comportamiento de las fiestas locales, que concentran buena parte de las ventas anuales en varias comunas.',
 9,26,2,NULL,'texto',NULL,'https://diariodelsur.example/nacional/comercio', DATE_SUB(NOW(), INTERVAL 64 HOUR), 720),

-- ── Internacional ───────────────────────────────────────────────────────────
(27,'Acuerdo regional para reconocer títulos técnicos entre cinco países',
 'El convenio permitirá que un técnico titulado en un país ejerza en los otros cuatro sin revalidar desde cero.',
 'Cinco países firmaron un convenio para el reconocimiento mutuo de títulos técnicos de nivel superior. El acuerdo define un marco común de competencias por área y un procedimiento de homologación que reemplaza la revalidación completa.\n\nLas primeras áreas incluidas son electricidad, mecánica automotriz, enfermería técnica y desarrollo de software. Cada país mantiene la facultad de exigir un examen práctico cuando el plan de estudios difiera en más de un umbral acordado.\n\nEl convenio entra en vigor cuando lo ratifiquen al menos tres parlamentos. Dos ya iniciaron la tramitación y se espera que el proceso tome cerca de un año.',
 10,28,8,NULL,'texto',NULL,'https://pacificopress.example/internacional/titulos', DATE_SUB(NOW(), INTERVAL 90 HOUR), 480),

(28,'Europa endurece las reglas de trazabilidad para importaciones agrícolas',
 'Las nuevas exigencias piden identificar el predio de origen. Los exportadores de la región piden un plazo mayor de adaptación.',
 'El bloque europeo aprobó nuevas exigencias de trazabilidad para importaciones agrícolas que obligan a identificar el predio de origen de cada lote, con coordenadas y registro de uso de suelo de los últimos años.\n\nLos gremios exportadores de la región valoran el objetivo pero piden ampliar el plazo de adaptación, sobre todo para productores pequeños que hoy venden a través de intermediarios y no cuentan con sistemas de registro digital.\n\nLos servicios agrícolas nacionales trabajan en una plataforma común para centralizar la información y evitar que cada comprador exija un formato distinto. La primera versión estaría disponible antes de la próxima temporada.',
 10,29,7,NULL,'texto',NULL,'https://globalwire.example/internacional/trazabilidad', DATE_SUB(NOW(), INTERVAL 120 HOUR), 560),

(29,'Un puerto asiático prueba grúas autónomas y reduce a la mitad los tiempos de espera',
 'El piloto operó seis meses con supervisión humana remota. El sindicato portuario negoció reconversión antes de la puesta en marcha.',
 'Un puerto de gran escala completó un piloto de seis meses con grúas autónomas supervisadas de forma remota. Los tiempos de espera de los camiones en el patio de contenedores se redujeron cerca de la mitad respecto de la operación anterior.\n\nEl acuerdo previo con el sindicato portuario fue determinante: se pactó un plan de reconversión con formación en operación remota y mantenimiento, y el compromiso de no reducir la dotación durante tres años.\n\nOtros puertos de la región siguen el caso de cerca. Los especialistas advierten que el resultado depende tanto de la tecnología como del rediseño de los turnos y de la coordinación con el transporte terrestre.',
 10,30,9,NULL,'texto',NULL,'https://atlasreport.example/internacional/puerto', DATE_SUB(NOW(), INTERVAL 150 HOUR), 830),

(30,'Alerta por campañas de phishing que suplantan a servicios de gobierno',
 'Los correos piden actualizar datos para no perder un beneficio. El organismo recuerda que nunca solicita claves por correo ni por WhatsApp.',
 'El equipo de respuesta ante incidentes advirtió sobre una campaña masiva de correos y mensajes que suplantan a servicios de gobierno. El mensaje anuncia la pérdida de un beneficio si no se actualizan los datos en un plazo de 24 horas e incluye un enlace a un sitio que imita el diseño oficial.\n\nEl organismo recordó que nunca pide claves ni códigos por correo, mensajería o teléfono, y que los trámites se hacen siempre desde el sitio oficial escrito a mano en el navegador, no desde enlaces recibidos.\n\nLas señales del engaño son las de siempre: urgencia, direcciones que se parecen pero no coinciden con el dominio oficial, y formularios que piden la clave completa. Ante la duda, cortar y consultar por los canales conocidos.',
 5,13,6,NULL,'texto',NULL,'https://rtn.example/tec/phishing-gobierno', DATE_SUB(NOW(), INTERVAL 6 HOUR), 4310);

-- Etiquetas (palabras clave para el buscador)
INSERT INTO etiquetas (id, nombre) VALUES
(1,'inteligencia artificial'),(2,'regulación'),(3,'empleo'),(4,'auditoría'),
(5,'filtración de datos'),(6,'ciberseguridad'),(7,'privacidad'),(8,'farmacias'),
(9,'educación'),(10,'financiamiento'),(11,'profesores'),(12,'streaming'),
(13,'series chilenas'),(14,'humanitario'),(15,'diplomacia'),(16,'encuesta'),
(17,'medios'),(18,'semiconductores'),(19,'videojuegos'),(20,'esports'),
(21,'fútbol'),(22,'selección'),(23,'universidades'),(24,'infraestructura'),
(25,'comercio'),(26,'integración regional'),(27,'agricultura'),(28,'puertos'),
(29,'phishing'),(30,'contraseñas'),(31,'verificación'),(32,'salud');

INSERT INTO noticia_etiqueta (noticia_id, etiqueta_id) VALUES
(1,1),(1,2),(1,4),(2,1),(2,3),(2,2),(3,1),(3,2),
(4,5),(4,6),(4,8),(4,7),(5,5),(5,8),(6,5),(6,31),(6,8),
(7,9),(7,10),(8,9),(8,11),(8,10),(9,9),(9,10),
(10,1),(10,32),(11,1),(11,31),
(12,13),(13,12),
(14,15),(14,14),(15,14),
(16,7),(16,2),(17,16),(17,17),
(18,6),(18,30),(19,18),
(20,19),(21,20),(21,19),
(22,21),(23,22),(23,21),
(24,23),(24,9),(25,24),(26,25),
(27,26),(28,27),(29,28),
(30,29),(30,6);

-- Cuenta de demostración. Usuario: demo | Contraseña: LectorLibre2026*
-- El hash es bcrypt (coste 12): compatible con cualquier PHP 7.4+.
-- CAMBIA esta contraseña antes de exponer el sitio a internet.
INSERT INTO usuarios (usuario, correo, clave_hash, rol, estado) VALUES
('demo', 'demo@buscadorsinfiltro.local', '$2y$12$nX1dMBM5LTWGNeQvJUUphesDOFKaekj/qoD5wZ8qeUt9dtXD9mp9G', 'lector', 'activo');

-- Firma de cada noticia: el asistente responde "¿quién escribió esto?"
UPDATE noticias SET autor = ELT(id,
 'Marta Ilabaca','Rodrigo Pizarro','Helen Vargas','Agencia Meridiano / Redacción',
 'Cristóbal Reyes','Equipo de Verificación','Redacción RTN','Nicolás Cifuentes',
 'Paula Andrade','Ingrid Solar','Equipo de Verificación','Camila Bustos',
 'Daniel Ortega Ruiz','Helen Vargas','Lucía Pardo','Agencia Meridiano / Redacción',
 'Sebastián Miranda','Andrea Fuentes','Tomás Elgueta','Camila Bustos',
 'Sebastián Miranda','Felipe Navarrete','Redacción RTN','Rosa Quispe',
 'Ignacio Salas','Nicolás Cifuentes','Rosa Quispe','Lucía Pardo',
 'Daniel Ortega Ruiz','Redacción RTN')
WHERE id BETWEEN 1 AND 30;

-- ============================================================================
--  MODO VENTAS — avisos clasificados
-- ============================================================================

CREATE TABLE categorias_venta (
    id     INT AUTO_INCREMENT PRIMARY KEY,
    slug   VARCHAR(40) NOT NULL UNIQUE,
    nombre VARCHAR(60) NOT NULL,
    orden  SMALLINT NOT NULL DEFAULT 0,
    activa TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE ventas (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    titulo       VARCHAR(160) NOT NULL,
    resumen      VARCHAR(300) NOT NULL,
    descripcion  TEXT         NOT NULL,
    precio       INT UNSIGNED NOT NULL,          -- pesos, sin decimales
    moneda       CHAR(3)      NOT NULL DEFAULT 'CLP',
    categoria_id INT NOT NULL,
    condicion    ENUM('nuevo','usado','reacondicionado') NOT NULL DEFAULT 'usado',
    region       VARCHAR(60)  NOT NULL,
    comuna       VARCHAR(60)  NOT NULL,
    vendedor     VARCHAR(80)  NOT NULL,
    contacto     VARCHAR(120) NOT NULL,          -- solo visible con sesión
    stock        SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    envio        TINYINT(1)   NOT NULL DEFAULT 0,
    publicada_en DATETIME     NOT NULL,
    estado       ENUM('publicada','pausada','vendida') NOT NULL DEFAULT 'publicada',
    vistas       INT UNSIGNED NOT NULL DEFAULT 0,

    KEY idx_v_orden  (estado, publicada_en),
    KEY idx_v_cat    (categoria_id, publicada_en),
    KEY idx_v_precio (precio),
    CONSTRAINT fk_venta_cat FOREIGN KEY (categoria_id) REFERENCES categorias_venta(id) ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT INTO categorias_venta (id, slug, nombre, orden) VALUES
(1,'tecnologia','Tecnología',1),(2,'hogar','Hogar',2),(3,'vehiculos','Vehículos',3),
(4,'deporte','Deporte',4),(5,'instrumentos','Instrumentos',5),(6,'herramientas','Herramientas',6),
(7,'libros','Libros',7),(8,'moda','Moda',8),(9,'mascotas','Mascotas',9),(10,'servicios','Servicios',10);

INSERT INTO ventas
(id,titulo,resumen,descripcion,precio,categoria_id,condicion,region,comuna,vendedor,contacto,stock,envio,publicada_en,vistas) VALUES
(1,'Notebook 14 pulgadas, 16 GB RAM, SSD 512 GB','Equipo de trabajo con dos años de uso y batería cambiada en marzo. Incluye cargador original y funda.','Notebook de 14 pulgadas, 16 GB de RAM y disco sólido de 512 GB. Lo usé para programar, nunca para juegos. La batería es nueva, con cambio certificado en marzo y boleta. Incluye cargador original, funda de neopreno y caja. Se entrega con el sistema recién instalado. Puedes probarlo antes de pagar.',389000,1,'usado','Metropolitana','Ñuñoa','Andrés Miranda','andres.miranda@correo.example / +56 9 7000 1122',1,1,DATE_SUB(NOW(), INTERVAL 4 HOUR),412),
(2,'Monitor 27 pulgadas 2K, 75 Hz','Panel IPS sin píxeles muertos. Se vende por cambio a formato ultrawide.','Monitor de 27 pulgadas con resolución 2560x1440 y 75 Hz. Panel IPS, sin píxeles muertos ni manchas. Incluye cable HDMI y DisplayPort. El soporte original está completo y también sirve brazo VESA de 100 mm. Lo vendo porque cambié a un ultrawide.',159000,1,'usado','Valparaíso','Viña del Mar','Karen Soto','karen.soto@correo.example',1,1,DATE_SUB(NOW(), INTERVAL 26 HOUR),268),
(3,'Bicicleta de montaña aro 29, talla M','Cuadro de aluminio, 21 cambios y frenos de disco hidráulicos recién purgados.','Bicicleta de montaña aro 29, talla M, para estatura de 1,68 a 1,80 m. Cuadro de aluminio, 21 cambios y frenos de disco hidráulicos purgados hace dos semanas. Neumáticos con buen dibujo. Uso recreativo de fin de semana, nunca competencia. Se entrega con pata y portabidón.',245000,4,'usado','Metropolitana','La Florida','Javier Rojas','javier.rojas@correo.example / +56 9 7311 8890',1,0,DATE_SUB(NOW(), INTERVAL 9 HOUR),530),
(4,'Guitarra eléctrica y amplificador de 15 W','Pack completo para empezar: guitarra, amplificador, correa, cable, funda y púas.','Guitarra tipo stratocaster con tres cápsulas single coil, palanca de trémolo y clavijas afinadas. Incluye amplificador de 15 W con distorsión, correa, cable de 3 metros, funda acolchada y púas. Todo funciona. La vendo porque pasé a una semiacústica.',179990,5,'usado','Biobío','Concepción','Marcela Fuenzalida','marcela.f@correo.example',1,1,DATE_SUB(NOW(), INTERVAL 52 HOUR),190),
(5,'Refrigerador no frost de 320 litros','Dos años de uso y funcionando perfecto. Se vende por cambio de casa.','Refrigerador no frost de 320 litros, color plata, dos puertas. Dos años de uso con mantención al día. Enfría parejo, sin ruidos raros ni goteos. Se vende porque el departamento nuevo trae uno empotrado. Retiro en el lugar; tengo carro de carga para ayudarte a bajarlo.',289000,2,'usado','Metropolitana','Maipú','Patricia Leiva','patricia.leiva@correo.example / +56 9 6422 0031',1,0,DATE_SUB(NOW(), INTERVAL 15 HOUR),305),
(6,'Escritorio de madera maciza 140x70','Mesa de trabajo sólida, no melamina. Pasacables incluido y patas desmontables.','Escritorio de madera maciza de 140 x 70 cm y 75 cm de alto. No es melamina: es madera de verdad y pesa lo suyo. Tiene pasacables en la esquina derecha y las patas van atornilladas, así que se desarma para el traslado. Un par de marcas de uso en la superficie.',135000,2,'usado','Metropolitana','Providencia','Tomás Herrera','tomas.herrera@correo.example',1,0,DATE_SUB(NOW(), INTERVAL 70 HOUR),142),
(7,'Taladro percutor inalámbrico 20 V con dos baterías','Herramienta con maletín, cargador rápido y set de 30 brocas y puntas.','Taladro percutor inalámbrico de 20 V con dos baterías de 2 Ah, cargador rápido y maletín rígido. Incluye set de 30 brocas y puntas para madera, metal y concreto. Lo compré para una remodelación que ya terminó. Las baterías mantienen buena autonomía.',119900,6,'usado','Maule','Talca','Óscar Bravo','oscar.bravo@correo.example / +56 9 5510 7744',1,1,DATE_SUB(NOW(), INTERVAL 33 HOUR),221),
(8,'Teclado mecánico 75% de switches lineales','Nuevo, sin uso: lo pedí y llegó en distribución ANSI en vez de español.','Teclado mecánico formato 75 por ciento, switches lineales, retroiluminación blanca y cable USB-C desmontable. Está nuevo y sin uso porque llegó en distribución ANSI cuando necesitaba ISO en español. Caja, cable y sacaswitches completos.',54990,1,'nuevo','Metropolitana','Santiago','Ignacio Pérez','ignacio.perez@correo.example',2,1,DATE_SUB(NOW(), INTERVAL 6 HOUR),377),
(9,'Colección de 40 libros de ciencia ficción','Lote completo en tapa blanda y buen estado. No se venden por separado.','Cuarenta novelas de ciencia ficción en español, tapa blanda, la mayoría leídas una vez. Ninguna tiene rayados ni hojas sueltas; un par tienen el lomo algo marcado. Se vende el lote completo. Entrego en metro Los Leones o despacho por encomienda con costo del comprador.',89000,7,'usado','Metropolitana','Las Condes','Rosa Ampuero','rosa.ampuero@correo.example',1,1,DATE_SUB(NOW(), INTERVAL 88 HOUR),98),
(10,'Automóvil sedán 2016, 98.000 kilómetros','Mantenciones al día en servicio oficial, dueño único y papeles vigentes.','Sedán año 2016, motor 1.6, transmisión manual y 98.000 kilómetros reales. Dueño único desde nuevo, con todas las mantenciones en servicio oficial y libro timbrado. Permiso de circulación y revisión técnica vigentes. Neumáticos cambiados el año pasado. Se recibe revisión mecánica de tu confianza.',6990000,3,'usado','Metropolitana','San Miguel','Luis Carrasco','luis.carrasco@correo.example / +56 9 8120 4455',1,0,DATE_SUB(NOW(), INTERVAL 44 HOUR),864),
(11,'Cámara sin espejo APS-C con lente 18-55','Cuerpo con 7.800 disparos, sensor limpio y dos baterías incluidas.','Cámara sin espejo con sensor APS-C de 24 MP y lente kit 18-55 mm estabilizado. El contador marca 7.800 disparos, el sensor está limpio y la pantalla no tiene rayas. Incluye dos baterías, cargador, correa y tarjeta de 64 GB. Ideal para quien parte en fotografía.',429000,1,'usado','Los Lagos','Puerto Montt','Camilo Vera','camilo.vera@correo.example',1,1,DATE_SUB(NOW(), INTERVAL 20 HOUR),311),
(12,'Zapatillas de running talla 42, sin uso','Modelo de entrenamiento neutro. Quedaron chicas y venció el plazo de cambio.','Zapatillas de running para pisada neutra, talla 42, completamente sin uso y con su caja original. Las pedí por internet y me quedaron justas; cuando quise cambiarlas ya había pasado el plazo. Amortiguación media, buenas para entrenamiento diario en asfalto.',44990,8,'nuevo','Metropolitana','Recoleta','Daniela Muñoz','daniela.munoz@correo.example',1,1,DATE_SUB(NOW(), INTERVAL 3 HOUR),206),
(13,'Kayak doble con remos y chalecos','Listo para el lago: kayak, dos remos, dos chalecos y carro de traslado.','Kayak doble rígido de polietileno, con dos asientos regulables y compartimento estanco en popa. Se vende con dos remos de aluminio, dos chalecos salvavidas talla adulto y carro de traslado plegable. Un par de rayones en el casco por uso normal en orilla de lago.',520000,4,'usado','La Araucanía','Villarrica','Hernán Paillalef','hernan.p@correo.example / +56 9 9033 2210',1,0,DATE_SUB(NOW(), INTERVAL 110 HOUR),176),
(14,'Piano digital de 88 teclas contrapesadas','Incluye pedal sustain, soporte en X y atril. Muy poco uso.','Piano digital de 88 teclas contrapesadas con sensibilidad ajustable, 10 sonidos y salida para audífonos. Incluye pedal sustain, soporte en X y atril. Poco uso: lo compré hace años y ya no tengo espacio. Se puede probar antes de comprar.',389000,5,'usado','Metropolitana','La Reina','Elena Zúñiga','elena.zuniga@correo.example',1,0,DATE_SUB(NOW(), INTERVAL 60 HOUR),134),
(15,'Instalación de red y WiFi para la casa','Visita, medición de cobertura y configuración de router y repetidores.','Técnico con diez años de experiencia en redes. El servicio incluye visita, medición de cobertura por ambiente, configuración del router, canales y clave segura, instalación de repetidores o malla si hace falta, y un informe simple con lo que quedó hecho. El precio es por visita en la Región Metropolitana; fuera de la región se cotiza aparte.',35000,10,'nuevo','Metropolitana','Santiago','Redes Cordillera SpA','contacto@redescordillera.example / +56 9 4477 1200',9,0,DATE_SUB(NOW(), INTERVAL 12 HOUR),252),
(16,'Cuna convertible en cama, con colchón','Madera natural, tres alturas de somier y colchón con funda lavable.','Cuna de madera natural que se convierte en cama de transición, con tres alturas de somier y barandas laterales. Incluye colchón con funda lavable, usado con protector desde el primer día. Sin mordidas en los bordes. Se entrega desarmada con todos los tornillos y la llave allen.',149000,2,'usado','Valparaíso','Quilpué','Francisca Ortiz','francisca.ortiz@correo.example',1,0,DATE_SUB(NOW(), INTERVAL 78 HOUR),119),
(17,'Rascador para gatos de 1,6 m con hamaca','Estructura firme forrada en sisal, tres plataformas y cueva cerrada.','Rascador de 1,6 metros de alto con base ancha antivuelco, tres plataformas, una cueva cerrada y hamaca superior. Postes forrados en cuerda de sisal en buen estado. Lo vendo porque mi gata prefirió el sillón. Se desarma en tres piezas para el traslado.',59900,9,'usado','Metropolitana','Peñalolén','Sofía Riquelme','sofia.riquelme@correo.example',1,0,DATE_SUB(NOW(), INTERVAL 140 HOUR),87),
(18,'Set de 6 sillas de comedor restauradas','Madera maciza lijada, barnizada al agua y con tapiz nuevo color gris.','Juego de seis sillas de comedor de madera maciza, restauradas en mi taller: lijadas, barnizadas al agua y con tapiz nuevo en tela resistente color gris. Estructuras firmes, sin cojeras. Se venden solo las seis juntas. Puedo enviar fotos de detalle de cada una.',240000,2,'reacondicionado','Metropolitana','Macul','Taller Madera Viva','taller@maderaviva.example / +56 9 3388 5512',1,0,DATE_SUB(NOW(), INTERVAL 30 HOUR),163),
(19,'Consola portátil con dos juegos y estuche','Pantalla sin rayas, batería sana, se entrega formateada y con cuenta cerrada.','Consola portátil con dock, dos mandos laterales, cable HDMI y adaptador de corriente. La pantalla no tiene rayas porque usó mica desde el primer día, y la batería aguanta unas tres horas. Incluye estuche rígido y dos juegos físicos. Se entrega formateada.',279000,1,'usado','Antofagasta','Antofagasta','Matías Cortés','matias.cortes@correo.example',1,1,DATE_SUB(NOW(), INTERVAL 7 HOUR),498),
(20,'Impresora multifuncional con tinta continua','Imprime, escanea y copia por WiFi. Incluye cuatro botellas de tinta selladas.','Impresora multifuncional con sistema de tinta continua de fábrica: imprime, escanea y copia, y se conecta por WiFi. Incluye cuatro botellas de tinta selladas: negro, cian, magenta y amarillo. La usé para documentos de oficina, no para fotos. Cabezales limpios y sin atascos.',129000,1,'usado','Coquimbo','La Serena','Pablo Aguirre','pablo.aguirre@correo.example / +56 9 6655 9901',1,1,DATE_SUB(NOW(), INTERVAL 96 HOUR),144);
