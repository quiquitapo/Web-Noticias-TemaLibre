<?php
declare(strict_types=1);

/**
 * ventas.php — modo Ventas. Misma estructura que el buscador de noticias:
 * categorías a la izquierda, búsqueda arriba, filtros abajo.
 * Ver un aviso es libre; el contacto del vendedor exige sesión.
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/buscador.php';   // rangosTiempo() se comparte
require_once __DIR__ . '/includes/ventas.php';
require_once __DIR__ . '/includes/funciones.php';

iniciarSesionSegura();
purgarIntentos();

$filtros   = filtrosVentaDesdeGet($_GET);
$resultado = buscarVentas($filtros);
$conteos   = conteoPorCategoriaVenta();

$modoActual   = 'ventas';
$tituloPagina = ($filtros['q'] !== '' ? '“' . $filtros['q'] . '” · ' : '')
              . 'Ventas · ' . APP_NOMBRE;

require __DIR__ . '/includes/header.php';
?>

<div class="lienzo">

  <nav class="categorias" aria-label="Categorías de venta">
    <ul>
      <li>
        <a href="<?= e(urlModo('ventas.php', $filtros, ['cat' => '', 'p' => 1])) ?>"
           class="<?= $filtros['categoria_slug'] === '' ? 'actual' : '' ?>">Todas</a>
      </li>
      <?php foreach (categoriasVenta() as $cat): ?>
        <?php $activa = $filtros['categoria_slug'] === $cat['slug']; ?>
        <li>
          <a href="<?= e(urlModo('ventas.php', $filtros, ['cat' => $cat['slug'], 'p' => 1])) ?>"
             class="<?= $activa ? 'actual' : '' ?>" <?= $activa ? 'aria-current="page"' : '' ?>>
            <?= e($cat['nombre']) ?>
            <span class="conteo"><?= (int) ($conteos[$cat['id']] ?? 0) ?></span>
          </a>
        </li>
      <?php endforeach; ?>
    </ul>
  </nav>

  <main class="panel" id="contenido">
    <form method="get" action="ventas.php" id="forma-buscador" role="search">
      <input type="hidden" name="cat" value="<?= e($filtros['categoria_slug']) ?>">

      <div class="fila-busqueda">
        <?php if ($filtros['q'] !== ''): ?>
          <a class="limpiar-busqueda" href="<?= e(urlModo('ventas.php', $filtros, ['q' => '', 'p' => 1])) ?>">Borrar búsqueda</a>
        <?php endif; ?>
        <div class="buscador">
          <label class="oculto-visual" for="q">Buscar productos por texto o palabra clave</label>
          <input type="search" id="q" name="q" placeholder="Buscar productos"
                 value="<?= e($filtros['q']) ?>" maxlength="<?= MAX_LARGO_BUSQUEDA ?>"
                 autocomplete="off" spellcheck="false">
          <button type="submit" class="boton-lupa" aria-label="Buscar">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                 stroke-width="2" aria-hidden="true">
              <circle cx="11" cy="11" r="7"></circle><path d="M20 20l-3.6-3.6"></path>
            </svg>
          </button>
        </div>
      </div>

      <div class="resumen">
        <span>
          <strong><?= number_format($resultado['total'], 0, ',', '.') ?></strong>
          <?= $resultado['total'] === 1 ? 'aviso' : 'avisos' ?>
          <?php if ($filtros['q'] !== ''): ?> para <strong><?= e($filtros['q']) ?></strong><?php endif; ?>
          <?php if ($filtros['categoria_nombre'] !== ''): ?> en <strong><?= e($filtros['categoria_nombre']) ?></strong><?php endif; ?>
        </span>
        <span class="orden">
          <label for="orden">Ordenar</label>
          <span class="orden-caja">
          <select name="orden" id="orden">
            <?php foreach (ordenesVenta() as $clave => $op): ?>
              <?php if ($clave === 'relevancia' && $filtros['q'] === '') { continue; } ?>
              <option value="<?= e($clave) ?>" <?= $filtros['orden'] === $clave ? 'selected' : '' ?>><?= e($op['etiqueta']) ?></option>
            <?php endforeach; ?>
          </select>
          </span>
        </span>
      </div>

      <?php if ($resultado['items']): ?>
        <div class="lista-noticias">
          <?php foreach ($resultado['items'] as $v): ?>
            <?php $enlace = 'venta.php?id=' . (int) $v['id']; ?>
            <article class="noticia">
              <a class="miniatura" href="<?= e($enlace) ?>" aria-label="Ver aviso: <?= e($v['titulo']) ?>">
                <?= miniaturaSvg((int) $v['id'] + 100, (string) $v['categoria'], false) ?>
              </a>

              <div class="noticia-cuerpo">
                <h2><a href="<?= e($enlace) ?>"><?= resaltar((string) $v['titulo'], $filtros['terminos']) ?></a></h2>
                <p class="precio-destacado"><?= e(precioFormateado((int) $v['precio'], (string) $v['moneda'])) ?></p>
                <p><?= resaltar(extracto((string) $v['resumen'], 220), $filtros['terminos']) ?></p>
                <div class="meta">
                  <span class="etiqueta-estado estado-<?= e((string) $v['condicion']) ?>"><?= e(ucfirst((string) $v['condicion'])) ?></span>
                  <span class="meta-origen"><?= e($v['comuna']) ?></span>
                  <span><?= e($v['region']) ?></span>
                  <span class="separador">·</span>
                  <span><?= $v['envio'] ? 'Con envío' : 'Retiro en el lugar' ?></span>
                  <span class="separador">·</span>
                  <time datetime="<?= e(date('c', (int) strtotime((string) $v['publicada_en']))) ?>">
                    <?= e(fechaRelativa((string) $v['publicada_en'])) ?>
                  </time>
                </div>
              </div>
            </article>
          <?php endforeach; ?>
        </div>

        <?php if ($resultado['paginas'] > 1): ?>
          <nav class="paginacion" aria-label="Paginación">
            <?php if ($resultado['pagina'] > 1): ?>
              <a href="<?= e(urlModo('ventas.php', $filtros, ['p' => $resultado['pagina'] - 1])) ?>" rel="prev">Anterior</a>
            <?php else: ?><span class="inactivo">Anterior</span><?php endif; ?>
            <span class="posicion">Página <?= (int) $resultado['pagina'] ?> de <?= (int) $resultado['paginas'] ?></span>
            <?php if ($resultado['pagina'] < $resultado['paginas']): ?>
              <a href="<?= e(urlModo('ventas.php', $filtros, ['p' => $resultado['pagina'] + 1])) ?>" rel="next">Siguiente</a>
            <?php else: ?><span class="inactivo">Siguiente</span><?php endif; ?>
          </nav>
        <?php endif; ?>

      <?php else: ?>
        <div class="vacio">
          <h2>Sin resultados</h2>
          <p>Ningún aviso cumple a la vez todos los filtros aplicados.<br>
             Prueba con menos palabras, otro tramo de precio u otra región.</p>
          <ul>
            <li><a href="<?= e(urlModo('ventas.php', $filtros, ['precio' => '', 'p' => 1])) ?>">Quitar el filtro de precio</a></li>
            <li><a href="<?= e(urlModo('ventas.php', $filtros, ['region' => '', 'p' => 1])) ?>">Ver todas las regiones</a></li>
            <li><a href="ventas.php">Empezar de nuevo</a></li>
          </ul>
        </div>
      <?php endif; ?>

      <div class="filtros">
        <div class="filtro <?= $filtros['tiempo'] !== '' ? 'filtro-activo' : '' ?>">
          <label for="tiempo">Filtro tiempo</label>
          <select name="tiempo" id="tiempo">
            <option value="">Cualquier fecha</option>
            <?php foreach (rangosTiempo() as $clave => $rango): ?>
              <option value="<?= e($clave) ?>" <?= $filtros['tiempo'] === $clave ? 'selected' : '' ?>><?= e($rango['etiqueta']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="filtro <?= $filtros['precio'] !== '' ? 'filtro-activo' : '' ?>">
          <label for="precio">Filtro precio</label>
          <select name="precio" id="precio">
            <option value="">Cualquier precio</option>
            <?php foreach (tramosPrecio() as $clave => $tramo): ?>
              <option value="<?= e($clave) ?>" <?= $filtros['precio'] === $clave ? 'selected' : '' ?>><?= e($tramo['etiqueta']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="filtro <?= $filtros['region'] !== '' ? 'filtro-activo' : '' ?>">
          <label for="region">Ubicación</label>
          <select name="region" id="region">
            <option value="">Todo el país</option>
            <?php foreach (regionesVenta() as $reg): ?>
              <option value="<?= e($reg) ?>" <?= $filtros['region'] === $reg ? 'selected' : '' ?>><?= e($reg) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <button type="submit" class="boton-aplicar">Aplicar</button>
      </div>
    </form>
  </main>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
