<?php
declare(strict_types=1);

/**
 * logout.php — solo por POST y con token.
 * Si se pudiera cerrar sesión con un simple GET, bastaría con que alguien te
 * hiciera cargar <img src="...logout.php"> para echarte del sitio.
 */

require_once __DIR__ . '/includes/auth.php';

iniciarSesionSegura();
exigirPostSeguro();

cerrarSesion();

// Sesión nueva y limpia, solo para poder mostrar el mensaje de despedida.
iniciarSesionSegura();
rotarTokenCsrf();
$_SESSION['aviso_ok'] = 'Cerraste sesión. Puedes seguir buscando sin cuenta.';

irA('index.php');
